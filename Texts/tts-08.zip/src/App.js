import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import "primereact/resources/themes/lara-light-cyan/theme.css";

import { ToastContainer } from "react-toastify";

import "react-toastify/dist/ReactToastify.css";
import Header from "./Component/Header/Header";
import HomePage from "./Pages/HomePage";
import Footer from "./Component/Footer/Footer";

import Product from "./Pages/Product/Product";
import Cart from "./Pages/Product/Cart";
import AddToCart from "./Pages/Product/AddToCart";
// import OrderReview from './Pages/Product/OrderReview';
import Wishlist from "./Pages/Product/Wishlist";
import MyOrders from "./Pages/Product/MyOrders";
import TrackOrder from "./Pages/Product/TrackOrder";
import Categories from "./Pages/Product/Categories";
import Signinpage from "./Component/Loginpage/Signinpage";
import Forgot from "./Component/Loginpage/Forgot";
import Profile from "./Component/Profilepage/Profile";
import Notifications from "./Component/Profilepage/Notifications";
import OffersCoupon from "./Component/Profilepage/OffersCoupon";
import ChooseLanguage from "./Component/Profilepage/ChooseLanguage";
import LegalPolicies from "./Component/Profilepage/LegalPolicies";
import Sidebars from "./Component/Profilepage/Sidebars";
import ProfileEdit from "./Component/Profilepage/ProfileEdit";
import Register from "./Component/Loginpage/Register";
import Otp from "./Component/Loginpage/Otp";
import Orders from "./Component/Profilepage/Orders";
import Profilelabel from "./Component/Profilepage/Profilelabel";
import WishlistProfile from "./Component/Profilepage/WishlistProfile";
import AddressManagement from "./Component/Profilepage/AddressManagement";
import Address from "./Component/Profilepage/Address";
import OrderTrack from "./Component/Profilepage/order/OrderTrack";
import ProductCard from "./Component/productCard/ProductCard";
import ProfilePage from "./Pages/profilePage/ProfilePage";

function App() {
  return (
    <>
      <BrowserRouter basename="/ecommerce">
        <Routes>
          <Route path="signin" element={<Signinpage />} />
          <Route path="forgot" element={<Forgot />} />
          <Route path="register" element={<Register />} />
          <Route path="otp" element={<Otp />} />
          <Route path="profile" element={<Profile />} />
          <Route path="profileedit" element={<ProfileEdit />} />
          <Route path="profilelabel" element={<Profilelabel />} />
          <Route path="wishlistprofile" element={<WishlistProfile />} />
          <Route path="addressmanagement" element={<AddressManagement />} />
          <Route path="address" element={<Address />} />

          <Route path="notification" element={<Notifications />} />
          <Route path="order" element={<Orders />} />
          <Route path="offersCoupon" element={<OffersCoupon />} />
          <Route path="chooselanguage" element={<ChooseLanguage />} />
          <Route path="legalpolicies" element={<LegalPolicies />} />
          <Route path="sidebar" element={<ProfilePage />} />
          {/* <Route path="pro" element={<ProfilePage />} /> */}
          <Route path="header" element={<Header />} />
          {/* <Route index element={< Footer/>} /> */}
          <Route path="/" element={<HomePage />} />
          <Route path="product" element={<Product />} />
          {/* <Route path="product/:id" element={<Product />} /> */}
          {/* <Route path="/product/:category_id" element={<Product />} /> */}
          {/* <Route path="/product/:category_id/:subcategory_id" element={<Product />} /> */}
          <Route path="cart" element={<Cart />} />
          <Route path="addtocart" element={<AddToCart />} />
          {/* <Route path="orderreview" element={<OrderReview />} /> */}
          <Route path="wishlist" element={<Wishlist />} />
          <Route path="myorders" element={<MyOrders />} />
          <Route path="trackorder" element={<TrackOrder />} />
          <Route path="categories" element={<Categories />} />
          <Route path="footers" element={<Footer />} />
          <Route path="order_track" element={<OrderTrack />} />
          {/* <Route path="*" element={<NoPage />} />  */}
        </Routes>
      </BrowserRouter>
      <ToastContainer position="top-center" autoClose={1000} />
    </>
  );
}

export default App;
