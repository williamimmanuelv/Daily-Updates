// export const base_url="http://127.0.0.1:8000/api/admin";
export const base_url="https://rooptek.com/ttsbrothers/api";


// export const img_path="https://rooptek.com/ttsbrothers/storage"
export const img_path="https://rooptek.com/ttsbrothers/storage/uploads"