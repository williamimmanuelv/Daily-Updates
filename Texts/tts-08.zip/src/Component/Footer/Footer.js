import React, { useEffect, useState } from 'react'
import "./footer.css"
import logo from "../../Assets/logo.png"
import appstore from "../../Assets/Store download button (1).png"
import googleapp from "../../Assets/Store download button.png"
import { IoLogoInstagram } from "react-icons/io5";
import { TiSocialFacebook } from "react-icons/ti"
import { CiLinkedin } from "react-icons/ci";
import { RiTwitterXLine } from "react-icons/ri";
import { base_url } from '../../BaseUrls/BaseUrl'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'


const Footer = () => {

  const navigate = useNavigate()
  const [fetchcategorys, setFetchcategorys] = useState([])
  console.log("fetchcategorysss", fetchcategorys)


  const fetchcategory = async () => {
    try {
      const response = await axios.get(`${base_url}/category`);
      setFetchcategorys(response.data);
      // console.log("response.data", response.data);
    } catch (error) {
      // console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchcategory();
  }, []);

  //  const editcategory =(id)=>{
  // navigate('/product',{state: id})
  // }
  const editcategory = (categoryId) => {
    console.log("categoryIdhhhhh", categoryId)
    navigate("/product", { state: { categoryId } });
  };
  return (
    //    <footer className="bg-dark text-white pt-5 pb-4">
    // <div className="container ">
    //   <div className="row gy-4 ">


    //     <div className="col-6 col-md-6 col-lg-3 footer_family">
    //       <h5 className="fw-bold text_underline ani pb-3">Quick Links</h5>
    //      <ul className="list-unstyled ">
    //         <li className="mb-3 text_underline">
    //          <span className="">Home</span>
    //         </li>
    //         <li className="mb-3 text_underline">
    //           <span className="">About US</span>
    //         </li>
    //         <li className="mb-3 text_underline">
    //          <span className="">Product</span>
    //         </li>
    //           <li className=" mb-3 text_underline">
    //          <span className="">FAQ</span>
    //         </li>
    //           <li className="mb-3 text_underline">
    //          <span className="">Contact US</span>
    //         </li>
    //       </ul>

    //     </div>


    //     <div className="col-6 col-md-6 col-lg-3 ">
    //       <h5 className="fw-bold pb-3">Our Category</h5>
    //       <ul className="list-unstyled">
    //         <li className="mb-3 text_underline">
    //          <span className="">Vegetables</span>
    //         </li>
    //         <li className="mb-3 text_underline">
    //           <span className="">Grocery</span>
    //         </li>
    //         <li className="mb-3 text_underline">
    //          <span className="">Vessel</span>
    //         </li>
    //           <li className=" mb-3 text_underline">
    //          <span className="">Garments</span>
    //         </li>
    //           <li className="mb-3 text_underline">
    //          <span className="">Rose Gold</span>
    //         </li>
    //       </ul>
    //     </div>


    //     <div className="col-6 col-md-6 col-lg-3">
    //       <h5 className="fw-bold pb-3">Top Sell Product</h5>
    //        <ul className="list-unstyled">
    //         <li className="mb-3 text_underline">
    //          <span className="">Turmeric Powder</span>
    //         </li>
    //         <li className="mb-3 text_underline">
    //           <span className="">Cardamom</span>
    //         </li>
    //         <li className="mb-3 text_underline">
    //          <span className="">Quartz Watch</span>
    //         </li>
    //           <li className=" mb-3 text_underline">
    //          <span className="">Tomato</span>
    //         </li>
    //           <li className="mb-3 text_underline">
    //          <span className="">Guava</span>
    //         </li>
    //       </ul>
    //     </div>


    //     <div className="col-6 col-md-6 col-lg-3">
    //       <h5 className="fw-bold pb-3">Today Discount</h5>
    //         <ul className="list-unstyled">
    //         <li className="mb-3 text_underline">
    //          <span className="">10% Discount</span>
    //         </li>
    //         <li className="mb-3 text_underline">
    //           <span className="">20% Discount</span>
    //         </li>
    //         <li className="mb-3 text_underline">
    //          <span className="">60% Discount</span>
    //         </li>
    //            </ul>
    //     </div>
    //   </div>

    //   <hr className="my-4 text-white" />


    //   <div className="row align-items-center text-center text-md-start">
    //     <div className="col-md-2 mb-3 mb-md-0">
    //      <img src={logo}  alt='' className='w-50'  />
    //     </div>
    //     <div className="col-md-8 d-flex justify-content-center footer_family">
    //       <div className='d-flex ps-5 ms-5'>
    //         <h5 className="mb-0  text-white">Today Discount</h5>
    //      <img src={appstore}  alt='' className='px-2'  />
    //      <img src={googleapp}  alt='' className='px-2'  />
    //       </div>



    //     </div>
    //     <div className='col-md-2'>
    //       <IoLogoInstagram  size={25} className='mx-2'/>
    //       <TiSocialFacebook size={25} className='mx-2'/>
    //       <RiTwitterXLine size={20} className='mx-2'/>
    //       <CiLinkedin  size={25} className='mx-2'/>

    //     </div>
    //     <p className='mt-3'>By continuing past this page, you agree to our Terms of Service, Cookie Policy, 
    //       Privacy Policy and Content Policies. All trademarks are properties of their respective owners<br/> 
    //       2008-2025 © Gharuda Infotech Pvt Ltd. All rights reserved</p>
    //   </div>
    // </div>
    //   </footer>

    <footer className="footer_bgcolor text-white pt-5 pb-4">
      <div className="container">
        <div className="row gy-4">

          <div className="col-6 col-md-6 col-lg-3 footer_family">
            <h5 className="fw-bold text_underline ani pb-3">Quick Links</h5>
            <ul className="list-unstyled">
              {["Home", "About US", "Product", "FAQ", "Contact US"].map((item, idx) => (
                <li className="mb-3 text_underline"style={{ cursor: "pointer" }} key={idx}>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="col-6 col-md-6 col-lg-3 footer_family">
            <h5 className="fw-bold pb-3">Our Category</h5>
            <ul className="list-unstyled"style={{ cursor: "pointer" }} >
              {fetchcategorys?.length > 0 ? (
                fetchcategorys.map((item) => (

                  <li
                    className="mb-3 text_underline"
                    onClick={(e) => {
                      e.preventDefault();
                      editcategory(item.id);
                    }}

                  >
                    <span>{item.title} </span>
                  </li>
                ))
              ) : (
                <div className="text-center text-muted">No categories available</div>
              )}

            </ul>
          </div>
          <div className="col-6 col-md-6 col-lg-3 footer_family">
            <h5 className="fw-bold pb-3">Top Sell Product</h5>
            <ul className="list-unstyled">
              {["Turmeric Powder", "Cardamom", "Quartz Watch", "Tomato", "Guava"].map((item, idx) => (
                <li className="mb-3 text_underline"style={{ cursor: "pointer" }} key={idx}>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="col-6 col-md-6 col-lg-3 footer_family">
            <h5 className="fw-bold pb-3">Today Discount</h5>
            <ul className="list-unstyled">
              {["10% Discount", "20% Discount", "60% Discount"].map((item, idx) => (
                <li className="mb-3 text_underline"style={{ cursor: "pointer" }} key={idx}>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <hr className="my-4 text-white" />


        <div className="row align-items-center text-center text-md-start">

          <div className="col-md-2 mb-3 mb-md-0">
            <img src={logo} alt="Logo" className="w-50 footer_logo" />
          </div>


          <div className="col-md-8 d-flex flex-column flex-md-row justify-content-center align-items-center footer_family">
            {/* <h5 className="mb-2 mb-md-0 text-white me-3">Today Discount</h5> */}
            <img src={appstore} alt="App Store" className="px-2" />
            <img src={googleapp} alt="Google Play" className="px-2" />
          </div>


          <div className="col-md-2 d-flex justify-content-center justify-content-md-start mt-3 mt-md-0">
            <IoLogoInstagram size={25} className="mx-2" />
            <TiSocialFacebook size={25} className="mx-2" />
            <RiTwitterXLine size={20} className="mx-2" />
            <CiLinkedin size={25} className="mx-2" />
          </div>
        </div>
        <p className="mt-4  small">
          By continuing past this page, you agree to our Terms of Service, Cookie Policy,
          Privacy Policy and Content Policies. All trademarks are properties of their respective owners.<br />
          2008–2025 © Gharuda Infotech Pvt Ltd. All rights reserved.
        </p>
      </div>
    </footer>


  )
}

export default Footer