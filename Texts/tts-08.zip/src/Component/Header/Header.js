import React, { useEffect, useState } from "react";
import logo from "../../Assets/logo.png";
import { FcMenu } from "react-icons/fc";

import "./header.css";
import { IoIosSearch } from "react-icons/io";
//  import { Dropdown } from 'primereact/dropdown';
//  import FaSearch from ''
import { HiOutlineLocationMarker } from "react-icons/hi";
import { CiHeart } from "react-icons/ci";
import { HiOutlineBell } from "react-icons/hi";
import { HiOutlineShoppingBag } from "react-icons/hi2";
import { CgMenu } from "react-icons/cg";
//  import { GoDotFill } from "react-icons/go";
import { IoIosArrowDown } from "react-icons/io";
import { Link, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import Toast from "../../Untils/Toast";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import * as yup from "yup";
import { CgProfile } from "react-icons/cg";
import { IoTimeOutline } from "react-icons/io5";
import { RxCross2 } from "react-icons/rx";
import Common from "../../common/Common";
import { setDeliveryType } from "../../store/cartSlice";
import { useDispatch, useSelector } from "react-redux";
import { Menubar } from 'primereact/menubar';

const Header = () => {
  const [fetchcategorys, setFetchcategorys] = useState([]);
  const dynamicItems = fetchcategorys?.map((item) => ({
    label: item.title,
    icon: "pi pi-folder",
    items: item.subcategories?.map((sub) => ({
      label: sub.sub_title,
      icon: "pi pi-angle-right",
      command: () => editsubcategory(sub.id)
    })) || []
  }));

  const navigate = useNavigate();

  const { favoriteData, cartCount, deliveryType } = Common();
  console.log("cartCount", cartCount);



  const dispatch = useDispatch();

  //  const [selectedCity, setSelectedCity] = useState(null);
  //   const cities = [
  //       { name: 'New York', code: 'NY' },
  //       { name: 'Rome', code: 'RM' },
  //       { name: 'London', code: 'LDN' },
  //       { name: 'Istanbul', code: 'IST' },
  //       { name: 'Paris', code: 'PRS' }
  //   ];

  const lll = localStorage.getItem("selectedRoute");
  console.log("llll", lll);
  const ppp = localStorage.getItem("selectedTitle");
  console.log("pppsss", ppp);
  const user_id = localStorage.getItem("user_id");
  const token = localStorage.getItem("token");
  console.log("token", token);
  const name = localStorage.getItem("name");

  //    const handleLogout = () => {
  //   localStorage.removeItem("token");
  //   localStorage.removeItem("name");
  //   navigate("/signin");
  // };

  const fetchcategory = async () => {
    try {
      const response = await axios.get(`${base_url}/category`);
      setFetchcategorys(response.data);
      // console.log("response.data", response.data);
    } catch (error) { }
  };

  useEffect(() => {
    fetchcategory();
  }, []);

  const updateDeliveryType = async (deliveryType) => {
    dispatch(setDeliveryType(deliveryType));
    try {
      if (!user_id) throw new Error("User not found");
      const payload = {
        user_id: user_id,
        delivery_type: deliveryType,
      };

      const response = await axios.post(
        `${base_url}/update-delivery-type`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    } catch (error) {
      const errorMessage =
        error.response?.data?.message || "Failed to update delivery type";
    }
  };

  const [searchKey, setSearchKey] = useState("");
  const [fetchSearchs, setFetchSearchs] = useState([]); // suggestions
  const [fetchSearchProducts, setFetchSearchProducts] = useState([]);
  const [fetchSearchHistory, setFetchSearchHistory] = useState([]);
  console.log("fetchSearchHistory", fetchSearchHistory);
  const [showHistory, setShowHistory] = useState(false);

  // Fetch search suggestions
  const fetchSearch = async (key) => {
    try {
      const response = await axios.get(`${base_url}/search/suggest`, {
        params: { search_key: key },
        headers: {
          "tts-user-id": user_id,
        },
      });
      if (response.data && Array.isArray(response.data.result)) {
        setFetchSearchs(response.data.result);
      } else {
        setFetchSearchs([]);
      }
    } catch (error) { }
  };

  const fetchSearchHistorys = async (key) => {
    try {
      const response = await axios.get(`${base_url}/search/history`, {
        headers: {
          "tts-user-id": user_id,
        },
      });
      if (response.data && Array.isArray(response.data.history)) {
        setFetchSearchHistory(response.data.history);
      } else {
        setFetchSearchHistory([]);
      }
    } catch (error) { }
  };
  console.log("setFetchSearchHistory", setFetchSearchHistory);

  useEffect(() => {
    fetchSearchHistorys();
  }, []);

  const fetchSearchHistoryRemove = async (id) => {
    console.log("idss", id);
    try {
      const payload = {
        id: id,
      };
      const response = await axios.post(
        `${base_url}/search/history/remove`,
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      fetchSearchHistorys();
    } catch (error) { }
  };

  //  Fetch actual products
  const fetchSearchProduct = async (filters = {}) => {
    const user_id = localStorage.getItem("user_id");

    try {
      const response = await axios.get(`${base_url}/search/products`, {
        params: {
          // user_id: user_id || "",
          keyword: filters.keyword || "",
          category: filters.category || "",
          subcategory: filters.subcategory || "",
          brand: filters.brand || "",
          min_price: filters.min_price || "",
          max_price: filters.max_price || "",
          discount_min: filters.discount_min || "",
          in_stock: filters.in_stock || "",
          sort: filters.sort || "",
        },
        headers: {
          "tts-user-id": user_id,
        },
      });

      if (response.data && Array.isArray(response.data.results)) {
        setFetchSearchProducts(response.data.results);
      } else {
        setFetchSearchProducts([]);
      }
    } catch (error) { }
  };
  useEffect(() => {
    fetchSearchProduct();
  }, []);

  //  Navigate with value
  const productSearch = (searchId) => {
    navigate("/product", { state: { searchId } });
  };

  //  Debounce suggestion fetch
  useEffect(() => {
    const delayDebounce = setTimeout(() => {
      if (searchKey.trim() !== "") {
        fetchSearch(searchKey);
      } else {
        setFetchSearchs([]);
      }
    }, 400);
    return () => clearTimeout(delayDebounce);
  }, [searchKey]);

  //  Handle suggestion click
  const handleSuggestionClick = (item) => {
    setSearchKey(item);
    setFetchSearchs([]);
    fetchSearchProduct({ keyword: item });
    productSearch(item); //  navigate immediately with selected item
  };

  //  Press Enter → fetch + navigate
  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      fetchSearchProduct({ keyword: searchKey });
      productSearch(searchKey);
      setFetchSearchs([]);
    }
  };

  const [wishlistCounts, setWishlistCounts] = useState(0);
  console.log("wishlistCountssss", wishlistCounts);

  const handleWishlistCount = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const response = await axios.post(
        `${base_url}/wishlist/count`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      // navigate('/addtocart')

      // console.log("response.data", response.data);
      //  Directly set the numeric count
      if (response.data?.count !== undefined) {
        setWishlistCounts(response.data.count);
        // console.log("wishh.data.cartCount", response.data.count)
      }
    } catch (error) {
      // console.error("Error adding to cart", error);
    }
  };

  useEffect(() => {
    handleWishlistCount();
  }, []);

  const [cartCounts, setCartCounts] = useState(0);
  console.log("cartCountsssssssss", cartCounts);

  const handleAddToCartproduct = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const response = await axios.post(
        `${base_url}/cart/count`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      // navigate('/addtocart')

      // console.log("response.data", response.data);
      //  Directly set the numeric count
      if (response.data?.cartCount !== undefined) {
        setCartCounts(response.data.cartCount);
      }
    } catch (error) { }
  };

  useEffect(() => {
    handleAddToCartproduct();
  }, []);

  //    const editsubcategory =(id)=>{
  //     console.log("idheader",id)
  // navigate('/product',{state: id})
  // }

  //  const editsubcategory = (subcategoryId) => {
  //   console.log("subcategoryId",subcategoryId)

  //   navigate("/product", { state: { subcategoryId } });
  // };

  const editsubcategory = (subcategoryId) => {
    console.log("categoryIdssss", subcategoryId);
    navigate("/product", { state: { subcategoryId } });
  };
  const handleNavigate = () => {
    if (!token) {
      navigate("/signin");
    } else {
      navigate("/wishlist");
    }
  };

  return (
    <>
      <div className="header_bgcolor p-1">
        <div className="container">
          <div className="row align-items-center g-3">
            {/* Logo */}
            <div className="col-12 col-md-2 text-center text-md-start">
              <Link to="/" className="text-decoration-none">
                <img
                  src={logo}
                  alt="Logo"
                  className="img-fluid"
                  style={{ maxHeight: "60px", objectFit: "contain" }}
                />
              </Link>
            </div>

            {/* Search + Dropdown */}
            <div className="col-12 col-md-4 col-lg-5 col-xl-5 ps-5 position-relative">
              {/* Input */}
              <div className="input-group search-input-group " style={{ cursor: "pointer", }}>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search for anything"
                  aria-label="Search"
                  value={searchKey}
                  onChange={(e) => setSearchKey(e.target.value)}
                  onKeyDown={handleKeyDown}
                  onClick={() => setShowHistory(true)} // SHOW HISTORY WHEN CLICK
                  onBlur={() => setTimeout(() => setShowHistory(false), 200)} // HIDE AFTER CLICK OUTSIDE
                />
                <span className="input-group-text searchbg">
                  <IoIosSearch
                    color="white"
                    size={20}
                    onClick={() => {
                      fetchSearchProduct({ keyword: searchKey });
                      productSearch(searchKey); //  use searchKey to navigate
                    }}
                  />
                </span>
              </div>

              {/* Suggestions */}
              {fetchSearchs.length > 0 && (
                <ul
                  className="list-group position-absolute mt-2 shadow-sm w-100"
                  style={{ zIndex: 999 }}
                >
                  {fetchSearchs.map((item, index) => (
                    <li
                      key={index}
                      className="list-group-item list-group-item-action"
                      style={{ cursor: "pointer" }}
                      onClick={() => handleSuggestionClick(item)}
                    >
                      {item}
                    </li>
                  ))}
                </ul>
              )}
              {/* SHOW SEARCH HISTORY */}
              {/* {showHistory && searchKey.trim() === "" && fetchSearchHistory.length > 0 && (
  <ul
    className="list-group position-absolute mt-2 shadow-sm w-100"
    style={{ zIndex: 999 }}
  >
    {fetchSearchHistory.map((item, index) => (
      <li
        key={index}
        className="list-group-item list-group-item-action d-flex align-items-center gap-2"
        style={{ cursor: "pointer" }}
        onClick={() =>handleSuggestionClick(item)}
      >
        <IoTimeOutline size={18} color="#888" />
        <span>{item}</span>
         <RxCross2
    size={20}
    className="ms-auto"
    onClick={() => {
     
      fetchSearchHistoryRemove(item.id);
    }}
  />
      </li>
    ))}
  </ul>
   )} */}
              {showHistory &&
                searchKey.trim() === "" &&
                fetchSearchHistory.length > 0 && (
                  <ul
                    className="list-group position-absolute mt-2 shadow-sm w-100"
                    style={{ zIndex: 999 }}
                  >
                    {fetchSearchHistory.map((item, index) => (
                      <li
                        key={index}
                        className="list-group-item list-group-item-action d-flex align-items-center"
                        style={{ cursor: "pointer" }}
                        onClick={() => handleSuggestionClick(item.keyword)}
                      >
                        <IoTimeOutline size={18} color="#888" />

                        {/* show keyword text */}
                        <span className="ms-2">{item.keyword}</span>

                        {/* delete icon right side */}
                        <RxCross2
                          size={20}
                          className="ms-auto"
                          onClick={(e) => {
                            e.stopPropagation(); // prevent item click
                            fetchSearchHistoryRemove(item.id);
                          }}
                        />
                      </li>
                    ))}
                  </ul>
                )}
            </div>

            <div
              className="col-12 col-md-3 col-lg-2 col-xl-2 text-white d-flex align-items-center justify-content-center justify-content-md-end gap-5 ms-lg-5"
              style={{ cursor: "pointer" }}
            >
              {/* <CiHeart size={25} className='ms-3' onClick={() => navigate('/wishlist')} /> */}

              <div className="position-relative">
                <CiHeart
                  size={24}
                  color="#fff"
                  onClick={() => handleNavigate()}
                />

                {token && favoriteData.length > 0 && (
                  <span
                    className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
                    style={{ fontSize: "0.7rem" }}
                  >
                    {favoriteData?.length}
                  </span>
                )}
              </div>
              <HiOutlineBell size={23} color="#fff" />
              {/* <HiOutlineShoppingBag size={20} /> */}
              <div className="position-relative">
                <HiOutlineShoppingBag
                  size={24}
                  color="#fff"
                  // onClick={handleAddToCartproduct}
                  onClick={() => {
                    handleAddToCartproduct();
                    navigate("/addtocart");
                  }}
                />
                {cartCount !== 0 && (
                  <span
                    className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"
                    style={{ fontSize: "0.7rem" }}
                  >
                    {/* {cartCounts} */}
                    {cartCount}{" "}
                  </span>
                )}
              </div>
            </div>

            {/* Login Button */}
            <div className="col-12 col-sm-2 col-md-3 col-lg-2 col-xl-2 text-center text-md-end ms-lg-4 ms-md-0">
              {token ? (
                <div
                  className="d-flex align-items-center justify-content-center text-white gap px-5"
                  style={{ cursor: "pointer" }}
                  onClick={() => navigate("/sidebar")}

                //  onClick={() => navigate(token ? "/sidebar" : "/signin")}
                >
                  <div>
                    <CgProfile
                      size={20}
                      className="text-white"
                    // onClick={() => navigate('/signin')}
                    />
                  </div>
                  <div>
                    <button
                      className="btn btn-sm  text-white fs-5 pt-2 text-nowrap  "
                    >
                      {name}
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  className="btn searchbg text-white fw-bold"
                  onClick={() => navigate("/signin")}
                >
                  Login
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      <div className="header_menubgcolor py-lg-0 py-md-0">
        <div className="container py-lg-0 py-md-0">
          <div className="row align-items-center justify-content-between">
            {/* LEFT: Navbar */}
            <div className="col-12 col-md-10 col-lg-10 col-xl-10 p-md-0 p-lg-0">
              {/* <nav className="navbar navbar-expand-lg navbar-dark">
                <div className="container-fluid p-0">
                  <button
                    className="navbar-toggler"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarNav"
                    aria-controls="navbarNav"
                    aria-expanded="false"
                    aria-label="Toggle navigation"
                  >
                    <FcMenu color="#fff" />
                  </button>

                  <div className="collapse navbar-collapse" id="navbarNav">
                    <ul className="navbar-nav header_text">
                   
                      <li className="nav-item">
                        <a
                          href="#"
                          className="nav-link fw-semibold text-white pt-2"
                          onClick={(e) => {
                            e.preventDefault();
                            navigate("/product");
                          }}
                        >
                          All
                        </a>
                      </li>

                    
                       {fetchcategorys?.length > 0 ? (
                        fetchcategorys.map((item) => (
                          <li
                            key={item.id}
                            className="nav-item dropdown position-static mx-1"
                          >
                            <a
                              className="nav-link fw-semibold text-white d-flex align-items-center text-nowrap"
                              href="#"
                              id={`dropdown-${item.id}`}
                              role="button"
                              data-bs-toggle="dropdown"
                              aria-expanded="false"
                            >
                              {item.title}
                              <IoIosArrowDown className="ms-1" />
                            </a>

                             MEGA MENU CONTENT 
                            <div
                              className="dropdown-menu mega-menu border-0 mt-3 shadow  w-25"
                              aria-labelledby={`dropdown-${item.id}`}
                            >
                              <div className="container">
                                <div className="row">
                                  {item.subcategories?.length > 0 ? (
                                    item.subcategories.map((sub) => (
                                      <div
                                        key={sub.id}
                                        className="col-12  mb-3"
                                      >
                                        <a
                                          href="#"
                                          onClick={(e) => {
                                            e.preventDefault();
                                            editsubcategory(sub.id);
                                          }}
                                          className="dropdown-item fw-semibold text-dark"
                                        >
                                          {sub.sub_title}
                                        </a>
                                      </div>
                                    ))
                                  ) : (
                                    <div className="col-12 text-muted text-center">
                                      No subcategories
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </li>
                        ))
                      ) : (
                        <div className="text-center text-muted">
                          No categories available
                        </div>
                      )} 
                      
                    </ul>

                  </div>
                </div>
              </nav> */}
              <div className="p-menubar">
                        {/* <Menubar model={dynamicItems} /> */}
                        <Menubar
                          model={[
                            {
                              label: "All",
                              command: () => navigate("/product"),
                            },
                            ...dynamicItems
                          ]}
                          className="main-menubar"
                        />
                      </div>

            </div>

            {/* RIGHT: Delivery / Pickup */}
            <div className="col-12 col-sm-4 col-md-4 text-center text-md-end col-lg-2 col-xl-2 mt-md-0 p-md-0 p-lg-0">
              <div className=" d-flex  d-inline-flex border  justify-content-center rounded-3 overflow-hidden">

                <button
                  type="button"
                  onClick={() => {
                    // setIsDelivery(true);
                    updateDeliveryType("delivery");
                    localStorage.setItem("deliveryType", "delivery");
                    window.dispatchEvent(new Event("deliveryTypeChanged"));
                  }}
                  className={`px-3 py-1 fw-bold border-0 ${deliveryType === "delivery"
                      ? "searchbg text-white"
                      : "header_deliverycolor text-dark"
                    }`}
                >
                  Delivery
                </button>

                <button
                  type="button"
                  onClick={() => {
                    // setIsDelivery(false);
                    updateDeliveryType("pickup");
                    localStorage.setItem("deliveryType", "pickup");
                    window.dispatchEvent(new Event("deliveryTypeChanged"));
                  }}
                  className={`px-3 py-1 fw-bold border-0 ${deliveryType === "pickup"
                      ? "searchbg text-white"
                      : "header_deliverycolor text-dark"
                    }`}
                >
                  Pickup
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <div className="header_bgcolor p-3">
      <div className="container">
        <div className="row align-items-center g-3">
        
          <div className="col-12 col-md-3 text-center text-md-start">
            <img
              src={logo}
              alt="Logo"
              className="img-fluid"
              style={{ maxHeight: '50px',objectFit:"cover" }}
            />
          </div>

      
          <div className="col-12 col-md-6">
            <div className="input-group">
              <span className="input-group-text bg-white">
                <IoIosSearch />
              </span>

              <input
                type="text"
                className="form-control"
                placeholder="Search for anything"
                aria-label="Search"
              />

              <button
                className="btn header_search text-dark fw-semibold btn-outline-secondary dropdown-toggle"
                type="button"
                data-bs-toggle="dropdown"
                aria-expanded="true"
              >
                All Categories
              </button>

              <ul className="dropdown-menu">
                <li>
                  <a className="dropdown-item" href="#">
                    Action
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    Another action
                  </a>
                </li>
                <li>
                  <a className="dropdown-item" href="#">
                    Something else here
                  </a>
                </li>
              </ul>
              
            </div>
          </div>

      
          <div className="col-12 col-md-3 text-center text-md-end">
            <button className="btn header_color text-white fw-bold">Login</button>
          </div>
        </div>

    

         <div className="row align-items-center justify-content-between mt-1 ">
       
          <div className="col-6  col-sm-end col-md-8">
            <nav className="navbar navbar-expand-lg navbar-dark">
              <div className="container-fluid p-0">
                <button
                  className="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarNav"
                  aria-controls="navbarNav"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
             
                  <FcMenu />
                </button>

                <div className="collapse navbar-collapse" id="navbarNav">
                  <ul className="navbar-nav header_text ">
                  
                    <li className="nav-item dropdown mx-2 ">
                      <a
                        className="nav-link dropdown-toggle fw-semibold text-white"
                        href="#"
                        id="homeDropdown"
                        data-bs-toggle="dropdown"
                         data-bs-target="#navbarNav"
                        aria-expanded="false"
                      >
                        Vegetables
                      </a>
                      <div className="dropdown-menu main-menu border-0 mt-3 shadow p-0">
                           <div className="container py-3">
                    <div className="row">
                      <div className="col-12" style={{lineHeight:"25px"}}>
                           <a className="dropdown-item " href="#">Landing page</a>
                         <a className="dropdown-item" href="">ClassNameic</a>
                        <a className="dropdown-item" href="">One page</a>
                        </div>
                        </div>
                        </div>
                      </div>
                    </li>
                    
                         <li className="nav-item dropdown mx-2 ps-5">
                      <a
                        className="nav-link dropdown-toggle fw-semibold text-white"
                        href="#"
                        id="homeDropdown"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Grocery
                      </a>
                      <div className="dropdown-menu main-menu border-0 mt-3 shadow p-0">
                           <div className="container py-3">
                    <div className="row">
                      <div className="col-12" style={{lineHeight:"25px"}}>
                           <a className="dropdown-item" href="#">Landing page</a>
                         <a className="dropdown-item" href="">ClassNameic</a>
                        <a className="dropdown-item" href="">One page</a>
                        </div>
                        </div>
                        </div>
                      </div>
                    </li>

                     <li className="nav-item dropdown mx-2 ps-5">
                      <a
                        className="nav-link dropdown-toggle  fw-semibold text-white"
                        href="#"
                        id="homeDropdown"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Vessel
                      </a>
                      <div className="dropdown-menu main-menu border-0 mt-3 shadow p-0">
                           <div className="container py-3">
                    <div className="row">
                      <div className="col-12" style={{lineHeight:"25px"}}>
                           <a className="dropdown-item" href="#">Landing page</a>
                         <a className="dropdown-item" href="">ClassNameic</a>
                        <a className="dropdown-item" href="">One page</a>
                        </div>
                        </div>
                        </div>
                      </div>
                    </li>
                       <li className="nav-item dropdown mx-2 ps-5">
                      <a
                        className="nav-link dropdown-toggle  fw-semibold text-white"
                        href="#"
                        id="homeDropdown"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Garments
                      </a>
                      <div className="dropdown-menu main-menu border-0 mt-3 shadow p-0">
                           <div className="container py-3">
                    <div className="row">
                      <div className="col-12" style={{lineHeight:"25px"}}>
                           <a className="dropdown-item" href="#">Landing page</a>
                         <a className="dropdown-item" href="">ClassNameic</a>
                        <a className="dropdown-item" href="">One page</a>
                        </div>
                        </div>
                        </div>
                      </div>
                    </li>
                    <li className="nav-item dropdown mx-2 ps-5">
                      <a
                        className="nav-link dropdown-toggle  fw-semibold text-white"
                        href="#"
                        id="homeDropdown"
                        data-bs-toggle="dropdown"
                        aria-expanded="false"
                      >
                        Rose Gold
                      </a>
                      <div className="dropdown-menu main-menu border-0 mt-3 shadow p-0">
                           <div className="container py-3">
                    <div className="row">
                      <div className="col-12" style={{lineHeight:"25px"}}>
                           <a className="dropdown-item" href="#">Landing page</a>
                         <a className="dropdown-item" href="">ClassNameic</a>
                        <a className="dropdown-item" href="">One page</a>
                        </div>
                        </div>
                        </div>
                      </div>
                    </li>

                  </ul>
                </div>
              </div>
            </nav>
          </div>

        
          <div className="col-6 col-md-2 text-white text-center">
            <HiOutlineLocationMarker className="me-1 fs-5 " />
            <span style={{ fontSize: '0.9rem' }}>
             <span className='fw-semibold'>Deliver to </span> <br />
              Berlin
            </span>
          </div>

          <div className="col-12 col-md-2 text-white d-flex align-items-center gap-5">
            <CiHeart size={26} className='ms-3' />
            <HiOutlineBell size={24} />
            <HiOutlineShoppingBag size={21} />
          </div>
        </div>

      </div>
    </div> */}
    </>
  );
};

export default Header;
