import React from 'react'
import loginfruit from "../../Assets/Mask group (46).png"

const Forgot = () => {
  return (
    <>
     <div className="body_bgcolor min-vh-100 d-flex justify-content-center align-items-center">
  <div className="bg-dark rounded-4  p-3 w-100" style={{ maxWidth: "800px" }}>
    <div className="row g-0">
    
      <div className="col-md-6 d-flex align-items-center justify-content-center">
        <img src={loginfruit} alt="fruit" className="img-fluid rounded" />
      </div>

     
      <div className="col-md-6 text-white mt-5 text-center  p-md-4">
        <h5 className="fw-semibold mb-2 cardfamily ">Forgot Password</h5>
        <p className="mb-4 small pt-2">Enter the email associated with your account and<br/> we’ll send and email to reset your password</p>

        <form>
         
          <div className="mb-3 pt-3">
            <label htmlFor="email" className="form-label">Email ID (or) Mobile Number*</label>
            <input type="email" id="email" name="email" className="form-control w-75 ms-5" />
          </div>

        <div className="d-grid mb-4 pt-4">
            <button className="btn btn-danger cart_color text-white rounded-5 py-2 w-75 ms-5">
              Send
            </button>
          </div>
        </form>

       <p className="small text-center">
          Back To  
          <a href="#" className=" ms-1 text-decoration-none fw-semibold">Sign IN</a>
        </p>
      </div>
    </div>
  </div>
          </div>
    </>
  )
}

export default Forgot