// import React from "react";
// import { Navigate } from "react-router-dom";

// const Private = ({ children }) => {
//   const token = localStorage.getItem("token");

//   if (!token) {
//     return <Navigate to="/login" replace />;
//   }

//   return children;
  
// };

// export default Private;
import React from "react";
import { Navigate, useLocation } from "react-router-dom";

const Private = ({ children }) => {
    
  const token = localStorage.getItem("token");
  const location = useLocation();

  // If logged in and trying to go to login page → redirect to dashboard
  if (token && location.pathname === "/") {
    return <Navigate to="/" replace />;
  }

  // If NOT logged in and trying to access any other page → redirect to login
  if (!token && location.pathname !== "/") {
    return <Navigate to="/" replace />;
  }

  return children;
};

export default Private;

const productTemplate = (productitem) => {
  if (!productitem) return null;


  // Load saved added products from localStorage
  
  const isAdded = addedProducts.includes(productitem.productID);

  const handleAddClick = () => {
    let updated;

    if (isAdded) {
      //  Remove from added list
      updated = addedProducts.filter((id) => id !== productitem.productID);
    } else {
      //  Add to list
      handleAddToCart(productitem);
      handleAddToCartCount();
      updated = [...addedProducts, productitem.productID];
    }

    setAddedProducts(updated);
    localStorage.setItem("addedProducts", JSON.stringify(updated));
  };


  return (
    <div className="ps-3">
      <div className="card shadow-sm position-relative" style={{ height: "100%" }}>
        <img
          src={`${img_path}/products/${productitem.product_image}`}
          alt={productitem.name}
          className="img-fluid p-1"
          onClick={() => navigate("/categories")}
          style={{ height: "180px", objectFit: "contain" }}
        />

        {/*  Wishlist icon */}
        <CiHeart
          size={24}
          className="position-absolute text-danger"
          onClick={() => {
            handlewishlist(productitem);
            handleWishlistCount();
          }}
          style={{ top: "15px", left: "15px", cursor: "pointer" }}
        />

        <div className="p-2">
          <h6 className="fw-bold">{productitem.product_name}</h6>

          <div className="d-flex justify-content-between py-2">
            <span>
              {productitem.weight}
              {productitem.attribute_type}
            </span>
            <span>
              <FaStar color="#FF9D00" />4.5
            </span>
          </div>

          <div className="d-flex justify-content-between align-items-center">
            <div>
              <span className="cart_color fs-5 fw-bold">{productitem.price}€</span>{" "}
              <small className="text-muted">
                <s>{productitem.mrp}€</s>
              </small>
            </div>

            {/*  Add / Added Button (per product) */}
            <button
              className={`btn btn-sm d-flex align-items-center ${isAdded ? "btn-success" : "btn-dark"}`}
              onClick={handleAddClick}
              disabled={isAdded}
            >
              {isAdded ? (
                <>
                  Added <BiCheckCircle size={18} className="ms-1" />
                </>
              ) : (
                <>
                  Add <BiSolidCartAdd size={18} className="ms-1" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};