// import { Formik, useFormik } from "formik";
// import React, { useEffect, useState } from "react";
// import { AiOutlineDelete } from "react-icons/ai";
// import { LuPencil } from "react-icons/lu";
// import { base_url } from "../../BaseUrls/BaseUrl";
// import axios from "axios";
// import { useNavigate } from "react-router-dom";
// import * as yup from "yup";
// import { GoogleMap, useJsApiLoader, Marker } from "@react-google-maps/api";
// import Toast from "../../Untils/Toast";
// import { Dialog } from "primereact/dialog";
// import AddressManagement from "./AddressManagement";

// const containerStyle = {
//   width: "100%",
//   height: "50vh",
// };

// const centers = {
//   lat: 13.078187,
//   lng: 79.972347,
// };
// const loaderOptions = {
//   id: "google-map-script",
//   googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
//   libraries: ["places", "geometry"],
// };

// const Address = () => {
//   const navigate = useNavigate();
//   const [fetchAddress, setFetchAddress] = useState([]);
//   const [visibleRight, setVisibleRight] = useState([]);
//   const { isLoaded } = useJsApiLoader(loaderOptions);
//   const [clickedLatLng, setClickedLatLng] = useState(null);
//   const [showMap, setShowMap] = useState(false); //  controls map visibility
//   const [addressconfirmmodal, setAddressconfirmmodal] = useState(false);

//   const [deliveryAddress, setDeliveryAddress] = useState(false);
//   const [editdeliveryAddress, setEditdeliveryAddress] = useState(false);
//   const [isEditing, setIsEditing] = useState(false);
//   const [isAddAddress, setIsAddAddress] = useState(false);

//   const handleMapClick = (event) => {
//     const latLng = {
//       lat: event.latLng.lat(),
//       lng: event.latLng.lng(),
//     };
//     setClickedLatLng(latLng);

//     // update formik fields
//     formik.setFieldValue("lat", latLng.lat);
//     formik.setFieldValue("lng", latLng.lng);

//     // optional: close map after selecting
//     setShowMap(false);
//   };

//   const handleEditAddress = (addr) => {
//     formik.setValues({
//       building_block_no: addr.building_block_no,
//       street_area: addr.street_area,
//       landmark: addr.landmark,
//       zip_code: addr.zip_code,
//       city: addr.city,
//       country: addr.country,
//       address_label: addr.address_label,
//       first_name: addr.first_name,
//       surname: addr.surname,
//       email: addr.email,
//       phone: addr.phone,
//       lat: addr.lat,

//       lng: addr.lng,
//       is_default: addr.is_default,

//       id: addr.id,
//     });
//     console.log(" Latitude:", addr.lat);
//     console.log(" Longitude:", addr.lng);

//     if (addr.lat && addr.lng) {
//       const location = { lat: Number(addr.lat), lng: Number(addr.lng) };
//       setClickedLatLng(location);

//       setShowMap(true);
//     } else {
//       setShowMap(true);
//     }
//     setEditdeliveryAddress(true);
//   };

//   const fetchAddresses = async () => {
//     try {
//       const encryptedUserId = localStorage.getItem("user_id");
//       const token = localStorage.getItem("token"); // assuming token is stored after login

//       const response = await axios.get(`${base_url}/address`, {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//           "tts-user-id": encryptedUserId,
//         },
//       });

//       setFetchAddress(response.data);
//       console.log("User details:", response.data);
//       setVisibleRight(false);
//     } catch (error) {}
//   };
//   useEffect(() => {
//     fetchAddresses();
//   }, []);

//   const handleAddressDelete = async (id) => {
//     console.log("addr", id);
//     try {
//       const encryptedUserId = localStorage.getItem("user_id");
//       const token = localStorage.getItem("token");

//       if (!token) {
//         return;
//       }
//       const response = await axios.delete(`${base_url}/address/${id}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//           "tts-user-id": encryptedUserId,
//         },
//       });

//       fetchAddresses();
//     } catch (error) {}
//   };

//   const editnagicate = (row) => {
//     navigate("/addressmanagement", { state: row });
//   };
//   const onSubmit = async (values) => {
//     try {
//       const encryptedUserId = localStorage.getItem("user_id");
//       const token = localStorage.getItem("token");

//       if (!token) {
//         Toast({
//           message: "Please log in to update your profile.",
//           type: "warning",
//         });
//         return;
//       }

//       const response = await axios.post(
//         `${base_url}/address/${values.id}?_method=PUT`,
//         values,
//         {
//           headers: {
//             Authorization: `Bearer ${token}`,
//             "Content-Type": "application/json",
//             "tts-user-id": encryptedUserId,
//           },
//         }
//       );

//       console.log("response.data", response.data);
//       formik.resetForm();
//       setAddressconfirmmodal(false);
//       fetchAddresses();
//     } catch (error) {}
//   };

//   const formik = useFormik({
//     initialValues: {
//       building_block_no: "",
//       street_area: "",
//       landmark: "",
//       zip_code: "",
//       city: "",
//       country: "",
//       address_label: "",
//       first_name: "",
//       surname: "",
//       email: "",
//       phone: "",
//       lat: "",
//       lng: "",
//       is_default: 0,
//     },
//     validationSchema: yup.object().shape({
//       building_block_no: yup
//         .string()
//         .required("building_block_no is required!"),
//       street_area: yup.string().required("street_area  is required"),
//       landmark: yup.string().required("landmark is required!"),
//       zip_code: yup.string().required("zip_code is required!"),
//       city: yup.string().required("city is required!"),
//       country: yup.string().required("country is required!"),
//       address_label: yup.string().required("address_label is required!"),
//       first_name: yup.string().required("first_name is required!"),
//       surname: yup.string().required("surname is required!"),
//       email: yup
//         .string()
//         .email("Enter a valid email address")
//         .required("Email is required!"),
//       phone: yup
//         .string()
//         .required("Phone number is required!")
//         .matches(/^[0-9]{15}$/, "Phone number must be exactly 15 digits"),

//       // lat: yup.string().required("lat is required!"),
//       // lng: yup.string().required("lng is required!"),
//       // is_default: yup.string().required("is_default is required!"),
//     }),
//     onSubmit,
//   });

//   return (
//     <>
//       {/* <div className='bg-white'>
//         <span> +Add New Address</span>
//     </div> */}
//       {isAddAddress ? (
//         <AddressManagement setIsAddAddress={setIsAddAddress} />
//       ) : (
//         <div className="fs-6 bg-white mx-3 mt-3">
//           <h5 className="ms-3 fw-semibold cardfamily pt-3">Select Address</h5>
//           <h6 className="ms-3 mt-3">Saved Addresses</h6>

//           <div className="border p-3 mx-3 my-4 rounded">
//             <div className="container">
//               {Array.isArray(fetchAddress) && fetchAddress.length > 0 ? (
//                 fetchAddress.map((addr) => (
//                   <div
//                     key={addr.id}
//                     className={`p-3 mx-3 my-4 rounded border ${
//                       addr.is_default === 1
//                         ? "border-success"
//                         : "border-secondary"
//                     }`}
//                     style={{
//                       borderWidth: addr.is_default === 1 ? "5px" : "3px",
//                     }}
//                   >
//                     {/* HEADER */}
//                     <div className="d-flex justify-content align-items-center">
//                       <div>
//                         <span className="fw-semibold">
//                           {addr.first_name} {addr.surname}
//                         </span>
//                         {addr.address_label && (
//                           <span className="bg-primary text-white ms-3 p-1 rounded-3 small">
//                             {addr.address_label}
//                           </span>
//                         )}
//                       </div>

//                       <div className=" d-flex ms-auto">
//                         {/* Edit Icon */}
//                         <LuPencil
//                           size={18}
//                           className="text-secondary mx-3"
//                           style={{ cursor: "pointer" }}
//                           onClick={() => {
//                             handleEditAddress(addr);
//                             setAddressconfirmmodal(true);
//                           }}
//                           // onClick={() => editnagicate(addr.id)}
//                         />
//                         <AiOutlineDelete
//                           size={20}
//                           style={{ cursor: "pointer" }}
//                           onClick={() => handleAddressDelete(addr.id)}
//                         />
//                       </div>
//                     </div>

//                     {/* ADDRESS DETAILS */}
//                     <p className="mt-2 mb-3 small text-muted">
//                       {addr.building_block_no}, {addr.street_area}, <br />
//                       {addr.landmark && `${addr.landmark}, `}
//                       {addr.city}, {addr.zip_code}, {addr.country}
//                       <br />
//                       Phone: {addr.phone}
//                     </p>
//                   </div>
//                 ))
//               ) : (
//                 <p className="text-muted text-center mt-4">
//                   No addresses found.
//                 </p>
//               )}
//             </div>
//           </div>

//           <div className=" d-flex flex-column h-50">
//             <div className="p-3 mt-auto text-center">
//               <button
//                 className="btn btn-outline-dark w-75 fw-semibold cardfamily"
//                 onClick={() => {
//                   setIsAddAddress(true);
//                   // navigate("/addressmanagement");
//                 }}
//               >
//                 + Add New Address
//               </button>
//             </div>
//           </div>
//         </div>
//       )}

//       <Dialog
//         header="Edit Address"
//         visible={addressconfirmmodal}
//         position="top"
//         style={{ width: "30vw" }}
//         onHide={() => {
//           if (!addressconfirmmodal) return;
//           setAddressconfirmmodal(false);
//         }}
//       >
//         <h5 className="fw-bold ms-4 mt-3 cardfamily pb-3">Delivery Location</h5>
//         <form onSubmit={formik.handleSubmit} autoComplete="off">
//           <div className="pb-4">
//             <div>
//               {isLoaded ? (
//                 <GoogleMap
//                   mapContainerStyle={containerStyle}
//                   center={clickedLatLng || centers}
//                   zoom={14}
//                   onClick={handleMapClick}
//                 >
//                   {clickedLatLng && <Marker position={clickedLatLng} />}
//                 </GoogleMap>
//               ) : (
//                 <p>Loading map...</p>
//               )}{" "}
//               <div className="text-center mt-3">
//                 <button
//                   className="btn btn-outline-dark rounded-5 px-4"
//                   onClick={() => setShowMap(false)}
//                 >
//                   Done
//                 </button>
//               </div>
//             </div>
//           </div>
//           <div className="px-3 mb-4">
//             <h6 className="fw-semibold mb-2">Address Details:</h6>

//             <label htmlFor="building_block_no" className="form-label">
//               Building & Block No: (Optional)
//             </label>
//             <input
//               type="text"
//               className="form-control bg-white mb-3"
//               id="building_block_no"
//               name="building_block_no"
//               placeholder="Enter building_block_no"
//               value={formik.values.building_block_no}
//               onChange={formik.handleChange}
//               onBlur={formik.handleBlur}
//             />
//             {formik.errors.building_block_no &&
//               formik.touched.building_block_no && (
//                 <p style={{ color: "red", fontSize: "12px" }}>
//                   {formik.errors.building_block_no}
//                 </p>
//               )}

//             <label htmlFor="street_area" className="form-label">
//               Street & Area Name : *
//             </label>
//             <input
//               type="text"
//               className="form-control bg-white mb-3"
//               id="street_area"
//               name="street_area"
//               placeholder="Enter street_area"
//               value={formik.values.street_area}
//               onChange={formik.handleChange}
//               onBlur={formik.handleBlur}
//             />
//             {formik.errors.street_area && formik.touched.street_area && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.street_area}
//               </p>
//             )}

//             <label htmlFor="landmark" className="form-label">
//               Landmark:
//             </label>
//             <input
//               type="text"
//               className="form-control bg-white mb-3"
//               id="landmark"
//               name="landmark"
//               placeholder="Enter landmark"
//               value={formik.values.landmark}
//               onChange={formik.handleChange}
//               onBlur={formik.handleBlur}
//             />
//             {formik.errors.landmark && formik.touched.landmark && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.landmark}
//               </p>
//             )}
//             <div className="d-flex">
//               <div>
//                 <label htmlFor="zip_code" className="form-label">
//                   {" "}
//                   ZIP code :
//                 </label>
//                 <input
//                   type="text"
//                   className="form-control bg-white mb-3"
//                   id="zip_code"
//                   name="zip_code"
//                   placeholder="Enter zip_code"
//                   value={formik.values.zip_code}
//                   onChange={formik.handleChange}
//                   onBlur={formik.handleBlur}
//                 />
//                 {formik.errors.zip_code && formik.touched.zip_code && (
//                   <p style={{ color: "red", fontSize: "12px" }}>
//                     {formik.errors.zip_code}
//                   </p>
//                 )}
//               </div>
//               <div className="px-3">
//                 <label htmlFor="city" className="form-label">
//                   {" "}
//                   City :
//                 </label>
//                 <input
//                   type="text"
//                   className="form-control bg-white mb-3"
//                   id="city"
//                   name="city"
//                   placeholder="Enter city"
//                   value={formik.values.city}
//                   onChange={formik.handleChange}
//                   onBlur={formik.handleBlur}
//                 />
//                 {formik.errors.city && formik.touched.city && (
//                   <p style={{ color: "red", fontSize: "12px" }}>
//                     {formik.errors.city}
//                   </p>
//                 )}
//               </div>
//             </div>

//             <label htmlFor="country" className="form-label">
//               Country :
//             </label>
//             <input
//               type="text"
//               className="form-control bg-white mb-3"
//               id="country"
//               name="country"
//               placeholder="Enter country"
//               value={formik.values.country}
//               onChange={formik.handleChange}
//               onBlur={formik.handleBlur}
//             />
//             {formik.errors.country && formik.touched.country && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.country}
//               </p>
//             )}
//           </div>

//           <div className="px-3 mb-4">
//             <h6 className="fw-semibold mb-2">Add Address Label</h6>
//             <div className="d-flex gap-2 pt-3">
//               {["Home", "Work", "Other"].map((label) => (
//                 <button
//                   type="button"
//                   key={label}
//                   className={`btn rounded-5 px-4 ${
//                     formik.values.address_label === label
//                       ? "btn-dark text-white"
//                       : "btn-outline-dark"
//                   }`}
//                   onClick={() => formik.setFieldValue("address_label", label)}
//                 >
//                   {label}
//                 </button>
//               ))}
//             </div>
//             {formik.errors.address_label && formik.touched.address_label && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.address_label}
//               </p>
//             )}
//           </div>

//           <div className="px-3 mb-4">
//             <h6 className="fw-semibold mb-2">Receiver Details</h6>

//             <label htmlFor="first_name" className="form-label">
//               Enter the First Name :
//             </label>
//             <input
//               type="text"
//               className="form-control bg-white mb-3"
//               id="first_name"
//               name="first_name"
//               placeholder="Enter first_name"
//               value={formik.values.first_name}
//               onChange={formik.handleChange}
//               onBlur={formik.handleBlur}
//             />
//             {formik.errors.first_name && formik.touched.first_name && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.first_name}
//               </p>
//             )}
//             <label htmlFor="surname" className="form-label">
//               Enter the Sure Name :
//             </label>
//             <input
//               type="text"
//               className="form-control bg-white mb-3"
//               id="surname"
//               name="surname"
//               placeholder="Enter surname"
//               value={formik.values.surname}
//               onChange={formik.handleChange}
//               onBlur={formik.handleBlur}
//             />
//             {formik.errors.surname && formik.touched.surname && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.surname}
//               </p>
//             )}

//             <label htmlFor="email" className="form-label">
//               Enter the Email ID :
//             </label>
//             <input
//               type="text"
//               className="form-control bg-white mb-3"
//               id="email"
//               name="email"
//               placeholder="Enter email"
//               value={formik.values.email}
//               onChange={formik.handleChange}
//               onBlur={formik.handleBlur}
//             />
//             {formik.errors.email && formik.touched.email && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.email}
//               </p>
//             )}

//             <label htmlFor="phone" className="form-label">
//               Receiver’s Phone Number
//             </label>
//             <input
//               type="text"
//               className="form-control bg-white mb-3"
//               id="phone"
//               name="phone"
//               placeholder="Enter phone"
//               value={formik.values.phone}
//               onChange={formik.handleChange}
//               onBlur={formik.handleBlur}
//               maxLength={15}
//             />
//             {formik.errors.phone && formik.touched.phone && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.phone}
//               </p>
//             )}
//           </div>
//           <div className="form-check mb-3 ms-3">
//             <input
//               type="checkbox"
//               className="form-check-input"
//               id="is_default"
//               name="is_default"
//               checked={formik.values.is_default === 1} //  checked if value is 1
//               onChange={(e) => {
//                 const checked = e.target.checked ? 1 : 0;
//                 formik.setFieldValue("is_default", checked);
//               }}
//             />
//             <label htmlFor="is_default" className="form-check-label px-2">
//               Set as default
//             </label>

//             {formik.touched.is_default && formik.errors.is_default && (
//               <p style={{ color: "red", fontSize: "12px" }}>
//                 {formik.errors.is_default}
//               </p>
//             )}
//           </div>
//           <div className="text-center pb-3">
//             <button
//               type="submit"
//               className="btn btn-dark rounded-5 px-5"
//               // onClick={() => navigate('/myorders')}
//               onClick={() => setIsEditing(true)}
//             >
//               Save & Proceed
//             </button>
//           </div>
//         </form>
//       </Dialog>
//     </>
//   );
// };

// export default Address;
import { Formik, useFormik } from "formik";
import React, { useEffect, useState } from "react";
import { AiOutlineDelete } from "react-icons/ai";
import { LuPencil } from "react-icons/lu";
import { base_url } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import * as yup from "yup";
import { GoogleMap, useJsApiLoader, Marker } from "@react-google-maps/api";
import Toast from "../../Untils/Toast";
import { Dialog } from "primereact/dialog";
import AddressManagement from "./AddressManagement";
import { Tag } from "antd";

const containerStyle = {
  width: "100%",
  height: "50vh",
};

const centers = {
  lat: 13.078187,
  lng: 79.972347,
};
const loaderOptions = {
  id: "google-map-script",
  googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
  libraries: ["places", "geometry"],
};

const Address = () => {
  const navigate = useNavigate();
  const [fetchAddress, setFetchAddress] = useState([]);
  const [visibleRight, setVisibleRight] = useState([]);
  const { isLoaded } = useJsApiLoader(loaderOptions);
  const [clickedLatLng, setClickedLatLng] = useState(null);
  const [showMap, setShowMap] = useState(false); //  controls map visibility
  const [addressconfirmmodal, setAddressconfirmmodal] = useState(false);

  const [deliveryAddress, setDeliveryAddress] = useState(false);
  const [editdeliveryAddress, setEditdeliveryAddress] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [isAddAddress, setIsAddAddress] = useState(false);

  const handleMapClick = (event) => {
    const latLng = {
      lat: event.latLng.lat(),
      lng: event.latLng.lng(),
    };
    setClickedLatLng(latLng);

    // update formik fields
    formik.setFieldValue("lat", latLng.lat);
    formik.setFieldValue("lng", latLng.lng);

    // optional: close map after selecting
    setShowMap(false);
  };

  const handleEditAddress = (addr) => {
    formik.setValues({
      building_block_no: addr.building_block_no,
      street_area: addr.street_area,
      landmark: addr.landmark,
      zip_code: addr.zip_code,
      city: addr.city,
      country: addr.country,
      address_label: addr.address_label,
      first_name: addr.first_name,
      surname: addr.surname,
      email: addr.email,
      phone: addr.phone,
      lat: addr.lat,

      lng: addr.lng,
      is_default: addr.is_default,

      id: addr.id,
    });
    console.log(" Latitude:", addr.lat);
    console.log(" Longitude:", addr.lng);

    if (addr.lat && addr.lng) {
      const location = { lat: Number(addr.lat), lng: Number(addr.lng) };
      setClickedLatLng(location);

      setShowMap(true);
    } else {
      setShowMap(true);
    }
    setEditdeliveryAddress(true);
  };

  const fetchAddresses = async () => {
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token"); // assuming token is stored after login

      const response = await axios.get(`${base_url}/address`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          "tts-user-id": encryptedUserId,
        },
      });

      setFetchAddress(response.data);
      console.log("User details:", response.data);
      setVisibleRight(false);
    } catch (error) {}
  };
  useEffect(() => {
    fetchAddresses();
  }, []);

  const handleAddressDelete = async (id) => {
    console.log("addr", id);
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token");

      if (!token) {
        return;
      }
      const response = await axios.delete(`${base_url}/address/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          "tts-user-id": encryptedUserId,
        },
      });

      fetchAddresses();
    } catch (error) {}
  };

  const editnagicate = (row) => {
    navigate("/addressmanagement", { state: row });
  };
  const onSubmit = async (values) => {
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token");

      if (!token) {
        Toast({
          message: "Please log in to update your profile.",
          type: "warning",
        });
        return;
      }

      const response = await axios.post(
        `${base_url}/address/${values.id}?_method=PUT`,
        values,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            "tts-user-id": encryptedUserId,
          },
        }
      );

      console.log("response.data", response.data);
      formik.resetForm();
      setAddressconfirmmodal(false);
      fetchAddresses();
    } catch (error) {}
  };

  const formik = useFormik({
    initialValues: {
      building_block_no: "",
      street_area: "",
      landmark: "",
      zip_code: "",
      city: "",
      country: "",
      address_label: "",
      first_name: "",
      surname: "",
      email: "",
      phone: "",
      lat: "",
      lng: "",
      is_default: 0,
    },
    validationSchema: yup.object().shape({
      building_block_no: yup
        .string()
        .required("building_block_no is required!"),
      street_area: yup.string().required("street_area  is required"),
      landmark: yup.string().required("landmark is required!"),
      zip_code: yup.string().required("zip_code is required!"),
      city: yup.string().required("city is required!"),
      country: yup.string().required("country is required!"),
      address_label: yup.string().required("address_label is required!"),
      first_name: yup.string().required("first_name is required!"),
      surname: yup.string().required("surname is required!"),
      email: yup
        .string()
        .email("Enter a valid email address")
        .required("Email is required!"),
      phone: yup
        .string()
        .required("Phone number is required!")
        .matches(/^[0-9]{15}$/, "Phone number must be exactly 15 digits"),

      // lat: yup.string().required("lat is required!"),
      // lng: yup.string().required("lng is required!"),
      // is_default: yup.string().required("is_default is required!"),
    }),
    onSubmit,
  });

  return (
    <>
      {/* <div className='bg-white'>
        <span> +Add New Address</span>
    </div> */}
      {isAddAddress ? (
        <AddressManagement setIsAddAddress={setIsAddAddress} />
      ) : (
        <div className="fs-6 bg-white  mt-2">
          <h5 className="ms-3 fw-semibold cardfamily pt-3">Select Address</h5>
          <h6 className="ms-3 mt-3">Saved Addresses</h6>

          <div className="border  rounded">
            <div className="container">
              {Array.isArray(fetchAddress) && fetchAddress.length > 0 ? (
                fetchAddress.map((addr) => (
                  <div
                    key={addr.id}
                    className={`p-3 mx-3 my-4 rounded border ${
                      addr.is_default === 1
                        ? "border-success"
                        : "border-secondary"
                    }`}
                    style={{
                      borderWidth: addr.is_default === 1 ? "5px" : "3px",
                    }}
                  >
                    {" "}
                    <Tag variant="filled" color="gold" size="small">
                      {addr.is_default === 1 ? "Default" : ""}
                    </Tag>
                    {/* HEADER */}
                    <div className="d-flex justify-content align-items-center">
                      <div>
                        <span className="fw-semibold">
                          {addr.first_name} {addr.surname}
                        </span>
                        {addr.address_label && (
                          <>
                            <span className="ms-3">
                              <Tag type="primary" color="blue" size="small">
                                {addr?.address_label}
                              </Tag>
                            </span>
                          </>
                        )}
                      </div>

                      <div className=" d-flex ms-auto align-items-center">
                        {/* Edit Icon */}
                        <LuPencil
                          size={18}
                          className="text-secondary mx-3"
                          style={{ cursor: "pointer" }}
                          onClick={() => {
                            handleEditAddress(addr);
                            setAddressconfirmmodal(true);
                          }}
                          // onClick={() => editnagicate(addr.id)}
                        />
                        <AiOutlineDelete
                          size={20}
                          style={{ cursor: "pointer" }}
                          onClick={() => handleAddressDelete(addr.id)}
                        />
                      </div>
                    </div>
                    {/* ADDRESS DETAILS */}
                    <p className="mt-2 mb-3 small text-muted">
                      {addr.building_block_no}, {addr.street_area}, <br />
                      {addr.landmark && `${addr.landmark}, `}
                      {addr.city}, {addr.zip_code}, {addr.country}
                      <br />
                      Phone: {addr.phone}
                    </p>
                  </div>
                ))
              ) : (
                <p className="text-muted text-center mt-4">
                  No addresses found.
                </p>
              )}
            </div>
          </div>

          <div className=" d-flex flex-column h-50">
            <div className="p-3 mt-auto text-center">
              <button
                className="btn btn-outline-dark w-75 fw-semibold cardfamily"
                onClick={() => {
                  setIsAddAddress(true);
                  // navigate("/addressmanagement");
                }}
              >
                + Add New Address
              </button>
            </div>
          </div>
        </div>
      )}

      <Dialog
        header="Edit Address"
        visible={addressconfirmmodal}
        position="top"
        // style={{ width: "30vw" }}
        onHide={() => {
          if (!addressconfirmmodal) return;
          setAddressconfirmmodal(false);
        }}
      >
        <h5 className="fw-bold ms-4 mt-3 cardfamily pb-3">Delivery Location</h5>
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className="pb-4">
            <div>
              {isLoaded ? (
                <GoogleMap
                  mapContainerStyle={containerStyle}
                  center={clickedLatLng || centers}
                  zoom={14}
                  onClick={handleMapClick}
                >
                  {clickedLatLng && <Marker position={clickedLatLng} />}
                </GoogleMap>
              ) : (
                <p>Loading map...</p>
              )}{" "}
              <div className="text-center mt-3">
                <button
                  className="btn btn-outline-dark rounded-5 px-4"
                  onClick={() => setShowMap(false)}
                >
                  Done
                </button>
              </div>
            </div>
          </div>
          <div className="px-3 mb-4">
            <h6 className="fw-semibold mb-2">Address Details:</h6>

            <label htmlFor="building_block_no" className="form-label">
              Building & Block No: (Optional)
            </label>
            <input
              type="text"
              className="form-control bg-white mb-3"
              id="building_block_no"
              name="building_block_no"
              placeholder="Enter building_block_no"
              value={formik.values.building_block_no}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.building_block_no &&
              formik.touched.building_block_no && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.building_block_no}
                </p>
              )}

            <label htmlFor="street_area" className="form-label">
              Street & Area Name : *
            </label>
            <input
              type="text"
              className="form-control bg-white mb-3"
              id="street_area"
              name="street_area"
              placeholder="Enter street_area"
              value={formik.values.street_area}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.street_area && formik.touched.street_area && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.street_area}
              </p>
            )}

            <label htmlFor="landmark" className="form-label">
              Landmark:
            </label>
            <input
              type="text"
              className="form-control bg-white mb-3"
              id="landmark"
              name="landmark"
              placeholder="Enter landmark"
              value={formik.values.landmark}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.landmark && formik.touched.landmark && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.landmark}
              </p>
            )}
            <div className="d-flex">
              <div>
                <label htmlFor="zip_code" className="form-label">
                  {" "}
                  ZIP code :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="zip_code"
                  name="zip_code"
                  placeholder="Enter zip_code"
                  value={formik.values.zip_code}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.zip_code && formik.touched.zip_code && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.zip_code}
                  </p>
                )}
              </div>
              <div className="px-3">
                <label htmlFor="city" className="form-label">
                  {" "}
                  City :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="city"
                  name="city"
                  placeholder="Enter city"
                  value={formik.values.city}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.city && formik.touched.city && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.city}
                  </p>
                )}
              </div>
            </div>

            <label htmlFor="country" className="form-label">
              Country :
            </label>
            <input
              type="text"
              className="form-control bg-white mb-3"
              id="country"
              name="country"
              placeholder="Enter country"
              value={formik.values.country}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.country && formik.touched.country && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.country}
              </p>
            )}
          </div>

          <div className="px-3 mb-4">
            <h6 className="fw-semibold mb-2">Add Address Label</h6>
            <div className="d-flex gap-2 pt-3">
              {["Home", "Work", "Other"].map((label) => (
                <button
                  type="button"
                  key={label}
                  className={`btn rounded-5 px-4 ${
                    formik.values.address_label === label
                      ? "btn-dark text-white"
                      : "btn-outline-dark"
                  }`}
                  onClick={() => formik.setFieldValue("address_label", label)}
                >
                  {label}
                </button>
              ))}
            </div>
            {formik.errors.address_label && formik.touched.address_label && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.address_label}
              </p>
            )}
          </div>

          <div className="px-3 mb-4">
            <h6 className="fw-semibold mb-2">Receiver Details</h6>

            <label htmlFor="first_name" className="form-label">
              Enter the First Name :
            </label>
            <input
              type="text"
              className="form-control bg-white mb-3"
              id="first_name"
              name="first_name"
              placeholder="Enter first_name"
              value={formik.values.first_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.first_name && formik.touched.first_name && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.first_name}
              </p>
            )}
            <label htmlFor="surname" className="form-label">
              Enter the Sure Name :
            </label>
            <input
              type="text"
              className="form-control bg-white mb-3"
              id="surname"
              name="surname"
              placeholder="Enter surname"
              value={formik.values.surname}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.surname && formik.touched.surname && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.surname}
              </p>
            )}

            <label htmlFor="email" className="form-label">
              Enter the Email ID :
            </label>
            <input
              type="text"
              className="form-control bg-white mb-3"
              id="email"
              name="email"
              placeholder="Enter email"
              value={formik.values.email}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.email && formik.touched.email && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.email}
              </p>
            )}

            <label htmlFor="phone" className="form-label">
              Receiver’s Phone Number
            </label>
            <input
              type="text"
              className="form-control bg-white mb-3"
              id="phone"
              name="phone"
              placeholder="Enter phone"
              value={formik.values.phone}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
              maxLength={15}
            />
            {formik.errors.phone && formik.touched.phone && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.phone}
              </p>
            )}
          </div>
          <div className="form-check mb-3 ms-3">
            <input
              type="checkbox"
              className="form-check-input"
              id="is_default"
              name="is_default"
              checked={formik.values.is_default === 1} //  checked if value is 1
              onChange={(e) => {
                const checked = e.target.checked ? 1 : 0;
                formik.setFieldValue("is_default", checked);
              }}
            />
            <label htmlFor="is_default" className="form-check-label px-2">
              Set as default
            </label>

            {formik.touched.is_default && formik.errors.is_default && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.is_default}
              </p>
            )}
          </div>
          <div className="text-center pb-3">
            <button
              type="submit"
              className="btn btn-dark rounded-5 px-5"
              // onClick={() => navigate('/myorders')}
              onClick={() => setIsEditing(true)}
            >
              Save & Proceed
            </button>
          </div>
        </form>
      </Dialog>
    </>
  );
};

export default Address;
