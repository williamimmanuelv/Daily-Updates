import { useFormik } from "formik";
import React, { useEffect, useState } from "react";
import { base_url } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import Toast from "../../Untils/Toast";
import * as yup from "yup";
import { Dialog } from "primereact/dialog";

import { GoogleMap, useJsApiLoader, Marker } from "@react-google-maps/api";
import { useLocation, useNavigate } from "react-router-dom";
import { message } from "antd";
const containerStyle = {
  width: "100%",
  height: "50vh",
};

const centers = {
  lat: 13.078187,
  lng: 79.972347,
};
const loaderOptions = {
  id: "google-map-script",
  googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
  libraries: ["places", "geometry"],
};

const AddressManagement = ({ setIsAddAddress }) => {
  const navigate = useNavigate();

  const [addressconfirmmodal, setAddressconfirmmodal] = useState(false);

  const [deliveryAddress, setDeliveryAddress] = useState(false);
  const [editdeliveryAddress, setEditdeliveryAddress] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [visibleRight, setVisibleRight] = useState(false);
  const [fetchAddress, setFetchAddress] = useState([]);
  const { isLoaded } = useJsApiLoader(loaderOptions);
  const [clickedLatLng, setClickedLatLng] = useState(null);
  const [showMap, setShowMap] = useState(false); //  controls map visibility

  const handleMapClick = (event) => {
    const latLng = {
      lat: event.latLng.lat(),
      lng: event.latLng.lng(),
    };
    setClickedLatLng(latLng);

    // update formik fields
    formik.setFieldValue("lat", latLng.lat);
    formik.setFieldValue("lng", latLng.lng);

    // optional: close map after selecting
    setShowMap(false);
  };
  const editnagicate = (row) => {
    navigate("/addressmanagement", { state: row });
  };

  const { state } = useLocation();
  const addresssData = state; // You passed row directly, so use state

  console.log("addresssDataqq", addresssData);

  useEffect(() => {
    if (!addresssData) return;

    formik.setFieldValue("building_block_no", addresssData?.product_name);
    formik.setFieldValue("street_area", addresssData?.street_area);
    formik.setFieldValue("landmark", addresssData?.landmark);
    formik.setFieldValue("zip_code", addresssData?.zip_code);
    formik.setFieldValue("city", addresssData?.city);
    formik.setFieldValue("country", addresssData?.country);
    formik.setFieldValue("address_label", addresssData?.address_label);
    formik.setFieldValue("first_name", addresssData?.first_name);
    formik.setFieldValue("surname", addresssData?.surname);
    formik.setFieldValue("email", addresssData?.email);
    formik.setFieldValue("phone", addresssData?.phone);
    formik.setFieldValue("lat", addresssData?.lat);
    formik.setFieldValue("lng", addresssData?.lng);
    formik.setFieldValue("is_default", addresssData?.is_default);
    formik.setFieldValue("id", addresssData?.id);

    if (addresssData?.lat && addresssData?.lng) {
      const location = {
        lat: Number(addresssData.lat),
        lng: Number(addresssData.lng),
      };
      setClickedLatLng(location);
    }

    setShowMap(true);
    setEditdeliveryAddress(true);
  }, [addresssData]);

  //   const handleEditAddress = (addr) => {

  //     formik.setValues({

  //       building_block_no: addr.building_block_no,
  //       street_area: addr.street_area,
  //       landmark: addr.landmark,
  //       zip_code: addr.zip_code,
  //       city: addr.city,
  //       country: addr.country,
  //       address_label: addr.address_label,
  //       first_name: addr.first_name,
  //       surname: addr.surname,
  //       email: addr.email,
  //       phone: addr.phone,
  //       lat: addr.lat,

  //       lng: addr.lng,
  //       is_default: addr.is_default,

  //       id: addr.id,
  //     });
  //     console.log(" Latitude:", addr.lat);
  //     console.log(" Longitude:", addr.lng);

  //     if (addr.lat && addr.lng) {
  //       const location = { lat: Number(addr.lat), lng: Number(addr.lng) };
  //       setClickedLatLng(location);

  //       setShowMap(true);
  //     } else {
  //       setShowMap(true);
  //     }
  //     setEditdeliveryAddress(true);

  //   };

  const fetchAddresses = async () => {
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token"); // assuming token is stored after login

      const response = await axios.get(`${base_url}/address`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          "tts-user-id": encryptedUserId,
        },
      });

      setFetchAddress(response.data);
      console.log("User details:", response.data);
      setVisibleRight(false);
    } catch (error) {}
  };
  useEffect(() => {
    fetchAddresses();
  }, []);

  const onSubmit = async (values) => {
    if (isEditing) {
      try {
        const encryptedUserId = localStorage.getItem("user_id");
        const token = localStorage.getItem("token");

        if (!token) {
          Toast({
            message: "Please log in to update your profile.",
            type: "warning",
          });
          return;
        }

        const response = await axios.post(
          `${base_url}/address/${values.id}?_method=PUT`,
          values,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
              "tts-user-id": encryptedUserId,
            },
          }
        );

        console.log("response.data", response.data);
        formik.resetForm();
        setEditdeliveryAddress(false);
        fetchAddresses();
      } catch (error) {
        message.error(error?.response?.data?.message || "Something went wrong");
      }
    } else {
      try {
        const encryptedUserId = localStorage.getItem("user_id");
        const token = localStorage.getItem("token");

        if (!token) {
          Toast({
            message: "Please log in to update your profile.",
            type: "warning",
          });
          return;
        }

        const response = await axios.post(`${base_url}/address`, values, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            "tts-user-id": encryptedUserId,
          },
        });

        console.log("response.data", response.data);
        formik.resetForm();
        setDeliveryAddress(false);
        fetchAddresses();
        navigate("/sidebar");
      } catch (error) {
        message.error(error?.response?.data?.message || "Something went wrong");
      }
    }
  };

  const formik = useFormik({
    initialValues: {
      building_block_no: "",
      street_area: "",
      landmark: "",
      zip_code: "",
      city: "",
      country: "",
      address_label: "",
      first_name: "",
      surname: "",
      email: "",
      phone: "",
      lat: "",
      lng: "",
      is_default: 0,
    },

    validationSchema: yup.object().shape({
      building_block_no: yup
        .string()
        .required("building_block_no is required!"),
      street_area: yup.string().required("street_area  is required"),
      landmark: yup.string().required("landmark is required!"),
      zip_code: yup.string().required("zip_code is required!"),
      city: yup.string().required("city is required!"),
      country: yup.string().required("country is required!"),
      address_label: yup.string().required("address_label is required!"),
      first_name: yup.string().required("first_name is required!"),
      surname: yup.string().required("surname is required!"),
      email: yup
        .string()
        .email("Enter a valid email address")
        .required("Email is required!"),

      phone: yup
        .string()
        .required("Phone number is required!")
        .matches(/^[0-9]{15}$/, "Phone number must be exactly 15 digits"),
      // lat: yup.string().required("lat is required!"),
      // lng: yup.string().required("lng is required!"),
      // is_default: yup.string().required("is_default is required!"),
    }),
    onSubmit,
  });
  return (
    <>
      <div className=" bg-white mx-3 fs-6">
        <div className="container">
          <h5 className="fw-bold ms-4 mt-3 cardfamily pb-3">
            Delivery Location
          </h5>
          <form onSubmit={formik.handleSubmit} autoComplete="off">
            <div className="pb-4">
              <div>
                {!isLoaded ? (
                  <>
                    <p className="text-center mt-3">Loading map...</p>
                  </>
                ) : (
                  <GoogleMap
                    mapContainerStyle={containerStyle}
                    center={centers}
                    zoom={14}
                    onClick={handleMapClick}
                  >
                    {clickedLatLng && <Marker position={clickedLatLng} />}
                  </GoogleMap>
                )}

                <div className="text-center mt-3">
                  <button
                    className="btn btn-outline-dark rounded-5 px-4"
                    onClick={() => setShowMap(false)}
                  >
                    Done
                  </button>
                </div>
              </div>
            </div>
            <div className="px-3 mb-4">
              <h6 className="fw-semibold mb-2">Address Details:</h6>

              <label htmlFor="building_block_no" className="form-label">
                Building & Block No: (Optional)
              </label>
              <input
                type="text"
                className="form-control bg-white mb-3"
                id="building_block_no"
                name="building_block_no"
                placeholder="Enter building_block_no"
                value={formik.values.building_block_no}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.building_block_no &&
                formik.touched.building_block_no && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.building_block_no}
                  </p>
                )}

              <label htmlFor="street_area" className="form-label">
                Street & Area Name : *
              </label>
              <input
                type="text"
                className="form-control bg-white mb-3"
                id="street_area"
                name="street_area"
                placeholder="Enter street_area"
                value={formik.values.street_area}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.street_area && formik.touched.street_area && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.street_area}
                </p>
              )}

              <label htmlFor="landmark" className="form-label">
                Landmark:
              </label>
              <input
                type="text"
                className="form-control bg-white mb-3"
                id="landmark"
                name="landmark"
                placeholder="Enter landmark"
                value={formik.values.landmark}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.landmark && formik.touched.landmark && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.landmark}
                </p>
              )}
              <div className="d-flex">
                <div>
                  <label htmlFor="zip_code" className="form-label">
                    {" "}
                    ZIP code :
                  </label>
                  <input
                    type="text"
                    className="form-control bg-white mb-3"
                    id="zip_code"
                    name="zip_code"
                    placeholder="Enter zip_code"
                    value={formik.values.zip_code}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    maxLength={6}
                  />
                  {formik.errors.zip_code && formik.touched.zip_code && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.zip_code}
                    </p>
                  )}
                </div>
                <div className="px-3">
                  <label htmlFor="city" className="form-label">
                    {" "}
                    City :
                  </label>
                  <input
                    type="text"
                    className="form-control bg-white mb-3"
                    id="city"
                    name="city"
                    placeholder="Enter city"
                    value={formik.values.city}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.city && formik.touched.city && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.city}
                    </p>
                  )}
                </div>
              </div>

              <label htmlFor="country" className="form-label">
                Country :
              </label>
              <input
                type="text"
                className="form-control bg-white mb-3"
                id="country"
                name="country"
                placeholder="Enter country"
                value={formik.values.country}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.country && formik.touched.country && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.country}
                </p>
              )}
            </div>

            <div className="px-3 mb-4">
              <h6 className="fw-semibold mb-2">Add Address Label</h6>
              <div className="d-flex gap-2 pt-3">
                {["Home", "Work", "Other"].map((label) => (
                  <button
                    type="button"
                    key={label}
                    className={`btn rounded-5 px-4 ${
                      formik.values.address_label === label
                        ? "btn-dark text-white"
                        : "btn-outline-dark"
                    }`}
                    onClick={() => formik.setFieldValue("address_label", label)}
                  >
                    {label}
                  </button>
                ))}
              </div>
              {formik.errors.address_label && formik.touched.address_label && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.address_label}
                </p>
              )}
            </div>

            <div className="px-3 mb-4">
              <h6 className="fw-semibold mb-2">Receiver Details</h6>

              <label htmlFor="first_name" className="form-label">
                Enter the First Name :
              </label>
              <input
                type="text"
                className="form-control bg-white mb-3"
                id="first_name"
                name="first_name"
                placeholder="Enter first_name"
                value={formik.values.first_name}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.first_name && formik.touched.first_name && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.first_name}
                </p>
              )}
              <label htmlFor="surname" className="form-label">
                Enter the Sure Name :
              </label>
              <input
                type="text"
                className="form-control bg-white mb-3"
                id="surname"
                name="surname"
                placeholder="Enter surname"
                value={formik.values.surname}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.surname && formik.touched.surname && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.surname}
                </p>
              )}

              <label htmlFor="email" className="form-label">
                Enter the Email ID :
              </label>
              <input
                type="text"
                className="form-control bg-white mb-3"
                id="email"
                name="email"
                placeholder="Enter email"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.email && formik.touched.email && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.email}
                </p>
              )}

              <label htmlFor="phone" className="form-label">
                Receiver’s Phone Number
              </label>
              <input
                type="text"
                className="form-control bg-white mb-3"
                id="phone"
                name="phone"
                placeholder="Enter phone"
                value={formik.values.phone}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                maxLength={15}
              />
              {formik.errors.phone && formik.touched.phone && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.phone}
                </p>
              )}
            </div>
            <div className="form-check mb-3 ms-3">
              <input
                type="checkbox"
                className="form-check-input"
                id="is_default"
                name="is_default"
                checked={formik.values.is_default === 1}
                onChange={(e) => {
                  const checked = e.target.checked ? 1 : 0;
                  formik.setFieldValue("is_default", checked);
                }}
              />
              <label htmlFor="is_default" className="form-check-label px-2">
                Set as default
              </label>

              {formik.touched.is_default && formik.errors.is_default && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.is_default}
                </p>
              )}
            </div>
            <div className="d-flex justify-content-end gap-3 text-center pb-3">
              <button
                type="submit"
                className="btn btn-dark rounded-5 px-5"
                // onClick={() => navigate('/myorders')}
                onClick={() => setIsAddAddress(false)}
              >
                cancel
              </button>
              <button
                type="submit"
                className="btn btn-dark rounded-5 px-5"
                // onClick={() => navigate('/myorders')}
                onClick={() => setIsEditing(false)}
              >
                Save & Proceed
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default AddressManagement;
