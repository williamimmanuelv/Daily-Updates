// import React from "react";
// import Footer from "../Footer/Footer";
// import Header from "../Header/Header";
// import { TbLanguageKatakana } from "react-icons/tb";
// import { PiTextAaDuotone } from "react-icons/pi";
// import { base_url } from "../../BaseUrls/BaseUrl";
// import axios from "axios";
// import Toast from "../../Untils/Toast";

// const ChooseLanguage = () => {
//   const user_id = localStorage.getItem("user_id");
//   const token = localStorage.getItem("token");

//   // ✅ Function to handle language selection
//   const handleLanguageSelect = async (language) => {
//     try {
//       if (!token) {
//         Toast({
//           message: "Please log in to update your language.",
//           type: "warning",
//         });
//         return;
//       }

//       const values = {
//         user_id: user_id,
//         language: language, // selected language
//       };

//       console.log("Update language payload:", values);

//       const response = await axios.post(`${base_url}/language`, values, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       console.log("response.data", response.data);

//       Toast({ message: "Language updated successfully!", type: "success" });
//     } catch (error) {
//       console.error("Error updating language:", error);
//       Toast({ message: "Failed to update language.", type: "error" });
//     }
//   };
//   return (
//     <>
//       {/* <div className='body_bgcolor'>
//                 <div className='container py-3'>

//                     <div className='row'>

//                         <div className='col-12 col-md-12'>

//                             <div className="bg-white p-4 w-100 pb-5 rounded shadow-sm ibm_family" style={{ height: "700px" }}>
//                                 <h5 className="fw-bold mb-3">Choose Language</h5>
//                                 <hr />

//                                 <div className="mt-5 d-flex flex-column align-items-center gap-3">

//                                     <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 w-50">
//                                         <span className="d-flex align-items-center gap-2">
//                                             <TbLanguageKatakana size={20} />
//                                             English
//                                         </span>
//                                         <button className="btn btn-success btn-sm">Select</button>
//                                     </div>

//                                     <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 w-50">
//                                         <span className="d-flex align-items-center gap-2">
//                                             <PiTextAaDuotone size={20} />
//                                             German
//                                         </span>
//                                         <button className="btn btn-dark btn-sm">Select</button>
//                                     </div>
//                                 </div>
//                             </div>

//                         </div>

//                     </div>
//                 </div>
//             </div> */}

//       <div className="body_bgcolor mx-3">
//         <div className="container py-3">
//           <div className="row">
//             <div className="col-12 col-md-12">
//               <div
//                 className="bg-white p-4 w-100 pb-5 rounded shadow-sm ibm_family"
//                 style={{ height: "700px" }}
//               >
//                 <h5 className="fw-bold mb-3">Choose Language</h5>
//                 <hr />

//                 <div className="mt-5 d-flex flex-column align-items-center gap-3">
//                   {/* English */}
//                   <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 w-50">
//                     <span className="d-flex align-items-center gap-2">
//                       <TbLanguageKatakana size={20} />
//                       English
//                     </span>
//                     <button
//                       className="btn btn-success btn-sm"
//                       onClick={() => handleLanguageSelect("English")}
//                     >
//                       Select
//                     </button>
//                   </div>

//                   {/* German */}
//                   <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 w-50">
//                     <span className="d-flex align-items-center gap-2">
//                       <PiTextAaDuotone size={20} />
//                       German
//                     </span>
//                     <button
//                       className="btn btn-dark btn-sm"
//                       onClick={() => handleLanguageSelect("German")}
//                     >
//                       Select
//                     </button>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default ChooseLanguage;
import React from "react";
import Footer from "../Footer/Footer";
import Header from "../Header/Header";
import { TbLanguageKatakana } from "react-icons/tb";
import { PiTextAaDuotone } from "react-icons/pi";
import { base_url } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import Toast from "../../Untils/Toast";

const ChooseLanguage = () => {
  const user_id = localStorage.getItem("user_id");
  const token = localStorage.getItem("token");

  // ✅ Function to handle language selection
  const handleLanguageSelect = async (language) => {
    try {
      if (!token) {
        Toast({
          message: "Please log in to update your language.",
          type: "warning",
        });
        return;
      }

      const values = {
        user_id: user_id,
        language: language, // selected language
      };

      console.log("Update language payload:", values);

      const response = await axios.post(`${base_url}/language`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("response.data", response.data);

      Toast({ message: "Language updated successfully!", type: "success" });
    } catch (error) {
      console.error("Error updating language:", error);
      Toast({ message: "Failed to update language.", type: "error" });
    }
  };
  return (
    <>
      {/* <div className='body_bgcolor'>
                <div className='container py-3'>
                 
                    <div className='row'>
                       
                        <div className='col-12 col-md-12'>

                            <div className="bg-white p-4 w-100 pb-5 rounded shadow-sm ibm_family" style={{ height: "700px" }}>
                                <h5 className="fw-bold mb-3">Choose Language</h5>
                                <hr />

                                <div className="mt-5 d-flex flex-column align-items-center gap-3">

                                    <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 w-50">
                                        <span className="d-flex align-items-center gap-2">
                                            <TbLanguageKatakana size={20} />
                                            English
                                        </span>
                                        <button className="btn btn-success btn-sm">Select</button>
                                    </div>

                                    <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 w-50">
                                        <span className="d-flex align-items-center gap-2">
                                            <PiTextAaDuotone size={20} />
                                            German
                                        </span>
                                        <button className="btn btn-dark btn-sm">Select</button>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </div>
            </div> */}

      <div className="container p-2">
        <div className="row">
          <div className="col-12 col-md-12">
            <div>
              <h5 className="fw-bold">Choose Language</h5>
              <hr />
            </div>

            <div className="mt-5 d-flex flex-column align-items-center gap-3">
              {/* English */}
              <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 w-50">
                <span className="d-flex align-items-center gap-2">
                  <TbLanguageKatakana size={20} />
                  English
                </span>
                <button
                  className="btn btn-success btn-sm"
                  onClick={() => handleLanguageSelect("English")}
                >
                  Select
                </button>
              </div>

              {/* German */}
              <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 w-50">
                <span className="d-flex align-items-center gap-2">
                  <PiTextAaDuotone size={20} />
                  German
                </span>
                <button
                  className="btn btn-dark btn-sm"
                  onClick={() => handleLanguageSelect("German")}
                >
                  Select
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ChooseLanguage;
