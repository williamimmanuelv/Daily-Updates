// import React from "react";
// import Footer from "../Footer/Footer";
// import Header from "../Header/Header";
// import { HiOutlineChevronRight } from "react-icons/hi";

// const LegalPolicies = () => {
//   return (
//     <>
//       <div className="container py-3 mx-3">
//         {/* <h4 className='fw-bold pb-3 cardfamily pt-3'>My Profile</h4> */}
//         <div className="row">
//           <div className="col-12 col-md-12">
//             <div
//               className="bg-white p-4 w-100 pb-5 rounded shadow-sm ibm_family"
//               style={{ height: "700px" }}
//             >
//               <h5 className="fw-bold mb-3">Legal Policies</h5>
//               <hr />

//               <div className="mt-5 d-flex flex-column  gap-3">
//                 <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 ">
//                   <span className="d-flex align-items-center gap-2">
//                     Terms of Use
//                   </span>
//                   <HiOutlineChevronRight />
//                 </div>

//                 <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2">
//                   <span className="d-flex align-items-center gap-2">
//                     Privacy Policy
//                   </span>
//                   <HiOutlineChevronRight />
//                 </div>

//                 <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2">
//                   <span className="d-flex align-items-center gap-2">
//                     Shipping Policy
//                   </span>
//                   <HiOutlineChevronRight />
//                 </div>
//                 <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2">
//                   <span className="d-flex align-items-center gap-2">
//                     Returns Policy
//                   </span>
//                   <HiOutlineChevronRight />
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default LegalPolicies;
import React from "react";
import Footer from "../Footer/Footer";
import Header from "../Header/Header";
import { HiOutlineChevronRight } from "react-icons/hi";

const LegalPolicies = () => {
  return (
    <>
      <div className="container p-2">
        {/* <h4 className='fw-bold pb-3 cardfamily pt-3'>My Profile</h4> */}
        <div className="ibm_family">
          <h5 className="fw-bold">Legal Policies</h5>
          <hr />
        </div>
        <div className="row p-4">
          <div className="col-12 col-md-12">
            <div className=" d-flex flex-column  gap-3">
              <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2 ">
                <span className="d-flex align-items-center gap-2">
                  Terms of Use
                </span>
                <HiOutlineChevronRight />
              </div>

              <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2">
                <span className="d-flex align-items-center gap-2">
                  Privacy Policy
                </span>
                <HiOutlineChevronRight />
              </div>

              <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2">
                <span className="d-flex align-items-center gap-2">
                  Shipping Policy
                </span>
                <HiOutlineChevronRight />
              </div>
              <div className="d-flex align-items-center justify-content-between border rounded px-3 py-2">
                <span className="d-flex align-items-center gap-2">
                  Returns Policy
                </span>
                <HiOutlineChevronRight />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default LegalPolicies;
