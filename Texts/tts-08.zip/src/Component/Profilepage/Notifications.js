// import React from "react";
// import Footer from "../Footer/Footer";
// import Header from "../Header/Header";
// import { BsBoxSeam } from "react-icons/bs";
// import { FaHeart } from "react-icons/fa6";
// import { FiGift } from "react-icons/fi";
// import { IoNotificationsOutline } from "react-icons/io5";
// import { SlEarphones } from "react-icons/sl";
// import { TbLanguageKatakana } from "react-icons/tb";
// import { CiLocationOn } from "react-icons/ci";
// import { TbMessage2Star } from "react-icons/tb";
// import { PiNotebookBold } from "react-icons/pi";
// import { ImSwitch } from "react-icons/im";
// import { HiOutlineChevronRight } from "react-icons/hi";
// import profileimg from "../../Assets/Mask group (47).png";
// import { FaCaravan } from "react-icons/fa";
// import { MdOutlinePayment } from "react-icons/md";
// import { CiLock } from "react-icons/ci";
// import { HiOutlineShoppingBag } from "react-icons/hi2";

// const Notifications = () => {
//   return (
//     <>
//       <div className="body_bgcolor mx-3">
//         <div className="container py-3">
//           <div className="row">
//             <div className="col-12 col-md-12">
//               <div className="bg-white p-4 w-100 rounded shadow-sm ibm_family">
//                 <h5 className="fw-bold mb-3">Notifications</h5>
//                 <hr />

//                 <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
//                   <div className="d-flex align-items-center">
//                     <BsBoxSeam size={20} className="me-3 notificationcolor" />
//                     <div>
//                       <p className="mb-1 fw-semibold">
//                         Order Placed Successfully
//                       </p>
//                       <span className="text-muted small">
//                         Your Order #12345 has been placed successfully.
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <span className="text-muted">2 hrs ago</span>
//                   </div>
//                 </div>

//                 <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
//                   <div className="d-flex align-items-center">
//                     <FaCaravan size={20} className="me-3 notificationOrder" />
//                     <div>
//                       <p className="mb-1 fw-semibold">Order Shipped</p>
//                       <span className="text-muted small">
//                         Your Order #12345 has been shipped. Track your package
//                         now..
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <span className="text-muted">1 day ago</span>
//                   </div>
//                 </div>

//                 <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
//                   <div className="d-flex align-items-center">
//                     <MdOutlinePayment size={20} className="me-3 text-primary" />
//                     <div>
//                       <p className="mb-1 fw-semibold">Payment Successful</p>
//                       <span className="text-muted small">
//                         Your payment of ₹2,499 for Order #12345 was successful.
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <span className="text-muted">2 days ago</span>
//                   </div>
//                 </div>

//                 <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
//                   <div className="d-flex align-items-center">
//                     <FiGift size={20} className="me-3 notificationexclusive" />
//                     <div>
//                       <p className="mb-1 fw-semibold">Exclusive Offer</p>
//                       <span className="text-muted small">
//                         Flat 20% OFF on your next purchase. Valid till Sunday!.
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <span className="text-muted">3 days ago</span>
//                   </div>
//                 </div>
//                 <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
//                   <div className="d-flex align-items-center">
//                     <CiLock size={22} className="me-3 text-danger" />
//                     <div>
//                       <p className="mb-1 fw-semibold">Account Security Alert</p>
//                       <span className="text-muted small">
//                         New login detected. If this wasn’t you, reset your
//                         password.
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <span className="text-muted">5 days ago</span>
//                   </div>
//                 </div>

//                 <div className="d-flex justify-content-between mt-3 align-items-center p-3 border rounded">
//                   <div className="d-flex align-items-center">
//                     <HiOutlineShoppingBag
//                       size={24}
//                       className="me-3 notificationcart"
//                     />
//                     <div>
//                       <p className="mb-1 fw-semibold">Cart Reminder</p>
//                       <span className="text-muted small">
//                         Items are waiting in your cart! Complete your purchase
//                         soon.
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <span className="text-muted">6 days ago</span>
//                   </div>
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default Notifications;
import React from "react";
import Footer from "../Footer/Footer";
import Header from "../Header/Header";
import { BsBoxSeam } from "react-icons/bs";
import { FaHeart } from "react-icons/fa6";
import { FiGift } from "react-icons/fi";
import { IoNotificationsOutline } from "react-icons/io5";
import { SlEarphones } from "react-icons/sl";
import { TbLanguageKatakana } from "react-icons/tb";
import { CiLocationOn } from "react-icons/ci";
import { TbMessage2Star } from "react-icons/tb";
import { PiNotebookBold } from "react-icons/pi";
import { ImSwitch } from "react-icons/im";
import { HiOutlineChevronRight } from "react-icons/hi";
import profileimg from "../../Assets/Mask group (47).png";
import { FaCaravan } from "react-icons/fa";
import { MdOutlinePayment } from "react-icons/md";
import { CiLock } from "react-icons/ci";
import { HiOutlineShoppingBag } from "react-icons/hi2";

const Notifications = () => {
  return (
    <>
      <div className="container p-2">
        <div className="row">
          <div className="col-12 col-md-12">
            <div>
              <h5 className="fw-bold ">Notifications</h5>
            </div>
            <hr />

            <div className="p-2">
              <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
                <div className="d-flex align-items-center">
                  <BsBoxSeam size={20} className="me-3 notificationcolor" />
                  <div>
                    <p className="mb-1 fw-semibold">
                      Order Placed Successfully
                    </p>
                    <span className="text-muted small">
                      Your Order #12345 has been placed successfully.
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-muted">2 hrs ago</span>
                </div>
              </div>

              <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
                <div className="d-flex align-items-center">
                  <FaCaravan size={20} className="me-3 notificationOrder" />
                  <div>
                    <p className="mb-1 fw-semibold">Order Shipped</p>
                    <span className="text-muted small">
                      Your Order #12345 has been shipped. Track your package
                      now..
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-muted">1 day ago</span>
                </div>
              </div>

              <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
                <div className="d-flex align-items-center">
                  <MdOutlinePayment size={20} className="me-3 text-primary" />
                  <div>
                    <p className="mb-1 fw-semibold">Payment Successful</p>
                    <span className="text-muted small">
                      Your payment of ₹2,499 for Order #12345 was successful.
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-muted">2 days ago</span>
                </div>
              </div>

              <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
                <div className="d-flex align-items-center">
                  <FiGift size={20} className="me-3 notificationexclusive" />
                  <div>
                    <p className="mb-1 fw-semibold">Exclusive Offer</p>
                    <span className="text-muted small">
                      Flat 20% OFF on your next purchase. Valid till Sunday!.
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-muted">3 days ago</span>
                </div>
              </div>
              <div className="d-flex justify-content-between mt-3 align-items-center p-2 border rounded">
                <div className="d-flex align-items-center">
                  <CiLock size={22} className="me-3 text-danger" />
                  <div>
                    <p className="mb-1 fw-semibold">Account Security Alert</p>
                    <span className="text-muted small">
                      New login detected. If this wasn’t you, reset your
                      password.
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-muted">5 days ago</span>
                </div>
              </div>

              <div className="d-flex justify-content-between mt-3 align-items-center p-3 border rounded">
                <div className="d-flex align-items-center">
                  <HiOutlineShoppingBag
                    size={24}
                    className="me-3 notificationcart"
                  />
                  <div>
                    <p className="mb-1 fw-semibold">Cart Reminder</p>
                    <span className="text-muted small">
                      Items are waiting in your cart! Complete your purchase
                      soon.
                    </span>
                  </div>
                </div>

                <div>
                  <span className="text-muted">6 days ago</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Notifications;
