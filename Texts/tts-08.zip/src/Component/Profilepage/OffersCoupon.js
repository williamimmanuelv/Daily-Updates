import React from "react";
import Footer from "../Footer/Footer";
import Header from "../Header/Header";
import { BsBoxSeam } from "react-icons/bs";
import { FaHeart } from "react-icons/fa6";
import { FiGift } from "react-icons/fi";
import { IoNotificationsOutline } from "react-icons/io5";
import { SlEarphones } from "react-icons/sl";
import { TbLanguageKatakana } from "react-icons/tb";
import { CiLocationOn } from "react-icons/ci";
import { TbMessage2Star } from "react-icons/tb";
import { PiNotebookBold } from "react-icons/pi";
import { ImSwitch } from "react-icons/im";
import { HiOutlineChevronRight } from "react-icons/hi";
import profileimg from "../../Assets/Mask group (47).png";
import { GoClock } from "react-icons/go";
import { RxCopy } from "react-icons/rx";
import { TbTag } from "react-icons/tb";

const OffersCoupon = () => {
  return (
    <>
      <div className="container p-2">
        {/* <h4 className='fw-bold pb-3 cardfamily pt-3'>My Profile</h4> */}
        <div className="row">
          <div className="col-12 col-md-12">
            <div className="rounded ibm_family">
              <h5 className="fw-bold ">Offers & Coupons</h5>
              <hr />
              <div className="row g-3">
                <div className="col-12 col-md-6">
                  <div className="offersCoupon p-3 rounded-4 bg-primary">
                    <div className="d-flex align-items-center mb-2">
                      <FiGift size={22} className="me-3 text-danger" />
                      <div>
                        <h6 className="mb-1 fs-5 fw-semibold">Flat 20% OFF</h6>
                        <small className="text-white-50 offer_text">
                          Get 20% off on all fashion products.
                        </small>
                      </div>
                    </div>

                    <hr className="border-light" />

                    <div className="d-flex justify-content-between align-items-center">
                      <div className="text-white">
                        <p className="mb-1 fw-semibold offer_code">SAVE20</p>
                        <small className="d-flex align-items-center offer_code_validate">
                          <GoClock className="me-1  " /> Valid till: 30 Aug 2025
                        </small>
                      </div>
                      <button className="btn btn-dark fw-semibold d-flex align-items-center copy_button">
                        <RxCopy size={18} className="me-2" /> Copy
                      </button>
                    </div>
                  </div>
                </div>
                <div className="col-12 col-md-6">
                  <div className="offerscashback p-3 rounded-4 bg-primary">
                    <div className="d-flex align-items-center mb-2">
                      <TbTag size={22} className="me-3 text-white" />
                      <div>
                        <h6 className="mb-1 fs-5 fw-semibold">₹500 Cashback</h6>
                        <small className="text-white-50 offer_text">
                          Get ₹500 cashback on orders above ₹4999.
                        </small>
                      </div>
                    </div>

                    <hr className="border-light" />

                    <div className="d-flex justify-content-between align-items-center">
                      <div className="text-white">
                        <p className="mb-1 fw-semibold offer_code">CASH500</p>
                        <small className="d-flex align-items-center offer_code_validate">
                          <GoClock className="me-1" /> Valid till: 15 Sep 2025
                        </small>
                      </div>
                      <button className="btn btn-dark fw-semibold d-flex align-items-center copy_button ">
                        <RxCopy size={20} className="me-2" /> Copy
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default OffersCoupon;
