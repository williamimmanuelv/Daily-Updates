import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

import basmatirice from "../../Assets/fd71f6518b357678996c850b48023ed9 1.png";
import basmati from "../../Assets/61ded8e828f0693eba9198b9ba78f727 1.png";
import sampamati from "../../Assets/fc63c555bde41112fe8e00cd232f343b 1.png";

import onion from "../../Assets/b08f48585f510825bebbe1a9acdbc725 1.png";
import { FaRegCircleCheck } from "react-icons/fa6";
import { FaRegCircleXmark } from "react-icons/fa6";
import { Timeline } from "primereact/timeline";

const Orders = () => {
  const navigate = useNavigate();
  const [active, setActive] = useState("all");
  const events = [
    {
      status: "Order Placed",
      date: "12-01-2025, 10:00am",
    },
    {
      status: "Processing",
      date: "12-01-2025, 12:00pm",
    },
    {
      status: "Packed",
      date: "12-01-2025,3:00pm",
    },
    {
      status: "Shipped",
      date: "12-01-2025, 6:00pm",
    },
    {
      status: "Delivery",
      date: "13-01-2025, 10:00am",
    },
  ];

  const tabs = [
    { key: "all", label: "All Orders" },
    { key: "ongoing", label: "Ongoing Orders" },
    { key: "completed", label: "Completed Orders" },
    { key: "cancel", label: "Cancel Orders" },
  ];

  return (
    <>
      <div className="body_bgcolor bg-white ms-3 mt-3 p-5">
        <div className="container py-3  px-3 fs-6">
          <h5 className="fw-bold cardfamily px-3">My Orders</h5>
          <div className="order_tab_main_container">
            <div className="order-tab-container">
              {tabs.map((tab, index) => (
                <div
                  key={tab.key}
                  onClick={() => setActive(tab.key)}
                  className={`d-flex align-items-center order_tab_p ${
                    active === tab.key ? "active" : ""
                  } ${
                    index === 0 && active === tab.key
                      ? "first-active"
                      : index === tabs.length - 1 && active === tab.key
                      ? "last-active"
                      : ""
                  }`}
                >
                  <button
                    className="order-tab-btn"
                    onClick={() => setActive(tab.key)}
                  >
                    {tab.label}
                  </button>
                </div>
              ))}
            </div>
          </div>
          {/* <div className="d-flex justify-content-center "> */}

          {/* <div
              className="d-flex rounded-pill overflow-hidden border bg-white cardfamily"
              style={{ height: "40px" }}
            >
              <ul
                className="nav nav-pills w-100 align-items-center "
                id="pills-tab"
                role="tablist"
              >
                <li
                  className="nav-item d-flex align-items-center"
                  role="presentation"
                >
                  <span
                    className="nav-link active fw-bold text-dark bg-danger bg-opacity-10"
                    id="pills-homeall-tab"
                    data-bs-toggle="pill"
                    data-bs-target="#homeall"
                    role="tab"
                  >
                    All
                  </span>
                  <div className="vr"></div>
                </li>

                <li
                  className="nav-item d-flex align-items-center"
                  role="presentation"
                >
                  <span
                    className="nav-link fw-bold text-dark "
                    id="pills-home-tab"
                    data-bs-toggle="pill"
                    data-bs-target="#home"
                    role="tab"
                  >
                    Ongoing Orders
                  </span>
                  <div className="vr"></div>
                </li>

                <li
                  className="nav-item d-flex align-items-center"
                  role="presentation"
                >
                  <span
                    className="nav-link fw-bold text-dark"
                    id="pills-menu1-tab"
                    data-bs-toggle="pill"
                    data-bs-target="#menu1"
                    role="tab"
                  >
                    Completed Orders
                  </span>
                  <div className="vr"></div>
                </li>

                <li className="nav-item" role="presentation">
                  <span
                    className="nav-link fw-bold text-dark"
                    id="pills-menu2-tab"
                    data-bs-toggle="pill"
                    data-bs-target="#menu2"
                    role="tab"
                  >
                    Cancel Orders
                  </span>
                </li>
              </ul>
            </div> */}
          {/* </div> */}
          <div className="order_page_content">
            {active === "ongoing" && (
              <div className="bg-white ms-3 mt-4">
                <div className="row ">
                  <div className="col-12 col-md-5 border ">
                    <div className="d-flex mt-4 mb-3">
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmatirice}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={sampamati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={onion}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-7 border">
                    <div className="container my-4 border">
                      <div className="position-relative mb-3">
                        <div className="progress" style={{ height: "4px" }}>
                          <div
                            className="progress-bar bg-danger"
                            role="progressbar"
                            style={{ width: "100%" }}
                          ></div>
                        </div>
                        <div
                          className="d-flex justify-content-between position-absolute w-100"
                          style={{ top: "-7px" }}
                        >
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle "
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Order Placed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Processing</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Packed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Shipped</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle ms-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Delivery</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    hi
                    {/* <div className='ms-2'>

                    <Timeline
                      value={events}
                      layout="horizontal"
                      align="top"
                      content={(item) => (
                        <div className="">
                          <div className="fw-semibold small">{item.status}</div>
                          <p className="text-muted  "style={{fontSize:"12px"}}>{item.date}</p>
                        </div>
                      )}
                    />
                                </div> */}
                    {/* <div className='row '>

                      <div className='col-12 col-md-3'>
                        <div className='pt-1'>
                          <span className='fw-semibold'>prices</span><br />
                          <span className="cart_color fw-bold fs-4 me-2 cardfamily">7,50€</span>

                        </div>
                      </div>

                      <div className='col-12 col-md-3 pt-1'>
                        <span>Order ID:</span>
                        <p>#order000101</p>
                      </div>
                      <div className='col-12 col-md-6'>
                        <div className='d-flex pt-1'>

                          <div className='mt-2 px-3'>
                            <FaRegCircleCheck size={20} className='text-success' />
                          </div>

                          <div>

                            <h5 className='fw-bold  ' onClick={()=>navigate('/trackorder')}>Order at delivered</h5>
                            <p className='text-muted'>Placed at 7th may 2025, 08:50pm </p>
                          </div>
                        </div>
                      </div>

                    </div> */}
                  </div>
                </div>
              </div>
            )}
            {active === "processing" && (
              <div className="bg-white ms-3 mt-4">hidjh</div>
            )}
            {active === "completed" && (
              <div className="bg-white ms-3 mt-4">hidddhh</div>
            )}
          </div>
          <div class="tab-content py-3" id="pills-tabContent">
            <div class="tab-pane fade show active" id="homeall" role="tabpanel">
              <div className="bg-white ms-3 mt-4">
                <div className="row ">
                  <div className="col-12 col-md-5">
                    <div className="d-flex mt-4 mb-3">
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmatirice}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={sampamati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={onion}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-7">
                    <div className="container my-4">
                      <div className="position-relative mb-3">
                        <div className="progress" style={{ height: "4px" }}>
                          <div
                            className="progress-bar bg-danger"
                            role="progressbar"
                            style={{ width: "100%" }}
                          ></div>
                        </div>
                        <div
                          className="d-flex justify-content-between position-absolute w-100"
                          style={{ top: "-7px" }}
                        >
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle "
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Order Placed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Processing</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Packed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Shipped</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle ms-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Delivery</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* <div className='ms-2'>

                    <Timeline
                      value={events}
                      layout="horizontal"
                      align="top"
                      content={(item) => (
                        <div className="">
                          <div className="fw-semibold small">{item.status}</div>
                          <p className="text-muted  "style={{fontSize:"12px"}}>{item.date}</p>
                        </div>
                      )}
                    />
                                </div> */}
                    {/* <div className='row '>

                      <div className='col-12 col-md-3'>
                        <div className='pt-1'>
                          <span className='fw-semibold'>prices</span><br />
                          <span className="cart_color fw-bold fs-4 me-2 cardfamily">7,50€</span>

                        </div>
                      </div>

                      <div className='col-12 col-md-3 pt-1'>
                        <span>Order ID:</span>
                        <p>#order000101</p>
                      </div>
                      <div className='col-12 col-md-6'>
                        <div className='d-flex pt-1'>

                          <div className='mt-2 px-3'>
                            <FaRegCircleCheck size={20} className='text-success' />
                          </div>

                          <div>

                            <h5 className='fw-bold  ' onClick={()=>navigate('/trackorder')}>Order at delivered</h5>
                            <p className='text-muted'>Placed at 7th may 2025, 08:50pm </p>
                          </div>
                        </div>
                      </div>

                    </div> */}
                  </div>
                </div>
              </div>

              <div className="bg-white ms-3 mt-4">
                <div className="row">
                  <div className="col-12 col-md-5">
                    <div className="d-flex mt-4 mb-3">
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmatirice}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={sampamati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={onion}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-7">
                    <div className="container my-4">
                      <div className="position-relative mb-3">
                        <div className="progress" style={{ height: "4px" }}>
                          <div
                            className="progress-bar bg-danger"
                            role="progressbar"
                            style={{ width: "100%" }}
                          ></div>
                        </div>

                        <div
                          className="d-flex justify-content-between position-absolute w-100 fs-6"
                          style={{ top: "-7px" }}
                        >
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle "
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Order Placed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Processing</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Packed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Shipped</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle ms-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Delivery</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="row pt-3 fs-6">
                      <div className="col-12 col-md-3">
                        <div className="pt-4">
                          <span className="fw-semibold">prices</span>
                          <br />
                          <span className="cart_color fw-bold fs-4 me-2 cardfamily">
                            7,50€
                          </span>
                        </div>
                      </div>

                      <div className="col-12 col-md-3 pt-4">
                        <span>Order ID:</span>
                        <p>#order000101</p>
                      </div>
                      <div className="col-12 col-md-6">
                        <div className="d-flex pt-4">
                          <div className="mt-2 px-3">
                            <FaRegCircleXmark
                              size={20}
                              className="text-danger"
                            />
                          </div>

                          <div>
                            <h5 className="fw-bold  ">Order at Cancelled</h5>
                            <p className="text-muted">
                              Placed at 7th may 2025, 08:50pm{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white mt-4 ms-3">
                <div className="row">
                  <div className="col-12 col-md-5">
                    <div className="d-flex mt-4 mb-3">
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmatirice}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={sampamati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={onion}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-7">
                    <div className="container my-4">
                      <div className="position-relative mb-3">
                        <div className="progress" style={{ height: "4px" }}>
                          <div
                            className="progress-bar bg-danger"
                            role="progressbar"
                            style={{ width: "60%" }}
                          ></div>
                        </div>

                        <div
                          className="d-flex justify-content-between position-absolute w-100 fs-6"
                          style={{ top: "-7px" }}
                        >
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle "
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Order Placed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Processing</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Packed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-secondary rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Shipped</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-secondary rounded-circle ms-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Delivery</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="row pt-3 fs-6">
                      <div className="col-12 col-md-3">
                        <div className="pt-4">
                          <span className="fw-semibold">prices</span>
                          <br />
                          <span className="cart_color fw-bold fs-4 me-2 cardfamily">
                            7,50€
                          </span>
                        </div>
                      </div>

                      <div className="col-12 col-md-3 pt-4">
                        <span>Order ID:</span>
                        <p>#order000101</p>
                      </div>
                      <div className="col-12 col-md-6">
                        <div className="d-flex pt-4">
                          <div className="mt-2 px-3">
                            <FaRegCircleCheck
                              size={20}
                              className="text-success"
                            />
                          </div>

                          <div>
                            <h5 className="fw-bold  ">Order at Processing</h5>
                            <p className="text-muted">
                              Placed at 7th may 2025, 08:50pm{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="tab-pane fade show" id="home" role="tabpanel">
              <div className="bg-white mt-4">
                <div className="row">
                  <div className="col-12 col-md-5">
                    <div className="d-flex mt-4 mb-3">
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmatirice}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={sampamati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={onion}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-7">
                    <div className="container my-4">
                      <div className="position-relative mb-3">
                        <div className="progress" style={{ height: "4px" }}>
                          <div
                            className="progress-bar bg-danger"
                            role="progressbar"
                            style={{ width: "60%" }}
                          ></div>
                        </div>

                        <div
                          className="d-flex justify-content-between position-absolute w-100 fs-6"
                          style={{ top: "-7px" }}
                        >
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle "
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Order Placed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Processing</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Packed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-secondary rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Shipped</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-secondary rounded-circle ms-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Delivery</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="row pt-3 fs-6">
                      <div className="col-12 col-md-3">
                        <div className="pt-4">
                          <span className="fw-semibold">prices</span>
                          <br />
                          <span className="cart_color fw-bold fs-4 me-2 cardfamily">
                            7,50€
                          </span>
                        </div>
                      </div>

                      <div className="col-12 col-md-3 pt-4">
                        <span>Order ID:</span>
                        <p>#order000101</p>
                      </div>
                      <div className="col-12 col-md-6">
                        <div className="d-flex pt-4">
                          <div className="mt-2 px-3">
                            <FaRegCircleCheck
                              size={20}
                              className="text-success"
                            />
                          </div>

                          <div>
                            <h5 className="fw-bold  ">Order at Processing</h5>
                            <p className="text-muted">
                              Placed at 7th may 2025, 08:50pm{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="tab-pane fade show" id="menu1" role="tabpanel">
              <div className="bg-white mt-4">
                <div className="row">
                  <div className="col-12 col-md-5">
                    <div className="d-flex mt-4 mb-3">
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmatirice}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={sampamati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={onion}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  <div className="col-12 col-md-7">
                    <div className="container my-4">
                      <div className="position-relative mb-3">
                        <div className="progress" style={{ height: "4px" }}>
                          <div
                            className="progress-bar bg-danger"
                            role="progressbar"
                            style={{ width: "100%" }}
                          ></div>
                        </div>

                        <div
                          className="d-flex justify-content-between position-absolute w-100 fs-6"
                          style={{ top: "-7px" }}
                        >
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle "
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Order Placed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Processing</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Packed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Shipped</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle ms-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Delivery</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="row pt-3 fs-6">
                      <div className="col-12 col-md-3">
                        <div className="pt-4">
                          <span className="fw-semibold">prices</span>
                          <br />
                          <span className="cart_color fw-bold fs-4 me-2 cardfamily">
                            7,50€
                          </span>
                        </div>
                      </div>

                      <div className="col-12 col-md-3 pt-4">
                        <span>Order ID:</span>
                        <p>#order000101</p>
                      </div>
                      <div className="col-12 col-md-6">
                        <div className="d-flex pt-4">
                          <div className="mt-2 px-3">
                            <FaRegCircleCheck
                              size={20}
                              className="text-success"
                            />
                          </div>

                          <div>
                            <h5 className="fw-bold  ">Order at delivered</h5>
                            <p className="text-muted">
                              Placed at 7th may 2025, 08:50pm{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="tab-pane fade show" id="menu2" role="tabpanel">
              <div className="bg-white mt-4 ">
                <div className="row">
                  <div className="col-12 col-md-5">
                    <div className="d-flex mt-4 mb-3">
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmatirice}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={sampamati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={basmati}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                      <div className="d-flex border rounded p-2 h-100 ms-3">
                        <img
                          src={onion}
                          alt="basmatirice"
                          className="img-fluid"
                          style={{
                            width: "80px",
                            height: "80px",
                            objectFit: "contain",
                          }}
                        />
                      </div>
                    </div>
                  </div>
                  {/* <div className='col-12 col-md-2'>
            <div className='pt-5'>
           <span className="cart_color fw-bold fs-4 me-2 cardfamily">7,50€</span>

            </div>
        </div>
        <div className='col-12 col-md-4'>
            <div className='d-flex pt-4'>

            <div className='mt-4 px-3'>
            <FaRegCircleXmark   size={20} className='text-danger'/>
            </div>

            <div>

            <h6 className='fw-bold'>Order at delivered</h6>
            <p className='text-muted'>Placed at 7th may 2025, 08:50pm <br/>#order000101</p>
            </div>
            </div>
          </div> */}
                  <div className="col-12 col-md-7">
                    <div className="container my-4">
                      <div className="position-relative mb-3">
                        <div className="progress" style={{ height: "4px" }}>
                          <div
                            className="progress-bar bg-danger"
                            role=""
                            style={{ width: "80%" }}
                          ></div>
                        </div>
                        <div
                          className="d-flex justify-content-between position-absolute w-100 fs-6"
                          style={{ top: "-7px" }}
                        >
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle "
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Order Placed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Processing</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Packed</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle mx-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Shipped</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                          <div className="text-center">
                            <div
                              className="bg-danger rounded-circle ms-auto"
                              style={{ width: "16px", height: "16px" }}
                            ></div>
                            <small className="fw-semibold">Delivery</small>
                            <br />
                            <span className="small opacity-75">
                              12-01-2025, 10:00pm
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="row pt-3 fs-6">
                      <div className="col-12 col-md-3">
                        <div className="pt-4">
                          <span className="fw-semibold">prices</span>
                          <br />
                          <span className="cart_color fw-bold fs-4 me-2 cardfamily">
                            7,50€
                          </span>
                        </div>
                      </div>

                      <div className="col-12 col-md-3 pt-4">
                        <span>Order ID:</span>
                        <p>#order000101</p>
                      </div>
                      <div className="col-12 col-md-6">
                        <div className="d-flex pt-4">
                          <div className="mt-2 px-3">
                            <FaRegCircleXmark
                              size={20}
                              className="text-danger"
                            />
                          </div>

                          <div>
                            <h5 className="fw-bold  ">Order at Cancelled</h5>
                            <p className="text-muted">
                              Placed at 7th may 2025, 08:50pm{" "}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Orders;
// import React from "react";

// const Orders = () => {
//   const dummyOrders = [
//     {
//       id: "1020",
//       deliveryDate: "12 Jun",
//       price: "34.55",
//       status: "Pending",
//     },
//     {
//       id: "1021",
//       deliveryDate: "15 Jun",
//       price: "52.20",
//       status: "Shipped",
//     },
//     {
//       id: "1022",
//       deliveryDate: "18 Jun",
//       price: "27.90",
//       status: "Completed",
//     },
//     {
//       id: "1023",
//       deliveryDate: "20 Jun",
//       price: "42.10",
//       status: "Processing",
//     },
//     {
//       id: "1024",
//       deliveryDate: "22 Jun",
//       price: "18.75",
//       status: "Cancelled",
//     },
//   ];
//   const [modalOpen, setModalOpen] = useState(false);
//   const [modalType, setModalType] = useState(""); // "view" or "track"
//   const [selectedOrder, setSelectedOrder] = useState(null);

//   const openModal = (order, type) => {
//     setSelectedOrder(order);
//     setModalType(type);
//     setModalOpen(true);
//   };
//   const navigate = useNavigate();
//   const handleClick = () => {
//     navigate("/order_track");
//   };
//   return (
//     <>
//       <div className="body_bgcolor px-3">
//         <div className="container py-3">
//           <div
//             className="bg-white p-4 w-100 pb-5 rounded shadow-sm ibm_family"
//             style={{ height: "700px" }}
//           >
//             <h5 className="fw-bold mb-3">Offers</h5>
//             <hr />

//             <div className="card_container">
//               {dummyOrders.map((order) => (
//                 <div className="order_box">
//                   <div className="order_header">
//                     <p className="order_title">Orders ID: {order.id}</p>
//                     <div>
//                       <Button
//                         icon={<IoEyeOutline style={{ color: "#ff7b00" }} />}
//                         size="middle"
//                         style={{
//                           borderColor: "#ff7b00",
//                           color: "#ff7b00",
//                         }}
//                         onClick={() => openModal(order, "view")}
//                       />

//                       <Button
//                         icon={<FaTruck style={{ color: "#ff7b00" }} />}
//                         size="middle"
//                         style={{
//                           borderColor: "#ff7b00",
//                           color: "#ff7b00",
//                           marginLeft: "10px",
//                         }}
//                         onClick={() => openModal(order, "track")}
//                       />
//                     </div>
//                   </div>

//                   <div className="order_row">
//                     <span>Delivery Date</span>
//                     <span>{order.deliveryDate}</span>
//                   </div>

//                   <div className="order_row">
//                     <span>Price</span>
//                     <span>${order.price}</span>
//                   </div>

//                   <div className="order_row">
//                     <span>Status</span>
//                     <span className="pending">{order.status}</span>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </div>
//         </div>
//       </div>
//       {/* ========== ANT DESIGN MODAL ========== */}
//       <Modal
//         open={modalOpen}
//         centered
//         footer={null}
//         onCancel={() => setModalOpen(false)}
//         width="70%"
//       >
//         {modalType === "view" && selectedOrder && (
//           <div>
//             <h3 className="fw-bold">Order Details</h3>
//             <p>Order ID: {selectedOrder.id}</p>
//             <p>Delivery Date: {selectedOrder.deliveryDate}</p>
//             <p>Price: ${selectedOrder.price}</p>
//             <p>Status: {selectedOrder.status}</p>
//           </div>
//         )}

//         {modalType === "track" && selectedOrder && (
//           <>
//             <OrderTrack />
//           </>
//         )}
//       </Modal>
//     </>
//   );
// };

// export default Orders;
