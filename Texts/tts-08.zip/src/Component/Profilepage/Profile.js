import React from 'react'
import './profile.css'
import profileimg from "../../Assets/Mask group (47).png"
import { BsBoxSeam } from "react-icons/bs";
import { FaHeart } from "react-icons/fa6";
import { FiGift } from "react-icons/fi";
import { IoNotificationsOutline } from "react-icons/io5";
import { SlEarphones } from "react-icons/sl";
import { TbLanguageKatakana } from "react-icons/tb";
import { CiLocationOn } from "react-icons/ci";
import { TbMessage2Star } from "react-icons/tb";
import { PiNotebookBold } from "react-icons/pi";
import { ImSwitch } from "react-icons/im";
import { HiOutlineChevronRight } from "react-icons/hi";
import Header from '../Header/Header';
import Footer from '../Footer/Footer';
import { Link } from 'react-router-dom';

const Profile = () => {
  return (
    <>
      <Header />
      <div className='body_bgcolor'>
        <div className='container py-4'>
          <h4 className='fw-bold pb-3 cardfamily pt-3'>My Profile</h4>
          <div className='row'>
            <div className='col-12 col-md-4 ibm_family'>
              <div className="profilebgcolor d-flex align-items-center justify-content-between p-3 rounded">

                <div className="d-flex align-items-center">
                  <img
                    src={profileimg}
                    alt="profile"
                    className="img-fluid rounded-circle me-3"
                    style={{ width: "60px", height: "60px", objectFit: "cover" }}
                  />
                  <div>
                    <span className="fw-semibold d-block">RMani K</span>
                    <span className="text-muted">+69 1234 5678</span>
                  </div>
                </div>


                <div>
                  <span className="heart_color fw-semibold" style={{ cursor: "pointer" }}>Edit</span>
                </div>
              </div>

              <div className="bg-white mt-3 rounded shadow-sm ibm_family">
                {/* Menu Item */}
                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <BsBoxSeam size={20} className="me-2 " /> My Orders
                  </span>
                  <HiOutlineChevronRight />
                </div>

                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <FaHeart size={20} className="me-2 " /> Wishlist
                  </span>
                  <HiOutlineChevronRight />
                </div>

                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <Link to="/offersCoupon"> <FiGift size={20} className="me-2 " /> Offers & Coupons</Link>
                  </span>
                  <HiOutlineChevronRight />
                </div>

                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <IoNotificationsOutline size={20} className="me-2 " /> Notifications
                  </span>
                  <HiOutlineChevronRight />
                </div>

                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <SlEarphones size={20} className="me-2 " /> Help & Support
                  </span>
                  <HiOutlineChevronRight />
                </div>

                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <TbLanguageKatakana size={20} className="me-2 " /> Choose Language
                  </span>
                  <HiOutlineChevronRight />
                </div>

                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <CiLocationOn size={20} className="me-2 " /> Address Management
                  </span>
                  <HiOutlineChevronRight />
                </div>

                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <TbMessage2Star size={20} className="me-2 " /> Review & Rating
                  </span>
                  <HiOutlineChevronRight />
                </div>

                <div className="d-flex justify-content-between align-items-center p-3 border-bottom">
                  <span className="d-flex align-items-center fw-semibold">
                    <PiNotebookBold size={20} className="me-2 " /> Legal Policies
                  </span>
                  <HiOutlineChevronRight />
                </div>

                {/* Logout - styled differently */}
                <div className="d-flex justify-content-between align-items-center p-3 text-danger fw-semibold">
                  <span className="d-flex align-items-center fw-semibold">
                    <ImSwitch size={20} className="me-2 " /> LOG OUT
                  </span>
                  <HiOutlineChevronRight />
                </div>
              </div>

            </div>
            {/* <div className='col-12 col-md-8'>

              <div className="bg-white p-4 w-100 rounded shadow-sm ibm_family">
                <h5 className="fw-bold mb-3">My Profile</h5>
                <hr />


                <div className=" mb-4">
                  <img
                    src={profileimg}
                    alt="Profile"
                    className="img-fluid rounded-circle"
                    style={{ width: "80px", height: "80px", objectFit: "cover" }}
                  />
                  <span className='ps-5 small'>Edit Profile Picture</span>
                </div>


                <form>
                  <div className="row g-3">

                    <div className="col-md-6">
                      <label htmlFor="firstName" className="form-label">
                        Enter the First Name:
                      </label>
                      <input
                        type="text"
                        id="firstName"
                        name="firstName"
                        className="form-control"

                      />
                    </div>

                    <div className="col-md-6">
                      <label htmlFor="lastName" className="form-label">
                        Enter the Last Name:
                      </label>
                      <input
                        type="text"
                        id="lastName"
                        name="lastName"
                        className="form-control"

                      />
                    </div>


                    <div className="col-md-6">
                      <label htmlFor="email" className="form-label">
                        Enter the Email ID:
                      </label>
                      <input
                        type="email"
                        id="email"
                        name="email"
                        className="form-control"

                      />
                    </div>


                    <div className="col-md-6">
                      <label htmlFor="phone" className="form-label">
                        Enter the Phone Number:
                      </label>
                      <input
                        type="tel"
                        id="phone"
                        name="phone"
                        className="form-control"

                      />
                    </div>
                  </div>


                  <div className="mt-4 text-center">
                    <button type="submit" className="btn btn-dark px-4">
                      Save
                    </button>
                  </div>
                </form>
              </div>

            </div> */}

          </div>

        </div>
      </div>
      <Footer />
    </>
  )
}

export default Profile