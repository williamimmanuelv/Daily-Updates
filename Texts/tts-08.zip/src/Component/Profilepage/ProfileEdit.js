import React, { useEffect, useState } from "react";
import profileimg from "../../Assets/Mask group (47).png";
import { useFormik } from "formik";
import axios from "axios";
import { base_url } from "../../BaseUrls/BaseUrl";
import Toast from "../../Untils/Toast";
import * as yup from "yup";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import { Dialog } from "primereact/dialog";

const ProfileEdit = () => {
  const navigate = useNavigate();

  const [token, setToken] = useState([]);
  const [useredit, setUseredit] = useState([]);
  const [createmodalpolice, setCreatemodalpolice] = useState(false);

  // const onSubmit = async (values) => {
  //   console.log("values", values)

  //   try {

  //     const response = await axios.post(`${base_url}/update/profile`, values)

  //     setToken(response.data)
  //     console.log("response.data", response.data)
  //     localStorage.setItem("token", response?.data?.token)

  //     // localStorage.removeItem("token")
  //     Toast({ message: " Otp send Successfully", type: "success" });
  //     formik.resetForm()
  //     // navigate('/otp')
  //   }
  //   catch (error) {
  //     const errorMessage =
  //       error.response?.data?.message ||
  //       error.response?.data?.errors?.email?.[0] ||
  //       "Invalid email. Please try again.";

  //     Toast({ message: errorMessage, type: "error" });
  //   }
  //  }

  const fetchuser = async () => {
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token"); // assuming token is stored after login

      if (!encryptedUserId || !token) {
        console.error("User ID or token missing in localStorage");
        return;
      }

      const response = await axios.get(`${base_url}/user/${encryptedUserId}`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      setUseredit(response.data);
      console.log("User details:", response.data);
      formik.setValues({
        name: response.data.name || "",
        email: response.data.email || "",
        phone: response.data.phone || "",
      });
    } catch (error) {
      console.error("Error fetching user details:", error);

      if (error.response && error.response.status === 401) {
        console.warn("Unauthorized: Invalid or expired token.");
        // Optional: redirect to login or refresh token
      }
    }
  };

  useEffect(() => {
    fetchuser();
  }, []);

  const onSubmit = async (values) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        Toast({
          message: "Please log in to update your profile.",
          type: "warning",
        });
        return;
      }

      const response = await axios.post(`${base_url}/profile`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("response.data", response.data);
      setCreatemodalpolice(true);
      // Optional success message
      Toast({ message: "Send the OTP successfully Email!", type: "success" });
    } catch (error) {
      console.error("Error updating profile:", error);
      Toast({
        message: "Failed to update profile. Please try again.",
        type: "error",
      });
    }
  };

  const formik = useFormik({
    initialValues: {
      name: "",
      phone: "",
      email: "",
    },
    validationSchema: yup.object().shape({
      name: yup.string().required("name is required!"),
      phone: yup
        .string()
        .required("Phone is required")
        .matches(/^[0-9]{10}$/, "Phone must be exactly 10 digits"),
      email: yup.string().required("email is required!"),
    }),
    onSubmit,
  });

  const formik1 = useFormik({
    initialValues: {
      otp: "",
    },
    validationSchema: yup.object().shape({
      otp: yup
        .string()
        .required("OTP is required!")
        .matches(/^\d{6}$/, "OTP must be a 6-digit number"),
    }),
    onSubmit: async (values) => {
      const payload = {
        otp: values.otp,
      };

      console.log("Payload to send:", payload);
      try {
        const token = localStorage.getItem("token");

        if (!token) {
          Toast({
            message: "Please log in to update your profile.",
            type: "warning",
          });
          return;
        }

        const response = await axios.post(
          `${base_url}/verify/emailupdateotp`,
          payload,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );
        console.log("response", response);
        console.log("hi");
        console.log("response.data", response.data);
        setCreatemodalpolice(false);
        formik1.resetForm();
        fetchuser()
        // Optional success message
        Toast({ message: "Send the OTP successfully Email!", type: "success" });
      } catch (error) {
        // try {
        //   const response = await axios.post(`${base_url}/verify/emailupdateotp`, payload);
        //   setToken(response.data);

        //   localStorage.setItem("token", response?.data?.token);
        //   localStorage.setItem("name", response?.data?.name);
        //   localStorage.setItem("email", response?.data?.email);
        //   localStorage.setItem("user_id", response?.data?.id);
        //   localStorage.setItem("customer_id", response?.data?.customer_id);

        //   Toast({ message: "Successfully Verified!", type: "success" });

        //   formik.resetForm();

        // }
        const errorMessage =
          error.response?.data?.message ||
          error.response?.data?.errors?.otp?.[0] ||
          "Invalid OTP. Please try again.";

        Toast({ message: errorMessage, type: "error" });
      }
    },
  });

  return (
    <>
      <div className="ps-3 py-3">
        <div className="col-12 col-md-12">
          <div className="bg-white p-4 w-100 rounded shadow-sm ibm_family">
            <h5 className="fw-bold mb-3">My Profile</h5>
            <hr />

            <div className=" mb-4">
              <img
                src={profileimg}
                alt="Profile"
                className="img-fluid rounded-circle"
                style={{ width: "80px", height: "80px", objectFit: "cover" }}
              />
              <span className="ps-5 small">Edit Profile Picture</span>
            </div>

            <form onSubmit={formik.handleSubmit} autoComplete="off">
              <div className="row g-3">
                <div className="col-md-6">
                  <label htmlFor="name" className="form-label">
                    Enter the First Name:
                  </label>
                  <input
                    type="text"
                    className="form-control bg-white"
                    id="name"
                    name="name"
                    placeholder="Enter name"
                    value={formik.values.name}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.name && formik.touched.name && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.name}
                    </p>
                  )}
                </div>

                {/* <div className="col-md-6">
                  <label htmlFor="lastName" className="form-label">
                    Enter the Last Name:
                  </label>
                  <input
                  type="text"
                  className="form-control bg-white"
                  id="lastName"
                  name="lastName"
                  placeholder="Enter lastName"
                  value={formik.values.lastName}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                 {formik.errors.lastName && formik.touched.lastName && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.lastName}
                      </p>
                    )}
                </div> */}

                <div className="col-md-6">
                  <label htmlFor="email" className="form-label ">
                    Enter the Email ID
                  </label>
                  <input
                    type="email"
                    className="form-control bg-white"
                    id="email"
                    name="email"
                    placeholder="Enter email"
                    value={formik.values.email}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.email && formik.touched.email && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.email}
                    </p>
                  )}
                </div>

                <div className="col-md-6">
                  <label htmlFor="phone" className="form-label">
                    Enter the Phone Number:
                  </label>
                  <input
                    type="text"
                    className="form-control bg-white"
                    id="phone"
                    name="phone"
                    placeholder="Enter phone"
                    value={formik.values.phone}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.phone && formik.touched.phone && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.phone}
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-4 text-end">
                <button
                  type="submit"
                  className="btn btn-dark px-4 mx-3"
                  onClick={() => formik.resetForm()}
                >
                  {" "}
                  Clear
                </button>

                <button type="submit" className="btn btn-success px-4">
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      <Dialog
        header="Confirm Otp"
        visible={createmodalpolice}
        position="top"
        style={{ width: "50vw" }}
        onHide={() => {
          if (!createmodalpolice) return;
          setCreatemodalpolice(false);
        }}
      >
        {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
        <form onSubmit={formik1.handleSubmit} autoComplete="off">
          <div className="row py-4">
            <div className="col-12 col-md-12">
              <div className="mb-3">
                <label htmlFor="otp" className="form-label text-muted">
                  OTP
                </label>
                <input
                  type="text"
                  className="form-control w-75"
                  id="otp"
                  name="otp"
                  rows="4"
                  placeholder="Type Otp"
                  value={formik1.values.otp}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.otp && formik1.touched.otp && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.otp}
                  </p>
                )}
              </div>
            </div>
            <div className="text-end">
              <Button
                variant="outlined"
                color="error"
                onClick={() => formik1.resetForm()}
              >
                {" "}
                Cancel
              </Button>
              <Button
                type="submit"
                variant="contained"
                className="mx-2"
                color="success"
              >
                Save{" "}
              </Button>
              &nbsp;
            </div>
          </div>
        </form>
      </Dialog>
    </>
  );
};

export default ProfileEdit;
