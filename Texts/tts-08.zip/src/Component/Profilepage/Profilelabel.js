// // import axios from "axios";
// // import React, { useEffect, useState } from "react";
// // import { useNavigate } from "react-router-dom";
// // import { base_url } from "../../BaseUrls/BaseUrl";
// // import profileimg from "../../Assets/Mask group (47).png";
// // import { TbEdit } from "react-icons/tb";

// // import { useFormik } from "formik";
// // import Toast from "../../Untils/Toast";
// // import * as yup from "yup";
// // import { FaRegEdit } from "react-icons/fa";

// // import Button from "@mui/material/Button";
// // import { Dialog } from "primereact/dialog";

// // import "./profile.css";

// // const Profilelabel = () => {
// //   const navigate = useNavigate();
// //   const [useredit, setUseredit] = useState({
// //     name: "",
// //     email: "",
// //     phone: "",
// //   });
// //   const [profileEdit, setprofileEdit] = useState(false);
// //   const [loading, setLoading] = useState(false);
// //   const [createmodalpolice, setCreatemodalpolice] = useState(false);

// //   const token = localStorage.getItem("token");

// //   const fetchusers = async () => {
// //     try {
// //       const encryptedUserId = localStorage.getItem("user_id");
// //       const token = localStorage.getItem("token");

// //       if (!encryptedUserId && !token) {
// //         console.error("User ID or token missing in localStorage");
// //         return;
// //       }

// //       const response = await axios.get(`${base_url}/user/${encryptedUserId}`, {
// //         headers: {
// //           "Content-Type": "application/json",
// //           Authorization: `Bearer ${token}`,
// //         },
// //       });
// //       const newData = response?.data;
// //       console.log("response newData", newData);
// //       if (newData?.status === "success") {
// //         formik.setFieldValue({
// //           name: newData?.data?.name ? newData?.data?.name : "",
// //           email: newData?.data?.email ? newData?.data?.email : "",
// //           phone: newData?.data?.phone ? newData?.data?.phone : "",
// //         });
// //         setUseredit(newData?.data);
// //       }
// //     } catch (error) {
// //       console.error("Error fetching user details:", error);

// //       if (error.response && error.response.status === 401) {
// //         console.warn("Unauthorized: Invalid or expired token.");
// //         // Optional: redirect to login or refresh token
// //       }
// //     }
// //   };

// //   useEffect(() => {
// //     const encryptedUserId = localStorage.getItem("user_id");
// //     if (encryptedUserId && token) {
// //       fetchusers();
// //     }
// //   }, [token]);

// //   const onSubmit = async (values) => {
// //     try {
// //       const token = localStorage.getItem("token");

// //       if (!token) {
// //         Toast({
// //           message: "Please log in to update your profile.",
// //           type: "warning",
// //         });
// //         return;
// //       }

// //       const response = await axios.post(`${base_url}/profile`, values, {
// //         headers: {
// //           Authorization: `Bearer ${token}`,
// //           "Content-Type": "application/json",
// //         },
// //       });

// //       console.log("response.data", response.data);
// //       setCreatemodalpolice(true);
// //       // Optional success message
// //       Toast({ message: "Send the OTP successfully Email!", type: "success" });
// //     } catch (error) {
// //       console.error("Error updating profile:", error);
// //       Toast({
// //         message: "Failed to update profile. Please try again.",
// //         type: "error",
// //       });
// //     }
// //   };

// //   const formik = useFormik({
// //     initialValues: {
// //       name: "",
// //       phone: "",
// //       email: "",
// //     },
// //     validationSchema: yup.object().shape({
// //       name: yup.string().required("name is required!"),
// //       phone: yup
// //         .string()
// //         .required("Phone is required")
// //         .matches(/^[0-9]{10}$/, "Phone must be exactly 10 digits"),
// //       email: yup.string().required("email is required!"),
// //     }),
// //     onSubmit,
// //   });

// //   const formik1 = useFormik({
// //     initialValues: {
// //       otp: "",
// //     },
// //     validationSchema: yup.object().shape({
// //       otp: yup
// //         .string()
// //         .required("OTP is required!")
// //         .matches(/^\d{6}$/, "OTP must be a 6-digit number"),
// //     }),
// //     onSubmit: async (values) => {
// //       const payload = {
// //         otp: values.otp,
// //       };

// //       console.log("Payload to send:", payload);
// //       try {
// //         const token = localStorage.getItem("token");

// //         if (!token) {
// //           Toast({
// //             message: "Please log in to update your profile.",
// //             type: "warning",
// //           });
// //           return;
// //         }

// //         const response = await axios.post(
// //           `${base_url}/verify/emailupdateotp`,
// //           payload,
// //           {
// //             headers: {
// //               Authorization: `Bearer ${token}`,
// //               "Content-Type": "application/json",
// //             },
// //           }
// //         );

// //         console.log("response.data", response.data);
// //         setCreatemodalpolice(false);
// //         // Optional success message
// //         Toast({ message: "Send the OTP successfully Email!", type: "success" });
// //       } catch (error) {
// //         // try {
// //         //   const response = await axios.post(`${base_url}/verify/emailupdateotp`, payload);
// //         //   setToken(response.data);

// //         //   localStorage.setItem("token", response?.data?.token);
// //         //   localStorage.setItem("name", response?.data?.name);
// //         //   localStorage.setItem("email", response?.data?.email);
// //         //   localStorage.setItem("user_id", response?.data?.id);
// //         //   localStorage.setItem("customer_id", response?.data?.customer_id);

// //         //   Toast({ message: "Successfully Verified!", type: "success" });

// //         //   formik.resetForm();

// //         // }
// //         const errorMessage =
// //           error.response?.data?.message ||
// //           error.response?.data?.errors?.otp?.[0] ||
// //           "Invalid OTP. Please try again.";

// //         Toast({ message: errorMessage, type: "error" });
// //       }
// //     },
// //   });

// //   const fetchuser = async () => {
// //     setLoading(true);
// //     try {
// //       const encryptedUserId = localStorage.getItem("user_id");

// //       if (!encryptedUserId || !token) {
// //         console.error("User ID or token missing");
// //         setLoading(false);
// //         return;
// //       }

// //       const response = await axios.get(`${base_url}/user/${encryptedUserId}`, {
// //         headers: {
// //           "Content-Type": "application/json",
// //           Authorization: `Bearer ${token}`,
// //         },
// //       });

// //       setUseredit(response.data);
// //     } catch (error) {
// //       console.error("Error fetching user details:", error);
// //       if (error.response?.status === 401) {
// //         // Optional: redirect to login
// //         // navigate('/login');
// //       }
// //     } finally {
// //       setLoading(false);
// //     }
// //   };

// //   return (
// //     <>
// //       <div className="bg-white p-2 mx-3 mt-3 rounded-2 pb-5">
// //         {useredit?.map((item) => (
// //           <div className="position-relative">
// //             {/* Edit Icon - Top Right */}
// //             <span
// //               onClick={() => setprofileEdit(true)}
// //               className="position-absolute top-0 end-0 fs-3 fw-medium"
// //               style={{ cursor: "pointer" }}
// //             >
// //               <TbEdit />
// //             </span>

// //             <div className="d-flex align-items-center gap-4 mt-4">
// //               <div className="profile-avatar"></div>

// //               <div className="user-info">
// //                 {loading ? (
// //                   <div className="text-muted">Loading...</div>
// //                 ) : useredit ? (
// //                   <>
// //                     <label className="fw-bold">UserName</label>
// //                     <p className="mb-1">
// //                       {useredit?.name ? useredit?.name : "User Name"}
// //                     </p>

// //                     <label className="fw-bold">PhoneNumber</label>
// //                     <p className="mb-2 ">
// //                       <i className="bi bi-telephone-fill "></i>
// //                       {useredit?.phone ? useredit?.phone : "+91 XXXXX XXXXX"}
// //                     </p>

// //                     <label className="fw-bold">Email</label>
// //                     <p className="mb-0">
// //                       <i className="bi bi-envelope-fill"></i>
// //                       {useredit?.email ? useredit?.email : "user@example.com"}
// //                     </p>
// //                   </>
// //                 ) : (
// //                   <p className="text-danger">Failed to load profile</p>
// //                 )}
// //               </div>
// //             </div>
// //           </div>
// //         ))}
// //       </div>

// //       {/* Edit Button */}

// //       <Dialog
// //         header="Edit Profile"
// //         visible={profileEdit}
// //         position="top"
// //         style={{ width: "30vw" }}
// //         onHide={() => {
// //           if (!profileEdit) return;
// //           setprofileEdit(false);
// //         }}
// //       >
// //         <div className="ps-3 py-3">
// //           <div className="col-12 col-md-12">
// //             <div className="bg-white p-4 w-100 rounded shadow-sm ibm_family">
// //               <h5 className="fw-bold mb-3">My Profile</h5>
// //               <hr />

// //               {/* <div className=" mb-4">
// //               <img
// //                 src={profileimg}
// //                 alt="Profile"
// //                 className="img-fluid rounded-circle"
// //                 style={{ width: "80px", height: "80px", objectFit: "cover" }}
// //               />
// //               <span className='ps-5 small'>Edit Profile Picture</span>
// //             </div> */}

// //               <form onSubmit={formik.handleSubmit} autoComplete="off">
// //                 <div className="row g-3">
// //                   <div className="col-md-6">
// //                     <label htmlFor="name" className="form-label">
// //                       Enter the First Name:
// //                     </label>
// //                     <input
// //                       type="text"
// //                       className="form-control bg-white"
// //                       id="name"
// //                       name="name"
// //                       placeholder="Enter name"
// //                       value={formik.values.name}
// //                       onChange={formik.handleChange}
// //                       onBlur={formik.handleBlur}
// //                     />
// //                     {formik.errors.name && formik.touched.name && (
// //                       <p style={{ color: "red", fontSize: "12px" }}>
// //                         {formik.errors.name}
// //                       </p>
// //                     )}
// //                   </div>

// //                   {/* <div className="col-md-6">
// //                   <label htmlFor="lastName" className="form-label">
// //                     Enter the Last Name:
// //                   </label>
// //                   <input
// //                   type="text"
// //                   className="form-control bg-white"
// //                   id="lastName"
// //                   name="lastName"
// //                   placeholder="Enter lastName"
// //                   value={formik.values.lastName}
// //                   onChange={formik.handleChange}
// //                   onBlur={formik.handleBlur}
// //                 />
// //                  {formik.errors.lastName && formik.touched.lastName && (
// //                       <p style={{ color: "red", fontSize: "12px" }}>
// //                         {formik.errors.lastName}
// //                       </p>
// //                     )}
// //                 </div> */}

// //                   <div className="col-md-6">
// //                     <label htmlFor="email" className="form-label ">
// //                       Enter the Email ID
// //                     </label>
// //                     <input
// //                       type="email"
// //                       className="form-control bg-white"
// //                       id="email"
// //                       name="email"
// //                       placeholder="Enter email"
// //                       value={formik.values.email}
// //                       onChange={formik.handleChange}
// //                       onBlur={formik.handleBlur}
// //                     />
// //                     {formik.errors.email && formik.touched.email && (
// //                       <p style={{ color: "red", fontSize: "12px" }}>
// //                         {formik.errors.email}
// //                       </p>
// //                     )}
// //                   </div>

// //                   <div className="col-md-6">
// //                     <label htmlFor="phone" className="form-label">
// //                       Enter the Phone Number:
// //                     </label>
// //                     <input
// //                       type="text"
// //                       className="form-control bg-white"
// //                       id="phone"
// //                       name="phone"
// //                       placeholder="Enter phone"
// //                       value={formik.values.phone}
// //                       onChange={formik.handleChange}
// //                       onBlur={formik.handleBlur}
// //                     />
// //                     {formik.errors.phone && formik.touched.phone && (
// //                       <p style={{ color: "red", fontSize: "12px" }}>
// //                         {formik.errors.phone}
// //                       </p>
// //                     )}
// //                   </div>
// //                 </div>

// //                 <div className="mt-4 text-end">
// //                   <button
// //                     type="submit"
// //                     className="btn btn-dark px-4 mx-3"
// //                     onClick={() => formik.resetForm()}
// //                   >
// //                     {" "}
// //                     Clear
// //                   </button>

// //                   <button type="submit" className="btn btn-success px-4">
// //                     Save
// //                   </button>
// //                 </div>
// //               </form>
// //             </div>
// //           </div>
// //         </div>
// //       </Dialog>
// //       <Dialog
// //         header="Confirm Otp"
// //         visible={createmodalpolice}
// //         position="top"
// //         style={{ width: "50vw" }}
// //         onHide={() => {
// //           if (!createmodalpolice) return;
// //           setCreatemodalpolice(false);
// //         }}
// //       >
// //         {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
// //         <form onSubmit={formik1.handleSubmit} autoComplete="off">
// //           <div className="row py-4">
// //             <div className="col-12 col-md-12">
// //               <div className="mb-3">
// //                 <label htmlFor="otp" className="form-label text-muted">
// //                   OTP
// //                 </label>
// //                 <input
// //                   type="text"
// //                   className="form-control w-75"
// //                   id="otp"
// //                   name="otp"
// //                   rows="4"
// //                   placeholder="Type Otp"
// //                   value={formik1.values.otp}
// //                   onChange={formik1.handleChange}
// //                   onBlur={formik1.handleBlur}
// //                 />
// //                 {formik1.errors.otp && formik1.touched.otp && (
// //                   <p style={{ color: "red", fontSize: "12px" }}>
// //                     {formik1.errors.otp}
// //                   </p>
// //                 )}
// //               </div>
// //             </div>
// //             <div className="text-end">
// //               <Button
// //                 variant="outlined"
// //                 color="error"
// //                 onClick={() => formik1.resetForm()}
// //               >
// //                 {" "}
// //                 Cancel
// //               </Button>
// //               <Button
// //                 type="submit"
// //                 variant="contained"
// //                 className="mx-2"
// //                 color="success"
// //               >
// //                 Save{" "}
// //               </Button>
// //               &nbsp;
// //             </div>
// //           </div>
// //         </form>
// //       </Dialog>
// //     </>
// //   );
// // };

// // export default Profilelabel;
// import axios from "axios";
// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { base_url } from "../../BaseUrls/BaseUrl";
// import { TbEdit } from "react-icons/tb";

// import { useFormik } from "formik";
// import * as yup from "yup";
// import Toast from "../../Untils/Toast";

// import Button from "@mui/material/Button";
// import { Dialog } from "primereact/dialog";

// import "./profile.css";
// import { setUserData } from "../../store/authSlice";
// import { useDispatch } from "react-redux";

// const Profilelabel = () => {
//   const navigate = useNavigate();
//   const [useredit, setUseredit] = useState(null);
//   const [profileEdit, setProfileEdit] = useState(false);
//   const [loading, setLoading] = useState(false);
//   const [otpModal, setOtpModal] = useState(false);
//   const dispatch = useDispatch();

//   const token = localStorage.getItem("token");

//   // -------------------------------
//   // Fetch User
//   // -------------------------------
//   const fetchUser = async () => {
//     setLoading(true);
//     try {
//       const user_id = localStorage.getItem("user_id");
//       const token = localStorage.getItem("token");

//       if (!user_id || !token) {
//         console.log("User ID or Token Missing");
//         return;
//       }

//       const response = await axios.get(`${base_url}/user/${user_id}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });

//       const res = response.data;
//       console.log("res wel", response);
//       if (res.status === "success") {
//         dispatch(setUserData(res?.data));
//         setUseredit(res.data);
//         localStorage.setItem("name", res?.data?.name);
//         formik.setValues({
//           name: res.data.name || "",
//           email: res.data.email || "",
//           phone: res.data.phone || "",
//         });
//       }
//     } catch (err) {
//       console.log("Fetch user error", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     if (token) fetchUser();
//   }, [token]);

//   // -------------------------------
//   // Update User Submit
//   // -------------------------------
//   const onSubmit = async (values) => {
//     console.log("useredit  m11", useredit);
//     console.log("values values values", values);
//     try {
//       const response = await axios.post(`${base_url}/profile`, values, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });
//       console.log("success", response);
//       const newData = response?.data;
//       if (newData?.status === "success") {
//         setProfileEdit(false);
//         fetchUser();
//         Toast({ message: newData?.message, type: "success" });
//       }

//       if (values.email !== useredit.email) {
//         setProfileEdit(false);
//         setOtpModal(true);
//       }
//     } catch (err) {
//       Toast({
//         message: "Failed to update profile. Try again.",
//         type: "error",
//       });
//     }
//   };

//   const formik = useFormik({
//     initialValues: { name: "", email: "", phone: "" },
//     validationSchema: yup.object({
//       name: yup.string().required("Name is required"),
//       email: yup.string().required("Email is required"),
//       phone: yup
//         .string()
//         .matches(/^[0-9]{10}$/, "Phone must be 10 digits")
//         .required("Phone is required"),
//     }),
//     onSubmit,
//   });

//   // -------------------------------
//   // OTP Verification Submit
//   // -------------------------------
//   const formikOtp = useFormik({
//     initialValues: { otp: "" },
//     validationSchema: yup.object({
//       otp: yup
//         .string()
//         .matches(/^[0-9]{6}$/, "OTP must be 6 digits")
//         .required("OTP is required"),
//     }),
//     onSubmit: async (values) => {
//       try {
//         const res = await axios.post(
//           `${base_url}/verify/emailupdateotp`,
//           { otp: values.otp },
//           {
//             headers: {
//               Authorization: `Bearer ${token}`,
//             },
//           }
//         );
//         console.log("res form", res);
//         if (res?.data?.status === "success") {
//           Toast({ message: "Email updated successfully!", type: "success" });
//           setOtpModal(false);
//           formikOtp.resetForm();
//           fetchUser();
//         }
//       } catch (err) {
//         Toast({
//           message:
//             err.response?.data?.message || "Invalid OTP. Please try again.",
//           type: "error",
//         });
//       }
//     },
//   });

//   // -------------------------------
//   // JSX
//   // -------------------------------

//   return (
//     <>
//       <div className="bg-white p-3 mx-3 mt-3 rounded-2 pb-5">
//         <div className="position-relative">
//           {/* Edit Icon */}
//           <span
//             onClick={() => setProfileEdit(true)}
//             className="position-absolute top-0 end-0 fs-3 fw-medium"
//             style={{ cursor: "pointer" }}
//           >
//             <TbEdit />
//           </span>

//           <div className="d-flex align-items-center gap-4 mt-4">
//             <div className="profile-avatar"></div>

//             <div className="user-info">
//               {loading ? (
//                 <div className="text-muted">Loading...</div>
//               ) : useredit ? (
//                 <>
//                   <label className="fw-bold">UserName</label>
//                   <p>{useredit.name || "User Name"}</p>

//                   <label className="fw-bold">PhoneNumber</label>
//                   <p>
//                     <i className="bi bi-telephone-fill"></i> {useredit.phone}
//                   </p>

//                   <label className="fw-bold">Email</label>
//                   <p>
//                     <i className="bi bi-envelope-fill"></i> {useredit.email}
//                   </p>
//                 </>
//               ) : (
//                 <p className="text-danger">Failed to load profile</p>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* --------------------- Edit Profile Modal --------------------- */}
//       <Dialog
//         header="Edit Profile"
//         visible={profileEdit}
//         position="top"
//         style={{ width: "32vw" }}
//         onHide={() => setProfileEdit(false)}
//       >
//         <form onSubmit={formik.handleSubmit} autoComplete="off">
//           <div className="row g-3 p-3">
//             <div className="col-md-6">
//               <label>Name</label>
//               <input
//                 type="text"
//                 name="name"
//                 className="form-control bg-white"
//                 value={formik.values.name}
//                 onChange={formik.handleChange}
//                 onBlur={formik.handleBlur}
//               />
//               {formik.touched.name && formik.errors.name && (
//                 <p className="text-danger small">{formik.errors.name}</p>
//               )}
//             </div>

//             <div className="col-md-6">
//               <label>Email</label>
//               <input
//                 type="text"
//                 name="email"
//                 className="form-control bg-white"
//                 value={formik.values.email}
//                 onChange={formik.handleChange}
//                 onBlur={formik.handleBlur}
//               />
//               {formik.touched.email && formik.errors.email && (
//                 <p className="text-danger small">{formik.errors.email}</p>
//               )}
//             </div>

//             <div className="col-md-6">
//               <label>Phone</label>
//               <input
//                 type="text"
//                 name="phone"
//                 className="form-control bg-white"
//                 value={formik.values.phone}
//                 onChange={formik.handleChange}
//                 onBlur={formik.handleBlur}
//               />
//               {formik.touched.phone && formik.errors.phone && (
//                 <p className="text-danger small">{formik.errors.phone}</p>
//               )}
//             </div>
//           </div>

//           <div className="text-end mt-3">
//             <button
//               type="button"
//               className="btn btn-dark mx-2"
//               onClick={() => setProfileEdit(false)}
//             >
//               cancel
//             </button>
//             <button type="submit" className="btn btn-success">
//               Save
//             </button>
//           </div>
//         </form>
//       </Dialog>

//       {/* --------------------- OTP Modal --------------------- */}
//       <Dialog
//         header="Confirm OTP"
//         visible={otpModal}
//         position="top"
//         style={{ width: "50vw" }}
//         onHide={() => setOtpModal(false)}
//       >
//         <form onSubmit={formikOtp.handleSubmit}>
//           <div className="p-4">
//             <label>OTP</label>
//             <input
//               type="text"
//               className="form-control w-50"
//               name="otp"
//               value={formikOtp.values.otp}
//               onChange={formikOtp.handleChange}
//               onBlur={formikOtp.handleBlur}
//             />
//             {formikOtp.touched.otp && formikOtp.errors.otp && (
//               <p className="text-danger small">{formikOtp.errors.otp}</p>
//             )}

//             <div className="text-end mt-4">
//               <Button
//                 variant="outlined"
//                 color="error"
//                 onClick={() => formikOtp.resetForm()}
//               >
//                 Cancel
//               </Button>

//               <Button
//                 type="submit"
//                 variant="contained"
//                 color="success"
//                 className="mx-2"
//               >
//                 Verify
//               </Button>
//             </div>
//           </div>
//         </form>
//       </Dialog>
//     </>
//   );
// };

// export default Profilelabel;

// import axios from "axios";
// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { base_url } from "../../BaseUrls/BaseUrl";
// import profileimg from "../../Assets/Mask group (47).png";
// import { TbEdit } from "react-icons/tb";

// import { useFormik } from "formik";
// import Toast from "../../Untils/Toast";
// import * as yup from "yup";
// import { FaRegEdit } from "react-icons/fa";

// import Button from "@mui/material/Button";
// import { Dialog } from "primereact/dialog";

// import "./profile.css";

// const Profilelabel = () => {
//   const navigate = useNavigate();
//   const [useredit, setUseredit] = useState({
//     name: "",
//     email: "",
//     phone: "",
//   });
//   const [profileEdit, setprofileEdit] = useState(false);
//   const [loading, setLoading] = useState(false);
//   const [createmodalpolice, setCreatemodalpolice] = useState(false);

//   const token = localStorage.getItem("token");

//   const fetchusers = async () => {
//     try {
//       const encryptedUserId = localStorage.getItem("user_id");
//       const token = localStorage.getItem("token");

//       if (!encryptedUserId && !token) {
//         console.error("User ID or token missing in localStorage");
//         return;
//       }

//       const response = await axios.get(`${base_url}/user/${encryptedUserId}`, {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//       });
//       const newData = response?.data;
//       console.log("response newData", newData);
//       if (newData?.status === "success") {
//         formik.setFieldValue({
//           name: newData?.data?.name ? newData?.data?.name : "",
//           email: newData?.data?.email ? newData?.data?.email : "",
//           phone: newData?.data?.phone ? newData?.data?.phone : "",
//         });
//         setUseredit(newData?.data);
//       }
//     } catch (error) {
//       console.error("Error fetching user details:", error);

//       if (error.response && error.response.status === 401) {
//         console.warn("Unauthorized: Invalid or expired token.");
//         // Optional: redirect to login or refresh token
//       }
//     }
//   };

//   useEffect(() => {
//     const encryptedUserId = localStorage.getItem("user_id");
//     if (encryptedUserId && token) {
//       fetchusers();
//     }
//   }, [token]);

//   const onSubmit = async (values) => {
//     try {
//       const token = localStorage.getItem("token");

//       if (!token) {
//         Toast({
//           message: "Please log in to update your profile.",
//           type: "warning",
//         });
//         return;
//       }

//       const response = await axios.post(`${base_url}/profile`, values, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       console.log("response.data", response.data);
//       setCreatemodalpolice(true);
//       // Optional success message
//       Toast({ message: "Send the OTP successfully Email!", type: "success" });
//     } catch (error) {
//       console.error("Error updating profile:", error);
//       Toast({
//         message: "Failed to update profile. Please try again.",
//         type: "error",
//       });
//     }
//   };

//   const formik = useFormik({
//     initialValues: {
//       name: "",
//       phone: "",
//       email: "",
//     },
//     validationSchema: yup.object().shape({
//       name: yup.string().required("name is required!"),
//       phone: yup
//         .string()
//         .required("Phone is required")
//         .matches(/^[0-9]{10}$/, "Phone must be exactly 10 digits"),
//       email: yup.string().required("email is required!"),
//     }),
//     onSubmit,
//   });

//   const formik1 = useFormik({
//     initialValues: {
//       otp: "",
//     },
//     validationSchema: yup.object().shape({
//       otp: yup
//         .string()
//         .required("OTP is required!")
//         .matches(/^\d{6}$/, "OTP must be a 6-digit number"),
//     }),
//     onSubmit: async (values) => {
//       const payload = {
//         otp: values.otp,
//       };

//       console.log("Payload to send:", payload);
//       try {
//         const token = localStorage.getItem("token");

//         if (!token) {
//           Toast({
//             message: "Please log in to update your profile.",
//             type: "warning",
//           });
//           return;
//         }

//         const response = await axios.post(
//           `${base_url}/verify/emailupdateotp`,
//           payload,
//           {
//             headers: {
//               Authorization: `Bearer ${token}`,
//               "Content-Type": "application/json",
//             },
//           }
//         );

//         console.log("response.data", response.data);
//         setCreatemodalpolice(false);
//         // Optional success message
//         Toast({ message: "Send the OTP successfully Email!", type: "success" });
//       } catch (error) {
//         // try {
//         //   const response = await axios.post(`${base_url}/verify/emailupdateotp`, payload);
//         //   setToken(response.data);

//         //   localStorage.setItem("token", response?.data?.token);
//         //   localStorage.setItem("name", response?.data?.name);
//         //   localStorage.setItem("email", response?.data?.email);
//         //   localStorage.setItem("user_id", response?.data?.id);
//         //   localStorage.setItem("customer_id", response?.data?.customer_id);

//         //   Toast({ message: "Successfully Verified!", type: "success" });

//         //   formik.resetForm();

//         // }
//         const errorMessage =
//           error.response?.data?.message ||
//           error.response?.data?.errors?.otp?.[0] ||
//           "Invalid OTP. Please try again.";

//         Toast({ message: errorMessage, type: "error" });
//       }
//     },
//   });

//   const fetchuser = async () => {
//     setLoading(true);
//     try {
//       const encryptedUserId = localStorage.getItem("user_id");

//       if (!encryptedUserId || !token) {
//         console.error("User ID or token missing");
//         setLoading(false);
//         return;
//       }

//       const response = await axios.get(`${base_url}/user/${encryptedUserId}`, {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//         },
//       });

//       setUseredit(response.data);
//     } catch (error) {
//       console.error("Error fetching user details:", error);
//       if (error.response?.status === 401) {
//         // Optional: redirect to login
//         // navigate('/login');
//       }
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <>
//       <div className="bg-white p-2 mx-3 mt-3 rounded-2 pb-5">
//         {useredit?.map((item) => (
//           <div className="position-relative">
//             {/* Edit Icon - Top Right */}
//             <span
//               onClick={() => setprofileEdit(true)}
//               className="position-absolute top-0 end-0 fs-3 fw-medium"
//               style={{ cursor: "pointer" }}
//             >
//               <TbEdit />
//             </span>

//             <div className="d-flex align-items-center gap-4 mt-4">
//               <div className="profile-avatar"></div>

//               <div className="user-info">
//                 {loading ? (
//                   <div className="text-muted">Loading...</div>
//                 ) : useredit ? (
//                   <>
//                     <label className="fw-bold">UserName</label>
//                     <p className="mb-1">
//                       {useredit?.name ? useredit?.name : "User Name"}
//                     </p>

//                     <label className="fw-bold">PhoneNumber</label>
//                     <p className="mb-2 ">
//                       <i className="bi bi-telephone-fill "></i>
//                       {useredit?.phone ? useredit?.phone : "+91 XXXXX XXXXX"}
//                     </p>

//                     <label className="fw-bold">Email</label>
//                     <p className="mb-0">
//                       <i className="bi bi-envelope-fill"></i>
//                       {useredit?.email ? useredit?.email : "user@example.com"}
//                     </p>
//                   </>
//                 ) : (
//                   <p className="text-danger">Failed to load profile</p>
//                 )}
//               </div>
//             </div>
//           </div>
//         ))}
//       </div>

//       {/* Edit Button */}

//       <Dialog
//         header="Edit Profile"
//         visible={profileEdit}
//         position="top"
//         style={{ width: "30vw" }}
//         onHide={() => {
//           if (!profileEdit) return;
//           setprofileEdit(false);
//         }}
//       >
//         <div className="ps-3 py-3">
//           <div className="col-12 col-md-12">
//             <div className="bg-white p-4 w-100 rounded shadow-sm ibm_family">
//               <h5 className="fw-bold mb-3">My Profile</h5>
//               <hr />

//               {/* <div className=" mb-4">
//               <img
//                 src={profileimg}
//                 alt="Profile"
//                 className="img-fluid rounded-circle"
//                 style={{ width: "80px", height: "80px", objectFit: "cover" }}
//               />
//               <span className='ps-5 small'>Edit Profile Picture</span>
//             </div> */}

//               <form onSubmit={formik.handleSubmit} autoComplete="off">
//                 <div className="row g-3">
//                   <div className="col-md-6">
//                     <label htmlFor="name" className="form-label">
//                       Enter the First Name:
//                     </label>
//                     <input
//                       type="text"
//                       className="form-control bg-white"
//                       id="name"
//                       name="name"
//                       placeholder="Enter name"
//                       value={formik.values.name}
//                       onChange={formik.handleChange}
//                       onBlur={formik.handleBlur}
//                     />
//                     {formik.errors.name && formik.touched.name && (
//                       <p style={{ color: "red", fontSize: "12px" }}>
//                         {formik.errors.name}
//                       </p>
//                     )}
//                   </div>

//                   {/* <div className="col-md-6">
//                   <label htmlFor="lastName" className="form-label">
//                     Enter the Last Name:
//                   </label>
//                   <input
//                   type="text"
//                   className="form-control bg-white"
//                   id="lastName"
//                   name="lastName"
//                   placeholder="Enter lastName"
//                   value={formik.values.lastName}
//                   onChange={formik.handleChange}
//                   onBlur={formik.handleBlur}
//                 />
//                  {formik.errors.lastName && formik.touched.lastName && (
//                       <p style={{ color: "red", fontSize: "12px" }}>
//                         {formik.errors.lastName}
//                       </p>
//                     )}
//                 </div> */}

//                   <div className="col-md-6">
//                     <label htmlFor="email" className="form-label ">
//                       Enter the Email ID
//                     </label>
//                     <input
//                       type="email"
//                       className="form-control bg-white"
//                       id="email"
//                       name="email"
//                       placeholder="Enter email"
//                       value={formik.values.email}
//                       onChange={formik.handleChange}
//                       onBlur={formik.handleBlur}
//                     />
//                     {formik.errors.email && formik.touched.email && (
//                       <p style={{ color: "red", fontSize: "12px" }}>
//                         {formik.errors.email}
//                       </p>
//                     )}
//                   </div>

//                   <div className="col-md-6">
//                     <label htmlFor="phone" className="form-label">
//                       Enter the Phone Number:
//                     </label>
//                     <input
//                       type="text"
//                       className="form-control bg-white"
//                       id="phone"
//                       name="phone"
//                       placeholder="Enter phone"
//                       value={formik.values.phone}
//                       onChange={formik.handleChange}
//                       onBlur={formik.handleBlur}
//                     />
//                     {formik.errors.phone && formik.touched.phone && (
//                       <p style={{ color: "red", fontSize: "12px" }}>
//                         {formik.errors.phone}
//                       </p>
//                     )}
//                   </div>
//                 </div>

//                 <div className="mt-4 text-end">
//                   <button
//                     type="submit"
//                     className="btn btn-dark px-4 mx-3"
//                     onClick={() => formik.resetForm()}
//                   >
//                     {" "}
//                     Clear
//                   </button>

//                   <button type="submit" className="btn btn-success px-4">
//                     Save
//                   </button>
//                 </div>
//               </form>
//             </div>
//           </div>
//         </div>
//       </Dialog>
//       <Dialog
//         header="Confirm Otp"
//         visible={createmodalpolice}
//         position="top"
//         style={{ width: "50vw" }}
//         onHide={() => {
//           if (!createmodalpolice) return;
//           setCreatemodalpolice(false);
//         }}
//       >
//         {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
//         <form onSubmit={formik1.handleSubmit} autoComplete="off">
//           <div className="row py-4">
//             <div className="col-12 col-md-12">
//               <div className="mb-3">
//                 <label htmlFor="otp" className="form-label text-muted">
//                   OTP
//                 </label>
//                 <input
//                   type="text"
//                   className="form-control w-75"
//                   id="otp"
//                   name="otp"
//                   rows="4"
//                   placeholder="Type Otp"
//                   value={formik1.values.otp}
//                   onChange={formik1.handleChange}
//                   onBlur={formik1.handleBlur}
//                 />
//                 {formik1.errors.otp && formik1.touched.otp && (
//                   <p style={{ color: "red", fontSize: "12px" }}>
//                     {formik1.errors.otp}
//                   </p>
//                 )}
//               </div>
//             </div>
//             <div className="text-end">
//               <Button
//                 variant="outlined"
//                 color="error"
//                 onClick={() => formik1.resetForm()}
//               >
//                 {" "}
//                 Cancel
//               </Button>
//               <Button
//                 type="submit"
//                 variant="contained"
//                 className="mx-2"
//                 color="success"
//               >
//                 Save{" "}
//               </Button>
//               &nbsp;
//             </div>
//           </div>
//         </form>
//       </Dialog>
//     </>
//   );
// };

// export default Profilelabel;
import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base_url } from "../../BaseUrls/BaseUrl";
import { TbEdit } from "react-icons/tb";

import { useFormik } from "formik";
import * as yup from "yup";
import Toast from "../../Untils/Toast";

import Button from "@mui/material/Button";
import { Dialog } from "primereact/dialog";

import "./profile.css";
import { setUserData } from "../../store/authSlice";
import { useDispatch } from "react-redux";
import Address from "./Address";

const Profilelabel = () => {
  const navigate = useNavigate();
  const [useredit, setUseredit] = useState(null);
  const [profileEdit, setProfileEdit] = useState(false);
  const [loading, setLoading] = useState(false);
  const [otpModal, setOtpModal] = useState(false);
  const dispatch = useDispatch();

  const token = localStorage.getItem("token");

  // -------------------------------
  // Fetch User
  // -------------------------------
  const fetchUser = async () => {
    setLoading(true);
    try {
      const user_id = localStorage.getItem("user_id");
      const token = localStorage.getItem("token");

      if (!user_id || !token) {
        console.log("User ID or Token Missing");
        return;
      }

      const response = await axios.get(`${base_url}/user/${user_id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      const res = response.data;
      console.log("res wel", response);
      if (res.status === "success") {
        dispatch(setUserData(res?.data));
        setUseredit(res.data);
        localStorage.setItem("name", res?.data?.name);
        formik.setValues({
          name: res.data.name || "",
          email: res.data.email || "",
          phone: res.data.phone || "",
        });
      }
    } catch (err) {
      console.log("Fetch user error", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) fetchUser();
  }, [token]);

  // -------------------------------
  // Update User Submit
  // -------------------------------
  const onSubmit = async (values) => {
    console.log("useredit  m11", useredit);
    console.log("values values values", values);
    try {
      const response = await axios.post(`${base_url}/profile`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      console.log("success", response);
      const newData = response?.data;
      if (newData?.status === "success") {
        setProfileEdit(false);
        fetchUser();
        Toast({ message: newData?.message, type: "success" });
      }

      if (values.email !== useredit.email) {
        setProfileEdit(false);
        setOtpModal(true);
      }
    } catch (err) {
      Toast({
        message: "Failed to update profile. Try again.",
        type: "error",
      });
    }
  };

  const formik = useFormik({
    initialValues: { name: "", email: "", phone: "" },
    validationSchema: yup.object({
      name: yup.string().required("Name is required"),
      email: yup.string().required("Email is required"),
      phone: yup
        .string()
        .matches(/^[0-9]{10}$/, "Phone must be 10 digits")
        .required("Phone is required"),
    }),
    onSubmit,
  });

  // -------------------------------
  // OTP Verification Submit
  // -------------------------------
  const formikOtp = useFormik({
    initialValues: { otp: "" },
    validationSchema: yup.object({
      otp: yup
        .string()
        .matches(/^[0-9]{6}$/, "OTP must be 6 digits")
        .required("OTP is required"),
    }),
    onSubmit: async (values) => {
      try {
        const res = await axios.post(
          `${base_url}/verify/emailupdateotp`,
          { otp: values.otp },
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        console.log("res form", res);
        if (res?.data?.status === "success") {
          Toast({ message: "Email updated successfully!", type: "success" });
          setOtpModal(false);
          formikOtp.resetForm();
          fetchUser();
        }
      } catch (err) {
        Toast({
          message:
            err.response?.data?.message || "Invalid OTP. Please try again.",
          type: "error",
        });
      }
    },
  });

  // -------------------------------
  // JSX
  // -------------------------------

  return (
    <>
      <div className=" position-relative">
        <div className="">
          {/* Edit Icon */}
          <span
            onClick={() => setProfileEdit(true)}
            className="fs-3 fw-medium"
            style={{
              position: "absolute",
              cursor: "pointer",
              top: "0",
              right: "13px",
            }}
          >
            <TbEdit />
          </span>

          <div className="d-flex align-items-center gap-4 pt-4">
            <div className="profile-avatar"></div>

            <div className="user-info" style={{ minHeight: "150px" }}>
              {loading ? (
                <div className="text-muted">Loading...</div>
              ) : useredit ? (
                <>
                  <label className="fw-bold">UserName</label>
                  <p className="m-0">{useredit.name || "User Name"}</p>

                  <label className="fw-bold">PhoneNumber</label>
                  <p className="m-0">
                    <i className="bi bi-telephone-fill"></i> {useredit.phone}
                  </p>

                  <label className="fw-bold">Email</label>
                  <p className="m-0">
                    <i className="bi bi-envelope-fill"></i> {useredit.email}
                  </p>
                </>
              ) : (
                <p className="text-danger">Failed to load profile</p>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* --------------------- Edit Profile Modal --------------------- */}
      <Dialog
        header="Edit Profile"
        visible={profileEdit}
        position="top"
        // style={{ width: "32vw" }}
        onHide={() => setProfileEdit(false)}
      >
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className="row g-3 p-3">
            <div className="col-md-6">
              <label>Name</label>
              <input
                type="text"
                name="name"
                className="form-control bg-white"
                value={formik.values.name}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.name && formik.errors.name && (
                <p className="text-danger small">{formik.errors.name}</p>
              )}
            </div>

            <div className="col-md-6">
              <label>Email</label>
              <input
                type="text"
                name="email"
                className="form-control bg-white"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.email && formik.errors.email && (
                <p className="text-danger small">{formik.errors.email}</p>
              )}
            </div>

            <div className="col-md-6">
              <label>Phone</label>
              <input
                type="text"
                name="phone"
                className="form-control bg-white"
                value={formik.values.phone}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.touched.phone && formik.errors.phone && (
                <p className="text-danger small">{formik.errors.phone}</p>
              )}
            </div>
          </div>

          <div className="text-end mt-3">
            <button
              type="button"
              className="btn btn-dark mx-2"
              onClick={() => setProfileEdit(false)}
            >
              cancel
            </button>
            <button type="submit" className="btn btn-success">
              Save
            </button>
          </div>
        </form>
      </Dialog>

      {/* --------------------- OTP Modal --------------------- */}
      <Dialog
        header="Confirm OTP"
        visible={otpModal}
        position="top"
        style={{ width: "50vw" }}
        onHide={() => setOtpModal(false)}
      >
        <form onSubmit={formikOtp.handleSubmit}>
          <div className="p-4">
            <label>OTP</label>
            <input
              type="text"
              className="form-control w-50"
              name="otp"
              value={formikOtp.values.otp}
              onChange={formikOtp.handleChange}
              onBlur={formikOtp.handleBlur}
            />
            {formikOtp.touched.otp && formikOtp.errors.otp && (
              <p className="text-danger small">{formikOtp.errors.otp}</p>
            )}

            <div className="text-end mt-4">
              <Button
                variant="outlined"
                color="error"
                onClick={() => formikOtp.resetForm()}
              >
                Cancel
              </Button>

              <Button
                type="submit"
                variant="contained"
                color="success"
                className="mx-2"
              >
                Verify
              </Button>
            </div>
          </div>
        </form>
      </Dialog>
      <div>
        <Address />
      </div>
    </>
  );
};

export default Profilelabel;
