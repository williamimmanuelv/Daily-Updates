import React, { useEffect, useState } from "react";
import { Sidebar, Menu, MenuItem, SubMenu } from "react-pro-sidebar";
import { FaUser, FaHeart, FaGift, FaBell, FaSignOutAlt } from "react-icons/fa";
import { MdOutlinePolicy } from "react-icons/md";
import LegalPolicies from "./LegalPolicies";
import Header from "../Header/Header";
import Footer from "../Footer/Footer";
import profileimg from "../../Assets/Mask group (47).png";
import { SlEarphones } from "react-icons/sl";
import { TbLanguageKatakana } from "react-icons/tb";
import { CiLocationOn } from "react-icons/ci";
import { TbMessage2Star } from "react-icons/tb";
import { PiNotebookBold } from "react-icons/pi";
import { ImSwitch } from "react-icons/im";
import { HiOutlineChevronRight } from "react-icons/hi";
import Notifications from "./Notifications";
import OffersCoupon from "./OffersCoupon";
import ChooseLanguage from "./ChooseLanguage";
import MyOrders from "../../Pages/Product/MyOrders";
import { useLocation, useNavigate } from "react-router-dom";
import { base_url } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import ProfileEdit from "./ProfileEdit";
import Orders from "./Orders";
import Profilelabel from "./Profilelabel";
import WishlistProfile from "./WishlistProfile";
// import AddressManagement from './AddressManagement';
import Address from "./Address";
import AddressManagement from "./AddressManagement";
import { logout } from "../../store/authSlice";
import { useDispatch } from "react-redux";
import Common from "../../common/Common";

const Sidebars = () => {
  // const [activePage, setActivePage] = useState("profile");
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [useredit, setUseredit] = useState([]);
  // const [activePage, setActivePage] = useState("profilelabel");
  const [activePage, setActivePage] = useState(["profilelabel", "address"]);
  const [activeTab, setActiveTab] = useState("");
  const { user } = Common();

  const token = localStorage.getItem("token");
  const location = useLocation();

  console.log("token", token);
  const handleLogout = async () => {
    dispatch(logout());
    try {
      const response = await axios.post(
        `${base_url}/logout`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );

      localStorage.removeItem("token");
      localStorage.removeItem("selectedRoute");
      localStorage.removeItem("selectedTitle");
      localStorage.removeItem("email");
      localStorage.removeItem("user_id");
      localStorage.removeItem("customer_id");
      localStorage.removeItem("name");
      navigate("/signin");
    } catch (error) {
      console.log("error message");
    }
  };

  const fetchuser = async () => {
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token");

      if (!encryptedUserId || !token) {
        console.error("User ID or token missing in localStorage");
        return;
      }

      const response = await axios.get(`${base_url}/user/${encryptedUserId}`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
      console.log("My Profile", response);
      setUseredit(response?.data?.data);
      console.log("User details:", response.data);
    } catch (error) {
      console.error("Error fetching user details:", error);

      if (error.response && error.response.status === 401) {
        console.warn("Unauthorized: Invalid or expired token.");
        // Optional: redirect to login or refresh token
      }
    }
  };
  console.log("name", useredit);
  useEffect(() => {
    fetchuser();
  }, []);

  useEffect(() => {
    if (location.pathname.includes("/sidebar/address")) {
      setActiveTab("address");
    } else if (location.pathname.includes("/profile_edit/addressmanagement")) {
      setActiveTab("addressmanagement");
    }
  }, [location.pathname]);

  return (
    <>
      <Header />
      <div className="body_bgcolor ">
        <div className=" container">
          <h4 className="fw-bold pb-3 cardfamily pt-3">My Profile</h4>
          <div className="row">
            <div className="col-12 col-md-3">
              <div className="profilebgcolor d-flex align-items-center justify-content-between p-3 rounded ">
                <div className="d-flex align-items-center">
                  <img
                    src={profileimg}
                    alt="profile"
                    className="img-fluid rounded-circle me-3"
                    style={{
                      width: "60px",
                      height: "60px",
                      objectFit: "cover",
                    }}
                  />

                  <div>
                    <span className="fw-semibold d-block">{user?.name}</span>
                    <span className="text-muted">{user?.phone}</span>
                  </div>
                </div>
                <div>
                  {/* <span className="heart_color fw-semibold" style={{ cursor: "pointer" }}
                    onClick={() => navigate('/profileedit')}
                   onClick={() => setActivePage("profileedit")}
                   >Edit</span> */}
                </div>
              </div>
            </div>
          </div>

          <div className="d-flex pb-5" style={{ minHeight: "100vh" }}>
            {/* Sidebar */}

            <div
              className="bg-white p-3 shadow-sm mt-3"
              style={{ width: "380px" }}
            >
              {/* Profile */}
              {/* Menu */}
              <ul className="list-unstyled">
                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "profilelabel" ? "bg-light fw-bold" : ""
                  }`}
                  onClick={() => setActivePage("profilelabel")}
                >
                  <FaUser className="me-2" />
                  Profile
                </li>
                <hr />

                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "order" ? "bg-light fw-bold" : ""
                  }`}
                  // onClick={() => setActivePage("order")}
                  onClick={() => navigate("/myorders")}
                >
                  <FaUser className="me-2" />
                  My Orders
                </li>
                <hr />
                <li
                  className={`py-2 px-2 rounded  ${
                    activePage === "wishlistprofile" ? "bg-light fw-bold" : ""
                  }`}
                  onClick={() => setActivePage("wishlistprofile")}
                >
                  <FaHeart className="me-2" /> Wishlist
                </li>
                <hr />

                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "offersCoupon" ? "bg-light fw-bold" : ""
                  }`}
                  onClick={() => setActivePage("offersCoupon")}
                >
                  <FaGift className="me-2" /> Offers & Coupons
                </li>
                <hr />

                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "notification" ? "bg-light fw-bold" : ""
                  }`}
                  onClick={() => setActivePage("notification")}
                >
                  <FaBell className="me-2" /> Notifications
                </li>
                <hr />
                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "helpsupport" ? "bg-light fw-bold" : ""
                  }`}
                  onClick={() => setActivePage("helpsupport")}
                >
                  <SlEarphones className="me-2" /> Help & Support
                </li>
                <hr />
                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "chooselanguage" ? "bg-light fw-bold" : ""
                  }`}
                  onClick={() => setActivePage("chooselanguage")}
                >
                  <TbLanguageKatakana className="me-2" /> Choose Language
                </li>
                <hr />
                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "address" ? "bg-light fw-bold" : ""
                  }`}
                  //       className={`py-2 px-2 rounded  ${ activeTab === "address" || activeTab === "addressmanagement"
                  //     ? "active"
                  //     : ""
                  // }`}
                  onClick={() => {
                    setActivePage("address");
                    //  navigate("/sidebar/address");
                  }}
                >
                  <CiLocationOn size={20} className="me-2" /> Address Management
                </li>
                {/* <li className="nav-item">
          <a
            className={`nav-link ${
              activeTab === "address" || activeTab === "add_address"
                ? "active"
                : ""
            }`}
            onClick={() => {
              setActiveTab("address");
              navigate("/profile_edit/address");
            }}
          >
            <ApartmentIcon /> Address
          </a>
        </li> */}
                <hr />
                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "reviewrating" ? "bg-light fw-bold" : ""
                  }`}
                  onClick={() => setActivePage("reviewrating")}
                >
                  <TbMessage2Star className="me-2" /> Review & Rating
                </li>
                <hr />

                <li
                  className={`py-2 px-2 rounded ${
                    activePage === "legalpolicies" ? "bg-light fw-bold" : ""
                  }`}
                  onClick={() => setActivePage("legalpolicies")}
                >
                  <PiNotebookBold className="me-2" /> Legal Policies
                </li>
                <hr />

                <li
                  className="py-2 px-2 rounded text-danger fw-bold"
                  onClick={() => handleLogout()}
                >
                  <ImSwitch className="me-2" /> Log Out
                </li>
              </ul>
            </div>

            {/* Main Content */}
            <div className="flex-grow-1 ">
              {/* {activePage === "profilelabel" && <Profilelabel />}  */}
              {activePage.includes("profilelabel") && <Profilelabel />}
              {/* <Profilelabel />  */}

              {activePage === "order" && (
                <h4>
                  <Orders />
                </h4>
              )}
              {activePage === "wishlistprofile" && (
                <h4>
                  <WishlistProfile />
                </h4>
              )}
              {activePage === "offersCoupon" && <OffersCoupon />}
              {activePage === "notification" && <Notifications />}
              {activePage === "helpsupport" && <h4>Help & Support</h4>}
              {activePage === "chooselanguage" && <ChooseLanguage />}
              {activePage === "addressmanagement" && (
                <h4>
                  <AddressManagement />
                </h4>
              )}
              {activePage.includes("address") && <Address />}
              {activePage === "reviewrating" && <h4>Review & Rating</h4>}
              {activePage === "legalpolicies" && <LegalPolicies />}
              {activePage === "logout" && <h4>LOG OUT</h4>}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Sidebars;
