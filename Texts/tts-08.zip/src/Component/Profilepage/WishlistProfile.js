// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom";
// import { base_url, img_path } from "../../BaseUrls/BaseUrl";
// import axios from "axios";
// import Toastify from "../../Untils/Toastify";
// import { FaHeart, FaStar } from "react-icons/fa6";
// import { RiDeleteBinLine } from "react-icons/ri";
// import { BiSolidCartAdd } from "react-icons/bi";
// import { CiHeart } from "react-icons/ci";
// import UpdateFilterData from "../../service/ApiService";

// const WishlistProfile = () => {
//   const navigate = useNavigate();
//   const { showAddToCartToast } = Toastify();
//   const { Update } = UpdateFilterData();

//   const [fetchwishlists, setFetchwishlists] = useState([]);
//   console.log("fetchwishlists", fetchwishlists);

//   const user_id = localStorage.getItem("user_id");

//   const fetchwishlist = async () => {
//     try {
//       const token = localStorage.getItem("token");

//       if (!token) {
//         // Toast({ message: "Please log in to view your cart.", type: "warning" });
//         return;
//       }

//       const response = await axios.get(`${base_url}/wishlist`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//           // "tts-user": user_id,
//         },
//       });

//       setFetchwishlists(response.data);
//       console.log("response.data", response.data);
//     } catch (error) {}
//   };

//   useEffect(() => {
//     fetchwishlist();
//   }, []);

//   const handleAddToCartproduct = async (item) => {
//     try {
//       const token = localStorage.getItem("token");

//       // if (!token) {
//       //   Toast({ message: "Please log in to add products to your cart.", type: "warning" });
//       //   return;
//       // }

//       const values = {
//         user_id: user_id,
//         product_id: item.id,

//         quantity: 1,
//       };

//       const response = await axios.post(`${base_url}/cart`, values, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });
//       await Update("cart");
//       showAddToCartToast();

//       // navigate('/addtocart')
//     } catch (error) {}
//   };

//   const handlewishlistcart = async (item) => {
//     try {
//       const token = localStorage.getItem("token");

//       if (!token) {
//         // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
//         return;
//       }

//       const values = {
//         user_id: user_id,
//         product_id: item.id,
//       };

//       const response = await axios.post(`${base_url}/wishlist`, values, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//           "Content-Type": "application/json",
//         },
//       });

//       console.log("response.data", response.data);
//     } catch (error) {}
//   };

//   const handleConfirmDelete = async (wid) => {
//     try {
//       const token = localStorage.getItem("token");

//       if (!token) {
//         // Toast({ message: "Please log in first.", type: "warning" });
//         return;
//       }
//       const response = await axios.delete(`${base_url}/wishlist/${wid}`, {
//         headers: {
//           Authorization: `Bearer ${token}`,
//         },
//       });

//       fetchwishlist();
//     } catch (error) {}
//   };

//   const editcategorypreview = (categoryId) => {
//     console.log("categoryIdhhhhh", categoryId);
//     navigate("/cart", { state: { categoryId } });
//   };

//   const [fetchOurrecomment, setFetchOurrecomment] = useState([]);
//   console.log("fetchOurrecommentddd", fetchOurrecomment);
//   const fetchrecommendation = async () => {
//     try {
//       const token = localStorage.getItem("token");

//       const response = await axios.get(`${base_url}/you-may-like/products`, {
//         headers: {
//           "Content-Type": "application/json",
//           Authorization: `Bearer ${token}`,
//           "tts-user-id": user_id,
//         },
//       });
//       setFetchOurrecomment(response.data?.data);
//     } catch (error) {}
//   };

//   useEffect(() => {
//     fetchrecommendation();
//   }, []);
//   return (
//     <>
//       <div className=" px-3">
//         <div className="container py-4 fs-6">
//           <h4 className="pb-3 fw-bold cardfamily"> My Wishlist</h4>
//           <div className="bg-white">
//             <h5 className="p-3 cardfamily fw-semibold">
//               Your favorited products
//             </h5>
//             <hr />

//             <div>
//               {fetchwishlists?.length > 0 ? (
//                 fetchwishlists.map((item) => (
//                   <div
//                     className="row align-items-center border-bottom rounded-3 p-3 mb-3"
//                     key={item.id}
//                   >
//                     {/* Product Image & Info */}
//                     <div
//                       className="col-12 col-md-4 d-flex align-items-center"
//                       onClick={() => editcategorypreview(item.id)}
//                     >
//                       <div className="position-relative me-3 border p-3">
//                         <img
//                           src={`${img_path}/products/${item.image}`}
//                           alt={item.product_name}
//                           className="img-fluid rounded"
//                           style={{
//                             width: "120px",
//                             height: "120px",
//                             objectFit: "contain",
//                           }}
//                         />

//                         {/* Wishlist Heart */}
//                         <FaHeart
//                           size={18}
//                           className="heart_color position-absolute"
//                           style={{ top: "5px", left: "-1px" }}
//                         />

//                         {/* Discount Badge */}
//                         <span
//                           className="position-absolute badge bg-dark small p-1"
//                           style={{ top: "5px", right: "-5px" }}
//                         >
//                           {item.discount}%
//                         </span>
//                       </div>

//                       <div>
//                         <h6 className="mb-1 cardfamily">{item.product_name}</h6>
//                         <p className="mb-1 text-muted small">(1 kg)</p>

//                         <div className="d-flex align-items-center">
//                           <FaStar color="#ff9d00" />
//                           <span className="fw-bold fs-6 ms-1">4.5</span>
//                         </div>

//                         <div className="mt-2">
//                           <span className="cart_color fw-bold fs-5 me-2">
//                             {item.price}€
//                           </span>
//                           <span className="text-muted">
//                             <s>{item.mrp}€</s>
//                           </span>
//                         </div>
//                       </div>
//                     </div>

//                     {/* Stock Info */}
//                     <div className="col-6 col-md-2 text-center mt-3 mt-md-0">
//                       <button className="btn btn-success btn-sm px-3">
//                         Stock In
//                       </button>
//                     </div>

//                     {/* Remove Button */}
//                     <div className="col-6 col-md-3 text-center mt-3 mt-md-0">
//                       <div
//                         className="border p-2 d-inline-flex align-items-center justify-content-center gap-2 rounded-3"
//                         style={{ cursor: "pointer" }}
//                         onClick={() => handleConfirmDelete(item.wid)}
//                       >
//                         <RiDeleteBinLine size={20} className="cart_color" />
//                         <span className="fw-semibold cardfamily">Remove</span>
//                       </div>
//                     </div>

//                     {/* Add To Cart */}
//                     <div className="col-12 col-md-3 text-center text-md-center mt-3 mt-md-0">
//                       <button
//                         className="btn btn-dark px-3 py-2"
//                         onClick={() => {
//                           handleAddToCartproduct(item);
//                         }}
//                       >
//                         Add
//                         <BiSolidCartAdd size={22} />
//                       </button>
//                     </div>
//                   </div>
//                 ))
//               ) : (
//                 <div className="text-center text-muted py-5">
//                   No products available
//                 </div>
//               )}
//             </div>

//             {/* <hr /> */}
//             {/* <div className='row py-1'>
//                 <div className="col-12 col-md-3">
//                   <div className='d-flex'>

//                     <div className="d-flex border rounded p-2 h-100 ms-3">

//                       <div className="position-relative me-3">
//                         <img
//                           src={basmatirice}
//                           alt="Basmati Rice"
//                           className="img-fluid mt-3"
//                           style={{ width: "120px", height: "120px", objectFit: "contain" }}
//                         />
//                         <FaHeart
//                           size={18}
//                           className="heart_color  position-absolute"
//                           style={{ top: "2px", left: "-5px" }}
//                         />
//                         <span
//                           className="position-absolute badge bg-dark small"
//                           style={{ top: "2px", right: "-22px" }}
//                         >
//                           20%
//                         </span>
//                       </div>
//                     </div>

//                     <div className="d-flex flex-column justify-content-between">
//                       <div className='ps-3'>
//                         <h6 className="mb-1 cardfamily">Masoor (Small)</h6>
//                         <p className="mb-1 text-muted small">(500 gm)</p>
//                         <div className="d-flex align-items-center  ms-5 ps-5">
//                           <FaStar color="#ff9d00" />
//                           <span className="fw-bold fs-6 ms-1">4.5</span>
//                         </div>
//                       </div>
//                       <div className='ps-3'>
//                         <span className="cart_color fw-bold fs-5 me-2">1,50€</span>
//                         <span className="text-muted">
//                           <s>7,50€</s>
//                         </span>
//                       </div>
//                     </div>
//                   </div>

//                 </div>
//                 <div className="col-12 col-md-3 text-md-center mt-5 pt-5 mt-md-0">
//                   <button className="btn btn-success btn-sm px-3">Stock In</button>
//                 </div>

//                 <div className="col-12 col-md-2 mt-5 pt-5 mt-md-0">
//                   <div className="border p-2 d-flex align-items-center justify-content-center gap-2 rounded-3">
//                     <RiDeleteBinLine size={20} className="cart_color" />
//                     <span className="fw-semibold cardfamily">Remove</span>
//                   </div>
//                 </div>

//                 <div className="col-12 col-md-3 text-md-end mt-5 pt-5 mt-md-0 cardfamily">
//                   <button className="btn btn-dark p-0 px-2 py-1">+ Add To Cart</button>
//                 </div>
//               </div> */}
//             <hr />
//             {/* <div className='row py-1'>
//                 <div className="col-12 col-md-3">
//                   <div className='d-flex'>

//                     <div className="d-flex border rounded p-2 h-100 ms-3">

//                       <div className="position-relative me-3">
//                         <img
//                           src={basmatirice}
//                           alt="Basmati Rice"
//                           className="img-fluid mt-3"
//                           style={{ width: "120px", height: "120px", objectFit: "contain" }}
//                         />
//                         <FaHeart
//                           size={18}
//                           className="heart_color  position-absolute"
//                           style={{ top: "2px", left: "-5px" }}
//                         />
//                         <span
//                           className="position-absolute badge bg-dark small"
//                           style={{ top: "2px", right: "-22px" }}
//                         >
//                           20%
//                         </span>
//                       </div>
//                     </div>

//                     <div className="d-flex flex-column justify-content-between">
//                       <div className='ps-3'>
//                         <h6 className="mb-1 cardfamily">Arhar Dal </h6>
//                         <p className="mb-1 text-muted small">(500 gm)</p>
//                         <div className="d-flex align-items-center  ms-5 ps-5">
//                           <FaStar color="#ff9d00" />
//                           <span className="fw-bold fs-6 ms-1">4.5</span>
//                         </div>
//                       </div>
//                       <div className='ps-3'>
//                         <span className="cart_color fw-bold fs-5 me-2">1,50€</span>
//                         <span className="text-muted">
//                           <s>7,50€</s>
//                         </span>
//                       </div>
//                     </div>
//                   </div>

//                 </div>

//                 <div className="col-12 col-md-3 text-md-center mt-5 pt-5 mt-md-0">
//                   <button className="btn btn-success btn-sm px-3">Stock In</button>
//                 </div>

//                 <div className="col-12 col-md-2 mt-5 pt-5 mt-md-0">
//                   <div className="border p-2 d-flex align-items-center justify-content-center gap-2 rounded-3">
//                     <RiDeleteBinLine size={20} className="cart_color" />
//                     <span className="fw-semibold cardfamily">Remove</span>
//                   </div>
//                 </div>

//                 <div className="col-12 col-md-3 text-md-end mt-5 pt-5 mt-md-0 cardfamily">
//                   <button className="btn btn-dark p-0 px-2 py-1">+ Add To Cart</button>
//                 </div>

//               </div> */}
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default WishlistProfile;

import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import Toastify from "../../Untils/Toastify";
import { FaHeart, FaStar } from "react-icons/fa6";
import { RiDeleteBinLine } from "react-icons/ri";
import { BiSolidCartAdd } from "react-icons/bi";
import { CiHeart } from "react-icons/ci";
import UpdateFilterData from "../../service/ApiService";

const WishlistProfile = () => {
  const navigate = useNavigate();
  const { showAddToCartToast } = Toastify();
  const { Update } = UpdateFilterData();

  const [fetchwishlists, setFetchwishlists] = useState([]);
  console.log("fetchwishlists", fetchwishlists);

  const user_id = localStorage.getItem("user_id");

  const fetchwishlist = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to view your cart.", type: "warning" });
        return;
      }

      const response = await axios.get(`${base_url}/wishlist`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          // "tts-user": user_id,
        },
      });

      setFetchwishlists(response.data);
      console.log("response.data", response.data);
    } catch (error) {}
  };

  useEffect(() => {
    fetchwishlist();
  }, []);

  const handleAddToCartproduct = async (item) => {
    try {
      const token = localStorage.getItem("token");

      // if (!token) {
      //   Toast({ message: "Please log in to add products to your cart.", type: "warning" });
      //   return;
      // }

      const values = {
        user_id: user_id,
        product_id: item.id,

        quantity: 1,
      };

      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await Update("cart");
      showAddToCartToast();

      // navigate('/addtocart')
    } catch (error) {}
  };

  const handlewishlistcart = async (item) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const values = {
        user_id: user_id,
        product_id: item.id,
      };

      const response = await axios.post(`${base_url}/wishlist`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("response.data", response.data);
    } catch (error) {}
  };

  const handleConfirmDelete = async (wid) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(`${base_url}/wishlist/${wid}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      fetchwishlist();
    } catch (error) {}
  };

  const editcategorypreview = (categoryId) => {
    console.log("categoryIdhhhhh", categoryId);
    navigate("/cart", { state: { categoryId } });
  };

  const [fetchOurrecomment, setFetchOurrecomment] = useState([]);
  console.log("fetchOurrecommentddd", fetchOurrecomment);
  const fetchrecommendation = async () => {
    try {
      const token = localStorage.getItem("token");

      const response = await axios.get(`${base_url}/you-may-like/products`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });
      setFetchOurrecomment(response.data?.data);
    } catch (error) {}
  };

  useEffect(() => {
    fetchrecommendation();
  }, []);
  return (
    <>
      <div className="container p-2 fs-6">
        <div className="side_bar_header">
          <h5 className="fw-bold "> My Wishlist</h5>
          <p className="cardfamily fw-semibold">Your favorited products</p>
        </div>
        <hr />

        <div>
          {fetchwishlists?.length > 0 ? (
            fetchwishlists.map((item) => (
              <div
                className="row align-items-center border-bottom rounded-3 p-3 mb-3"
                key={item.id}
              >
                {/* Product Image & Info */}
                <div
                  className="col-12 col-md-4 d-flex align-items-center"
                  onClick={() => editcategorypreview(item.id)}
                >
                  <div className="position-relative me-3 border p-3">
                    <img
                      src={`${img_path}/products/${item.image}`}
                      alt={item.product_name}
                      className="img-fluid rounded"
                      style={{
                        width: "120px",
                        height: "120px",
                        objectFit: "contain",
                      }}
                    />

                    {/* Wishlist Heart */}
                    <FaHeart
                      size={18}
                      className="heart_color position-absolute"
                      style={{ top: "5px", left: "-1px" }}
                    />

                    {/* Discount Badge */}
                    <span
                      className="position-absolute badge bg-dark small p-1"
                      style={{ top: "5px", right: "-5px" }}
                    >
                      {item.discount}%
                    </span>
                  </div>

                  <div>
                    <h6 className="mb-1 cardfamily">{item.product_name}</h6>
                    <p className="mb-1 text-muted small">(1 kg)</p>

                    <div className="d-flex align-items-center">
                      <FaStar color="#ff9d00" />
                      <span className="fw-bold fs-6 ms-1">4.5</span>
                    </div>

                    <div className="mt-2">
                      <span className="cart_color fw-bold fs-5 me-2">
                        {item.price}€
                      </span>
                      <span className="text-muted">
                        <s>{item.mrp}€</s>
                      </span>
                    </div>
                  </div>
                </div>

                {/* Stock Info */}
                <div className="col-6 col-md-2 text-center mt-3 mt-md-0">
                  <button className="btn btn-success btn-sm px-3">
                    Stock In
                  </button>
                </div>

                {/* Remove Button */}
                <div className="col-6 col-md-3 text-center mt-3 mt-md-0">
                  <div
                    className="border p-2 d-inline-flex align-items-center justify-content-center gap-2 rounded-3"
                    style={{ cursor: "pointer" }}
                    onClick={() => handleConfirmDelete(item.wid)}
                  >
                    <RiDeleteBinLine size={20} className="cart_color" />
                    <span className="fw-semibold cardfamily">Remove</span>
                  </div>
                </div>

                {/* Add To Cart */}
                <div className="col-12 col-md-3 text-center text-md-center mt-3 mt-md-0">
                  <button
                    className="btn btn-dark px-3 py-2"
                    onClick={() => {
                      handleAddToCartproduct(item);
                    }}
                  >
                    Add
                    <BiSolidCartAdd size={22} />
                  </button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center text-muted py-5">
              No products available
            </div>
          )}
        </div>

        {/* <hr /> */}
        {/* <div className='row py-1'>
                <div className="col-12 col-md-3">
                  <div className='d-flex'>
  
                    <div className="d-flex border rounded p-2 h-100 ms-3">
  
                      <div className="position-relative me-3">
                        <img
                          src={basmatirice}
                          alt="Basmati Rice"
                          className="img-fluid mt-3"
                          style={{ width: "120px", height: "120px", objectFit: "contain" }}
                        />
                        <FaHeart
                          size={18}
                          className="heart_color  position-absolute"
                          style={{ top: "2px", left: "-5px" }}
                        />
                        <span
                          className="position-absolute badge bg-dark small"
                          style={{ top: "2px", right: "-22px" }}
                        >
                          20%
                        </span>
                      </div>
                    </div>
  
  
                    <div className="d-flex flex-column justify-content-between">
                      <div className='ps-3'>
                        <h6 className="mb-1 cardfamily">Masoor (Small)</h6>
                        <p className="mb-1 text-muted small">(500 gm)</p>
                        <div className="d-flex align-items-center  ms-5 ps-5">
                          <FaStar color="#ff9d00" />
                          <span className="fw-bold fs-6 ms-1">4.5</span>
                        </div>
                      </div>
                      <div className='ps-3'>
                        <span className="cart_color fw-bold fs-5 me-2">1,50€</span>
                        <span className="text-muted">
                          <s>7,50€</s>
                        </span>
                      </div>
                    </div>
                  </div>
  
                </div>
                <div className="col-12 col-md-3 text-md-center mt-5 pt-5 mt-md-0">
                  <button className="btn btn-success btn-sm px-3">Stock In</button>
                </div>
  
                <div className="col-12 col-md-2 mt-5 pt-5 mt-md-0">
                  <div className="border p-2 d-flex align-items-center justify-content-center gap-2 rounded-3">
                    <RiDeleteBinLine size={20} className="cart_color" />
                    <span className="fw-semibold cardfamily">Remove</span>
                  </div>
                </div>
  
  
                <div className="col-12 col-md-3 text-md-end mt-5 pt-5 mt-md-0 cardfamily">
                  <button className="btn btn-dark p-0 px-2 py-1">+ Add To Cart</button>
                </div>
              </div> */}
        <hr />
        {/* <div className='row py-1'>
                <div className="col-12 col-md-3">
                  <div className='d-flex'>
  
                    <div className="d-flex border rounded p-2 h-100 ms-3">
  
                      <div className="position-relative me-3">
                        <img
                          src={basmatirice}
                          alt="Basmati Rice"
                          className="img-fluid mt-3"
                          style={{ width: "120px", height: "120px", objectFit: "contain" }}
                        />
                        <FaHeart
                          size={18}
                          className="heart_color  position-absolute"
                          style={{ top: "2px", left: "-5px" }}
                        />
                        <span
                          className="position-absolute badge bg-dark small"
                          style={{ top: "2px", right: "-22px" }}
                        >
                          20%
                        </span>
                      </div>
                    </div>
  
  
                    <div className="d-flex flex-column justify-content-between">
                      <div className='ps-3'>
                        <h6 className="mb-1 cardfamily">Arhar Dal </h6>
                        <p className="mb-1 text-muted small">(500 gm)</p>
                        <div className="d-flex align-items-center  ms-5 ps-5">
                          <FaStar color="#ff9d00" />
                          <span className="fw-bold fs-6 ms-1">4.5</span>
                        </div>
                      </div>
                      <div className='ps-3'>
                        <span className="cart_color fw-bold fs-5 me-2">1,50€</span>
                        <span className="text-muted">
                          <s>7,50€</s>
                        </span>
                      </div>
                    </div>
                  </div>
  
                </div>
  
  
  
                <div className="col-12 col-md-3 text-md-center mt-5 pt-5 mt-md-0">
                  <button className="btn btn-success btn-sm px-3">Stock In</button>
                </div>
  
  
                <div className="col-12 col-md-2 mt-5 pt-5 mt-md-0">
                  <div className="border p-2 d-flex align-items-center justify-content-center gap-2 rounded-3">
                    <RiDeleteBinLine size={20} className="cart_color" />
                    <span className="fw-semibold cardfamily">Remove</span>
                  </div>
                </div>
  
  
                <div className="col-12 col-md-3 text-md-end mt-5 pt-5 mt-md-0 cardfamily">
                  <button className="btn btn-dark p-0 px-2 py-1">+ Add To Cart</button>
                </div>
  
  
              </div> */}
      </div>
    </>
  );
};

export default WishlistProfile;
