import { Button } from "antd";
import React from "react";
import { AiOutlineLeft } from "react-icons/ai";
import "./orderTrack.css";
import success_tick from "../../../Assets/sucess_tick.svg";
import { useNavigate } from "react-router-dom";
const OrderTrack = ({ orderStatus = "delivered" }) => {
  const trackingStages = [
    { key: "confirmed", label: "Ordered" },
    // { key: "in_transit", label: "In Transition" },
    { key: "pending", label: "Processing" },
    { key: "shipping", label: "Shipping" },
    { key: "out_for_delivery", label: "Out for Delivery" },
    { key: "delivered", label: "Delivered" },
  ];
  const getStatusIndex = (status) => {
    return trackingStages?.findIndex((stage) => stage.key === status);
  };
  const navigate = useNavigate();

  const currentIndex = getStatusIndex(orderStatus);
  return (
    <div>
      <div className="order-track-container">
        {/* {loading ? (
          <div className="loader-wrapper">
            <Loader />
          </div>
        ) : ( */}
        <>
          <div className="track-header">
            <h2 className="track-title">My Order - Tracking</h2>
          </div>

          <div className="track-grid">
            <div className="track-right">
              <img src={Image} alt="" className="track-image" />
            </div>
            <div className="track-left">
              <ol className="track-stepper">
                {orderStatus === "cancelled" ? (
                  <h3 className="cancel-msg">Your order has been cancelled.</h3>
                ) : (
                  trackingStages?.map((stage, index) => {
                    const isActive = index <= currentIndex;
                    return (
                      <li key={stage.key} className="step-item">
                        <span
                          className={`step-icon ${
                            isActive ? "active" : "inactive"
                          }`}
                        >
                          {isActive ? (
                            <img
                              src={success_tick}
                              alt=""
                              className="tick-img"
                            />
                          ) : (
                            <div className="step-dot"></div>
                          )}
                        </span>

                        <h3
                          className={`step-label ${
                            isActive ? "active-text" : "inactive-text"
                          }`}
                        >
                          {stage.label}
                        </h3>
                      </li>
                    );
                  })
                )}
              </ol>
            </div>
          </div>
        </>
        {/* )} */}
      </div>
    </div>
  );
};

export default OrderTrack;
