import { Carousel, Image, Modal } from "antd";
import React, { useEffect, useState } from "react";
import Common from "../../common/Common";
import { setFirstRender } from "../../store/authSlice";
import "./intialmodal.css";
import axios from "axios";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";

const InitialModal = () => {
  const { firstRender, dispatch, navigate } = Common();
  const [banners, setBanners] = useState([]);
  const handleCancel = () => {
    dispatch(setFirstRender(false));
  };
  const fetchBanners = async () => {
    try {
      const res = await axios.get(`${base_url}/home/dymanicpopup`);
      console.log("res", res);
      setBanners(res?.data);
    } catch (error) {
      console.log("error", error);
    }
  };
  useEffect(() => {
    if (firstRender) {
      fetchBanners();
    }
  }, [firstRender]);

  const handleClick = (e, link) => {
    e.preventDefault();
    if (link) {
      e.stopPropagation();
      window.open(link, "_blank");
    }
  };

  return (
    <>
      <div>
        {" "}
        <Modal
          open={firstRender}
          onCancel={handleCancel}
          footer={null}
          closable={true}
          maskClosable={false}
          className="initial_popup_modal"
          width="70%"
        >
          <Carousel autoplay infinite={true} draggable>
            {banners?.map((banner) => (
              <div className="image_container">
                <img
                  key={banner.id}
                  src={`${img_path}/dynamicpopup/${banner?.thumbnail}`}
                  alt={banner?.discount_product}
                  className="image_container_img"
                  onClick={(e) => handleClick(e, banner?.product_page_link)}
                />
              </div>
            ))}
          </Carousel>
        </Modal>
      </div>
    </>
  );
};

export default InitialModal;
