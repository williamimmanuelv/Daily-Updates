import React from "react";
import "./ordercard.css";

const orders = [
  {
    id: "Order000101",
    date: "7th May 2025, 08:50pm",
    price: "7,50€",
    status: "delivered", // delivered | cancelled | processing
    timeline: {
      placed: true,
      processing: true,
      packed: true,
      shipped: true,
      delivered: true,
    },
    items: [
     { img: "https://via.placeholder.com/120?text=Item+1" },
      { img: "https://via.placeholder.com/120?text=Item+2" },
      { img: "https://via.placeholder.com/120?text=Item+3" },
      { img: "https://via.placeholder.com/120?text=Item+4" },,
    ],
  },

  {
    id: "Order000102",
    date: "7th May 2025, 08:50pm",
    price: "7,50€",
    status: "cancelled",
    timeline: {
      placed: true,
      processing: true,
      packed: true,
      shipped: true,
      delivered: false,
    },
    items: [
      //   { img: bRice },
      //   { img: tataMasoorDal },
      //   { img: corn },
      //   { img: onion },
    ],
  },
];

const OrderCard = ({ order = orders[0] }) => {
  const statusText = {
    delivered: "Order at delivered",
    cancelled: "Order at Cancelled",
    processing: "Order at Processing",
  };

  const statusIcon = {
    delivered: "🟢",
    cancelled: "🔴",
    processing: "🟢",
  };

  return (
    <div className="order_card">
      {/* Product images list */}
      <div className="order_items">
        {order.items.map((item, index) => (
          <div className="order_item_box" key={index}>
            <img src={item.img} alt="product" className="order_item_img" />
          </div>
        ))}
      </div>

      {/* Order right section */}
      <div className="order_details">
        {/* Timeline */}
        <div className="order_timeline">
          {["placed", "processing", "packed", "shipped", "delivered"].map(
            (step, i) => (
              <div
                className={`timeline_step ${
                  order.timeline[step] ? "active" : ""
                }`}
                key={i}
              >
                <div className="dot"></div>
                <p>{step.charAt(0).toUpperCase() + step.slice(1)}</p>
              </div>
            )
          )}
        </div>

        <div className="order_info">
          <div className="price">
            Prices: <span>{order.price}</span>
          </div>
          <div className="orderid">Order ID: #{order.id}</div>

          {/* Status */}
          <h3 className="order_status">
            {statusIcon[order.status]} {statusText[order.status]}
          </h3>

          <p className="order_date">Placed at {order.date}</p>
        </div>
      </div>
    </div>
  );
};

export default OrderCard;
