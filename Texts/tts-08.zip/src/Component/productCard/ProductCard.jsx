import React, { useState } from "react";
import "./productCard.css";

const ProductCard = () => {
  const [fav, setFav] = useState(false);

  return (
    <div className="product-card">
      <div className="img-wrap">
        <button
          className={`fav ${fav ? "filled" : ""}`}
          onClick={() => setFav(!fav)}
        >
          <svg viewBox="0 0 24 24">
            <path d="M12.1 21.35l-1.1-.99C5.14 15.24 2 12.39 2 8.9 2 6.2 4.2 4 6.9 4c1.7 0 3.3.86 4.1 2.09C11.8 4.86 13.4 4 15.1 4 17.8 4 20 6.2 20 8.9c0 3.49-3.14 6.34-8.99 11.46l-1.01.99z" />
          </svg>
        </button>

        <img
          src="/mnt/data/edf85197-e21f-41db-afec-990b19b92d0b.png"
          alt="Steel Stockpot"
        />
      </div>

      <div className="card-body">
        <h3 className="title">Steel Stockpo</h3>
        <p className="subtitle">5L</p>

        <div className="rating">
          <svg viewBox="0 0 24 24" className="star">
            <path d="M12 .587l3.668 7.431L23.6 9.75l-5.8 5.66L19.4 24 12 19.77 4.6 24l1.6-8.59L.4 9.75l7.932-1.732z" />
          </svg>
          <span>4.5</span>
        </div>

        <div className="price-block">
          <div className="price">
            <span className="new-price">600€</span>
            <span className="old-price">800€</span>
          </div>

          <button className="add-btn">
            Add{" "}
            <svg viewBox="0 0 24 24" className="cart-icon">
              <path d="M7 4h-2l-1 2h2l3.6 7.59-1.35 2.44A1 1 0 0 0 9 17h9v-2H9.42c.03 0 .06-.02.08-.05L10.6 15h7.3a1 1 0 0 0 .92-.62l2-5A1 1 0 0 0 20.9 8H6.21l-.94-2H2V4h5zM7 20a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
