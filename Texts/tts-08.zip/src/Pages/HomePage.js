import React, { useEffect, useState } from "react";
import imgs from "../Assets/Group 47.png";

import potatoes from "../Assets/60b5c96d36124d2d2b58a8351e37b6e4 1.png";
import Grocerys from "../Assets/a34b33804739e89b6ffeb6c0997cc721 1.png";
import BasmatiRice from "../Assets/fd71f6518b357678996c850b48023ed9 1.png";
import MasoorSmall from "../Assets/fc63c555bde41112fe8e00cd232f343b 1.png";
import ArharDal from "../Assets/61ded8e828f0693eba9198b9ba78f727 1.png";
import Sunflower from "../Assets/599a9041adeff627fde4f72c56725333 1.png";
import Vessel from "../Assets/aa035a1dec333d4742237c923920cd3d 1.png";
import TitaniumSteelPot from "../Assets/COMFORT P C 5 1.png";
import MultifunctionalElectricPot from "../Assets/salman 1 1.png";
import MilkPan from "../Assets/SS Idli Maker 1.png";
import fryingpan from "../Assets/COMFORT P C 5 2.png";
import Garments from "../Assets/c12d13b7ca3c8ffe970b1f077e15c094 1.png";
import bomberjacket from "../Assets/e824f453f3db67208a6e1a90c067a3c6 1.png";
import Tshits from "../Assets/7176083d04925626c1c6fc9777e84610 1.png";
import trousers from "../Assets/ffc06ee915f7cb3e714967e406bd7a81 1.png";
import pants from "../Assets/e4ac8473075d9f3b9326071eb8226824 1.png";
import RoseGold from "../Assets/89fd0d0b93ce3c324fc029a6fb4b3a24 1.png";
import AustinDiamondRing from "../Assets/1039aa2b92368d6751e7dd9f0d611e50 1.png";
import Anklet from "../Assets/63c7ae498b58017a2f93b5e297ded07e 1.png";
import Chelseapendantnecklace from "../Assets/e929583d468589cd67702cf687fe1b25 1.png";
import goldhoopearrings from "../Assets/2fd44384eb0e29878708fe35c836b7bb 1.png";
import QuartzWatch from "../Assets/Mask group (18).png";
import SteelStockpo from "../Assets/Mask group (19).png";
import Jaggerys from "../Assets/Mask group (20).png";
import Cardamom from "../Assets/Mask group (21).png";
import TurmericPowder from "../Assets/Mask group (22).png";
import clock from "../Assets/4dcbfc134457b64e98e963a0ee2e80be-removebg-preview 1.png";
import { CiHeart } from "react-icons/ci";
import panels from "../Assets/Group 51 (1).png";
import "./home.css";
import Header from "../Component/Header/Header";
import Footer from "../Component/Footer/Footer";
import { Carousel } from "primereact/carousel";
import { Button } from "primereact/button";
import { useNavigate, useParams } from "react-router-dom";
import { FaStar } from "react-icons/fa6";
import axios from "axios";
import { base_url, img_path } from "../BaseUrls/BaseUrl";
import { BiSolidCartAdd } from "react-icons/bi";
import { useFormik } from "formik";
import Toast from "../Untils/Toast";
import { toast } from "react-toastify";
import { IoIosHeart } from "react-icons/io";
import { FaHeart } from "react-icons/fa6";
import Toastify from "../Untils/Toastify";
import Common from "../common/Common";
import ProductCard from "../Component/productCard/ProductCard";
import UpdateFilterData from "../service/ApiService";
import { removeFavorite } from "../store/favoriteSlice";
import FirstBanner from "./home/heroBanner/FirstBanner";
import "./product.css";
import image_left from "../Assets/Mask group (46).png";
import ThirdBanner from "./home/heroBanner/ThirdBanner";
import WatchBanner from "./home/heroBanner/WatchBanner";
import InitialModal from "../Component/initialModal/InitialModal";

const HomePage = () => {
  const { showAddToCartToast } = Toastify();
  const { Update } = UpdateFilterData();
  const { favoriteData, dispatch } = Common();
  const user_id = localStorage.getItem("user_id");
  console.log("favoriteData", favoriteData);
  const { id } = useParams();
  console.log("id", id);

  const token = localStorage.getItem("token");

  const navigate = useNavigate();

  const [fetchcategorys, setFetchcategorys] = useState([]);
  console.log("fetchcategorysss", fetchcategorys);
  const [fetchflashdeals, setFetchflashdeals] = useState([]);
  console.log("fetchflashdeals", fetchflashdeals);
  const [fetchproducts, setFetchproducts] = useState([]);
  console.log("fetchproducts", fetchproducts);
  const [fetchallbanners, setFetchallbanners] = useState([]);
  console.log("fetchallbannersaaa", fetchallbanners);

  const [fetchcart, setFetchcart] = useState([]);
  console.log("fetchcart", fetchcart);

  const [showAll, setShowAll] = useState(false);

  const vegetablesData = fetchproducts?.filter(
    (item) => item.category_name === "Vegitable"
  );
  console.log("vegetablesData", vegetablesData);

  const GroceryData = fetchproducts?.filter(
    (item) => item.category_name === "Grocery"
  );
  console.log("GroceryData", GroceryData);

  const vesselData = fetchproducts?.filter(
    (item) => item.category_name === "Vessel"
  );
  console.log("vesselData", vesselData);

  const garmentsData = fetchproducts?.filter(
    (item) => item.category_name === "Garments"
  );
  console.log("garmentsData", garmentsData);

  const rosegoldData = fetchproducts?.filter(
    (item) => item.category_name === "Rose Gold"
  );
  console.log("rosegoldData", rosegoldData);

  const heroBanners = fetchallbanners?.filter(
    (banner) =>
      banner.banner_type === "hero_banner" && banner.status === "active"
  );

  const heroPromoting = fetchallbanners?.filter(
    (banner) =>
      banner.banner_type === "promoting_banner" && banner.status === "active"
  );

  const heroadverting = fetchallbanners?.filter(
    (banner) =>
      banner.banner_type === "advertising_banner" && banner.status === "active"
  );

  const responsiveOptions = [
    {
      breakpoint: "1400px",
      numVisible: 4,
      numScroll: 1,
    },
    {
      breakpoint: "1199px",
      numVisible: 2,
      numScroll: 1,
    },
    {
      breakpoint: "768px",
      numVisible: 1,
      numScroll: 1,
    },
  ];
  const ourresponsiveOption = [
    { breakpoint: "1400px", numVisible: 4, numScroll: 1 },
    { breakpoint: "1199px", numVisible: 4, numScroll: 1 },
    { breakpoint: "767px", numVisible: 2, numScroll: 1 },
    { breakpoint: "575px", numVisible: 1, numScroll: 1 },
  ];
  const [addedProductId, setAddedProductId] = useState(null);

  const productTemplate = (productitem) => {
    const { token } = Common();
    console.log("Flash Deal", productitem);
    if (!productitem) return null;

    return (
      <div style={{ paddingLeft: "3px" }}>
        <div
          className="card  shadow-sm position-relative "
          style={{ width: "", height: "100%" }}
        >
          <img
            src={`${img_path}/products/${productitem.product_image}`}
            alt={productitem.name}
            className="img-fluid p-1"
            style={{ height: "180px", objectFit: "contain" }}
            onClick={() => editcategorypreview(productitem.productID)}
          />
          {token &&
          favoriteData?.some(
            (favorite) => favorite?.id === productitem?.productID
          ) ? (
            <FaHeart
              size={20}
              className="position-absolute text-danger"
              style={{ top: "15px", left: "15px", cursor: "pointer" }}
              // onClick={() => handlewishlist(productitem)}
              onClick={() => handleConfirmDelete(productitem)}
            />
          ) : (
            <CiHeart
              size={24}
              className="position-absolute text-danger"
              style={{ top: "15px", left: "15px", cursor: "pointer" }}
              onClick={() => handlewishlist(productitem)}
            />
          )}

          <div className="p-2">
            <h6 className="fw-bold">{productitem.product_name}</h6>
            {/* <p className="small text-muted panner_family">{productitem.description}</p> */}
            <div className="d-flex justify-content-between py-2">
              <span>
                {productitem.weight}
                {productitem.attribute_type}
              </span>
              <span>
                <FaStar color="#FF9D00" />
                4.5
              </span>
            </div>
            <div className="d-flex justify-content-between align-items-center">
              <div>
                <span className="cart_color fs-5 fw-bold">
                  {productitem.price}€
                </span>{" "}
                <small className="text-muted">
                  <s>{productitem.mrp}€</s>
                </small>
              </div>
              {/* <Button label="+ Add to Cart" className="p-button-sm p-button-dark" /> */}
              {/* <button
                                className="btn btn-dark btn-sm d-flex align-items-center"
                                onClick={() => {
                                    handleAddToCart(productitem);
                                    handleAddToCartCount();
                                }}
                            >
                                Add <BiSolidCartAdd size={18} className="ms-1" />
                            </button> */}
              <button
                // className={`btn btn-sm  d-flex align-items-center ${addedProductId === productitem.productID ? "btn-success" : "btn-dark"
                //     }`}
                className="btn btn-sm d-flex align-items-center btn-dark"
                onClick={async () => {
                  await handleAddToCart(productitem);
                  // await handleAddToCartCount();
                  setAddedProductId(productitem.productID); //  mark this ID as added
                }}
                // disabled={addedProductId === productitem.productID}
              >
                {/* {addedProductId === productitem.productID ? (
                                    <>
                                        Added <BiSolidCartAdd size={18} className="ms-1" />
                                    </>
                                ) : (
                                    <>
                                        Add <BiSolidCartAdd size={18} className="ms-1" />
                                    </>
                                )} */}
                Add <BiSolidCartAdd size={18} className="ms-1" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const ourproductTemplate = (item) => {
    if (!item) return null;
    console.log("item ourproductTemplate", item);
    const { token } = Common();
    return (
      <div
        className="card shadow-sm position-relative h-100"
        style={{
          width: "250px",
          cursor: "pointer",
          minHeight: "330px",
          maxHeight: "340px",
          // minWidth: "140px",
          // minWidth: "140px",
        }}
      >
        <div
          className="d-flex justify-content-center  align-items-center bg-light"
          style={{
            height: "200px",
            width: "100%",
            overflow: "hidden",
            borderTopLeftRadius: "12px",
            borderTopRightRadius: "12px",
          }}
          onClick={() => editcategorypreview(item.id)}
        >
          <img
            src={`${img_path}/products/${item.image}`}
            alt={item.product_name}
            className=""
            style={{}}
          />
        </div>

        {token &&
        favoriteData?.some((favorite) => favorite?.id === item?.id) ? (
          <FaHeart
            size={20}
            className="position-absolute text-danger"
            style={{ top: "15px", left: "15px", cursor: "pointer" }}
            // onClick={() => handlewishlist(productitem)}
            onClick={() => handleProductConfirmDelete(item?.id)}
          />
        ) : (
          <CiHeart
            size={24}
            className="position-absolute text-danger"
            style={{ top: "15px", left: "15px", cursor: "pointer" }}
            onClick={() => handlewishlistProduct(item)}
          />
        )}

        {/* Heart Icon
          {token && (
            <CiHeart
              size={24}
              className="position-absolute text-danger"
              onClick={() => {
                handlewishlistProduct(item);
                // handleWishlistCount();
              }}
              style={{ top: "15px", left: "15px" }}
            />
          )} */}
        {/* Product Info */}
        <div className="p-2">
          <h6
            className="fw-bold text-truncate mb-1 text-wrap"
            style={{ fontSize: "15px" }}
          >
            {item.product_name}
          </h6>

          <div className="d-flex justify-content-between align-items-center py-1">
            <span className="small text-muted">
              {item.weight}
              {item.attribute_type}
            </span>
            <span className="d-flex align-items-center">
              <FaStar color="#FF9D00" size={14} />{" "}
              <small className="ms-1 fw-semibold">4.5</small>
            </span>
          </div>

          <div className="d-flex justify-content-between align-items-center mt-2">
            <div>
              <span className="cart_color fs-6 fw-bold">{item.price}€</span>{" "}
              <small className="text-muted">
                <s>{item.mrp}€</s>
              </small>
            </div>

            <button
              className="btn btn-dark btn-sm d-flex align-items-center"
              onClick={() => {
                handleAddToCartproduct(item);
                // handleAddToCartCount();
              }}
            >
              Add <BiSolidCartAdd size={18} className="ms-1" />
            </button>
          </div>
        </div>
      </div>
    );
  };
  const productTemplateNew = (productitem) => {
    if (!productitem) return null;

    return (
      <div className="ps-2 ">
        <div
          className="bg-white border rounded pr_card_container"
          onClick={() => editcategorypreview(productitem.id)}
        >
          <div className="   text-center p-3 h-100 image_cart_container">
            <img
              src={`${img_path}/products/${productitem.image}`}
              alt={productitem.product_name}
              className="img-fluid"
              style={{ height: "160px", width: "100%", objectFit: "contain" }}
            />
          </div>
          {token &&
          favoriteData?.some((favorite) => favorite?.id === productitem?.id) ? (
            <FaHeart
              size={20}
              className="position-absolute text-danger"
              style={{ top: "15px", left: "15px", cursor: "pointer" }}
              // onClick={() => handlewishlist(productitem)}
              onClick={(e) => {
                e.stopPropagation();
                handleProductConfirmDelete(productitem?.id);
              }}
            />
          ) : (
            <CiHeart
              size={24}
              className="position-absolute text-danger"
              style={{ top: "15px", left: "15px", cursor: "pointer" }}
              onClick={(e) => {
                e.stopPropagation();
                handlewishlistProduct(productitem);
              }}
            />
          )}

          <div className="right_card_content">
            <p className="product_name">
              {productitem?.product_name?.length > 16
                ? productitem.product_name.slice(0, 16) + "..."
                : productitem.product_name}
            </p>
            <div className="kg_container">
              <p className="kg_text">
                {productitem?.weight}
                {productitem?.attribute_type}
              </p>

              <div>
                <FaStar color="#FF9D00" size={14} />
                <span className="star">4.5</span>
              </div>
            </div>
            <div className="d-flex justify-content-between mt-2">
              <p className="product_price">
                {productitem.price}€ <span>{productitem.mrp}€</span>
              </p>
              <button
                className="btn btn-dark btn-sm d-flex align-items-center"
                onClick={(e) => {
                  e.stopPropagation();
                  if (token) {
                    handleAddToCartproduct(productitem);
                  } else {
                    navigate("/login");
                  }
                  // handleAddToCartCount();
                }}
              >
                Add <BiSolidCartAdd size={18} className="ms-1" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };
  const ourproductTemplatepannel = (pannel) => {
    return (
      <div className="">
        <div className="position-relative">
          <img
            src={pannel.image}
            alt=""
            className="img-fluid"
            style={{ height: "300px", width: "1480px" }}
          />
          <div
            className="text-white position-absolute banner-overlay"
            style={{
              top: "20%",
              left: "5%",
              // transform: 'translate(-50%, -50%)',
              // textAlign: 'center',
              // maxWidth: '90%',
            }}
          >
            <h1 className="fw-semibold  paner_heading banner_family">
              {pannel.name}
            </h1>
            <p className=" banner_para ">{pannel.description}</p>

            {/* <button className="btn btn-dark  banner_button">Order Now</button> */}
          </div>
          {/* <CiHeart size={24} className='position-absolute text-danger' style={{ top: "15px", left: "15px" }} /> */}
        </div>
      </div>
    );
  };

  const fetchcategory = async () => {
    try {
      const response = await axios.get(`${base_url}/category`);
      setFetchcategorys(response.data);
    } catch (error) {}
  };

  useEffect(() => {
    fetchcategory();
  }, []);

  const fetchflash = async () => {
    try {
      const response = await axios.get(`${base_url}/flashsale`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          "tts-user-id": user_id,
        },
      });
      await Update("favorite");
      console.log("fetchflash", response);
      setFetchflashdeals(response.data);
    } catch (error) {
      console.log("error", error);
    }
  };

  useEffect(() => {
    fetchflash();
  }, []);

  const fetchProduct = async () => {
    try {
      const response = await axios.get(`${base_url}/allproducts`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          "tts-user-id": user_id,
        },
      });
      setFetchproducts(response.data);
    } catch (error) {}
  };

  useEffect(() => {
    fetchProduct();
  }, []);

  const fetchallbanner = async () => {
    try {
      const response = await axios.get(`${base_url}/allbanners`);
      setFetchallbanners(response.data);
    } catch (error) {}
  };

  useEffect(() => {
    fetchallbanner();
  }, []);

  const visibleProducts = showAll ? fetchproducts : fetchproducts?.slice(0, 20);

  //     const editcategory =(id)=>{
  //         console.log("idhome",id)
  //   navigate('/product',{state: id})
  //   }
  const editcategory = (categoryId) => {
    console.log("categoryIdhhhhh", categoryId);
    navigate("/product", { state: { categoryId } });
  };

  const editcategorypreview = (categoryId) => {
    console.log("categoryIdhhhhh", categoryId);
    navigate("/cart", { state: { categoryId } });
  };
  const [isAdded, setIsAdded] = useState(false);

  const handleAddToCart = async (productitem) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        navigate("/signin");
        return;
      }

      const values = {
        user_id: user_id,
        product_id: productitem.productID,

        quantity: 1,
      };

      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      //  Custom Toast with button + width styling
      await Update("cart");
      showAddToCartToast();
    } catch (error) {}
  };

  const handleAddToCartproduct = async (item) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        navigate("/signin");
        return;
      }

      const values = {
        user_id: user_id,
        product_id: item.id,

        quantity: 1,
      };
      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      // navigate('/addtocart')
      await Update("cart");
      showAddToCartToast();
      // fetchCart()
    } catch (error) {}
  };

  const handleAddCartOurPro = async (items) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        navigate("/signin");
        return;
      }

      const values = {
        user_id: user_id,
        product_id: items.id,

        quantity: 1,
      };

      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      // navigate('/addtocart')
      await Update("cart");
      showAddToCartToast();
    } catch (error) {}
  };
  const handlewishlist = async (productitem) => {
    console.log("productitem handlewishlist", productitem);
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        navigate("/signin");
        return;
      }

      const values = {
        user_id: user_id,
        product_id: productitem.productID,
      };

      const response = await axios.post(`${base_url}/wishlist`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      console.log("response handlewishlist", response);
      // fetchflash();
      await Update("favorite");
    } catch (error) {
      console.log("error handlewishlist", error);
    }
  };
  const handlewishlistProduct = async (item) => {
    console.log("res item", item);
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        navigate("/signin");
        return;
      }

      const values = {
        user_id: user_id,
        product_id: item.id,
      };

      const response = await axios.post(`${base_url}/wishlist`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      console.log("response handlewishlist", response);
      await Update("favorite");
    } catch (error) {
      console.log("error handlewishlist", error);
    }
  };
  const handleConfirmDelete = async (item) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(
        `${base_url}/wishlist/${item.productID}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "tts-user-id": user_id,
          },
        }
      );
      dispatch(removeFavorite(item?.id));
      await Update("favorite");
      // fetchflash();
      console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  };
  const handleProductConfirmDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(`${base_url}/wishlist/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });
      dispatch(removeFavorite(id));
      await Update("favorite");
      // fetchflash();
      console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  };
  const handlewishlistOurpro = async (items) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        navigate("/signin");
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const values = {
        user_id: user_id,
        product_id: items.id,
      };

      const response = await axios.post(`${base_url}/wishlist`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await Update("favorite");
    } catch (error) {}
  };

  const [likedProducts, setLikedProducts] = useState([]);
  let firstRender = true;

  return (
    <>
      <Header />

      {/* <div className=" py-4 ">
                                   <Carousel 
                                       value={pannel}
                                    
                                       numVisible={1}
                                       numScroll={1}
                                      responsiveOptions={responsiveOptions}
                                       itemTemplate={ourproductTemplatepannel}
                                       autoplayInterval={2000}
                                       
                                   />
                               </div> */}
      <div className="body_bgcolor">
        <InitialModal />
        <div className="container">
          {/* home banner first */}
          <div className="section_hero_container">
            {/* <FirstBanner heroBanners={heroBanners} /> */}
            {heroBanners?.length > 0 && (
              <div className="position-relative banner_button ">
                <img
                  src={`${img_path}/webbanner/${heroBanners[0].image}`}
                  alt={heroBanners[0].title}
                  className="img-fluid w-100 rounded"
                />

                <div
                  className="text-white position-absolute banner-overlay"
                  style={{
                    top: "20%",
                    left: "5%",
                  }}
                >
                  <h1 className="fw-semibold paner_heading banner_family">
                    {heroBanners[0].title}
                  </h1>
                  <p className="banner_para">{heroBanners[0].description}</p>

                  {heroBanners[0].button_text && heroBanners[0].button_url && (
                    <a
                      href={heroBanners[0].button_url}
                      className="btn btn-dark banner_button"
                    >
                      {heroBanners[0].button_text}
                    </a>
                  )}
                </div>
              </div>
            )}
          </div>
          {/* our category */}
          <div className="section_container">
            {/* <Category
              fetchcategorys={fetchcategorys}
              editcategory={editcategory}
            /> */}
            <h3 className=" section_headeing">Our Category</h3>
            <div className="row justify-content-center g-lg-5 container">
              {fetchcategorys?.length > 0 ? (
                fetchcategorys.map((item) => (
                  <div
                    key={item.id}
                    className="col-6 col-sm-4 col-md-2 text-center"
                    onClick={(e) => {
                      e.preventDefault();
                      editcategory(item.id);
                    }}
                    style={{ cursor: "pointer" }}
                  >
                    <img
                      src={`${img_path}/categories/${item.thumbnail}`}
                      alt={item.title}
                      className="img-fluid mb-2 w-100"
                    />
                    <div className="fw-semibold fs-5">{item.title}</div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted">
                  No categories available
                </div>
              )}
            </div>
          </div>
          {/* Flash Deal */}

          <div className="section_container">
            <div className="paner_bgcolor p-2 ">
              <h2 className="paner_color fw-semibold section_flas_headeing ">
                Flash Deal
              </h2>
              <p className="text-center m-0">
                Hurry Up ! The offer is limited. Grab while it lasts
              </p>

              <div className="container-fluid py-4 ">
                <Carousel
                  value={fetchflashdeals}
                  className="hide-this-list your-other-class"
                  numVisible={5}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplate}
                  //    autoplayInterval={2000}
                />
              </div>
            </div>
          </div>

          {/* <div className='container py-5 mt-5 pt-5 '>
                <div className='paner_colorbg p-4 mt-5 rounded '>
                   <div className=' d-flex position-relative '>
                    <div className='ps-5'>
                       <h1 className='Premium_Basmati'>Premium Basmati </h1>
                       <h1 className='Premium_Basmati'>Rice (5kg)</h1>
                       <span className='fs-5'>Long-grain, aged rice for fragrant and fluffy meals every time.</span>
                       <div>
                        <button className="btn btn-dark  mt-4">Order Now</button>
                         </div>
                    </div>
                       <div className=' position-absolute' style={{left:"750px", bottom:"-20px"}}>
                              <img src={rice} alt='' className='img-fliud ' style={{ maxWidth: "400px", height: "auto" }}  />
                       </div>
                   </div>
                </div>

              </div> */}
          {/* second banner  */}
          <div className="container section_rice_container">
            <ThirdBanner heroPromoting={heroPromoting} />

            {/* <div className="paner_colorbg p-5 rounded">
              {heroPromoting?.length > 0 && (
                <div className="row align-items-center  position-relative">
                  <div className="col-12 col-md-6 ps-md-5 ">
                    <h1 className="Premium_Basmati Premium_Basmatiss">
                      {heroPromoting[0].title}
                    </h1>

                    <span className="fs-5 d-block mt-2 Premium_Basmatiss">
                      {heroPromoting[0].description}
                    </span>
                    <div className="pt-3">
                      {heroPromoting[0].button_text &&
                        heroPromoting[0].button_url && (
                          <a
                            href={heroPromoting[0].button_url}
                            className="btn btn-dark banner_button"
                          >
                            {heroPromoting[0].button_text}
                          </a>
                        )}
                    </div>
                  </div>

                  <div className="col-12 col-md-6 text-center basmati_rice  position-absolute rice_image">
                    <img
                      src={`${img_path}/webbanner/${heroPromoting[0].image}`}
                      alt={heroBanners[0].title}
                      className="img-fluid rice_small_image"
                    />
                  </div>
                </div>
              )}
            </div> */}
          </div>
          {/* our product section  */}
          <div className="section_container ">
            <h3 className="section_headeing">Our Product </h3>

            <div className="row product_main_container mb-2">
              <div className="product_first_container">
                {/* Left static category card */}
                {fetchcategorys.length > 0 && (
                  <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                    <div className="card rounded position-relative catory_product">
                      <img
                        src={`${img_path}/categories/${fetchcategorys[0].thumbnail}`}
                        alt={fetchcategorys[0].title}
                        className="img-fluid mt-5 mx-auto"
                        style={{ width: "200px", height: "214px" }}
                      />
                      <h5 className="fw-bold text-center">
                        {" "}
                        {fetchcategorys[0].title}
                      </h5>
                    </div>
                  </div>
                )}
              </div>
              <div className="container product_cursol_balance ">
                <Carousel
                  value={vegetablesData}
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplateNew}
                  //   autoplayInterval={2000}
                />
              </div>
            </div>
            <div className="row product_main_container mb-2">
              <div className="product_first_container">
                {/* Left static category card */}
                <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                  <div className="card rounded position-relative catory_product">
                    <img
                      src={Grocerys}
                      alt="Grocerys"
                      className="img-fluid mt-5 mx-auto"
                      style={{ width: "200px", height: "214px" }}
                    />
                    <h5 className="fw-bold text-center"> Grocerys</h5>
                  </div>
                </div>
              </div>
              <div className="container product_cursol_balance">
                <Carousel
                  value={GroceryData}
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplateNew}
                  //   autoplayInterval={2000}
                />
              </div>
            </div>

            <div className="row product_main_container mb-2">
              <div className="product_first_container">
                {/* Left static category card */}
                <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                  <div className="card rounded position-relative catory_product">
                    <img
                      src={Garments}
                      alt="Garments"
                      className="img-fluid mt-5 mx-auto"
                      style={{ width: "200px", height: "214px" }}
                    />
                    <h5 className="fw-bold text-center"> Garments</h5>
                  </div>
                </div>
              </div>
              <div className="container product_cursol_balance">
                <Carousel
                  value={garmentsData}
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplateNew}
                  //   autoplayInterval={2000}
                />
              </div>
            </div>
            <div className="row product_main_container mb-2">
              <div className="product_first_container">
                {/* Left static category card */}
                <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                  <div className="card rounded position-relative catory_product">
                    <img
                      src={RoseGold}
                      alt="RoseGold"
                      className="img-fluid mt-5 mx-auto"
                      style={{ width: "200px", height: "214px" }}
                    />
                    <h5 className="fw-bold text-center"> RoseGold</h5>
                  </div>
                </div>
              </div>
              <div className="container product_cursol_balance">
                <Carousel
                  value={rosegoldData}
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplateNew}
                  //   autoplayInterval={2000}
                />
              </div>
            </div>
            <div className="row product_main_container mb-2">
              <div className="product_first_container">
                {/* Left static category card */}
                <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                  <div className="card rounded position-relative catory_product">
                    <img
                      src={Vessel}
                      alt="Vessel"
                      className="img-fluid mt-5 mx-auto"
                      style={{ width: "200px", height: "214px" }}
                    />
                    <h5 className="fw-bold text-center"> Vessel</h5>
                  </div>
                </div>
              </div>
              <div className="container product_cursol_balance">
                <Carousel
                  value={vesselData}
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplateNew}
                  //   autoplayInterval={2000}
                />
              </div>
            </div>

            {/* product_balance */}
          </div>
          {/* third section */}
          <div className="container p-0 position-relative section_container">
            <WatchBanner heroadverting={heroadverting} />
            {/* <div className="timeless_clock mt-5 rounded   ">
              {heroadverting?.length > 0 && (
                <div className="row align-items-center">
                  <div className="col-12 col-md-6 ps-md-5">
                    <h1 className="Premium_Basmati Premium_Basmatiss">
                      {heroadverting[0].title}{" "}
                    </h1>
                    <span className="fs-5 Premium_Basmatiss">
                      {heroadverting[0].description}
                    </span>
                    <div className="pt-3">
                      {heroadverting[0].button_text &&
                        heroadverting[0].button_url && (
                          <a
                            href={heroadverting[0].button_url}
                            className="btn btn-dark banner_button"
                          >
                            {heroadverting[0].button_text}
                          </a>
                        )}
                    </div>
                  </div>
                  <div className="col-12 col-md-6 text-center basmati_rice  position-absolute">
                    <img
                      src={`${img_path}/webbanner/${heroadverting[0].image}`}
                      alt={heroadverting[0].title}
                      className="img-fluid watch_image"
                      //   style={{ maxWidth: "400px", height: "auto" }}
                    />
                  </div>
                </div>
              )}
            </div> */}
          </div>
          {/* our product */}
          <div className="container section_container">
            <h3 className="section_headeing">Our Product</h3>

            <div className="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3  row-cols-xl-5 ">
              {visibleProducts?.length > 0 ? (
                visibleProducts.map((items) => (
                  <div className="col mb-4" key={items.id}>
                    <div className="card h-100 w-100 px-1 product-card py-1 rounded position-relative">
                      <img
                        src={`${img_path}/products/${items.image}`}
                        alt={items.product_name}
                        className="img-fluid"
                        onClick={() => editcategorypreview(items.id)}
                      />
                      {token &&
                      favoriteData?.some(
                        (favorite) => favorite?.id === items?.id
                      ) ? (
                        <FaHeart
                          size={20}
                          className="position-absolute text-danger"
                          style={{
                            top: "15px",
                            left: "15px",
                            cursor: "pointer",
                          }}
                          // onClick={() => handlewishlist(productitem)}
                          onClick={() => handleProductConfirmDelete(items?.id)}
                        />
                      ) : (
                        <>
                          <CiHeart
                            size={24}
                            className="position-absolute text-danger"
                            style={{
                              top: "15px",
                              left: "15px",
                              cursor: "pointer",
                            }}
                            onClick={() => handlewishlistOurpro(items)}
                          />
                        </>
                      )}
                      {/* <CiHeart
                        size={25}
                        className="heart_color position-absolute"
                        onClick={() => {
                          handlewishlistOurpro(items);
                          // handleWishlistCount();
                        }}
                        style={{ top: "25px", left: "20px" }}
                      /> */}

                      <h6 className="fw-bold ps-2 pt-2">
                        {items.product_name}
                      </h6>

                      <div className="d-flex justify-content-between py-2 px-2">
                        <span>
                          {items.weight}
                          {items.attribute_type}
                        </span>
                        <span>
                          <FaStar color="#FF9D00" /> 4.5
                        </span>
                      </div>

                      <div className="d-flex justify-content-between align-items-center">
                        {/* <div className="">
                          <span className="cart_color fw-bold fs-5 me-2">
                            {items.price}€
                          </span>
                          <span className="text-muted">
                            <s>{items.mrp}€</s>
                          </span>
                        </div> */}
                        <p className="product_price">
                          {items.price}€ <span>{items.mrp}€</span>
                        </p>
                        <button
                          className="btn btn-dark btn-sm me-2"
                          onClick={() => {
                            handleAddCartOurPro(items);
                            // handleAddToCartCount();
                          }}
                        >
                          Add
                          <BiSolidCartAdd size={22} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted">
                  No products available
                </div>
              )}
            </div>

            {/* View All button — only show if there are more than 20 products */}
            {fetchproducts?.length > 20 && (
              <div className="text-center pb-4">
                <button
                  className="btn btn-dark btn-sm"
                  onClick={() => setShowAll(!showAll)}
                >
                  {showAll ? "Show Less" : "View All"}
                </button>
              </div>
            )}
          </div>
        </div>

        {/* <div className="col">
                            <div className='card w-100 ms-3 px-1 py-1 rounted position-relative'>
                                <img src={Tomato} alt="Tomato" className="img-fluid " />
                               
                                <CiHeart size={25} className='heart_color position-absolute' style={{ top: "25px", left: "20px" }} />
                                <h6 className="fw-bold ps-2 pt-2">Tomato </h6>
                                <div className='d-flex justify-content-between py-2 px-2'>
                                    <span>(1kg)</span>
                                    <span><FaStar color='#FF9D00' />4.5</span>
                                </div>
                                <div className="d-flex justify-content-between align-items-center ps-2 py-1">
                                    <div>
                                        <span className="cart_color fw-bold fs-5 me-2">1,50€</span>
                                        <span className="text-muted"><s>1,80€</s></span>
                                    </div>
                                    <button className="btn btn-dark btn-sm  me-2">+ Add To Cart</button>
                                </div>
                            </div>
                        </div> */}
        <a href="#" className="text-decoration-none text-white">
          <div className="backto_bgcolor p-2">
            <div className="container-fluid">
              <h5 className="text-white text-center">Back to Top</h5>
            </div>
          </div>
        </a>
      </div>

      <Footer />
    </>
  );
};

export default HomePage;
