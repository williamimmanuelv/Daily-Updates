import React, { useCallback, useEffect, useState } from "react";
import Header from "../../Component/Header/Header";
import "./mycart.css";
import Footer from "../../Component/Footer/Footer";
import { RiDeleteBinLine } from "react-icons/ri";
import starburst from "../../Assets/Group 61 (1).png";
import { FaAngleRight, FaHeart } from "react-icons/fa6";
import { BiSolidCartAdd } from "react-icons/bi";

import { FaStar } from "react-icons/fa";
import { CiHeart } from "react-icons/ci";

import { Sidebar } from "primereact/sidebar";
import { AiOutlineDelete } from "react-icons/ai";

import { LuPencil } from "react-icons/lu";
import { Dialog } from "primereact/dialog";
import { useNavigate } from "react-router-dom";
import Toast from "../../Untils/Toast";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import { useFormik } from "formik";
import * as yup from "yup";
import { GoogleMap, useJsApiLoader, Marker } from "@react-google-maps/api";
import { PayPalScriptProvider, PayPalButtons } from "@paypal/react-paypal-js";
import Toastify from "../../Untils/Toastify";
import Common from "../../common/Common";
import UpdateFilterData from "../../service/ApiService";
import { removeFavorite } from "../../store/favoriteSlice";
import { DatePicker, message, TimePicker } from "antd";
import { setCouponId } from "../../store/cartSlice";

const steps = ["Your Cart", "Order Review", "Payment"];

const containerStyle = {
  width: "100%",
  height: "50vh",
};

const centers = {
  lat: 13.078187,
  lng: 79.972347,
};

const loaderOptions = {
  id: "google-map-script",
  googleMapsApiKey: process.env.REACT_APP_GOOGLE_MAPS_API_KEY,
  libraries: ["places", "geometry"],
};

const AddToCart = () => {
  const navigate = useNavigate();
  const { showAddToCartToast } = Toastify();
  const [payMethod, setPayMethod] = useState("shop");
  const [pickupDate, setPickupDate] = useState("");
  const [pickupTime, setPickupTime] = useState("");
  // const [couponID, setCouponID] = useState();
  const [error, setError] = useState({
    pickup_date: {
      error: false,
      message: "",
    },
    pickup_time: {
      error: false,
      message: "",
    },
  });

  const { favoriteData, dispatch, couponId } = Common();
  const { Update } = UpdateFilterData();
  const { isLoaded } = useJsApiLoader(loaderOptions);
  const [clickedLatLng, setClickedLatLng] = useState(null);
  const [showMap, setShowMap] = useState(false); //  controls map visibility

  const [isDelivery, setIsDelivery] = useState(
    localStorage.getItem("deliveryType") === "pickup" ? false : true
  );

  useEffect(() => {
    const updateDelivery = () => {
      const type = localStorage.getItem("deliveryType");
      setIsDelivery(type === "delivery");
      setError({
        pickup_date: {
          error: false,
          message: "",
        },
        pickup_time: {
          error: false,
          message: "",
        },
      });
    };
    window.addEventListener("deliveryTypeChanged", updateDelivery);

    return () => {
      window.removeEventListener("deliveryTypeChanged", updateDelivery);
    };
  }, []);

  const handleMapClick = (event) => {
    const latLng = {
      lat: event.latLng.lat(),
      lng: event.latLng.lng(),
    };
    setClickedLatLng(latLng);

    // update formik fields
    formik.setFieldValue("lat", latLng.lat);
    formik.setFieldValue("lng", latLng.lng);

    // optional: close map after selecting
    setShowMap(false);
  };

  const [paymentconfirmmodal, setPaymentconfirmmodal] = useState(false);
  const [paymentpaypalmodal, setPaymentpaypalmodal] = useState(false);
  const [visibleRight, setVisibleRight] = useState(false);
  const [couponapply, setCouponapply] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState(false);
  const [editdeliveryAddress, setEditdeliveryAddress] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [couponData, setCouponData] = useState();

  const [fetchcart, setFetchcart] = useState([]);
  const [payPalData, setPayPalData] = useState();
  const [calculateData, setCalculateData] = useState();

  const user_id = localStorage.getItem("user_id");
  const token = localStorage.getItem("token");
  console.log("token", token);

  const fetchCarts = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to view your cart.", type: "warning" });
        return;
      }

      const response = await axios.get(`${base_url}/cart`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      console.log("response", response);

      await Update("cart");
      setFetchcart(response.data);
      console.log("response.data", response.data);
    } catch (error) {
      console.error("Error fetching cart data:", error);
      // Toast({ message: "Failed to fetch cart items.", type: "error" });
    }
  };

  useEffect(() => {
    fetchCarts();
  }, []);

  const [fetchviewCoupon, setFetchviewCoupon] = useState([]);

  const fetchViewCoupons = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to view your cart.", type: "warning" });
        return;
      }

      const response = await axios.get(`${base_url}/viewcoupons`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      console.log("fetchviewCoupon_Data", response);
      setFetchviewCoupon(response?.data);
      console.log("response.data", response.data);
    } catch (error) {
      console.error("Error fetching cart data:", error);
      // Toast({ message: "Failed to fetch cart items.", type: "error" });
    }
  };

  useEffect(() => {
    fetchViewCoupons();
    fetchProductCalculate();
  }, []);

  const handlecheckout = async () => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;
      const addressId = fetchAddress?.find((item) => item?.is_default === 1);
      console.log("is_default", addressId);
      const values = {
        user_id: user_id,
        cart_total_amount: calculateData?.grand_total
          ? calculateData?.grand_total
          : 0,
        discount_applied: calculateData?.discount_amount
          ? calculateData?.discount_amount
          : 0,
        pay_method: payMethod, // "online" or "shop"
        pickup_date: isDelivery ? null : pickupDate,
        pickup_time: isDelivery ? null : pickupTime,
        tax_amount: calculateData?.tax_amount ? calculateData?.tax_amount : 0,
        delivery_charge: calculateData?.delivery_charge
          ? calculateData?.delivery_charge
          : 0,
        coupon_id: calculateData?.coupon_id ? calculateData?.coupon_id : null,
      };
      console.log("check out values", values);

      const response = await axios.post(`${base_url}/checkout`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      const newData = response?.data?.paypal;
      setPayPalData(newData);
      console.log("newData checkout", newData);
      if (response.status && payMethod === "shop") {
        message.success(response?.data?.message);
        dispatch(setCouponId(null));
        navigate("/myorders");
      }
      console.log("response", response);
      console.log("Checkout success:", response.data);
    } catch (error) {
      const msg = error?.response?.data?.message || "Something went wrong";
      console.log("Checkout error:", error);
      message.error(msg);
    }
  };

  const handleAddToCartproduct = async (item) => {
    try {
      const token = localStorage.getItem("token");

      // if (!token) {
      //   Toast({ message: "Please log in to add products to your cart.", type: "warning" });
      //   return;
      // }

      const values = {
        user_id: user_id,
        product_id: item.id,

        quantity: 1,
      };

      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await Update("cart");
      fetchCarts();
      showAddToCartToast();
    } catch (error) {}
  };

  const handlewishlistcart = async (item) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const values = {
        user_id: user_id,
        product_id: item.id,
      };

      const response = await axios.post(`${base_url}/wishlist`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("response.data", response.data);
    } catch (error) {}
  };

  const handleConfirmDelete = async (cid) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }

      const response = await axios.delete(`${base_url}/cart/${cid}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      fetchCarts();
      await fetchProductCalculate();
    } catch (error) {
      console.error("Delete error:", error);
      // Toast({ message: "Delete failed. Please try again.", type: "error" });
    }
  };

  const [cartItems, setCartItems] = useState([]);

  const fetchProductCalculate = async () => {
    const newData = {
      user_id: user_id,
      coupon_id: couponId ? couponId : null,
    };
    console.log("newData", newData);
    try {
      const res = await axios.post(`${base_url}/checkout/calculate`, newData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      const newRes = res?.data;
      if (newRes?.status) {
        setCalculateData(newRes?.data);
      }
      console.log("res checkout", res);
    } catch (error) {
      console.log("error", error);
      const err = error?.response?.data?.message;
      if (err == "Coupon discount exceeds cart total") {
        dispatch(setCouponId(null));
      }

      message.error(err);
    }
  };
  useEffect(() => {
    fetchProductCalculate();
  }, [couponId]);
  console.log("calculateData dd ", calculateData);
  const handleCartIncrease = async (item) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        // Toast({ message: "Please log in to modify your cart.", type: "warning" });
        return;
      }

      const response = await axios.post(
        `${base_url}/cart/increase/${item.id}`,
        { quantity: 1 },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      await fetchProductCalculate();
      console.log("Increase success:", response.data);

      //  Update the cart item with the *returned quantity*
      // setFetchcart((prev) =>
      //   prev.map((i) =>
      //     i.id === item.id ? { ...i, quantity: response.data.quantity } : i
      //   )
      // );
      fetchCarts();
    } catch (error) {
      console.error("Error increasing quantity:", error);
    }
  };
  const handleProductConfirmDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(`${base_url}/wishlist/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });
      dispatch(removeFavorite(id));
      await Update("favorite");
      // fetchflash();
      console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  };
  const handleCartDecrease = async (item) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) {
        // Toast({ message: "Please log in to modify your cart.", type: "warning" });
        return;
      }

      const response = await axios.post(
        `${base_url}/cart/decrease/${item.id}`,
        { quantity: 1 },
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("Decrease success:", response.data);

      await fetchProductCalculate();
      //  Use the new quantity returned by API
      // setFetchcart((prev) =>
      //   prev.map((i) =>
      //     i.id === item.id ? { ...i, quantity: response.data.quantity } : i
      //   )
      // );
      fetchCarts();
    } catch (error) {
      console.error("Error decreasing quantity:", error);
    }
  };

  const editcategorypreview = (categoryId) => {
    navigate("/cart", { state: { categoryId } });
  };
  const [couponInput, setCouponInput] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState(null);

  // Handle "Apply" from coupon list
  const handleApplyFromList = async (item) => {
    // if (!couponInput) return;

    if (item.coupon_status === "inactive") {
      Toast({
        message: "Invalid coupon. This coupon is expired or inactive.",
        type: "error",
      });
      return;
    }
    // if (item?.discount_amount > finalTotal) {
    //   Toast({
    //     message: "Invalid coupon. Discount exceeds order total.",
    //     type: "error",
    //   });
    //   return;
    // }

    setAppliedCoupon(item);
    setDiscount(parseFloat(item.discount_amount));
    // setCouponID(item?.id);
    dispatch(setCouponId(item?.id));
    setCouponData(item);

    await fetchProductCalculate();
    setCouponapply(false);
    // alert(`Coupon ${item.coupon_code} applied successfully!`);
  };
  console.log("couponID", couponId);
  const [discount, setDiscount] = useState(0); //  define discount here

  // Optional: if you have coupon logic
  const handleApplyFromInput = async () => {
    // Check if user entered a code
    if (!couponInput) {
      Toast({ message: "Please enter a coupon code", type: "error" });
      return;
    }

    // Find matching coupon
    const match = fetchviewCoupon?.find(
      (item) => item?.coupon_code === couponInput
    );
    console.log("match_test", match);
    // if (match?.discount_amount > calculateData?.grand_total) {
    //   Toast({
    //     message: "Invalid coupon. Discount exceeds order total.",
    //     type: "error",
    //   });
    //   return;
    // }

    if (!match) {
      Toast({ message: "Invalid coupon code", type: "error" });
      setDiscount(0);
      return;
    }

    if (match.coupon_status === "inactive") {
      Toast({ message: "This coupon is expired or inactive", type: "error" });
      setDiscount(0);
      return;
    }

    setDiscount(parseFloat(match.discount_amount));
    dispatch(setCouponId(match?.id));
    await fetchProductCalculate();
    setCouponData(match);

    //  Apply discount
    Toast({
      message: `Coupon code  ${couponInput} applied successfully!`,
      type: "success",
    });
    // updates discount dynamically
    setCouponapply(false);
    // alert(`Coupon ${match.coupon_code} applied!`);
  };

  const [defaultAddress, setDefaultAddress] = useState(null);

  const handleSetDefaultAddress = async (id) => {
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token");

      if (!token) {
        Toast({ message: "Please log in first.", type: "warning" });
        return;
      }

      const response = await axios.post(
        `${base_url}/address/set-default/${id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            "tts-user-id": encryptedUserId,
          },
        }
      );

      await fetchAddresses(); // refresh list

      // set selected address
      const selected = fetchAddress.find((a) => a.id === id);
      if (selected) setDefaultAddress(selected);
    } catch (error) {
      console.error(error);
    }
  };

  const [fetchAddress, setFetchAddress] = useState([]);

  const handleEditAddress = (addr) => {
    formik.setValues({
      building_block_no: addr.building_block_no,
      street_area: addr.street_area,
      landmark: addr.landmark,
      zip_code: addr.zip_code,
      city: addr.city,
      country: addr.country,
      address_label: addr.address_label,
      first_name: addr.first_name,
      surname: addr.surname,
      email: addr.email,
      phone: addr.phone,
      lat: addr.lat,

      lng: addr.lng,
      is_default: addr.is_default,

      id: addr.id,
    });
    console.log(" Latitude:", addr.lat);
    console.log(" Longitude:", addr.lng);

    if (addr.lat && addr.lng) {
      const location = { lat: Number(addr.lat), lng: Number(addr.lng) };
      setClickedLatLng(location);

      setShowMap(true);
    } else {
      setShowMap(true); // Open map even if lat/lng missing
    }
    setEditdeliveryAddress(true);
  };

  const fetchAddresses = async () => {
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token"); // assuming token is stored after login

      const response = await axios.get(`${base_url}/address`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          "tts-user-id": encryptedUserId,
        },
      });

      setFetchAddress(response.data);
      console.log("User details:", response.data);
      setVisibleRight(false);
    } catch (error) {}
  };
  useEffect(() => {
    fetchAddresses();
  }, []);

  const handleAddressDelete = async (id) => {
    console.log("addr", id);
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(`${base_url}/address/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          "tts-user-id": encryptedUserId,
        },
      });

      fetchAddresses();
    } catch (error) {}
  };

  const onSubmit = async (values) => {
    if (isEditing) {
      try {
        const encryptedUserId = localStorage.getItem("user_id");
        const token = localStorage.getItem("token");

        if (!token) {
          Toast({
            message: "Please log in to update your profile.",
            type: "warning",
          });
          return;
        }

        const response = await axios.post(
          `${base_url}/address/${values.id}?_method=PUT`,
          values,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
              "tts-user-id": encryptedUserId,
            },
          }
        );

        console.log("response.data", response.data);
        formik.resetForm();
        setEditdeliveryAddress(false);
        fetchAddresses();
      } catch (error) {}
    } else {
      try {
        const encryptedUserId = localStorage.getItem("user_id");
        const token = localStorage.getItem("token");

        if (!token) {
          Toast({
            message: "Please log in to update your profile.",
            type: "warning",
          });
          return;
        }

        const response = await axios.post(`${base_url}/address`, values, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            "tts-user-id": encryptedUserId,
          },
        });

        console.log("response.data", response.data);
        formik.resetForm();
        setDeliveryAddress(false);
        fetchAddresses();
      } catch (error) {}
    }
  };

  const formik = useFormik({
    initialValues: {
      building_block_no: "",
      street_area: "",
      landmark: "",
      zip_code: "",
      city: "",
      country: "",
      address_label: "",
      first_name: "",
      surname: "",
      email: "",
      phone: "",
      lat: "",
      lng: "",
      is_default: 0,
    },
    validationSchema: yup.object().shape({
      building_block_no: yup
        .string()
        .required("building_block_no is required!"),
      street_area: yup.string().required("street_area  is required"),
      landmark: yup.string().required("landmark is required!"),
      zip_code: yup.string().required("zip_code is required!"),
      city: yup.string().required("city is required!"),
      country: yup.string().required("country is required!"),
      address_label: yup.string().required("address_label is required!"),
      first_name: yup.string().required("first_name is required!"),
      surname: yup.string().required("surname is required!"),
      email: yup.string().required("email is required!"),
      phone: yup
        .string()
        .required("Phone is required")
        .matches(/^[0-9]{10}$/, "Phone must be exactly 10 digits"),
      // lat: yup.string().required("lat is required!"),
      // lng: yup.string().required("lng is required!"),
      // is_default: yup.string().required("is_default is required!"),
    }),
    onSubmit,
  });
  const [fetchProductlike, setFetchProductlike] = useState([]);
  console.log("fetchProductlikeeee", fetchProductlike);
  const fetchlikeproduct = async () => {
    try {
      // const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token");

      const response = await axios.get(`${base_url}/you-may-like/products`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });

      setFetchProductlike(response.data?.data);
    } catch (error) {}
  };
  useEffect(() => {
    fetchlikeproduct();
  }, []);

  // const subtotal = Array.isArray(fetchcart)
  //   ? fetchcart.reduce(
  //       (sum, item) => sum + parseFloat(item.total_price || 0),
  //       0
  //     )
  //   : 0;
  // const discountAmount = parseFloat(discount) || 0;
  // const finalTotal = subtotal - discountAmount;
  const handleAddMoreItems = () => {
    navigate("/");
  };
  const validatePickup = () => {
    let valid = true;

    if (!pickupDate) {
      valid = false;
      setError((prev) => ({
        ...prev,
        pickup_date: { error: true, message: "Pickup date is required" },
      }));
    }

    if (!pickupTime) {
      valid = false;
      setError((prev) => ({
        ...prev,
        pickup_time: { error: true, message: "Pickup time is required" },
      }));
    }

    return valid;
  };

  console.log("payPalData", payPalData);
  const handleRemoveCoupon = async () => {
    setAppliedCoupon(null);
    setDiscount(0);
    setCouponapply(false);
    setCouponData(null);
    dispatch(setCouponId(null));
    setCouponInput("");
  };

  return (
    <>
      <Header />
      <div className="body_bgcolor">
        <div className="container py-4">
          <div className="row">
            <h4 className="fw-semibold cardfamily">My Cart</h4>

            <div className="col-12 col-md-8">
              {/* <div className="border p-4  my-4 bg-white">
                <div className=''>
                  <h5 className='cardfamily fw-semibold'>Select the delivery type</h5>
                </div>
                <hr />
                <div className="d-flex justify-content-around align-items-center">
                 
                  <div className="form-check">
                    <input
                      className="form-check-input fs-5"
                      type="radio"
                      name="deliveryOption"
                      id="radioDelivery"
                      checked={isDelivery === true}
                      onChange={() => {
                        setIsDelivery(true);
                        updateDeliveryType("delivery");
                      }}
                    />
                    <label
                      className="form-check-label panerfamis fw-semibold ps-2"
                      htmlFor="radioDelivery"
                    >
                      Delivery
                    </label>
                  </div>

                
                  <div className="form-check">
                    <input
                      className="form-check-input fs-5"
                      type="radio"
                      name="deliveryOption"
                      id="radioPickup"
                      checked={isDelivery === false}
                      onChange={() => {
                        setIsDelivery(false);
                        updateDeliveryType("pickup");
                      }}
                    />
                    <label
                      className="form-check-label panerfamis fw-semibold ps-2"
                      htmlFor="radioPickup"
                    >
                      Pick Up
                    </label>
                  </div>
                </div>

              </div> */}

              <div className="border p-3 bg-white mt-4">
                <div>
                  <div className="d-flex justify-content-between align-items-center cardfamily">
                    <h6>From Saved Addresses</h6>
                  </div>

                  <hr className="p-0" />

                  {/* <div>
                    {fetchcart?.length > 0 ? (
                      fetchcart.map((item) => (

                        <div className="row align-items-center p-3  border-bottom  ">

                          <div className="col-md-3 pt-2">
                            <div className="border p-2">
                              <img
                                src={`${img_path}/products/${item.image}`}
                                alt={item.product_name}
                                className="img-fluid rounded"
                                style={{ width: "120px", height: "120px", objectFit: "contain" }}
                              />

                            </div>
                          </div>


                          <div className="col-md-6 cardfamily">
                            <h5 className=''> {item.product_name}</h5>

                          
                            <p className="fw-semibold mb-1 cardfamily">
                              Size: <span className=' py-2 px-2'>{item.weight}{item.attribute_type}</span>

                            </p>


                            <div className="pt-1">
                              <span className=" fw-semibold fs-5 me-2">{item.price}€</span>
                              <span className="text-muted opacity-75 fs-5 fw-semibold">
                                <s>{item.mrp}€</s>
                              </span>
                              <span className="text-success ms-2 fw-semibold">42% off</span>
                            </div>
                          </div>

                          <div className="col-md-3 px-5 cardfamily">
                            <div className="border rounded-5  d-flex align-items-center justify-content-between px-3 py-1 mb-2">
                              <button className="btn btn-dark btn-sm rounded ">-</button>
                              <span className="fs-5">1</span>
                              <button className="btn btn-dark btn-sm rounded">+</button>
                            </div>

                            <div className="border p-1 d-flex align-items-center ps-3 gap-2 mt-3 rounded-3" onClick={() => handleConfirmDelete(item.cid)}>
                              <RiDeleteBinLine size={20} className='cart_color' />
                              <span className='fw-semibold'  >Remove</span>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center text-muted py-5">
                        No products available
                      </div>
                    )}
                  </div> */}

                  {fetchcart?.length > 0 ? (
                    fetchcart?.map((item, index) => {
                      return (
                        <div
                          className="row align-items-center p-3 border-bottom"
                          style={{ cursor: "pointer" }}
                          key={item.id}
                        >
                          <div className="col-md-3 pt-2">
                            <div
                              className="border p-2"
                              onClick={() =>
                                editcategorypreview(item.primary_id)
                              }
                            >
                              <img
                                src={`${img_path}/products/${item.image}`}
                                alt={item.product_name}
                                className="img-fluid rounded"
                                style={{
                                  width: "120px",
                                  height: "120px",
                                  objectFit: "contain",
                                }}
                              />
                            </div>
                          </div>

                          <div className="col-md-6 cardfamily">
                            <h5>{item.product_name}</h5>
                            <p className="fw-semibold mb-1 cardfamily">
                              Size:{" "}
                              <span className="py-2 px-2">
                                {item.weight}
                                {item.attribute_type}
                              </span>
                            </p>
                            <div className="pt-1">
                              <span className="fw-semibold fs-5 me-2">
                                {item.price}€
                              </span>
                              <span className="text-muted opacity-75 fs-5 fw-semibold">
                                <s>{item.mrp}€</s>
                              </span>
                              <span className="text-success ms-2 fw-semibold">
                                42% off
                              </span>
                            </div>
                          </div>

                          <div className=" col-md-3   col-lg-3 col-xl-3  cardfamily">
                            {/* Quantity Controls */}
                            <div className="border  rounded-5 d-flex align-items-center justify-content-between px-3 py-1 mb-2">
                              <button
                                className="btn btn-dark btn-sm rounded"
                                onClick={() => handleCartDecrease(item)}
                              >
                                –
                              </button>

                              <span className="fs-5">{item.quantity || 1}</span>

                              <button
                                className="btn btn-dark btn-sm rounded"
                                onClick={() => handleCartIncrease(item)}
                              >
                                +
                              </button>
                            </div>

                            <div
                              className="border p-1  d-flex align-items-center justify-content-center mt-3 rounded-3"
                              style={{ cursor: "pointer" }}
                              onClick={() => handleConfirmDelete(item.id)}
                            >
                              <div>
                                <RiDeleteBinLine
                                  // size={20}
                                  className="cart_color remove-icon"
                                />
                              </div>
                              <div>
                                <span className="fw-semibold remove-text px-2 ">
                                  Remove
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    <div className="text-center text-muted py-5">
                      No products available
                    </div>
                  )}

                  {/* <hr /> */}
                  {/* <div className="row align-items-center">

                    <div className="col-md-3">
                      <div className="border p-3">
                        <img src={maggie} alt="Cooker" className="img-fluid ms-5" />
                      </div>
                    </div>


                    <div className="col-md-6 cardfamily">
                      <h5>Maggi Masala Instant Noodles 560G </h5>

                      <p className="fw-semibold mb-1 cardfamily">
                        Weight:
                        <span className="fw-normal ms-1">560G</span>
                      </p>
                      <p className="fw-semibold mb-1 cardfamily">
                        Seller:
                        <span className="fw-normal ms-1">SHRENIK1991</span>
                      </p>
                      <p className="fw-semibold mb-1 cardfamily">
                        Size:
                        <span className="fw-normal ms-1">12 Liters</span>
                      </p>


                      <div className="pt-2">
                        <span className=" fw-semibold fs-4 me-2">7,50€</span>
                        <span className="text-muted opacity-75 fs-5 fw-semibold">
                          <s>1,80€</s>
                        </span>
                        <span className="text-success ms-2 fw-semibold">42% off</span>
                      </div>
                    </div>


                    <div className="col-md-3 px-5 cardfamily">
                      <div className="border rounded-4  d-flex align-items-center justify-content-between px-3 py-1 mb-2">
                        <button className="btn btn-dark btn-sm rounded">-</button>
                        <span className="fs-5">1</span>
                        <button className="btn btn-dark btn-sm rounded">+</button>
                      </div>

                      <div className="border p-1 d-flex align-items-center ps-3 gap-2 mt-3 rounded-3">
                        <RiDeleteBinLine size={20} className='cart_color' />
                        <span className='fw-semibold'>Remove</span>
                      </div>
                    </div>
                  </div>  */}
                  {/* <hr /> */}
                  <div className="d-flex justify-content-between align-items-center mt-3">
                    <h5>Missed something?</h5>
                    <button
                      className="btn btn-dark"
                      onClick={handleAddMoreItems}
                    >
                      + Add More Items
                    </button>
                  </div>
                </div>
              </div>
              {/* <div className="border p-4  my-4 bg-white">
                <div className='d-flex justify-content-between'>

                  <div className=''>
                    <h5 className='cardfamily fw-semibold'>Customer Delivery Address</h5>
                  </div>
                  <button className="btn btn-outline-danger btncolor mycartbgcolorbtn" onClick={() => setVisibleRight(true)}>
                    Change the Address
                  </button>

                </div>



                <hr />
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <span className="fw-semibold">TTS-Brothers GmbH&Co. KG</span>
                    <span className="bg-primary text-white ms-3 p-1 px-2 rounded-3 small">
                      Work
                    </span>
                  </div>
                  <LuPencil className="text-secondary" />
                </div>

                <p className="mt-2 mb-3 small text-muted">
                  Asien Supermarkt in Dortmund <br />
                  Textiles & Food Items, Retail & Wholesale, Rheinischestr.52, Dortmund
                  4413
                </p>
              </div> */}
              {isDelivery && (
                <div className="border p-4 my-4 bg-white">
                  <div className="d-flex justify-content-between">
                    <div>
                      <h5 className="cardfamily fw-semibold">
                        Customer Delivery Address
                      </h5>
                    </div>
                    <button
                      className="btn btn-outline-success btncolor mycartbgcolorbtn"
                      onClick={() => setVisibleRight(true)}
                    >
                      {Array.isArray(fetchAddress) && fetchAddress.length > 0
                        ? "Change the Address"
                        : "Add Address"}
                    </button>
                  </div>

                  <hr />
                  {/* {defaultAddress ? (
  <>
    <div className="d-flex justify-content-between align-items-center">
      <div>
        <span className="fw-semibold">
          {defaultAddress.first_name} {defaultAddress.surname}
        </span>
        {defaultAddress.address_label && (
          <span className="bg-primary text-white ms-3 p-1 px-2 rounded-3 small">
            {defaultAddress.address_label}
          </span>
        )}
      </div>
      <LuPencil className="text-secondary" />
    </div>

    <p className="mt-2 mb-3 small text-muted">
      {defaultAddress.building_block_no}, {defaultAddress.street_area}, <br />
      {defaultAddress.landmark && `${defaultAddress.landmark}, `}
      {defaultAddress.city}, {defaultAddress.zip_code}, {defaultAddress.country}
      <br />
      Phone: {defaultAddress.phone}
    </p>
    </>
    ) : (
  <p className="text-muted text-center mt-4">No address selected yet.</p>
)} */}

                  {Array.isArray(fetchAddress) && fetchAddress.length > 0 ? (
                    (() => {
                      const defaultAddr = fetchAddress.find(
                        (addr) => addr.is_default === 1
                      );

                      return defaultAddr ? (
                        <>
                          <div className="d-flex justify-content-between align-items-center">
                            <div>
                              <span className="fw-semibold">
                                {defaultAddr.first_name} {defaultAddr.surname}
                              </span>
                              {defaultAddr.address_label && (
                                <span className="bg-primary text-white ms-3 p-1 px-2 rounded-3 small">
                                  {defaultAddr.address_label}
                                </span>
                              )}
                            </div>
                          </div>

                          <p className="mt-2 mb-3 small text-muted">
                            {defaultAddr.building_block_no},{" "}
                            {defaultAddr.street_area}, <br />
                            {defaultAddr.landmark &&
                              `${defaultAddr.landmark}, `}
                            {defaultAddr.city}, {defaultAddr.zip_code},{" "}
                            {defaultAddr.country}
                            <br />
                            Phone: {defaultAddr.phone}
                          </p>
                        </>
                      ) : (
                        <p className="text-muted text-center mt-4">
                          No default address selected yet.
                        </p>
                      );
                    })()
                  ) : (
                    <p className="text-muted text-center mt-4">
                      No addresses found.
                    </p>
                  )}
                </div>
              )}
              <div className="border p-4  my-4 bg-white">
                <div className="d-flex justify-content-between">
                  <div className="">
                    <h5 className="cardfamily fw-semibold">Shop Address</h5>
                  </div>
                </div>
                <hr />
                <div className="d-flex justify-content-between align-items-center">
                  <div>
                    <span className="fw-semibold">
                      TTS-Brothers GmbH&Co. KG
                    </span>
                  </div>
                  {/* <LuPencil className="text-secondary" /> */}
                </div>

                <p className="mt-2 mb-3 small text-muted">
                  Asien Supermarkt in Dortmund <br />
                  Textiles & Food Items, Retail & Wholesale, Rheinischestr.52,
                  Dortmund 4413
                </p>
              </div>
            </div>

            <div className="col-12 col-md-4" style={{ cursor: "pointer" }}>
              {!isDelivery && (
                <div className="bg-white border p-4   rounded mt-4">
                  <div className="row g-3  p-2 ">
                    {/* Pick Up Date */}
                    <div className="col-12 col-md-6">
                      <h6 className="fw-semibold cardfamily mb-2">
                        Pick Up Date
                      </h6>
                      <DatePicker
                        name="pickup_date"
                        format="YYYY-MM-DD"
                        onChange={(date) => {
                          setPickupDate(date ? date.format("YYYY-MM-DD") : "");
                          setError((prev) => ({
                            ...prev,
                            pickup_date: { error: false, message: "" },
                          }));
                        }}
                        status={error.pickup_date.error ? "error" : ""}
                      />
                      {error.pickup_date.error && (
                        <small className="text-danger">
                          {error.pickup_date.message}
                        </small>
                      )}
                    </div>

                    {/* Pick Up Time */}
                    <div className="col-12 col-md-6 ">
                      <h6 className="fw-semibold cardfamily mb-2">
                        Pick Up Time
                      </h6>
                      <TimePicker
                        name="pickup_time"
                        format="HH:mm"
                        onChange={(t, s) => {
                          setPickupTime(t ? s : "");

                          setError((prev) => ({
                            ...prev,
                            pickup_time: { error: false, message: "" },
                          }));
                        }}
                        status={error.pickup_time.error ? "error" : ""}
                      />

                      {error.pickup_time.error && (
                        <small className="text-danger">
                          {error.pickup_time.message}
                        </small>
                      )}

                      {/* <input
                        type="time"
                        className="form-control"
                        placeholder="Enter time"
                        onChange={(e) => setPickupTime(e.target.value)}
                      /> */}
                    </div>
                  </div>
                </div>
              )}

              {/* <div className='bg-white border p-1 px-3 rounded mt-4 '>

                <h5 className='fw-bold cardfamily mt-3'>coupon codesssssssssssss</h5>
                <input type='text' id='' name='' className='form-control' placeholder='Enter coupon code' />
                <div className='text-center mt-3'>
                  <button className='btn btn-dark fw-semibold p-0 px-5 rounded-5 pb-1' >Apply</button>
                </div>
                ' </div> */}
              {/* <Box sx={{ width: '100%' }} className="">
                  <Stepper activeStep={1} alternativeLabel>
                    {steps.map((label) => (
                      <Step key={label}>
                        <StepLabel>{label}</StepLabel>
                      </Step>
                    ))}
                  </Stepper>
                </Box> */}
              <div
                className="d-flex bg-white p-3 mt-2 rounded"
                onClick={() => setCouponapply(true)}
              >
                <img src={starburst} alt="starburst" className="img-fluid " />
                <h5 className="px-3">Apply Coupon</h5>
                <FaAngleRight className="mt-2 ms-5" />
              </div>

              <div className="bg-white border my-2 rounded ">
                <h4 className="fw-semibold px-3 py-3 border-bottom cardfamily">
                  Price details
                </h4>
                <div className="px-3">
                  <p className="d-flex justify-content-between ibm_family">
                    <span className="fw-semibold">Total items</span>
                    <span>{calculateData?.total_items} Items</span>
                  </p>

                  <>
                    <p className="d-flex justify-content-between ibm_family">
                      <span className="fw-semibold">Cart Total</span>
                      <span> {calculateData?.cart_total || 0} €</span>
                    </p>

                    {calculateData?.tax_amount > 0 && (
                      <p className="d-flex justify-content-between ibm_family">
                        <span className="fw-semibold">Tax Amount</span>
                        <span> {calculateData?.tax_amount || 0} €</span>
                      </p>
                    )}
                    {calculateData?.delivery_charge > 0 && (
                      <p className="d-flex justify-content-between ibm_family">
                        <span className="fw-semibold">Delivery Charge</span>
                        <span> {calculateData?.delivery_charge || 0} €</span>
                      </p>
                    )}

                    {calculateData?.coupon_discount > 0 && (
                      <p className="d-flex justify-content-between ibm_family">
                        <span className="fw-semibold">Discount</span>
                        <span>-{calculateData?.coupon_discount || 0} €</span>
                      </p>
                    )}
                    <p className="d-flex justify-content-between ibm_family">
                      <span className="fw-semibold">Subtotal</span>
                      <span> {calculateData?.sub_total || 0} €</span>
                    </p>
                    <hr />
                    <p className="d-flex justify-content-between ibm_family">
                      <span className="fw-semibold">Total</span>
                      <span> {calculateData?.grand_total || 0} €</span>
                    </p>
                  </>

                  <hr />
                  {discount > 0 && (
                    <h6 className="pb-2 text-success ibm_family">
                      You will save {discount.toFixed(2)}€ on this order
                    </h6>
                  )}
                </div>
              </div>
              {/* <p className='d-flex justify-content-between ibm_family'>
                    <span className='fw-semibold'>VAT</span>
                    <span>5%</span>
                  </p> */}

              <div className="text-center">
                <button
                  className="btn btn-dark cardfamily fs-6 px-5 fw-semibold rounded-5 "
                  onClick={() => {
                    if (!isDelivery) {
                      validatePickup() && setPaymentconfirmmodal(true);
                    } else {
                      if (!defaultAddress || defaultAddress.length === 0) {
                        Toast({
                          message: "Please add address.",
                          type: "error",
                        });
                      } else {
                        setPaymentconfirmmodal(true);
                      }
                    }
                  }}
                  disabled={fetchcart.length === 0 || !token}
                >
                  Places Order
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white  mt-5">
            <h4 className="cardfamily fw-semibold pt-3 px-3">
              Products You Might Like
            </h4>

            {/* <div className="row row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-5 py-5">
              {fetchProductlike?.length > 0 ? (
                fetchProductlike.map((items) => (
                  <div className="col mb-4" key={items.id}>
                    <div className="card h-100 w-100 px-1 product-card py-1 rounded position-relative">
                      <img
                        src={`${img_path}/products/${items.image}`}
                        alt={items.product_name}
                        className="img-fluid"
                      
                        onClick={() => editcategorypreview(items.id)}
                      />
                      {token &&
                      favoriteData?.some(
                        (favorite) => favorite?.id === items?.id
                      ) ? (
                        <FaHeart
                          size={20}
                          className="position-absolute text-danger"
                          style={{
                            top: "15px",
                            left: "15px",
                            cursor: "pointer",
                          }}
                        
                          onClick={() => handleProductConfirmDelete(items?.id)}
                        />
                      ) : (
                        <>
                          <CiHeart
                            size={24}
                            className="position-absolute text-danger"
                            style={{
                              top: "15px",
                              left: "15px",
                              cursor: "pointer",
                            }}
                            onClick={() => handlewishlistcart(items)}
                          />
                        </>
                      )}
                      
                      <h6 className="fw-bold ps-2 pt-2">
                        {items.product_name}
                      </h6>

                      <div className="d-flex justify-content-between py-2 px-2">
                        <span>
                          {items.weight}
                          {items.attribute_type}
                        </span>
                        <span>
                          <FaStar color="#FF9D00" /> 4.5
                        </span>
                      </div>

                      <div className="d-flex justify-content-between align-items-center ps-2 py-1">
                        <div>
                          <span className="cart_color fw-bold fs-5 me-2">
                            {items.price}€
                          </span>
                          <span className="text-muted">
                            <s>{items.mrp}€</s>
                          </span>
                        </div>
                        <button
                          className="btn btn-dark btn-sm me-2"
                          onClick={() => {
                            handleAddToCartproduct(items);
                            
                          }}
                        >
                          Add
                          <BiSolidCartAdd size={22} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted">
                  No products available
                </div>
              )}
            </div> */}

            <div className="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3  row-cols-xl-5 ">
              {fetchProductlike?.length > 0 ? (
                fetchProductlike.map((items) => (
                  <div className="col mb-4" key={items.id}>
                    <div className="card h-100 w-100 px-1 product-card py-1 rounded position-relative">
                      <img
                        src={`${img_path}/products/${items.image}`}
                        alt={items.product_name}
                        className="img-fluid"
                        onClick={() => editcategorypreview(items.id)}
                      />
                      {token &&
                      favoriteData?.some(
                        (favorite) => favorite?.id === items?.id
                      ) ? (
                        <FaHeart
                          size={20}
                          className="position-absolute text-danger"
                          style={{
                            top: "15px",
                            left: "15px",
                            cursor: "pointer",
                          }}
                          // onClick={() => handlewishlist(productitem)}
                          onClick={() => handleProductConfirmDelete(items?.id)}
                        />
                      ) : (
                        <>
                          <CiHeart
                            size={24}
                            className="position-absolute text-danger"
                            style={{
                              top: "15px",
                              left: "15px",
                              cursor: "pointer",
                            }}
                            onClick={() => handlewishlistcart(items)}
                          />
                        </>
                      )}
                      {/* <CiHeart
                                                                size={25}
                                                                className="heart_color position-absolute"
                                                                onClick={() => {
                                                                  handlewishlistOurpro(items);
                                                                  // handleWishlistCount();
                                                                }}
                                                                style={{ top: "25px", left: "20px" }}
                                                              /> */}

                      <h6 className="fw-bold ps-2 pt-2">
                        {items.product_name}
                      </h6>

                      <div className="d-flex justify-content-between py-2 px-2">
                        <span>
                          {items.weight}
                          {items.attribute_type}
                        </span>
                        <span>
                          <FaStar color="#FF9D00" /> 4.5
                        </span>
                      </div>

                      <div className="d-flex justify-content-between align-items-center ps-2 py-1">
                        <div>
                          <span className="cart_color fw-bold fs-5 me-2">
                            {items.price}€
                          </span>
                          <span className="text-muted">
                            <s>{items.mrp}€</s>
                          </span>
                        </div>
                        <button
                          className="btn btn-dark btn-sm me-2"
                          onClick={() => {
                            handleAddToCartproduct(items);
                            // handleAddToCartCount();
                          }}
                        >
                          Add
                          <BiSolidCartAdd size={22} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted">
                  No products available
                </div>
              )}
            </div>
          </div>

          <Sidebar
            visible={visibleRight}
            position="right"
            onHide={() => setVisibleRight(false)}
            style={{ width: "500px" }}
          >
            <h5 className="ms-3 fw-semibold cardfamily">Select Address</h5>
            <h6 className="ms-3 mt-3">Saved Addresses</h6>

            <div className="border p-3 mx-3 my-4 rounded">
              <div className="container">
                {Array.isArray(fetchAddress) && fetchAddress.length > 0 ? (
                  fetchAddress.map((addr) => (
                    <div
                      key={addr.id}
                      className={`p-3 mx-3 my-4 rounded border ${
                        addr.is_default === 1
                          ? "border-success"
                          : "border-secondary"
                      }`}
                      style={{
                        borderWidth: addr.is_default === 1 ? "5px" : "3px",
                      }}
                    >
                      {/* HEADER */}
                      <div className="d-flex justify-content align-items-center">
                        <div>
                          <span className="fw-semibold">
                            {addr.first_name} {addr.surname}
                          </span>
                          {addr.address_label && (
                            <span className="bg-primary text-white ms-3 p-1 rounded-3 small">
                              {addr.address_label}
                            </span>
                          )}
                        </div>

                        <div className=" d-flex ms-auto">
                          {/* Edit Icon */}
                          <LuPencil
                            size={18}
                            className="text-secondary mx-3"
                            style={{ cursor: "pointer" }}
                            onClick={() => handleEditAddress(addr)}
                          />
                          <AiOutlineDelete
                            size={20}
                            style={{ cursor: "pointer" }}
                            onClick={() => handleAddressDelete(addr.id)}
                          />
                        </div>
                      </div>

                      {/* ADDRESS DETAILS */}
                      <p className="mt-2 mb-3 small text-muted">
                        {addr.building_block_no}, {addr.street_area}, <br />
                        {addr.landmark && `${addr.landmark}, `}
                        {addr.city}, {addr.zip_code}, {addr.country}
                        <br />
                        Phone: {addr.phone}
                      </p>

                      {/* {addr.is_default === 1 && (
                        <span className="badge bg-success mb-2">Default Address</span>
                      )}

                    
                      <div className="text-center cardfamily">
                        <button
                          className="btn btn-dark rounded-5 px-5"
                      
                        >
                          Deliver Here
                        </button>
                      </div> */}
                      {/* DEFAULT LABEL OR SET DEFAULT BUTTON */}
                      {addr.is_default === 1 ? (
                        <span className="badge bg-success mb-2">
                          Default Address
                        </span>
                      ) : (
                        <div className="text-center cardfamily">
                          <button
                            className="btn btn-dark rounded-5 px-5"
                            onClick={() => handleSetDefaultAddress(addr.id)}
                          >
                            Deliver Here
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                ) : (
                  <p className="text-muted text-center mt-4">
                    No addresses found.
                  </p>
                )}
              </div>
            </div>

            <div className=" d-flex flex-column h-50">
              <div className="p-3 mt-auto text-center">
                <button
                  className="btn btn-outline-dark w-75 fw-semibold cardfamily"
                  onClick={() => setDeliveryAddress(true)}
                >
                  + Add New Address
                </button>
              </div>
            </div>
          </Sidebar>

          <Sidebar
            visible={couponapply}
            position="right"
            onHide={() => setCouponapply(false)}
            style={{ width: "500px" }}
          >
            <h5 className="fw-bold ms-4 mt-3 cardfamily">Apply Coupon</h5>
            <div>
              {/* <h6 className="fw-bold cardfamily mt-3 ps-4">Coupon Code</h6> */}

              {/* Input field */}
              <div className="mx-4">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter coupon code"
                  value={couponInput}
                  onChange={(e) => setCouponInput(e?.target?.value)}
                />
              </div>

              {/* Apply button */}
              <div className="text-center mt-3">
                <button
                  className="btn btn-dark fw-semibold p-0 px-5 rounded-5 pb-1"
                  onClick={handleApplyFromInput}
                >
                  Apply
                </button>
              </div>

              {/* Coupon List */}
              <div className="d-flex border p-2 ms-3 rounded mt-3 flex-wrap">
                {fetchviewCoupon?.filter(
                  (item) => item.coupon_status === "active"
                ).length > 0 ? (
                  fetchviewCoupon
                    ?.filter((item) => item.coupon_status === "active")
                    ?.map((item, index) => (
                      <div
                        key={index}
                        className="d-flex align-items-center border rounded p-2 me-3 mb-2"
                        style={{ width: "100%" }}
                      >
                        <span className="pt-3 ms-2 couponcolor">
                          {item.discount_amount
                            ? `${item.discount_amount}₹`
                            : "Discount"}
                        </span>

                        <div className="vr mx-3"></div>

                        <div className="me-3">
                          <span className="fw-bold">{item?.coupon_code}</span>
                          <p className="mb-0 small text-muted">
                            Valid till:{" "}
                            {item.end_date
                              ? new Date(item.end_date).toLocaleDateString()
                              : "N/A"}
                          </p>
                        </div>

                        <div>
                          {Number(couponId) === Number(item.id) ? (
                            <button
                              className={`btn btn-sm btn-danger rounded `}
                              onClick={handleRemoveCoupon}
                            >
                              Remove
                            </button>
                          ) : (
                            <button
                              className={`btn btn-sm btn-primary rounded `}
                              onClick={() => handleApplyFromList(item)}
                            >
                              Apply
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                ) : (
                  <div className="text-center text-muted py-5 w-100">
                    No coupons available
                  </div>
                )}
              </div>

              {/* <div className="d-flex border p-2 ms-3 rounded mt-3 flex-wrap">
                {fetchviewCoupon?.length > 0 ? (
                  fetchviewCoupon.map((item, index) => (
                    
                    <div
                      key={index}
                      className="d-flex align-items-center border rounded p-2 me-3 mb-2"
                      style={{ minWidth: "300px" }}
                    >
                      <span className="pt-3 ms-2 couponcolor">
                        {item.discount_amount
                          ? `${item.discount_amount}₹`
                          : "Discount"}
                      </span>

                      <div className="vr mx-3"></div>

                      <div className="me-3">
                        <span className="fw-bold">{item.coupon_code}</span>
                        <p className="mb-0 small text-muted">
                          Valid till:{" "}
                          {item.end_date
                            ? new Date(item.end_date).toLocaleDateString()
                            : "N/A"}
                        </p>
                      </div>

                      <div>
                        <button
                          className={`btn btn-sm rounded ${
                            item.coupon_status === "inactive"
                              ? "btn-secondary"
                              : "btn-primary"
                          }`}
                          disabled={item.coupon_status === "inactive"}
                          onClick={() => handleApplyFromList(item)}
                        >
                          {item.coupon_status === "inactive"
                            ? "Expired"
                            : "Apply"}
                        </button>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted py-5 w-100">
                    No coupons available
                  </div>
                )}
              </div> */}

              {/* Applied coupon display */}
              {appliedCoupon && (
                <div className="alert alert-success mt-3 mx-4" role="alert">
                  Applied Coupon: <strong>{appliedCoupon.coupon_code}</strong> —{" "}
                  {appliedCoupon.discount_amount}% OFF
                </div>
              )}
            </div>
          </Sidebar>

          <Sidebar
            visible={deliveryAddress}
            position="right"
            onHide={() => setDeliveryAddress(false)}
            style={{ width: "500px" }}
          >
            <h5 className="fw-bold ms-4 mt-3 cardfamily pb-3">
              Delivery Location
            </h5>
            <form onSubmit={formik.handleSubmit} autoComplete="off">
              {/* <div className="pb-4">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2525.231418426135!2d7.1165011121071755!3d50.734196566774735!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47bee112e1a7043f%3A0x8e9768505af0864b!2sTTS%20Brothers!5e0!3m2!1sen!2sin!4v1755760015842!5m2!1sen!2sin"
                  width="100%"
                  height="300"
                  style={{ border: "0" }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Delivery Location Map"
                ></iframe>
              </div> */}

              <div className="pb-4">
                {/* <div>
                  <GoogleMap
                    mapContainerStyle={containerStyle}
                    center={centers}
                    zoom={10}
                    onClick={handleMapClick}
                  >
                    {clickedLatLng && <Marker position={clickedLatLng} />}
                  </GoogleMap>

                  <div className="text-center mt-3">
                    <button
                      className="btn btn-outline-dark rounded-5 px-4"
                      onClick={() => setShowMap(false)}
                    >
                      Done
                    </button>
                  </div>
                </div> */}

                <div>
                  <GoogleMap
                    mapContainerStyle={containerStyle}
                    center={centers} // use dynamic center
                    zoom={14}
                    onClick={handleMapClick}
                  >
                    {clickedLatLng && <Marker position={clickedLatLng} />}
                  </GoogleMap>

                  <div className="text-center mt-3">
                    <button
                      className="btn btn-outline-dark rounded-5 px-4"
                      onClick={() => setShowMap(false)}
                    >
                      Done
                    </button>
                  </div>
                </div>

                {/* <div className="px-3 cardfamily mb-3">
                  <p>
                    Asien Supermarkt in Dortmund <br />
                    Textiles & Food Items, Retail & Wholesale, Rheinischestr.52, Dortmund 4413
                  </p>
                  <p
                    className="text-primary border-bottom pb-2"
                    style={{ cursor: "pointer" }}
                    onClick={() => setShowMap(true)}
                  >
                    Edit Location on Map
                  </p>
                </div> */}
              </div>
              <div className="px-3 mb-4">
                <h6 className="fw-semibold mb-2">Address Details:</h6>

                <label htmlFor="building_block_no" className="form-label">
                  Building & Block No: (Optional)
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="building_block_no"
                  name="building_block_no"
                  placeholder="Enter building_block_no"
                  value={formik.values.building_block_no}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.building_block_no &&
                  formik.touched.building_block_no && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.building_block_no}
                    </p>
                  )}

                <label htmlFor="street_area" className="form-label">
                  Street & Area Name : *
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="street_area"
                  name="street_area"
                  placeholder="Enter street_area"
                  value={formik.values.street_area}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.street_area && formik.touched.street_area && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.street_area}
                  </p>
                )}

                <label htmlFor="landmark" className="form-label">
                  Landmark:
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="landmark"
                  name="landmark"
                  placeholder="Enter landmark"
                  value={formik.values.landmark}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.landmark && formik.touched.landmark && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.landmark}
                  </p>
                )}
                <div className="d-flex">
                  <div>
                    <label htmlFor="zip_code" className="form-label">
                      {" "}
                      ZIP code :
                    </label>
                    <input
                      type="text"
                      className="form-control bg-white mb-3"
                      id="zip_code"
                      name="zip_code"
                      placeholder="Enter zip_code"
                      value={formik.values.zip_code}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.zip_code && formik.touched.zip_code && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.zip_code}
                      </p>
                    )}
                  </div>
                  <div className="px-3">
                    <label htmlFor="city" className="form-label">
                      {" "}
                      City :
                    </label>
                    <input
                      type="text"
                      className="form-control bg-white mb-3"
                      id="city"
                      name="city"
                      placeholder="Enter city"
                      value={formik.values.city}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.city && formik.touched.city && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.city}
                      </p>
                    )}
                  </div>
                </div>

                <label htmlFor="country" className="form-label">
                  Country :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="country"
                  name="country"
                  placeholder="Enter country"
                  value={formik.values.country}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.country && formik.touched.country && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.country}
                  </p>
                )}
              </div>

              <div className="px-3 mb-4">
                <h6 className="fw-semibold mb-2">Add Address Label</h6>
                <div className="d-flex gap-2 pt-3">
                  {["Home", "Work", "Other"].map((label) => (
                    <button
                      type="button"
                      key={label}
                      className={`btn rounded-5 px-4 ${
                        formik.values.address_label === label
                          ? "btn-dark text-white"
                          : "btn-outline-dark"
                      }`}
                      onClick={() =>
                        formik.setFieldValue("address_label", label)
                      }
                    >
                      {label}
                    </button>
                  ))}
                </div>
                {formik.errors.address_label &&
                  formik.touched.address_label && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.address_label}
                    </p>
                  )}
              </div>

              <div className="px-3 mb-4">
                <h6 className="fw-semibold mb-2">Receiver Details</h6>

                <label htmlFor="first_name" className="form-label">
                  Enter the First Name :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="first_name"
                  name="first_name"
                  placeholder="Enter first_name"
                  value={formik.values.first_name}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.first_name && formik.touched.first_name && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.first_name}
                  </p>
                )}
                <label htmlFor="surname" className="form-label">
                  Enter the Sure Name :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="surname"
                  name="surname"
                  placeholder="Enter surname"
                  value={formik.values.surname}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.surname && formik.touched.surname && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.surname}
                  </p>
                )}

                <label htmlFor="email" className="form-label">
                  Enter the Email ID :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="email"
                  name="email"
                  placeholder="Enter email"
                  value={formik.values.email}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.email && formik.touched.email && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.email}
                  </p>
                )}

                <label htmlFor="phone" className="form-label">
                  Receiver’s Phone Number
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="phone"
                  name="phone"
                  placeholder="Enter phone"
                  value={formik.values.phone}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.phone && formik.touched.phone && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.phone}
                  </p>
                )}
              </div>
              <div className="form-check mb-3 ms-3">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="is_default"
                  name="is_default"
                  checked={formik.values.is_default === 1} //  checked if value is 1
                  onChange={(e) => {
                    const checked = e.target.checked ? 1 : 0;
                    formik.setFieldValue("is_default", checked);
                  }}
                />
                <label htmlFor="is_default" className="form-check-label px-2">
                  Set as default
                </label>

                {formik.touched.is_default && formik.errors.is_default && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.is_default}
                  </p>
                )}
              </div>
              <div className="text-center pb-3">
                <button
                  type="submit"
                  className="btn btn-dark rounded-5 px-5"
                  // onClick={() => navigate('/myorders')}
                  onClick={() => setIsEditing(false)}
                >
                  Save & Proceed
                </button>
              </div>
            </form>
          </Sidebar>

          <Sidebar
            visible={editdeliveryAddress}
            position="right"
            onHide={() => setEditdeliveryAddress(false)}
            style={{ width: "500px" }}
          >
            <h5 className="fw-bold ms-4 mt-3 cardfamily pb-3">
              Delivery Location
            </h5>
            <form onSubmit={formik.handleSubmit} autoComplete="off">
              {/* <div className="pb-4">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2525.231418426135!2d7.1165011121071755!3d50.734196566774735!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47bee112e1a7043f%3A0x8e9768505af0864b!2sTTS%20Brothers!5e0!3m2!1sen!2sin!4v1755760015842!5m2!1sen!2sin"
                  width="100%"
                  height="300"
                  style={{ border: "0" }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Delivery Location Map"
                ></iframe>
              </div> */}

              <div className="pb-4">
                <div>
                  <GoogleMap
                    mapContainerStyle={containerStyle}
                    center={centers}
                    zoom={10}
                    onClick={handleMapClick}
                  >
                    {clickedLatLng && <Marker position={clickedLatLng} />}
                  </GoogleMap>

                  <div className="text-center mt-3">
                    <button
                      className="btn btn-outline-dark rounded-5 px-4"
                      onClick={() => setShowMap(false)}
                    >
                      Done
                    </button>
                  </div>
                </div>

                {/* <div className="px-3 cardfamily mb-3">
                  <p>
                    Asien Supermarkt in Dortmund <br />
                    Textiles & Food Items, Retail & Wholesale, Rheinischestr.52, Dortmund 4413
                  </p>
                  <p
                    className="text-primary border-bottom pb-2"
                    style={{ cursor: "pointer" }}
                    onClick={() => setShowMap(true)}
                  >
                    Edit Location on Map
                  </p>
                </div> */}
              </div>
              <div className="px-3 mb-4">
                <h6 className="fw-semibold mb-2">Address Details:</h6>

                <label htmlFor="building_block_no" className="form-label">
                  Building & Block No: (Optional)
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="building_block_no"
                  name="building_block_no"
                  placeholder="Enter building_block_no"
                  value={formik.values.building_block_no}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.building_block_no &&
                  formik.touched.building_block_no && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.building_block_no}
                    </p>
                  )}

                <label htmlFor="street_area" className="form-label">
                  Street & Area Name : *
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="street_area"
                  name="street_area"
                  placeholder="Enter street_area"
                  value={formik.values.street_area}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.street_area && formik.touched.street_area && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.street_area}
                  </p>
                )}

                <label htmlFor="landmark" className="form-label">
                  Landmark:
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="landmark"
                  name="landmark"
                  placeholder="Enter landmark"
                  value={formik.values.landmark}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.landmark && formik.touched.landmark && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.landmark}
                  </p>
                )}
                <div className="d-flex">
                  <div>
                    <label htmlFor="zip_code" className="form-label">
                      {" "}
                      ZIP code :
                    </label>
                    <input
                      type="text"
                      className="form-control bg-white mb-3"
                      id="zip_code"
                      name="zip_code"
                      placeholder="Enter zip_code"
                      value={formik.values.zip_code}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.zip_code && formik.touched.zip_code && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.zip_code}
                      </p>
                    )}
                  </div>
                  <div className="px-3">
                    <label htmlFor="city" className="form-label">
                      {" "}
                      City :
                    </label>
                    <input
                      type="text"
                      className="form-control bg-white mb-3"
                      id="city"
                      name="city"
                      placeholder="Enter city"
                      value={formik.values.city}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.city && formik.touched.city && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.city}
                      </p>
                    )}
                  </div>
                </div>

                <label htmlFor="country" className="form-label">
                  Country :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="country"
                  name="country"
                  placeholder="Enter country"
                  value={formik.values.country}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.country && formik.touched.country && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.country}
                  </p>
                )}
              </div>

              <div className="px-3 mb-4">
                <h6 className="fw-semibold mb-2">Add Address Label</h6>
                <div className="d-flex gap-2 pt-3">
                  {["Home", "Work", "Other"].map((label) => (
                    <button
                      type="button"
                      key={label}
                      className={`btn rounded-5 px-4 ${
                        formik.values.address_label === label
                          ? "btn-dark text-white"
                          : "btn-outline-dark"
                      }`}
                      onClick={() =>
                        formik.setFieldValue("address_label", label)
                      }
                    >
                      {label}
                    </button>
                  ))}
                </div>
                {formik.errors.address_label &&
                  formik.touched.address_label && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.address_label}
                    </p>
                  )}
              </div>

              <div className="px-3 mb-4">
                <h6 className="fw-semibold mb-2">Receiver Details</h6>

                <label htmlFor="first_name" className="form-label">
                  Enter the First Name :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="first_name"
                  name="first_name"
                  placeholder="Enter first_name"
                  value={formik.values.first_name}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.first_name && formik.touched.first_name && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.first_name}
                  </p>
                )}
                <label htmlFor="surname" className="form-label">
                  Enter the Sure Name :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="surname"
                  name="surname"
                  placeholder="Enter surname"
                  value={formik.values.surname}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.surname && formik.touched.surname && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.surname}
                  </p>
                )}

                <label htmlFor="email" className="form-label">
                  Enter the Email ID :
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="email"
                  name="email"
                  placeholder="Enter email"
                  value={formik.values.email}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.email && formik.touched.email && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.email}
                  </p>
                )}

                <label htmlFor="phone" className="form-label">
                  Receiver’s Phone Number
                </label>
                <input
                  type="text"
                  className="form-control bg-white mb-3"
                  id="phone"
                  name="phone"
                  placeholder="Enter phone"
                  value={formik.values.phone}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.phone && formik.touched.phone && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.phone}
                  </p>
                )}
              </div>
              <div className="form-check mb-3 ms-3">
                <input
                  type="checkbox"
                  className="form-check-input"
                  id="is_default"
                  name="is_default"
                  checked={formik.values.is_default === 1} //  checked if value is 1
                  onChange={(e) => {
                    const checked = e.target.checked ? 1 : 0;
                    formik.setFieldValue("is_default", checked);
                  }}
                />
                <label htmlFor="is_default" className="form-check-label px-2">
                  Set as default
                </label>

                {formik.touched.is_default && formik.errors.is_default && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.is_default}
                  </p>
                )}
              </div>
              <div className="text-center pb-3">
                <button
                  type="submit"
                  className="btn btn-dark rounded-5 px-5"
                  // onClick={() => navigate('/myorders')}
                  onClick={() => setIsEditing(true)}
                >
                  Save & Proceed
                </button>
              </div>
            </form>
          </Sidebar>
        </div>
      </div>
      <Dialog
        header="Select Your Payment Method"
        visible={paymentconfirmmodal}
        position="center"
        style={{ width: "30vw" }}
        onHide={() => {
          if (!paymentconfirmmodal) return;
          setPaymentconfirmmodal(false);
        }}
      >
        <div className="d-flex justify-content-around align-items-center">
          <div className="form-check">
            <input
              className="form-check-input fs-5"
              type="radio"
              name="radios"
              value="shop"
              checked={payMethod === "shop"}
              onChange={(e) => setPayMethod(e.target.value)}
            />
            <label className="form-check-label fw-semibold ps-2">
              Pay at Store
            </label>
          </div>
          <div className="form-check">
            <input
              className="form-check-input fs-5"
              type="radio"
              name="radios"
              value="online"
              checked={payMethod === "online"}
              onChange={(e) => setPayMethod(e.target.value)}
            />
            <label className="form-check-label fw-semibold ps-2">
              Pay Online
            </label>
          </div>
        </div>
        <div className="d-flex p-3 justify-content-center mt-3">
          {payMethod !== "shop" ? (
            <button
              className="btn btn-dark "
              type="submit"
              onClick={() => {
                setPaymentpaypalmodal(true);
                handlecheckout();
              }}
            >
              continue
            </button>
          ) : (
            <button
              className="btn btn-dark"
              type="submit"
              onClick={handlecheckout}
            >
              Place Order
            </button>
          )}
        </div>
      </Dialog>

      <Dialog
        header="Select Your Payment Method in paypal"
        visible={paymentpaypalmodal}
        position="top"
        style={{ width: "30vw" }}
        onHide={() => {
          if (!paymentpaypalmodal) return;
          setPaymentpaypalmodal(false);
        }}
      >
        <PayPalScriptProvider
          options={{
            clientId: "test",
            currency: payPalData?.amount?.currency_code,
            disableFunding: "card",
            intent: "capture",
          }}
        >
          <PayPalButtons
            style={{ layout: "vertical" }}
            createOrder={(data, actions) => {
              console.log("data", data);
              const amountValue = payPalData?.amount?.value
                ?.toString()
                .replace(/,/g, "");
              return actions.order.create({
                purchase_units: [
                  {
                    amount: {
                      value: amountValue,
                    },
                  },
                ],
              });
            }}
            onApprove={async (data, actions) => {
              console.log("data onapprove", data);
              const details = await actions.order.capture();
              console.log("Payment Success:", details);

              const payload = {
                transaction_id: data?.paymentID,
                user_id: payPalData?.user_id,
                paymentRef: payPalData?.payment_ref,
                discount_applied: payPalData?.discount_applied,
                tax_amount: payPalData?.tax_amount,
                coupon_id: couponId || null,
                delivery_charge: payPalData?.delivery_charge,
              };
              console.log("payload Data", payload);

              alert("Payment completed!");
            }}
            onError={(err) => {
              console.log("err payment faile", err);
              const payload = {
                user_id: payPalData?.user_id,
                paymentRef: payPalData?.payment_ref,
                reason: "failed",
              };
              console.error("PayPal Error:", err);
              alert("Payment failed");
            }}
          />

          {/* <PayPalButtons style={{ layout: "horizontal" }} /> */}
        </PayPalScriptProvider>
      </Dialog>

      <Footer />
    </>
  );
};

export default AddToCart;
