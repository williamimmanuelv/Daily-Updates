import React, { useState } from "react";
import supermixie from "../../Assets/SUPER G MIXIE-2523 1.png";
import { CiHeart } from "react-icons/ci";

import { FaStar } from "react-icons/fa";
import { FaStarHalfAlt } from "react-icons/fa";
import "./cart.css";

import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Header from "../../Component/Header/Header";
import Footer from "../../Component/Footer/Footer";
import * as yup from "yup";

// import ReactImageZoom from "./ReactImageZoom";
import { useEffect, useRef } from "react";
import ImageZoom from "js-image-zoom";
import { useLocation, useNavigate } from "react-router-dom";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import { useFormik } from "formik";
import { BiSolidCartAdd } from "react-icons/bi";
import Toast from "../../Untils/Toast";
import Common from "../../common/Common";
import { FaHeart } from "react-icons/fa6";
import { removeFavorite } from "../../store/favoriteSlice";
import UpdateFilterData from "../../service/ApiService";
import Toastify from "../../Untils/Toastify";
import Loader from "../../Component/loading/Loader";

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 2 }}>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

const Cart = () => {
  const navigate = useNavigate();
  const user_id = localStorage.getItem("user_id");
  const { token, dispatch } = Common();
  const { Update } = UpdateFilterData();
  const { showAddToCartToast } = Toastify();

  const [fetchcart, setFetchcart] = useState([]);
  console.log("fetchcart", fetchcart);
  const [cartCount, setCartCount] = useState(0);

  const { state } = useLocation();
  // const getproductPreview = state;
  const getproductPreview = state?.categoryId || null;
  console.log("getproductPreview", getproductPreview);
  const getproductPreviewrelated = state?.categoryId || null;
  console.log("getproductPreview", getproductPreview);

  const [fetchproductscart, setFetchproductscart] = useState([]);

  const [fetchproductscartrelated, setFetchproductscartrelated] = useState([]);
  console.log("fetchproductscartrelated", fetchproductscartrelated);
  const [loading, setLoading] = useState(false);

  // const handleChange = (event: React.SyntheticEvent, newValue: number) => {
  //   setValue(newValue);
  // };
  const [value, setValue] = useState(0);
  const { favoriteData } = Common();
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  const zoomRef = useRef(null);

  useEffect(() => {
    const options = {
      width: 250,
      height: 250,
      zoomWidth: 400,
      img: supermixie, // only js-image-zoom inserts <img>
      zoomPosition: "right",
      offset: { vertical: 0, horizontal: 10 },
    };

    if (zoomRef.current) {
      // clear any existing children (avoid multiple <img>)
      zoomRef.current.innerHTML = "";
      new ImageZoom(zoomRef.current, options);
    }
  }, []);

  const fetchProduct = async () => {
    // alert("rukku")
    try {
      // if (!getproductPreview) return;

      //  Use ID in the URL path
      const response = await axios.get(
        `${base_url}/allproducts/${getproductPreview}`
      );

      console.log("responsefetchproductscart", response.data);
      setFetchproductscart(response.data?.data);
    } catch (error) {
      console.error("Error fetching product", error);
    }
  };
  console.log("fetchproductscart", fetchproductscart);

  useEffect(() => {
    fetchProduct();
  }, []);

  useEffect(() => {
    fetchProduct();
  }, [getproductPreview]);

  const fetchProductrelated = async () => {
    setLoading(true);
    try {
      // if (!getproductPreview) return;
      const token = localStorage.getItem("token");
      //  Use ID in the URL path
      const response = await axios.get(
        `${base_url}/products/related/${getproductPreviewrelated}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
            "tts-user-id": user_id,
          },
        }
      );

      setFetchproductscartrelated(response?.data?.related);
      console.log("response.data", response.data);
    } catch (error) {
      console.error("Error fetching product", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (getproductPreviewrelated) {
      fetchProductrelated();
    }
  }, [getproductPreviewrelated]);

  //     if (!fetchproductscart) {
  //   return <p className="text-center py-5">Loading product details...</p>;
  // }
  const [quantity, setQuantity] = useState(fetchproductscart.quantity || 1);

  const handleAddToCartproduct = async (item, newQty = quantity) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) return;

      const values = {
        user_id,
        product_id: item.id,
        quantity: newQty, //
      };

      console.log("Updating cart quantity:", newQty);

      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await Update("cart");
      console.log("response.data", response.data);
      //  if (navigateAfterAdd) {
      //   navigate("/addtocart");
      // }
      showAddToCartToast();
    } catch (error) {
      console.error("Error updating cart", error);
    }
  };

  const handleAddToCartproductrelated = async (item) => {
    try {
      const token = localStorage.getItem("token");

      // if (!token) {
      //   Toast({ message: "Please log in to add products to your cart.", type: "warning" });
      //   return;
      // }

      const values = {
        user_id: user_id,
        product_id: item.id,

        quantity: 1,
      };

      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await Update("cart");
      showAddToCartToast();

      // navigate('/addtocart')
    } catch (error) {}
  };

  //  Increase quantity and sync with API
  const handleCartIncrease = () => {
    setQuantity((prev) => {
      const newQty = prev + 1;
      // handleAddToCartproduct(fetchproductscart, newQty);
      return newQty;
    });
  };

  //  Decrease quantity and sync with API
  const handleCartDecrease = () => {
    setQuantity((prev) => {
      const newQty = prev > 1 ? prev - 1 : 1;
      // handleAddToCartproduct(fetchproductscart, newQty);
      return newQty;
    });
  };

  const handleAddToCartCount = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const values = {};

      console.log("Sending request:", values);

      //  Correct axios POST syntax
      const response = await axios.post(`${base_url}/cart/count`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("response.data", response.data);

      //  If API returns count
      if (response.data?.count !== undefined) {
        setCartCount(response.data.count);
      }

      // Optional Toast
      // Toast({ message: "Cart count updated!", type: "success" });
    } catch (error) {
      console.error("Error adding to cart", error);
      // Toast({ message: "Failed to update cart count.", type: "error" });
    }
  };
  const handlewishlistcart = async (item) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        navigate("/signin");
        return;
      }

      const values = {
        user_id: user_id,
        product_id: item.id,
      };

      const response = await axios.post(`${base_url}/wishlist`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await Update("favorite");

      console.log("response.data", response.data);
    } catch (error) {}
  };
  const handleProductConfirmDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(`${base_url}/wishlist/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });
      dispatch(removeFavorite(id));
      await Update("favorite");
      // fetchflash();
      console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  };

  const editcategorypreview = (categoryId) => {
    console.log("categoryIdhhhhh", categoryId);
    navigate("/cart", { state: { categoryId } });
  };

  return (
    <>
      <Header />
      <div className=" body_bgcolor">
        <div className="container">
          <div className="row py-4 px-5">
            <>
              <div className="row">
                {/* LEFT SIDE - IMAGES */}
                <div className="col-12 col-md-5 ">
                  <div className="card px-2 py-2 rounded position-relative d-flex justify-content-center align-items-center">
                    <img
                      src={`${img_path}/products/${fetchproductscart.image}`}
                      alt={fetchproductscart.product_name}
                      className="img-fluid rounded"
                      style={{
                        height: "100%",
                        width: "100%",
                        objectFit: "cover",
                        padding: "10px",
                      }}
                    />

                    {token &&
                    favoriteData?.some(
                      (favorite) => favorite?.id === fetchproductscart?.id
                    ) ? (
                      <FaHeart
                        size={20}
                        className="position-absolute text-danger"
                        style={{
                          top: "15px",
                          left: "15px",
                          cursor: "pointer",
                        }}
                        // onClick={() => handlewishlist(productitem)}
                        onClick={() =>
                          handleProductConfirmDelete(fetchproductscart?.id)
                        }
                      />
                    ) : (
                      <>
                        <CiHeart
                          size={24}
                          className="position-absolute text-danger"
                          style={{
                            top: "15px",
                            left: "15px",
                            cursor: "pointer",
                          }}
                          onClick={() => handlewishlistcart(fetchproductscart)}
                        />
                      </>
                    )}
                    {/* <CiHeart
                      size={25}
                      className="heart_color position-absolute"
                      style={{ top: "15px", left: "20px" }}
                      onClick={() => {
                        handlewishlistcart(fetchproductscart);
                        // handleAddToCartCount();
                      }}
                    /> */}

                    <span
                      className="position-absolute px-2 badge bg-success"
                      style={{ top: "10px", right: "20px" }}
                    >
                      New
                    </span>
                    <span
                      className="position-absolute px-2 badge bg-danger"
                      style={{ top: "40px", right: "20px" }}
                    >
                      {fetchproductscart.discount}%
                    </span>
                  </div>

                  {/* Thumbnail Images */}
                  <div className="row mt-3 g-2  gap_cartimg">
                    {JSON.parse(fetchproductscart.thumbnail || "[]").map(
                      (thumb, i) => (
                        <div
                          key={i}
                          className="col-6 col-sm-2 col-md-2 col-lg-2 col-xl-2"
                        >
                          <div className="shadow p-2 bg-white rounded thumb-box">
                            <img
                              src={`${img_path}/products/${thumb}`}
                              alt={`thumb-${i}`}
                              className="img-fluid thumb-img"
                            />
                          </div>
                        </div>
                      )
                    )}
                  </div>
                </div>

                {/* RIGHT SIDE - DETAILS */}
                <div className="col-12 col-md-6 ps-5 ms-3">
                  <h4 className="cardfamily fw-semibold">
                    {fetchproductscart.product_name}
                  </h4>
                  <span className="small ps-2 pt-1">Ratings</span>

                  <div className="d-flex ps-2 py-1 align-items-center">
                    <div>
                      <span className="fw-bold fs-5 me-2">4.5</span>
                      <FaStar color="#ff9d00" />
                    </div>
                    <button className="btn btn-success btn-sm px-2 ms-4 banner_family">
                      Stock In
                    </button>
                  </div>

                  <div className="pt-2">
                    <span className="cart_color fw-bold fs-3 me-2">
                      {fetchproductscart.price}€
                    </span>
                    <span className="text-muted opacity-75 fs-5 fw-semibold">
                      <s>{fetchproductscart.mrp}€</s>
                    </span>
                    <span> Incl. VAT</span>
                  </div>

                  {/* Quantity and Cart Buttons */}
                  <div className="d-flex ps-2 py-3 align-items-center">
                    <div className="d-flex align-items-center">
                      {/* <button className="btn btn-outline-secondary px-3 p-0">-</button>
                      <span className="mx-3 fw-bold">1</span>
                      <button className="btn btn-outline-secondary px-3 p-0">+</button> */}
                      <button
                        className="btn btn-dark btn-sm rounded"
                        onClick={handleCartDecrease}
                      >
                        –
                      </button>
                      <span className="fs-5 px-2">{quantity}</span>
                      <button
                        className="btn btn-dark btn-sm rounded"
                        onClick={handleCartIncrease}
                      >
                        +
                      </button>
                    </div>
                    <button
                      className="btn btn-dark btn-sm ms-4 px-3 cardfamily"
                      onClick={() => {
                        if (!token) {
                          navigate("/signin");
                        } else {
                          handleAddToCartproduct(fetchproductscart, quantity);
                          handleAddToCartCount();
                          navigate("/addtocart");
                        }
                      }}
                    >
                      Add <BiSolidCartAdd size={22} />
                    </button>
                  </div>

                  <div className="mt-3">
                    <button
                      className="btn btn-dark px-5 p-1 cardfamily"
                      onClick={() => {
                        if (!token) {
                          navigate("/signin");
                        } else {
                          handleAddToCartproduct(fetchproductscart, quantity);
                          handleAddToCartCount();
                          navigate("/addtocart");
                        }
                      }}
                    >
                      Buy Now
                    </button>
                  </div>

                  <hr />
                  <div>
                    <p className="fw-semibold mb-1 cardfamily">
                      Brand Name:{" "}
                      <span className="fw-normal ms-1">
                        {fetchproductscart.brand}
                      </span>
                    </p>
                    <p className="fw-semibold mb-1 cardfamily">
                      SKU:{" "}
                      <span className="fw-normal ms-1">
                        {fetchproductscart.pro_sku}
                      </span>
                    </p>
                    <p className="fw-semibold mb-1 cardfamily">
                      Categories:{" "}
                      <span
                        className="fw-normal ms-1"
                        dangerouslySetInnerHTML={{
                          __html: fetchproductscart.additional_info,
                        }}
                      />
                    </p>
                    <p className="fw-semibold mb-1 cardfamily">
                      Tag:{" "}
                      <span className="fw-normal ms-1">
                        {fetchproductscart.tag}
                      </span>
                    </p>
                  </div>

                  <hr />
                  <p className="cardfamily">
                    {/* Colour: <span className="fw-semibold">Black</span> */}
                    Colour:{" "}
                    <span className="fw-semibold ms-2">
                      {fetchproductscart.color === "#db1414"
                        ? "Red"
                        : fetchproductscart.color === "#000000"
                        ? "Black"
                        : fetchproductscart.color === "#ffffff"
                        ? "White"
                        : fetchproductscart.color === "#0000ff"
                        ? "Blue"
                        : fetchproductscart.color
                        ? fetchproductscart.color
                        : "N/A"}
                    </span>
                  </p>
                </div>
              </div>
            </>

            {/* <div className='row'>
            <div className="col-12 col-md-5">

             
              <div className="bg-white mx-5 py-2 ms-5   position-relative d-flex justify-content-center align-items-center">

                <div ref={zoomRef}></div>

                <CiHeart
                  size={25}
                  className="heart_color position-absolute"
                  style={{ top: "15px", left: "20px" }}
                />
                <span
                  className="position-absolute px-2 badge bg-success"
                  style={{ top: "10px", right: "40px" }}
                >
                  New
                </span>
                <span
                  className="position-absolute px-2 badge bg-danger"
                  style={{ top: "40px", right: "40px" }}
                >
                  20%
                </span>
              </div>


              <div className="row mt-3 g-2 ">
                <div className="col-6 col-md-2 ms-4">
                  <div className="shadow p-2 bg-white rounded thumb-box">
                    <img src={supermixie} alt="SuperMixie" className="img-fluid thumb-img" />
                  </div>
                </div>

                <div className="col-6 col-md-2 ">
                  <div className="shadow p-2 bg-white rounded thumb-box">
                    <img src={supermixieone} alt="SuperMixie One" className="img-fluid" />
                  </div>
                </div>

                <div className="col-6 col-md-2">
                  <div className="shadow p-2 bg-white rounded thumb-box">
                    <img src={supermixietwo} alt="SuperMixie Two" className="img-fluid thumb-img" />
                  </div>
                </div>

                <div className="col-6 col-md-2">
                  <div className="shadow p-2 bg-white rounded thumb-box">
                    <img src={supermixiethree} alt="SuperMixie Three" className="img-fluid thumb-img" />
                  </div>
                </div>

                <div className="col-6 col-md-2">
                  <div className="shadow p-2 bg-white rounded thumb-box">
                    <img src={supermixiethree} alt="SuperMixie Four" className="img-fluid thumb-img" />
                  </div>
                </div>
              </div>
            </div>
            <div className='col-12 col-md-6 ps-5'>
              <h4 className='cardfamily fw-semibold'>PREMIER KM 501 Mixer Grinder, 550W,</h4>
              <h4 className='cardfamily fw-semibold'>3 Jars (White), REGULAR</h4>
              <span className="small ps-2 pt-1">Ratings</span>
              <div className="d-flex  ps-2 py-1">
                <div>
                  <span className="fw-bold fs-5 me-2">4.5</span>
                  <FaStar color="#ff9d00" />
                  <FaStar color="#ff9d00" />
                  <FaStar color="#ff9d00" />
                  <FaStar color="#ff9d00" />
                  <FaStarHalfAlt color="#ff9d00" />
                </div>
                <button className="btn btn-success btn-sm px-2 ms-4 p-0 me-2 banner_family ms-5">Stock In</button>
              </div>

              <div className='pt-2'>
                <span className="cart_color fw-bold fs-3 me-2">50,00€</span>
                <span className="text-muted opacity-75 fs-5 fw-semibold">
                  <s>1,80€</s></span>
                <span className=''> Incl. VAT</span>

              </div>
              <div className='d-flex  ps-2 py-3'>
                <div className="d-flex align-items-center">
                  <button className="btn btn-outline-secondary px-3 p-0">-</button>
                  <span className="mx-3 fw-bold">1</span>
                  <button className="btn btn-outline-secondary px-3 p-0">+</button>
                </div>


                <button className="btn btn-dark btn-sm mx-3 px-3 p-0 me-2 cardfamily" onClick={() => navigate('/addtocart')}>+ Add To Cart</button>

              </div>
              <div className='mt-3'>
                <button className='btn btn-dark px-5  p-1 cardfamily' onClick={() => navigate('/addtocart')}>Buy Now</button>

              </div>
              <hr />
              <div>
                <p className="fw-semibold mb-1 cardfamily">
                  Brand Name: <span className="fw-normal ms-1">Premier</span>
                </p>

                <p className="fw-semibold mb-1 cardfamily">
                  SKU: <span className="fw-normal ms-1">145170701760</span>
                </p>

                <p className="fw-semibold mb-1 cardfamily">
                  Categories:
                  <span className="fw-normal ms-1">
                    All products, BLENDER, Blue, Collections, Deep Sea <br />Collection, Home Appliances, Home Appliances Deep Sea
                  </span>
                </p>

                <p className="fw-semibold mb-1 cardfamily">
                  Tag: <span className="fw-normal ms-1">Table blender</span>
                </p>
              </div>

              <hr />
              <div>
                <p className=' cardfamily'>Colour  :<span className='fw-semibold'>Black</span></p>

                <div className="row g-2 px-lg-0 mx-lg-0">
                 
                  <div className="col-12 col-md-2">
                    <div className="shadow bg-white  text-center ">
                      <img src={image1} alt="superMixie" className="img-fluid " style={{ maxHeight: "100px", objectFit: "contain" }} />
                      <hr className="my-1" />
                      <span className="text-muted opacity-75 d-block" style={{ fontSize: "0.85rem" }}>
                        <s>1,15€</s>
                      </span>
                      <p className="fw-semibold mb-0" style={{ fontSize: "0.9rem" }}>50,00€</p>
                    </div>
                  </div>

               
                  <div className="col-12 col-md-2">
                    <div className="shadow bg-white  text-center ">
                      <img src={image2} alt="superMixie" className="img-fluid pt-1" style={{ maxHeight: "100px", objectFit: "contain" }} />
                      <hr className="my-1" />
                      <span className="text-muted opacity-75 d-block" style={{ fontSize: "0.85rem" }}>
                        <s>1,80€</s>
                      </span>
                      <p className="fw-semibold mb-0" style={{ fontSize: "0.9rem" }}>40,00€</p>
                    </div>
                  </div>

                 
                  <div className="col-12 col-md-2">
                    <div className="shadow bg-white  text-center ">
                      <img src={image3} alt="superMixie" className="img-fluid pt-1" style={{ maxHeight: "100px", objectFit: "contain" }} />
                      <hr className="my-1" />
                      <span className="text-muted opacity-75 d-block" style={{ fontSize: "0.85rem" }}>
                        <s>1,70€</s>
                      </span>
                      <p className="fw-semibold mb-0" style={{ fontSize: "0.9rem" }}>60,00€</p>
                    </div>
                  </div>
                </div>

              </div>

            </div>
            </div> */}
            <div className="py-4">
              <div>
                <Box sx={{ width: "100%" }}>
                  {/* Tabs */}
                  <Tabs value={value} onChange={handleChange} centered>
                    <Tab label="DESCRIPTION" />
                    <Tab label="ADDITIONAL INFORMATION" />
                    <Tab label="REVIEWS (1,476)" />
                  </Tabs>

                  {/* Tab Panels */}
                  <TabPanel value={value} index={0}>
                    <p
                      className="cardfamily"
                      dangerouslySetInnerHTML={{
                        __html: fetchproductscart.description,
                      }}
                    ></p>
                  </TabPanel>
                  <TabPanel value={value} index={1}>
                    <p
                      className="cardfamily"
                      dangerouslySetInnerHTML={{
                        __html: fetchproductscart.additional_info,
                      }}
                    ></p>
                  </TabPanel>
                  <TabPanel value={value} index={2}>
                    <p>Customer reviews will be displayed here.</p>
                  </TabPanel>
                </Box>
                {/* <Box sx={{ width: '100%', bgcolor: 'background.paper' }}>
              <Tabs value={value} onChange={handleChange} centered>
                <Tab label="DESCRIPTION" />
                <Tab label="ADDITIONAL INFORMATION" />
                <Tab label="REVIEWS (1,476)" />
              </Tabs>
            </Box> */}
              </div>
              <hr />
              <div>
                <p className="banner_family">
                  Premier Kitchen Machines are an advanced product of modern
                  engineering. Premier Super-G mixer grinder is sleek and
                  durable,
                  <br />
                  come with three stainless steel jars. Premier Super-G features
                  550-Watts, Heavy Duty Motor with an automatic overload cut-off{" "}
                  <br />
                  system. The Super G Kitchen Machine is well protected against
                  sudden overloads.
                </p>
              </div>
              <hr />
              <div>
                <h5>Related Products</h5>

                {/* <div className="row g-3 row-cols-2 row-cols-sm-3 row-cols-md-4 row-cols-lg-5 py-5">
                  {fetchproductscartrelated?.length > 0 ? (
                    fetchproductscartrelated.map((items) => (
                      <div className="col mb-4" key={items.id}>
                        <div className="card h-100 w-100 px-1 product-card py-1 rounded position-relative">
                          <img
                            src={`${img_path}/products/${items.image}`}
                            alt={items.product_name}
                            className="img-fluid"
                            onClick={() => editcategorypreview(items.id)}
                          />
                          {token &&
                          favoriteData?.some(
                            (favorite) => favorite?.id === items?.id
                          ) ? (
                            <FaHeart
                              size={20}
                              className="position-absolute text-danger"
                              style={{
                                top: "15px",
                                left: "15px",
                                cursor: "pointer",
                              }}
                            
                              onClick={() =>
                                handleProductConfirmDelete(items?.id)
                              }
                            />
                          ) : (
                            <>
                              <CiHeart
                                size={24}
                                className="position-absolute text-danger"
                                style={{
                                  top: "15px",
                                  left: "15px",
                                  cursor: "pointer",
                                }}
                                onClick={() => handlewishlistcart(items)}
                              />
                            </>
                          )}
                         
                          <h6 className="fw-bold ps-2 pt-2">
                            {items.product_name}
                          </h6>

                          <div className="d-flex justify-content-between py-2 px-2">
                            <span>
                              {items.weight}
                              {items.attribute_type}
                            </span>
                            <span>
                              <FaStar color="#FF9D00" /> 4.5
                            </span>
                          </div>

                        <div className="d-flex justify-content-between align-items-center ps-2 py-1 flex-wrap gap-2">


  <div className="d-flex flex-column flex-sm-row align-items-start align-items-sm-center">
    <span className="cart_color fw-bold fs-6 fs-sm-5 me-sm-2">
      {items.price}€
    </span>
    <span className="text-muted fs-7 fs-sm-6">
      <s>{items.mrp}€</s>
    </span>
  </div>

  <button
    className="btn btn-dark px-2 px-sm-3 px-md-4 py-1 py-sm-2 fw-semibold d-flex align-items-center gap-1"
    onClick={() => {
      if (!token) {
        navigate("/signin");
      } else {
        handleAddToCartproductrelated(items);
      }
    }}
  >
    Add
    <BiSolidCartAdd size={20} />
  </button>

</div>

                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-muted">
                      No products available
                    </div>
                  )}
                </div> */}

                <div className="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3  row-cols-xl-5 ">
                  {loading ? (
                    <>
                      <Loader />
                    </>
                  ) : fetchproductscartrelated?.length > 0 ? (
                    fetchproductscartrelated.map((items) => (
                      <div className="col mb-4" key={items.id}>
                        <div className="card h-100 w-100 px-1 product-card py-1 rounded position-relative">
                          <img
                            src={`${img_path}/products/${items.image}`}
                            alt={items.product_name}
                            className="img-fluid"
                            onClick={() => editcategorypreview(items.id)}
                          />
                          {token &&
                          favoriteData?.some(
                            (favorite) => favorite?.id === items?.id
                          ) ? (
                            <FaHeart
                              size={20}
                              className="position-absolute text-danger"
                              style={{
                                top: "15px",
                                left: "15px",
                                cursor: "pointer",
                              }}
                              // onClick={() => handlewishlist(productitem)}
                              onClick={() =>
                                handleProductConfirmDelete(items?.id)
                              }
                            />
                          ) : (
                            <>
                              <CiHeart
                                size={24}
                                className="position-absolute text-danger"
                                style={{
                                  top: "15px",
                                  left: "15px",
                                  cursor: "pointer",
                                }}
                                onClick={() => handlewishlistcart(items)}
                              />
                            </>
                          )}
                          {/* <CiHeart
                                                    size={25}
                                                    className="heart_color position-absolute"
                                                    onClick={() => {
                                                      handlewishlistOurpro(items);
                                                      // handleWishlistCount();
                                                    }}
                                                    style={{ top: "25px", left: "20px" }}
                                                  /> */}

                          <h6 className="fw-bold ps-2 pt-2">
                            {/* {items.product_name} */}
                             {" "}
              {items?.product_name?.length > 16
                ? items.product_name.slice(0, 16) + "..."
                : items.product_name}
                          </h6>

                          <div className="d-flex justify-content-between py-2 px-2">
                            <span>
                              {items.weight}
                              {items.attribute_type}
                            </span>
                            <span>
                              <FaStar color="#FF9D00" /> 4.5
                            </span>
                          </div>

                          <div className="d-flex justify-content-between align-items-center ps-2 py-1">
                            <div>
                              <span className="cart_color fw-bold fs-5 me-2">
                                {items.price}€
                              </span>
                              <span className="text-muted">
                                <s>{items.mrp}€</s>
                              </span>
                            </div>
                            <button
                              className="btn btn-dark btn-sm me-2"
                              onClick={() => {
                                handleAddToCartproduct(items);
                                // handleAddToCartCount();
                              }}
                            >
                              Add
                              <BiSolidCartAdd size={22} />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center text-muted">
                      No products available
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default Cart;
