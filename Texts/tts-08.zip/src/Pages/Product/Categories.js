import React, { useEffect, useState } from "react";
import Header from "../../Component/Header/Header";
import Footer from "../../Component/Footer/Footer";
import sunflowerOil from "../../Assets/Group 66.png";
import TLSugars from "../../Assets/T&L Sugars 1.png";
import Spices from "../../Assets/Group 67.png";
import Rice from "../../Assets/download (47) 1.png";
import Flours from "../../Assets/Pumpkin-Shape Meatball Biscuits 1.png";
import Atta from "../../Assets/Dheeraj Bhati 1.png";
import Vegetables from "../../Assets/Green Vegetables Photos - Download Free High-Quality Pictures _ Freepik 1.png";

import Potato from "../../Assets/Group 62.png";

import Earrings from "../../Assets/Mask group (41).png";
import Rings from "../../Assets/Mask group (42).png";
import BraceletsBangles from "../../Assets/Mask group (43).png";
import MinimalistJewelry from "../../Assets/Mask group (44).png";
import GiftSets from "../../Assets/Mask group (45).png";
import { useNavigate } from "react-router-dom";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import { Carousel } from "primereact/carousel";
import Common from "../../common/Common";

const Categories = () => {
  const navigate = useNavigate();

  const [fetchproducts, setFetchproducts] = useState([]);
  console.log("fetchproducts", fetchproducts);
  const [fetchflashdeals, setFetchflashdeals] = useState([]);
  console.log("fetchflashdeals", fetchflashdeals);

  const [fetchcategorys, setFetchcategorys] = useState([]);
  console.log("fetchcategorysss", fetchcategorys);

  const responsiveOptions = [
    { breakpoint: "1400px", numVisible: 4, numScroll: 1 },
    { breakpoint: "1199px", numVisible: 3, numScroll: 1 },
    { breakpoint: "767px", numVisible: 2, numScroll: 1 },
    { breakpoint: "575px", numVisible: 1, numScroll: 1 },
  ];

  const vegetablesData = fetchproducts?.filter(
    (item) => item.category_name === "Vegitable"
  );
  console.log("vegetablesData", vegetablesData);

  const GroceryData = fetchproducts?.filter(
    (item) => item.category_name === "Grocery"
  );
  console.log("GroceryData", GroceryData);

  const vesselData = fetchproducts?.filter(
    (item) => item.category_name === "Vessel"
  );
  console.log("vesselData", vesselData);

  const garmentsData = fetchproducts?.filter(
    (item) => item.category_name === "Garments"
  );
  console.log("garmentsData", garmentsData);

  const rosegoldData = fetchproducts?.filter(
    (item) => item.category_name === "Rose Gold"
  );
  console.log("rosegoldData", rosegoldData);
  const { token, user } = Common();
  const fetchProduct = async () => {
    try {
      const response = await axios.get(`${base_url}/allproducts`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          "tts-user-id": user?.user_id,
        },
      });
      setFetchproducts(response.data);
      console.log("response.data", response.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchProduct();
  }, []);

  const fetchflash = async () => {
    try {
      const response = await axios.get(`${base_url}/flashsale`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          "tts-user": user?.user_id,
        },
      });
      setFetchflashdeals(response.data);
      console.log("response.data", response.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchflash();
  }, []);

  const fetchcategory = async () => {
    try {
      const response = await axios.get(`${base_url}/category`);
      setFetchcategorys(response.data);
      console.log("response.data", response.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchcategory();
  }, []);

  const productTemplate = (productitem) => {
    if (!productitem) return null;

    return (
      <div className="p-2">
        <div className="border rounded bg-white  text-center p-3 h-100">
          <img
            src={`${img_path}/products/${productitem.image}`}
            alt={productitem.product_name}
            className="img-fluid"
            style={{ height: "160px", width: "100%", objectFit: "contain" }}
          />
        </div>

        <p className="ibm_family fw-semibold pt-2 text-center mb-0 pb-3">
          {productitem.product_name}
        </p>
      </div>
    );
  };

  const TopCategories = (item) => {
    if (!item) return null;

    return (
      <div className="text-center p-3">
        <div
          className="border rounded shadow-sm p-2"
          onClick={(e) => {
            e.preventDefault();
            editcategory(item.id);
          }}
        >
          <p className="fw-semibold ibm_family mb-1 categoriycollor">
            {item.title}
          </p>

          <img
            src={`${img_path}/categories/${item.thumbnail}`}
            alt={item.title}
            className="img-fluid rounded mb-2"
            style={{ height: "120px", objectFit: "contain" }}
          />
          <p className="categoriesbcolor text-white p-0 m-0 ibm_family">
            Up to 30% Off{" "}
          </p>
        </div>
      </div>
    );
  };

  const editcategory = (categoryId) => {
    console.log("categoryIdhhhhh", categoryId);
    navigate("/product", { state: { categoryId } });
  };

  return (
    <>
      <Header />
      <div className="body_bgcolor">
        <div className="container py-4">
          <h4 className="fw-bold cardfamily pb-3">Categories</h4>

          {/* <div className=' py-4'>

            <div className='bg-white  rounded'>
              <h5 className='fw-semibold ibm_family ps-5 py-3'>Top Categories</h5>

              <div className="container ">
                <Carousel
                  value={fetchcategorys}
                  className="hide-this-list your-other-class"
                  numVisible={5}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={TopCategories}
                //    autoplayInterval={2000}

                />
              </div>
            </div>
          </div> */}
          <div className="py-4">
            <div className="bg-white rounded">
              <h5 className="fw-semibold ibm_family ps-5 py-3">
                Top Categories
              </h5>

              <div className="container">
                <Carousel
                  value={fetchcategorys}
                  numVisible={5}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={TopCategories}
                />
              </div>
            </div>
          </div>

          <div className=" py-4">
            <div className="bg-white  rounded">
              <h5 className="fw-semibold ibm_family ps-5 py-3">Vegetables</h5>

              <div className="container ">
                <Carousel
                  value={vegetablesData}
                  className="hide-this-list your-other-class"
                  numVisible={5}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplate}
                  //    autoplayInterval={2000}
                />
              </div>
            </div>
          </div>

          <div className=" ">
            <div className="bg-white  rounded">
              <h5 className="fw-semibold ibm_family ps-5 pt-4">Grocery</h5>

              <div className="container ">
                <Carousel
                  value={GroceryData}
                  className="hide-this-list your-other-class"
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplate}
                  //    autoplayInterval={2000}
                />
              </div>
            </div>
          </div>

          <div className="py-4 ">
            <div className="bg-white  rounded">
              <h5 className="fw-semibold ibm_family ps-5 pt-4">Vessel</h5>

              <div className="container ">
                <Carousel
                  value={vesselData}
                  className="hide-this-list your-other-class"
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplate}
                  //    autoplayInterval={2000}
                />
              </div>
            </div>
          </div>

          <div className="py-4 ">
            <div className="bg-white  rounded">
              <h5 className="fw-semibold ibm_family ps-5 pt-4">Rose Gold</h5>

              <div className="container ">
                <Carousel
                  value={rosegoldData}
                  className="hide-this-list your-other-class"
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={responsiveOptions}
                  itemTemplate={productTemplate}
                  //    autoplayInterval={2000}
                />
              </div>
            </div>
          </div>

          {/* <div className='col-6 col-md-2'>
                <div className='border text-center ms-3'>
                  <p className='categoriycollor pt-1 fw-semibold ibm_family'>Sugar & More</p>
                  <img src={TLSugars} alt='sunflower oil' className='img-fluid' style={{ height: "150px" }} />
                  <p className='categoriesbcolor text-white p-0 m-0 ibm_family'>Up to 20% Off </p>
                </div>
              </div> */}

          {/* <div className='bg-white p-3 mt-4 rounded'>
            <h5 className='fw-semibold ibm_family ps-2 py-3'>Vegetables</h5>
            <div className='row ps-2'>
              <div className='col-6 col-md-4'>
                <div className='border'>
                  <img src={Vegetables} alt='Vegetables' className='img-bluid' />
                </div>
                <p className='ibm_family fw-semibold pt-2 text-center'>Fresh Vegetables</p>
              </div>
              <div className='col-6 col-md-2'>
                <div className='border'>
                  <img src={Potato} alt='Vegetables' className='img-bluid pt-4 mt-1' />
                </div>
                <p className='ibm_family fw-semibold pt-2 text-center'>Potato, Onion & Tomato</p>
              </div>
              <div className='col-6 col-md-2'>
                <div className='border'>
                  <img src={GreenVeggies} alt='Vegetables' className='img-bluid' style={{ height: "160px" }} />
                </div>
                <p className='ibm_family fw-semibold pt-2 text-center'>Green Veggies</p>
              </div>
              <div className='col-6 col-md-2'>
                <div className='border'>
                  <img src={HerbsSeasonings} alt='Vegetables' className='img-bluid' style={{ height: "160px" }} />
                </div>
                <p className='ibm_family fw-semibold pt-2 text-center'>Herbs & Seasonings</p>
              </div>
              <div className='col-6 col-md-2'>
                <div className='border'>
                  <img src={LocalVeggies} alt='Vegetables' className='img-bluid' style={{ height: "160px" }} />
                </div>
                <p className='ibm_family fw-semibold pt-2 text-center'>Local Veggies</p>
              </div>
            </div>

          </div>

          <div className='bg-white mt-4 ps-3 rounded'>
            <h5 className='fw-semibold ibm_family ps-2 py-3'>Grocery</h5>

            <div className='row ps-2'>
              <div className='col-6 col-md-2'>
                <div className='border'>
                  <img src={RiceattaDals} alt='RiceattaDals' className='img-fluid' />

                </div>
                <p className='ibm_family fw-semibold pt-2 text-center'>Rice, atta & Dals</p>

              </div>
              <div className='col-6 col-md-2'>
                <div className='border py-4'>
                  <img src={Masalas} alt='RiceattaDals' className='img-fluid pt-3' />

                </div>
                <p className='ibm_family fw-semibold pt-2 text-center'>Masalas & Dry Fruits </p>

              </div>
              <div className='col-6 col-md-2'>
                <img src={SugarSaltJaggery} alt='RiceattaDals' className='img-fluid' style={{ height: "160px" }} />
                <p className='ibm_family fw-semibold pt-2 text-center'>Sugar, Salt &<br /> Jaggery </p>

              </div>
              <div className='col-6 col-md-2'>
                <img src={TeaCoffee} alt='RiceattaDals' className='img-fluid' style={{ height: "160px" }} />
                <p className='ibm_family fw-semibold pt-2 text-center'>Tea, Coffee &<br /> More</p>
              </div>
              <div className='col-6 col-md-2'>
                <img src={TeaPersonalsCare} alt='RiceattaDals' className='img-fluid' style={{ height: "160px" }} />
                <p className='ibm_family fw-semibold pt-2 text-center'>Personals Care</p>
              </div>
              <div className='col-6 col-md-2'>
                <img src={CleaningHousehold} alt='RiceattaDals' className='img-fluid' style={{ height: "160px" }} />
                <p className='ibm_family fw-semibold pt-2 text-center'>Cleaning &<br /> Household</p>
              </div>

            </div>

          </div>

          <div className='bg-white mt-4 rounded ps-3'>
            <h5 className='fw-semibold ibm_family ps-2 py-3'>Vessel</h5>
            <div className='row ps-2'>
              <div className='col-6 col-md-2'>
                <img src={CookwareSets} alt='RiceattaDals' className='img-fluid' />
                <p className='ibm_family fw-semibold pt-2 text-center'>Cookware Sets </p>

              </div>
              <div className='col-6 col-md-2'>
                <img src={NonStickPotsPans} alt='RiceattaDals' className='img-fluid' />
                <p className='ibm_family fw-semibold pt-2 text-center'>Non-Stick Pots & <br />Pans </p>

              </div>

              <div className='col-6 col-md-2'>
                <img src={Stainless} alt='RiceattaDals' className='img-fluid' />
                <p className='ibm_family fw-semibold pt-2 text-center'>Stainless Steel<br /> Utensils </p>

              </div>
              <div className='col-6 col-md-2'>
                <img src={TraditionalIndianGermanTools} alt='RiceattaDals' className='img-fluid' />
                <p className='ibm_family fw-semibold pt-2 text-center'>Traditional Indian/<br />German Tools </p>

              </div>
              <div className='col-6 col-md-2'>
                <img src={StorageJarsContainers} alt='RiceattaDals' className='img-fluid' />
                <p className='ibm_family fw-semibold pt-2 text-center'>Storage Jars &<br /> Containers </p>
              </div>
              <div className='col-6 col-md-2'>
                <img src={BakingEssentials} alt='RiceattaDals' className='img-fluid' />
                <p className='ibm_family fw-semibold pt-2 text-center'>Baking<br /> Essentials </p>
              </div>
            </div>

          </div>

         */}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Categories;
