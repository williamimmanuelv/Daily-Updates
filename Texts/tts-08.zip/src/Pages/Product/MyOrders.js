import React, { useEffect, useState } from "react";
import "./myorders.css";
import Header from "../../Component/Header/Header";
import Footer from "../../Component/Footer/Footer";
import basmatirice from "../../Assets/fd71f6518b357678996c850b48023ed9 1.png";
import basmati from "../../Assets/61ded8e828f0693eba9198b9ba78f727 1.png";
import sampamati from "../../Assets/fc63c555bde41112fe8e00cd232f343b 1.png";
import onion from "../../Assets/b08f48585f510825bebbe1a9acdbc725 1.png";
import { FaRegCircleCheck } from "react-icons/fa6";
import { FaRegCircleXmark } from "react-icons/fa6";
import { Timeline } from "primereact/timeline";
import { useNavigate } from "react-router-dom";
import "./myorders.css";
import { ConfigProvider, message, Spin, Steps } from "antd";
import AllOrder from "./orderlist/AllOrder";
import OngoingOrder from "./orderlist/OngoingOrder";
import CompletedOrder from "./orderlist/CompletedOrder";
import CancelOrder from "./orderlist/CancelOrder";
import { base_url } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import Common from "../../common/Common";
import { AiOutlineLeft } from "react-icons/ai";

const MyOrders = () => {
  const navigate = useNavigate();
  const [active, setActive] = useState("all");
  const { token } = Common();
  const [orderData, setOrderData] = useState();
  const [loading, setLoading] = useState(false);
  const fetchOrder = async () => {
    setLoading(true);
    try {
      const res = await axios.get(`${base_url}/view/order`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      const newData = res?.data;
      if (newData?.status) {
        setOrderData(newData?.orders);
      }
      console.log("order track", res);
    } catch (error) {
      console.log("error", error);
      message.error(error?.response?.data?.message);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (token) {
      fetchOrder();
    }
  }, []);

  // const currentIndex = items.findIndex((item) => item.status === "packed");
  // const orderData = [
  //   {
  //     id: 1,
  //     status: "packed",
  //   },
  //   {
  //     id: 2,
  //     status: "shipped",
  //   },
  //   {
  //     id: 3,
  //     status: "order_placed",
  //   },
  // ];

  const tabs = [
    { key: "all", label: "All Orders" },
    { key: "ongoing", label: "Ongoing Orders" },
    { key: "completed", label: "Completed Orders" },
    { key: "cancel", label: "Cancel Orders" },
  ];

  return (
    <>
      <Header />
      <div className="body_bgcolor">
        <div className="container-fluid container-lg py-4">
          <div className="d-flex align-items-center gap-3 pb-3">
            <button
              className="back-btn d-flex align-items-center justify-content-center"
              onClick={() => navigate("/sidebar")}
            >
              <AiOutlineLeft />
            </button>

            <h4 className="m-0 fw-bold text-dark">My Orders</h4>
          </div>
          {/* <h5 className="fw-bold cardfamily">My Orders</h5> */}
          <div className="order_tab_main_container">
            <div className="order-tab-container">
              {tabs.map((tab, index) => (
                <div
                  key={tab.key}
                  onClick={() => setActive(tab.key)}
                  className={`d-flex align-items-center order_tab ${
                    active === tab.key ? "active" : ""
                  } ${
                    index === 0 && active === tab.key
                      ? "first-active"
                      : index === tabs.length - 1 && active === tab.key
                      ? "last-active"
                      : ""
                  }`}
                >
                  <button
                    className="order-tab-btn"
                    onClick={() => setActive(tab.key)}
                  >
                    {tab?.label}
                  </button>
                </div>
              ))}
            </div>
          </div>
          <div className="tab_content_container">
            {loading ? (
              <div className="d-flex align-items-center justify-content-center h-100">
                <Spin />
              </div>
            ) : (
              <>
                {active === "all" && (
                  <>
                    <AllOrder order={orderData} />
                  </>
                )}
                {active === "ongoing" && (
                  <OngoingOrder
                    order={orderData?.filter(
                      (item) =>
                        item?.status === "Picked Up" ||
                        item?.status === "Shipped"
                    )}
                  />
                )}
                {active === "completed" && (
                  <CompletedOrder
                    order={orderData?.filter(
                      (item) => item?.status === "Delivered"
                    )}
                  />
                )}
                {active === "cancel" && (
                  <CancelOrder
                    order={orderData?.filter(
                      (item) => item?.status === "Cancelled"
                    )}
                  />
                )}
              </>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default MyOrders;
