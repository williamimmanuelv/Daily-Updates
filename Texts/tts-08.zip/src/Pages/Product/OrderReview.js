import React, { useState } from 'react'
import Header from '../../Component/Header/Header'
import { LuPencil } from "react-icons/lu";
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Footer from '../../Component/Footer/Footer'

const steps = [
  'Your Cart',
  'Order Review',
  'Payment',
];

const OrderReview = () => {
    
  return (
   <>
   <Header />
   <div className='body_bgcolor'>

   <div className='container py-4'>
    <div className='row'>
        <div className='col-12 col-md-8'>



    <h4 className="ms-3 mt-2 fw-semibold cardfamily">Order Review</h4>
     <div className="border p-4 mx-3 my-4 bg-white">
                <h5 className='cardfamily'>Delivery Address</h5>
                <hr/>
              <div className="d-flex justify-content-between align-items-center">
                <div>   
                  <span className="fw-semibold">TTS-Brothers GmbH&Co. KG</span>
                  <span className="bg-primary text-white ms-3 p-1 px-2 rounded-3 small">
                    Work
                  </span>
                </div>
                <LuPencil className="text-secondary" />
              </div>

              <p className="mt-2 mb-3 small text-muted">
                Asien Supermarkt in Dortmund <br />
                Textiles & Food Items, Retail & Wholesale, Rheinischestr.52, Dortmund
                4413
              </p>
             </div>
             </div>

              <div className="col-12 col-md-4 mt-5">

              <div className='bg-white border p-3'>

                <Box sx={{ width: '100%' }} className="">
                  <Stepper activeStep={1} alternativeLabel>
                    {steps.map((label) => (
                      <Step key={label}>
                        <StepLabel>{label}</StepLabel>
                      </Step>
                    ))}
                  </Stepper>
                </Box>
              </div>
             

              <div className='bg-white border my-4 '>
                <h4 className='fw-semibold px-3 py-3 border-bottom cardfamily'>Price details</h4>
                <div className='px-3'>
                  <p className='d-flex justify-content-between ibm_family'>
                    <span className='fw-semibold'>Total items</span>
                    <span>10 Number</span>
                  </p>
                  <p className='d-flex justify-content-between ibm_family'>
                    <span className='fw-semibold'>Subtotal</span>
                    <span>10,000€</span>
                  </p>
                  <p className='d-flex justify-content-between ibm_family'>
                    <span className='fw-semibold'>Discount</span>
                    <span>20%</span>
                  </p>
                  <p className='d-flex justify-content-between ibm_family'>
                    <span className='fw-semibold'>VAT</span>
                    <span>5%</span>
                  </p>
                  <hr />
                  <p className='d-flex justify-content-between ibm_family'>
                    <span className='fw-semibold'>Total </span>
                    <span>13,000€</span>
                  </p>
                  <hr />
                  <h6 className='pb-2 text-success ibm_family'>You will save 100€ on this order</h6>
                </div>
              </div>

              <div className='pb-5 text-center'>
                <button className='btn btn-dark cardfamily fs-5 px-5 fw-semibold rounded-5'>Make Payment</button>
              </div>



            </div>
    </div>

   </div>
   </div>


   <Footer />
   </>
  )
}

export default OrderReview