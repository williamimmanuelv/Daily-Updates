import React, { useEffect, useState } from "react";
import Header from "../../Component/Header/Header";
import Footer from "../../Component/Footer/Footer";
import { CiHeart } from "react-icons/ci";
import fryingpan from "../../Assets/COMFORT P C 5 1.png";
import frying from "../../Assets/salman 1 1.png";
import milkpan from "../../Assets/SS Idli Maker 1.png";
import comfort from "../../Assets/COMFORT P C 5 2.png";
import Box from "@mui/material/Box";
// import Slider from '@mui/material/Slider';
// import { Slider } from "primereact/slider";
import tbhander from "../../Assets/TB Handi PC 5 ltr image.png";

import { BiSolidCartAdd } from "react-icons/bi";

import { FaStar } from "react-icons/fa";
import { FaStarHalfAlt } from "react-icons/fa";
import "./product.css";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";
import axios from "axios";
import Toast from "../../Untils/Toast";
import { FaHeart } from "react-icons/fa6";
import Common from "../../common/Common";
import UpdateFilterData from "../../service/ApiService";
import { removeFavorite } from "../../store/favoriteSlice";
import Toastify from "../../Untils/Toastify";
import { Slider } from "antd";

const Product = () => {
  const navigate = useNavigate();
  const [value, setValue] = useState([20, 80]);
  const { favoriteData, dispatch } = Common();
  const { Update } = UpdateFilterData();
  const { showAddToCartToast } = Toastify();

  const user_id = localStorage.getItem("user_id");

  // const { id } = useParams()
  // const { category_id, subcategory_id } = useParams();
  // console.log("category_id", category_id)
  // console.log("subcategory_id", subcategory_id)

  const { state } = useLocation();
  console.log("state?.categoryId", state?.categoryId);
  const CategoryData = state?.categoryId || null;

  const SubCategoryData = state?.subcategoryId || null;

  console.log("SubCategoryData:", SubCategoryData);
  const ProductSearch = state?.searchId || null;

  const [fetchproducts, setFetchproducts] = useState([]);
  console.log("fetchproducts", fetchproducts);
  const [fetchfilteproduct, setFetchfilteproduct] = useState([]);
  console.log("fetchfilteproduct", fetchfilteproduct);
  const [fetchproductsFlter, setFetchproductsFlter] = useState([]);
  console.log("fetchproductsFlterdd", fetchproductsFlter);

  //   const fetchfilteproall = async () => {
  //   try {
  //     const response = await axios.get(`${base_url}/filterproducts`,);
  //     setFetchfilteproduct(response.data);
  //     console.log("response.data", response.data);
  //   } catch (error) {
  //     console.error("Error fetching data", error);
  //   }
  // };

  // useEffect(() => {
  //   fetchfilteproall();
  // }, []);

  // const fetchfiltepro = async () => {
  //   try {
  //     const response = await axios.get(`${base_url}/filterproducts`, {
  //       headers: {
  //         "tts-filter-x": CategoryData,
  //         "tts-filter-y": SubCategoryData,
  //          "tts-filter-z": ProductSearch,
  //       }
  //     });
  //   console.log("request", SubCategoryData);

  //     setFetchfilteproduct(response.data);
  //     console.log("response.data", response.data);
  //   } catch (error) {
  //     console.error("Error fetching data", error);
  //   }
  // };
  const [selectedBrands, setSelectedBrands] = useState([]);
  const [selectedSizes, setSelectedSizes] = useState([]);
  const [selectedDiscounts, setSelectedDiscounts] = useState([]);
  const [selectedWeights, setSelectedWeights] = useState([]);
  const [selectedColors, setSelectedColors] = useState([]);
  // const [priceRange, setPriceRange] = useState([0, 0]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [priceRange, setPriceRange] = useState([0, 0]);
  const [showAllBrands, setShowAllBrands] = useState(false);
  const [showAllDiscount, setShowAllDiscount] = useState(false);
  const [showAllweight, setShowAllweight] = useState(false);

  const token = localStorage.getItem("token");

  //  Toggle selection (checkbox)
  const handleSelect = (value, stateSetter) => {
    stateSetter((prev) =>
      prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value]
    );
  };

  // useEffect(() => {
  //   if (fetchproductsFlter?.filters?.price_range) {
  //     const min = fetchproductsFlter?.filters?.price_range?.min;
  //     const max = fetchproductsFlter?.filters?.price_range?.max;
  //     setPriceRange([min, max]);
  //   }
  // }, [fetchproductsFlter]);

  // useEffect(() => {
  //   const pr = fetchproductsFlter?.filters?.price_range;
  //   if (pr) {
  //     const min = Number(pr.min) || 0;
  //     const max = Number(pr.max) || 0;
  //     // ensure we store numbers (not strings)
  //     setPriceRange([min, max]);
  //   }
  // }, [fetchproductsFlter]);
  const minPrice = Number(fetchproductsFlter?.filters?.price_range?.min) || 0;
  const maxPrice =
    Number(fetchproductsFlter?.filters?.price_range?.max) || 10000;

  useEffect(() => {
    if (fetchproductsFlter?.filters?.price_range) {
      console.log(
        "fetchproductsFlter?.filters?.price_range",
        fetchproductsFlter?.filters?.price_range
      );
      setPriceRange([minPrice, maxPrice]);
    }
  }, [fetchproductsFlter]);
  console.log("priceRange", priceRange);

  const filterproducts = async () => {
    try {
      const payload = {
        //  category: CategoryData || null,
        category: selectedCategories.join(",") || CategoryData,
        subcategory: SubCategoryData || null,
        search: ProductSearch || null,
        brand: selectedBrands.join(","),
        min_price: priceRange[0] || "",
        max_price: priceRange[1] || "",
        color: selectedColors.join(","),
        size: selectedSizes.join(","),
        discounts: selectedDiscounts.join(","),
        weights: selectedWeights.join(","),
      };

      console.log("📦 Sending payload:", payload);

      const response = await axios.post(`${base_url}/filterproducts`, payload, {
        headers: {
          "Content-Type": "application/json",
          "tts-user-id": user_id,
        },
      });

      setFetchfilteproduct(response.data);
    } catch (error) {
      console.error(" Filter request failed", error);
    }
  };

  useEffect(() => {
    filterproducts();
  }, [CategoryData, SubCategoryData, ProductSearch]);

  // const fetchProduct = async () => {
  //   try {
  //     const response = await axios.get(`${base_url}/allproducts`);
  //     setFetchproducts(response.data);
  //     console.log("response.data", response.data);
  //   } catch (error) {
  //     console.error("Error fetching data", error);
  //   }
  // };

  // useEffect(() => {
  //   fetchProduct();
  // }, []);

  const fetchProductFilter = async () => {
    try {
      const response = await axios.get(`${base_url}/getfiltersname`);
      setFetchproductsFlter(response.data);
      console.log("response.data", response.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchProductFilter();
  }, []);

  const handlewishlist = async (item) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        navigate("/signin");

        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const values = {
        user_id: user_id,
        //   product_id: productitem.id,
        product_id: item.id,
      };

      console.log("Add to cart:", values);

      const response = await axios.post(`${base_url}/wishlist`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      await Update("favorite");
      console.log("response.data", response.data);

      // Toast({ message: "Added to cart successfully!", type: "success" });
    } catch (error) {
      console.error("Error adding to cart", error);
    }
  };

  const handleAddToCartproduct = async (item) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const values = {
        user_id: user_id,
        product_id: item.id,

        quantity: 1,
      };

      console.log("Add to cart:", values);

      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await Update("cart");

      console.log("response.data", response.data);
      showAddToCartToast();
      // Toast({ message: "Added to cart successfully!", type: "success" });
    } catch (error) {
      console.error("Error adding to cart", error);
    }
  };

  const [wishlistCounts, setWishlistCounts] = useState(0);
  console.log("wishlistCountssss", wishlistCounts);

  const handleWishlistCount = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const response = await axios.post(
        `${base_url}/wishlist/count`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      // navigate('/wishlist')
      console.log("response.data", response.data);
      //  Directly set the numeric count
      if (response.data?.count !== undefined) {
        setWishlistCounts(response.data.count);
      }
    } catch (error) {
      console.error("Error adding to cart", error);
      // Toast({ message: "Failed to update cart count.", type: "error" });
    }
  };
  const handleProductConfirmDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(`${base_url}/wishlist/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });
      dispatch(removeFavorite(id));
      await Update("favorite");
      // fetchflash();
      console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  };
  const [cartCount, setCartCount] = useState(0);

  //  Add to Cart Count API (POST)
  const handleAddToCartCount = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const values = {};

      console.log("Sending request:", values);

      //  Correct axios POST syntax
      const response = await axios.post(`${base_url}/cart/count`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });

      console.log("response.data", response.data);

      //  If API returns count
      if (response.data?.count !== undefined) {
        setCartCount(response.data.count);
      }

      // Optional Toast
      // Toast({ message: "Cart count updated!", type: "success" });
    } catch (error) {
      console.error("Error adding to cart", error);
      // Toast({ message: "Failed to update cart count.", type: "error" });
    }
  };

  const editcategorypreview = (categoryId) => {
    console.log("categoryIdhhhhh", categoryId);
    navigate("/cart", { state: { categoryId } });
  };
  const handleSort = (type) => {
    if (!Array.isArray(fetchfilteproduct.data)) return;

    let sorted = [...fetchfilteproduct.data]; // copy array safely

    if (type === "lowtohigh") {
      sorted.sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
    } else if (type === "hightolow") {
      sorted.sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
    } else if (type === "newest") {
      sorted.sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
    }

    setFetchfilteproduct({ ...fetchfilteproduct, data: sorted });
  };

  // const handleSort = (type) => {
  //   if (!Array.isArray(fetchfilteproduct.data)) return;

  //   let sorted = [...fetchfilteproduct.data];
  //   let filtered = [];

  //   if (type === "lowtohigh") {

  //     const minPrice = Math.min(...sorted.map((item) => parseFloat(item.price)));
  //     filtered = sorted.filter((item) => parseFloat(item.price) === minPrice);
  //   }
  //   else if (type === "hightolow") {

  //     const maxPrice = Math.max(...sorted.map((item) => parseFloat(item.price)));
  //     filtered = sorted.filter((item) => parseFloat(item.price) === maxPrice);
  //   }
  //   else if (type === "newest") {

  //     const newestDate = Math.max(...sorted.map((item) => new Date(item.updated_at)));
  //     filtered = sorted.filter((item) => new Date(item.updated_at).getTime() === newestDate);
  //   }

  //   setFetchfilteproduct({ ...fetchfilteproduct, data: filtered });
  // };

  const isGrocerySelected = selectedCategories.includes(42);

  return (
    <>
      <Header />
      <div className="body_bgcolor">
        <div className="py-3 container">
          <div className="dropdown py-3 text-end">
            <button
              type="button"
              className="btn btn-secondary px-4 dropdown-toggle"
              data-bs-toggle="dropdown"
            >
              Sort By
            </button>

            <ul className="dropdown-menu">
              <li>
                <button
                  className="dropdown-item"
                  onClick={() => handleSort("lowtohigh")}
                >
                  Price: Low to High
                </button>
              </li>
              <li>
                <button
                  className="dropdown-item"
                  onClick={() => handleSort("hightolow")}
                >
                  Price: High to Low
                </button>
              </li>
              <li>
                <button
                  className="dropdown-item"
                  onClick={() => handleSort("newest")}
                >
                  Newest
                </button>
              </li>
            </ul>
          </div>

          <div className="row">
            <div className="col-12 col-lg-3">
              <div className="bg-white shadow p-4 rounded-3">
                <div className="mb-4">
                  <h5 className="pb-3 border-bottom">Categories</h5>
                  {fetchproductsFlter?.filters?.categories?.map((cat) => (
                    <div className="form-check" key={cat.id}>
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id={`cat-${cat.id}`}
                        onChange={() =>
                          handleSelect(cat.id, setSelectedCategories)
                        }
                        checked={selectedCategories?.includes(cat.id)}
                      />
                      <label
                        className="form-check-label px-2"
                        htmlFor={`cat-${cat.id}`}
                      >
                        {cat.title}
                      </label>
                    </div>
                  ))}
                </div>

                {/* PRICE RANGE */}
                <div className="mb-4">
                  <h5 className="pb-3 border-bottom">Price</h5>

                  <div className="pt-3">
                    <Slider
                      range
                      value={priceRange}
                      onChange={(value) => {
                        // Prevent negative or below-min
                        const fixed = [
                          Math.max(value[0], minPrice),
                          Math.max(value[1], minPrice),
                        ];
                        setPriceRange(fixed);
                      }}
                      className="w-100"
                      min={minPrice}
                      max={maxPrice}
                    />

                    {/* <Slider
                      range
                      value={priceRange}
                      onChange={(value) => setPriceRange(value)}
                      className="w-100"
                      min={fetchproductsFlter?.filters?.price_range?.min || 0}
                      max={
                        fetchproductsFlter?.filters?.price_range?.max || 10000
                      }
                    /> */}
                  </div>

                  <div className="d-flex align-items-center mt-3 justify-content-between">
                    <button className="btn btn-outline-secondary  w-25">
                      €{priceRange[0]}
                    </button>
                    <span className="fw-bold mx-2">to</span>
                    <button className="btn btn-outline-secondary px-3 w-25">
                      €{priceRange[1]}
                    </button>
                  </div>
                </div>

                {/* BRAND */}
                <div className="mb-4">
                  <h5 className="pb-2 border-bottom">Brand</h5>

                  {fetchproductsFlter?.filters?.brands
                    ?.slice(
                      0,
                      showAllBrands
                        ? fetchproductsFlter.filters.brands.length
                        : 6
                    ) // show 6 by default
                    .map((brand, idx) => (
                      <div className="form-check" key={idx}>
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id={`brand-${idx}`}
                          onChange={() =>
                            handleSelect(brand, setSelectedBrands)
                          }
                          checked={selectedBrands.includes(brand)}
                        />
                        <label
                          className="form-check-label px-2"
                          htmlFor={`brand-${idx}`}
                        >
                          {brand}
                        </label>
                      </div>
                    ))}

                  {/*  See More / Show Less button */}
                  {fetchproductsFlter?.filters?.brands?.length > 6 && (
                    <div className=" mt-2">
                      <Link
                        // href="#"
                        className="text-decoration-none"
                        onClick={(e) => {
                          e.preventDefault();
                          setShowAllBrands(!showAllBrands);
                        }}
                      >
                        {showAllBrands ? "Show Less" : "See More"}
                      </Link>
                    </div>
                  )}
                </div>

                {/* DISCOUNT */}
                <div className="mb-4">
                  <h5 className="pb-2 border-bottom">Discount</h5>
                  {fetchproductsFlter?.filters?.discounts
                    ?.slice(
                      0,
                      showAllDiscount
                        ? fetchproductsFlter.filters.discounts.length
                        : 6
                    )
                    .map((discount, idx) => (
                      <div className="form-check" key={idx}>
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id={`discount-${idx}`}
                          onChange={() =>
                            handleSelect(discount, setSelectedDiscounts)
                          }
                          checked={selectedDiscounts.includes(discount)}
                        />
                        <label
                          className="form-check-label px-2"
                          htmlFor={`discount-${idx}`}
                        >
                          {discount}% Off or more
                        </label>
                      </div>
                    ))}
                  {fetchproductsFlter?.filters?.discounts?.length > 6 && (
                    <div className=" mt-2">
                      <Link
                        // href="#"
                        className="text-decoration-none"
                        onClick={(e) => {
                          e.preventDefault();
                          setShowAllDiscount(!showAllDiscount);
                        }}
                      >
                        {showAllDiscount ? "Show Less" : "See More"}
                      </Link>
                    </div>
                  )}
                </div>

                {/* SIZE */}
                <div className="mb-4">
                  <h5 className="pb-2 border-bottom">Size</h5>
                  {fetchproductsFlter?.filters?.sizes?.map((sz, idx) => (
                    <div className="form-check" key={idx}>
                      <input
                        className="form-check-input"
                        type="checkbox"
                        id={`size-${idx}`}
                        onChange={() => handleSelect(sz, setSelectedSizes)}
                        checked={selectedSizes.includes(sz)}
                      />
                      <label
                        className="form-check-label px-2"
                        htmlFor={`size-${idx}`}
                      >
                        {sz}
                      </label>
                    </div>
                  ))}
                </div>

                {/* COLOR */}
                {isGrocerySelected && (
                  <div className="mb-4">
                    <h5 className="pb-2 border-bottom">Color</h5>
                    <div className="d-flex flex-wrap gap-2">
                      {fetchproductsFlter?.filters?.colors?.map((clr, idx) => (
                        <div
                          key={idx}
                          className={`border rounded-circle ${
                            selectedColors.includes(clr)
                              ? "border-dark border-3"
                              : ""
                          }`}
                          style={{
                            width: "25px",
                            height: "25px",
                            backgroundColor: clr,
                            cursor: "pointer",
                          }}
                          onClick={() => handleSelect(clr, setSelectedColors)}
                        ></div>
                      ))}
                    </div>
                  </div>
                )}
                {/* Weights */}
                <div className="mb-4">
                  <h5 className="pb-3 border-bottom">Weight</h5>
                  {fetchproductsFlter?.filters?.weights
                    ?.filter((w) => w && w !== "null")
                    ?.slice(0, 8)
                    ?.slice(
                      0,
                      showAllweight
                        ? fetchproductsFlter?.filters?.weights?.length
                        : 6
                    )
                    .map((w, idx) => (
                      <div className="form-check" key={idx}>
                        <input
                          className="form-check-input"
                          type="checkbox"
                          id={`weight-${idx}`}
                          name="weight"
                          value={w}
                        />
                        <label
                          className="form-check-label px-2"
                          htmlFor={`weight-${idx}`}
                        >
                          {w} g / kg
                        </label>
                      </div>
                    ))}

                  {fetchproductsFlter?.filters?.weights?.length > 6 && (
                    <div className=" mt-2">
                      <Link
                        href="#"
                        className="text-decoration-none"
                        onClick={(e) => {
                          e.preventDefault();
                          setShowAllweight(!showAllweight);
                        }}
                      >
                        {showAllweight ? "Show Less" : "See More"}
                      </Link>
                    </div>
                  )}
                </div>

                {/* APPLY BUTTON */}
                <div className="text-center">
                  <button
                    className="btn btn-success w-100 rounded-4 fw-semibold"
                    onClick={filterproducts}
                  >
                    Filters
                  </button>
                </div>
              </div>
            </div>
            <div className="col-12 col-md-9">
              <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 ">
                {fetchfilteproduct?.data?.length > 0 ? (
                  fetchfilteproduct?.data?.map((item) => (
                    <div className="col mb-4" key={item.id}>
                      <div className="card h-100 w-100 px-1 product-card py-1 rounded position-relative">
                        {/* <img src={fryingpan} alt="Titanium Steel Pot Set" className="img-fluid pt-5" onClick={()=>navigate('/cart')}/> */}
                        <img
                          src={`${img_path}/products/${item.image}`}
                          alt={item.product_name}
                          className="img-fluid "
                          onClick={() => editcategorypreview(item.id)}
                        />
                        {token &&
                        favoriteData?.some(
                          (favorite) => favorite?.id === item?.id
                        ) ? (
                          <FaHeart
                            size={20}
                            className="position-absolute text-danger"
                            style={{
                              top: "15px",
                              left: "15px",
                              cursor: "pointer",
                            }}
                            // onClick={() => handlewishlist(productitem)}
                            onClick={() => handleProductConfirmDelete(item?.id)}
                          />
                        ) : (
                          <>
                            <CiHeart
                              size={24}
                              className="position-absolute text-danger"
                              style={{
                                top: "15px",
                                left: "15px",
                                cursor: "pointer",
                              }}
                              onClick={() => handlewishlist(item)}
                            />
                          </>
                        )}
                        {/* <CiHeart
                          size={25}
                          className="heart_color position-absolute"
                          onClick={() => {
                            handlewishlist(item);
                            handleWishlistCount();
                          }}
                          style={{ top: "15px", left: "20px" }}
                        /> */}
                        <span
                          className="position-absolute px-2 padge"
                          style={{ top: "15px", right: "20px" }}
                        >
                          {item.discount}%
                        </span>
                        <h6 className="fw-bold ps-2 pt-2 cardfamily">
                          {item.product_name}
                        </h6>
                        <div className=" py-2 px-2">
                          <span>
                            {item.weight}
                            {item.attribute_type}
                          </span>
                        </div>
                        <span className="small ps-2 pt-1">Ratings</span>
                        <div className="d-flex justify-content-between align-items-center ps-2 py-1">
                          <div>
                            <span className="fw-bold fs-5 me-2">4.5</span>
                            <FaStar color="#ff9d00" />
                            {/* <FaStar color="#ff9d00" />
                            <FaStar color="#ff9d00" />
                            <FaStar color="#ff9d00" />
                            <FaStarHalfAlt color="#ff9d00" /> */}
                          </div>
                          <button className="btn btn-success btn-sm px-2 p-0 me-2">
                            Stock In
                          </button>
                        </div>
                        <div className="d-flex justify-content-between align-items-center ps-2 py-1">
                          <div>
                            <span className="cart_color fw-bold fs-5 me-2">
                              {" "}
                              {item.price}€
                            </span>
                            <span className="text-muted">
                              <s>{item.mrp}€</s>
                            </span>
                          </div>
                          <button
                            className="btn btn-dark btn-sm px-2 p-0 me-2"
                            onClick={() => {
                              if (!token) {
                                navigate("/signin");
                              } else {
                                handleAddToCartproduct(item);
                                handleAddToCartCount();
                              }
                            }}
                          >
                            Add
                            <BiSolidCartAdd size={22} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center text-muted">
                    No products available
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default Product;
