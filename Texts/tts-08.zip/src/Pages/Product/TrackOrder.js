import React, { useEffect, useState, useCallback } from "react";
import Footer from "../../Component/Footer/Footer";
import Header from "../../Component/Header/Header";
import cooker from "../../Assets/COMFORT P C 5 1.png";
import { FaAngleRight } from "react-icons/fa6";
import "./trackorder.css";
import { TbNotes } from "react-icons/tb";
import { PiNotepadBold } from "react-icons/pi";

import maggie from "../../Assets/aajao Maggie Khalo mitroo🤣👍 1.png";
import { useLocation, useNavigate } from "react-router-dom";
import { Button, ConfigProvider, Spin, Steps } from "antd";
import axios from "axios";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";
import Common from "../../common/Common";
import { AiOutlineLeft } from "react-icons/ai";

const TrackOrder = () => {
  // const location = useLocation();
  const { token, orderTrackId } = Common();
  // const { id } = location.state || {};
  // console.log("state_data", id);
  const [orderData, setOrderData] = useState();
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const fetchTrackOrder = useCallback(async () => {
    setLoading(true);
    try {
      const response = await axios.get(
        `${base_url}/view/order/${orderTrackId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      console.log("fetchTrackOrder", response);
      setOrderData(response?.data);
    } catch (error) {
      console.log("error", error);
    } finally {
      setLoading(false);
    }
  }, [orderTrackId, token]);

  console.log("orderData", orderData);
  console.log("order no", orderData?.order?.order_no);
  useEffect(() => {
    if (orderTrackId && token) {
      fetchTrackOrder();
    }
  }, [orderTrackId, token, fetchTrackOrder]);

  const items = [
    {
      label: "Order Placed",
      status: "order_placed",
    },
    {
      label: "Processing",
      status: "Processing",
    },
    {
      label: "Packed",
      status: "Picked Up",
    },
    {
      label: "Shipped",
      status: "Shipped",
    },
    {
      label: "Delivery",
      status: "delivery",
    },
  ];
  const cancelItem = [
    {
      label: "Order Placed",
      status: "order_placed",
    },
    {
      label: "Processing",
      status: "Processing",
    },
    {
      label: "Packed",
      status: "Picked Up",
    },
    {
      label: "Shipped",
      status: "Shipped",
    },
    {
      label: "Cancelled",
      status: "Cancelled",
    },
  ];
  const readyForPickupItem = [
    {
      label: "Order Placed",
      status: "order_placed",
    },
    {
      label: "Processing",
      status: "Processing",
    },
    {
      label: "Packed",
      status: "Picked Up",
    },
    {
      label: "Ready for Pickup",
      status: "Ready for Pickup",
    },
    {
      label: "Delivery",
      status: "delivery",
    },
  ];

  const stepItems = items.map((item) => ({
    title: item.label,
    description: item.date,
  }));

  const cancelStep = cancelItem.map((item) => ({
    title: item.label,
    description: item.date,
  }));

  const readyForPickupStep = readyForPickupItem.map((item) => ({
    title: item.label,
    description: item.date,
  }));

  const steps = ["Order Placed", "Processing", "Packed", "Shipped", "Delivery"];
  return (
    <>
      <Header />
      <div className="body_bgcolor">
        <div className="container py-4">
          <div className="d-flex align-items-center gap-3 pb-3">
            <button
              className="back-btn d-flex align-items-center justify-content-center"
              onClick={() => navigate("/myorders")}
            >
              <AiOutlineLeft />
            </button>

            <h4 className="m-0 fw-bold text-dark">Track Order</h4>
          </div>
          {/* <div className="d-flex gap-3">
            <Button
              className="back_arrow_btn"
              icon={<AiOutlineLeft className="back_arrow_btn" />}
            />
            <h4 className="fw-bold pb-3">Track Order</h4>
          </div> */}
          {loading ? (
            <>
              <div className="d-flex align-items-center justify-content-center h-100">
                <Spin />
              </div>
            </>
          ) : (
            <>
              <div className="row">
                <div className="col-12  col-lg-8">
                  <div className="bg-white p-2 px-3">
                    <div className="d-flex pt-2 justify-content-between mb-3">
                      <div>
                        <h6 className="fw-bold m-0">Delivered Status</h6>
                        <span className="m-0 order_id">
                          #{orderData?.order?.order_no}
                        </span>
                      </div>
                      <div>
                        <span class="badge badge_text bg-success p-2">
                          {orderData?.order?.status}
                        </span>
                      </div>
                    </div>
                    <div className="steps_full_width">
                      <ConfigProvider
                        theme={{
                          components: {
                            Steps: {
                              dotSize: 12,
                              iconSize: 12,
                              colorPrimary: "#ff0000",
                              colorSplit: "#ff0000",
                              lineHeight: 8,
                            },
                          },
                        }}
                      >
                        {orderData?.order?.status === "Cancelled" && (
                          <Steps
                            type="dot"
                            size="default"
                            current={cancelItem?.findIndex(
                              (item) => item.status === orderData?.order?.status
                            )}
                            items={cancelStep}
                            status={
                              orderData?.order?.status === "Cancelled"
                                ? "error"
                                : ""
                            }
                          />
                        )}
                        {orderData?.order?.status !== "Cancelled" &&
                          orderData?.order?.status !== "Ready for Pickup" && (
                            <Steps
                              type="dot"
                              size="default"
                              current={items?.findIndex(
                                (item) =>
                                  item.status === orderData?.order?.status
                              )}
                              items={stepItems}
                            />
                          )}
                        {orderData?.order?.status === "Ready for Pickup" && (
                          <Steps
                            type="dot"
                            size="default"
                            current={readyForPickupItem?.findIndex(
                              (item) => item.status === orderData?.order.status
                            )}
                            items={readyForPickupStep}
                          />
                        )}
                      </ConfigProvider>
                    </div>

                    <div className="border-bottom-dashed py-3 opacity-75"></div>
                    <p className="pt-3 fw-semibold">
                      {orderData?.items?.length} Items in Order
                    </p>
                    {orderData?.items?.map((item) => (
                      <React.Fragment key={item.id}>
                        <div className="row align-items-center  mt-3 ">
                          <div className="col-md-3">
                            <div className="border p-2 d-flex justify-content-center">
                              <img
                                src={`${img_path}/products/${item?.image}`}
                                alt="Cooker"
                                className="img-fluid"
                              />
                            </div>
                          </div>

                          <div className="col-md-7 cardfamily track_product_text">
                            <h5 className=""> {item?.product_name}</h5>

                            <p className="fw-semibold mb-1 cardfamily track_product_text">
                              Material Type:
                              <span className="fw-normal ms-1 track_product_value">
                                {item?.material_type || "N/A"}
                              </span>
                            </p>
                            <p className="fw-semibold mb-1 cardfamily track_product_text">
                              Seller:
                              <span className="fw-normal ms-1 track_product_value">
                                {item?.seller || "N/A"}
                              </span>
                            </p>
                            <p className="fw-semibold mb-1 cardfamily track_product_text">
                              Size:
                              <span className="fw-normal ms-1 track_product_value">
                                {item.attribute || "N/A"}
                              </span>
                            </p>
                          </div>

                          <div className="col-md-2  cardfamily  d-flex gap-2 gap-md-0 flex-row align-items-center flex-md-column">
                            <div className="">
                              <span className=" fw-semibold fs-5 ">
                                {item?.price}€
                              </span>
                            </div>
                            <div className="text-muted opacity-75 fs-6 fw-semibold">
                              {item?.mrp}€
                            </div>
                          </div>
                        </div>
                      </React.Fragment>
                    ))}

                    {/* <div className="row align-items-center pt-4">
                      <div className="col-md-3">
                        <div className="border p-3">
                          <img
                            src={maggie}
                            alt="Cooker"
                            className="img-fluid ms-5"
                          />
                        </div>
                      </div>

                      <div className="col-md-6 cardfamily">
                        <h5>Maggi Masala Instant Noodles 560G </h5>

                        <p className="fw-semibold mb-1 cardfamily">
                          Weight:
                          <span className="fw-normal ms-1">560G</span>
                        </p>
                        <p className="fw-semibold mb-1 cardfamily">
                          Seller:
                          <span className="fw-normal ms-1">SHRENIK1991</span>
                        </p>
                        <p className="fw-semibold mb-1 cardfamily">
                          Size:
                          <span className="fw-normal ms-1">12 Liters</span>
                        </p>
                      </div>

                      <div className="col-md-3 px-5 cardfamily">
                        <div className="pt-2">
                          <span className=" fw-semibold fs-5 me-2">7,50€</span>
                          <span className="text-muted opacity-75 fs-6 fw-semibold">
                            <s>1,80€</s>
                          </span>
                        </div>
                      </div>
                    </div> */}
                  </div>
                </div>

                <div className="col-12 col-lg-4">
                  <div className="invoice-btn d-flex align-items-center justify-content-between border rounded p-2 mt-1">
                    <div className="d-flex gap-2 align-items-center">
                      <TbNotes size={20} className="cart_color" />
                      <span className="invoice-text  text-center cart_color">
                        Download Invoice
                      </span>
                    </div>
                    <FaAngleRight className="cart_color justify-content-end" />
                  </div>

                  <div className="bg-white p-4 rounded ibm_family shadow-sm mt-2">
                    <h5 className="fw-bold mb-4 ">Order Details</h5>

                    <h6 className="mb-1 fw-semibold">Order ID</h6>
                    <span className="d-block mb-3 text-muted">
                      #order000101
                    </span>

                    <h6 className="mb-1 fw-semibold">Receiver Details</h6>
                    <span className="d-block mb-3 text-muted">
                      Sam S, +69 1234 5678
                    </span>

                    <h6 className="mb-1 fw-semibold">Delivery Address</h6>
                    <p className="mb-3  text-muted">
                      TTS-Brothers GmbH &amp; Co. KG <br />
                      Asien Supermarkt in Dortmund, Textiles &amp; Food <br />
                      Items, Retail &amp; Wholesale, Rheinischestr.52, Dortmund
                      44137
                    </p>

                    <h6 className="mb-1 fw-semibold">Order Placed</h6>
                    <span className="d-block mb-3 text-muted">29 Mar 2025</span>

                    <h6 className="mb-1">Order Arrived At</h6>
                  </div>
                  <div className="bg-white mt-2 p-3 rounded shadow-sm">
                    <div className="d-flex align-items-center mb-3 ibm_family">
                      <PiNotepadBold size={20} className="me-2" />
                      <h5 className="mb-0">Bill Summary</h5>
                    </div>

                    <div className="d-flex justify-content-between mb-2">
                      <span>Item Total & GST</span>
                      <span>
                        <s className="text-muted me-2">1,80€</s>{" "}
                        <strong>1,25€</strong>
                      </span>
                    </div>

                    <div className="d-flex justify-content-between mb-2">
                      <span>Delivery Fee</span>
                      <span>
                        <s className="text-muted me-2">15€</s>{" "}
                        <strong>10€</strong>
                      </span>
                    </div>

                    <div className="d-flex justify-content-between align-items-start pt-2 mt-2">
                      <div>
                        <span className="fw-semibold">Total Bill</span>
                        <p
                          className="mb-0 text-muted"
                          style={{ fontSize: "0.85rem" }}
                        >
                          Inc all taxes and charges
                        </p>
                      </div>
                      <div>
                        <s className="text-muted me-2">1,500€</s>
                        <span className="fw-bold text-danger fs-5">
                          10,000€
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default TrackOrder;
