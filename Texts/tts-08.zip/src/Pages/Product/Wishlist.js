import React, { useEffect, useState } from "react";
import Header from "../../Component/Header/Header";
import Footer from "../../Component/Footer/Footer";
import basmatirice from "../../Assets/fd71f6518b357678996c850b48023ed9 1.png";
import { RiDeleteBinLine } from "react-icons/ri";
import { CiHeart } from "react-icons/ci";
import chilies from "../../Assets/b20dcdf09492f0bab646945e76aada78 1.png";
import potatoes from "../../Assets/60b5c96d36124d2d2b58a8351e37b6e4 1.png";
import tomatoes from "../../Assets/2ddfc9f8af3d3af4a82a949b80bd2486 1.png";
import onion from "../../Assets/b08f48585f510825bebbe1a9acdbc725 1.png";
import { BiSolidCartAdd } from "react-icons/bi";

import { FaStarHalfAlt } from "react-icons/fa";

import { FaHeart } from "react-icons/fa6";
import { FaStar } from "react-icons/fa";
import axios from "axios";
import { base_url, img_path } from "../../BaseUrls/BaseUrl";
import Toast from "../../Untils/Toast";
import { useNavigate } from "react-router-dom";
import Toastify from "../../Untils/Toastify";
import UpdateFilterData from "../../service/ApiService";
import Common from "../../common/Common";
import { removeFavorite, setFavoriteData } from "../../store/favoriteSlice";

const Wishlist = () => {
  const navigate = useNavigate();
  const { showAddToCartToast } = Toastify();

  const [fetchwishlists, setFetchwishlists] = useState([]);
  console.log("fetchwishlists", fetchwishlists);

  const { Update } = UpdateFilterData();

  const user_id = localStorage.getItem("user_id");

  const fetchwishlist = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in to view your cart.", type: "warning" });
        return;
      }

      const response = await axios.get(`${base_url}/wishlist`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          // "tts-user": user_id,
        },
      });
      dispatch(setFavoriteData(response.data));
      setFetchwishlists(response.data);
      console.log("response.data", response.data);
    } catch (error) {}
  };

  useEffect(() => {
    fetchwishlist();
  }, []);

  const handleAddToCartproduct = async (item) => {
    try {
      const token = localStorage.getItem("token");

      // if (!token) {
      //   Toast({ message: "Please log in to add products to your cart.", type: "warning" });
      //   return;
      // }

      const values = {
        user_id: user_id,
        product_id: item.id,

        quantity: 1,
      };

      const response = await axios.post(`${base_url}/cart`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      await Update("cart");
      showAddToCartToast();

      // navigate('/addtocart')
    } catch (error) {}
  };

  const handlewishlistcart = async (item) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        navigate("/signin");
        // Toast({ message: "Please log in to add products to your cart.", type: "warning" });
        return;
      }

      const values = {
        user_id: user_id,
        product_id: item.id,
      };

      const response = await axios.post(`${base_url}/wishlist`, values, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      fetchwishlist();
      console.log("response.data", response.data);
    } catch (error) {}
  };

  const handleConfirmDelete = async (id) => {
    console.log("id", id);
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(`${base_url}/wishlist/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });
      dispatch(removeFavorite(id));
      fetchwishlist();
    } catch (error) {}
  };

  const editcategorypreview = (categoryId) => {
    console.log("categoryIdhhhhh", categoryId);
    navigate("/cart", { state: { categoryId } });
  };

  const [fetchOurrecomment, setFetchOurrecomment] = useState([]);
  const fetchrecommendation = async () => {
    try {
      const token = localStorage.getItem("token");

      const response = await axios.get(`${base_url}/you-may-like/products`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });
      console.log("dispatch", response.data);
      setFetchOurrecomment(response.data?.data);
    } catch (error) {}
  };
  const { token, favoriteData, dispatch } = Common();

  useEffect(() => {
    fetchrecommendation();
  }, []);

  const handleProductConfirmDelete = async (id) => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // Toast({ message: "Please log in first.", type: "warning" });
        return;
      }
      const response = await axios.delete(`${base_url}/wishlist/${id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "tts-user-id": user_id,
        },
      });
      dispatch(removeFavorite(id));
      fetchwishlist();

      console.log("response", response);
    } catch (error) {
      console.log("error", error);
    }
  };

  return (
    <>
      <Header />
      <div className="body_bgcolor">
        <div className="container py-4">
          <h4 className="pb-3 fw-bold cardfamily"> My Wishlist</h4>
          <div className="bg-white">
            <h5 className="p-3 cardfamily fw-semibold">
              Your favorited products
            </h5>
            <hr />

            <div>
              {fetchwishlists?.length > 0 ? (
                fetchwishlists.map((item) => (
                  <div
                    className="row align-items-center border-bottom rounded-3 p-3 mb-3"
                    key={item.id}
                  >
                    {/* Product Image & Info */}
                    <div
                      className="col-12 col-sm-4 col-md-4 col-lg-4 col-xl-4 d-flex align-items-center"
                      onClick={() => editcategorypreview(item.id)}
                    >
                      <div className="position-relative me-3 border p-3">
                        <img
                          src={`${img_path}/products/${item.image}`}
                          alt={item.product_name}
                          className="img-fluid rounded"
                          style={{
                            width: "120px",
                            height: "120px",
                            objectFit: "contain",
                          }}
                        />

                        {/* Wishlist Heart */}
                        <FaHeart
                          size={18}
                          className="heart_color position-absolute"
                          style={{ top: "5px", left: "-1px" }}
                        />

                        {/* Discount Badge */}
                        <span
                          className="position-absolute badge bg-dark small p-1"
                          style={{ top: "5px", right: "-5px" }}
                        >
                          {item.discount}%
                        </span>
                      </div>

                      <div>
                        <h6 className="mb-1 cardfamily">{item.product_name}</h6>
                        <p className="mb-1 text-muted small">(1 kg)</p>

                        <div className="d-flex align-items-center">
                          <FaStar color="#ff9d00" />
                          <span className="fw-bold fs-6 ms-1">4.5</span>
                        </div>

                        <div className="mt-2">
                          <span className="cart_color fw-bold fs-5 me-2">
                            {item.price}€
                          </span>
                          <span className="text-muted">
                            <s>{item.mrp}€</s>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Stock Info */}
                    <div className="col-6 col-md-2 col-lg-2 col-xl-2 col-sm-2 text-center mt-3 mt-md-0">
                      <button className="btn btn-success btn-sm px-3">
                        Stock In
                      </button>
                    </div>

                    {/* Remove Button */}
                    <div className="col-6 col-md-3  col-lg-3 col-xl-3 col-sm-3 text-center mt-3 mt-md-0">
                      <div
                        className="border p-2 d-inline-flex align-items-center justify-content-center gap-2 rounded-3"
                        style={{ cursor: "pointer" }}
                        onClick={() => handleConfirmDelete(item.id)}
                      >
                        <RiDeleteBinLine size={20} className="cart_color" />
                        <span className="fw-semibold cardfamily">Remove</span>
                      </div>
                    </div>

                    {/* Add To Cart */}
                    <div className="col-6  col-md-3 col-lg-3 col-xl-3 col-sm-3 text-center text-md-center mt-3 mt-md-0">
                      <button
                        className="btn btn-dark px-3 py-2"
                        onClick={() => {
                          handleAddToCartproduct(item);
                        }}
                      >
                        Add
                        <BiSolidCartAdd size={22} />
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted py-5">
                  No products available
                </div>
              )}
            </div>
          </div>

          <div className="bg-white  mt-5">
            <h4 className="cardfamily fw-semibold pt-3 px-3">
              Our Recommendations
            </h4>

            {/* <div className="row row-cols-2 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 row-cols-xl-5  py-5 px-3">
              {fetchOurrecomment?.length > 0 ? (
                fetchOurrecomment.map((items) => (
                  <div className="col mb-4" key={items.id}>
                    <div className="card h-100 w-100 px-1 product-card py-1 rounded position-relative">
                      <img
                        src={`${img_path}/products/${items.image}`}
                        alt={items.product_name}
                        className="img-fluid"
                        onClick={() => editcategorypreview(items.id)}
                      />
                      {token &&
                      favoriteData?.some(
                        (favorite) => favorite?.id === items?.id
                      ) ? (
                        <FaHeart
                          size={20}
                          className="position-absolute text-danger"
                          style={{
                            top: "15px",
                            left: "15px",
                            cursor: "pointer",
                          }}
                         
                          onClick={() => handleProductConfirmDelete(items?.id)}
                        />
                      ) : (
                        <>
                          <CiHeart
                            size={24}
                            className="position-absolute text-danger"
                            style={{
                              top: "15px",
                              left: "15px",
                              cursor: "pointer",
                            }}
                            onClick={() => handlewishlistcart(items)}
                          />
                        </>
                      )}
                     
                      <h6 className="fw-bold ps-2 pt-2">
                        {items.product_name}
                      </h6>

                      <div className="d-flex justify-content-between py-2 px-2">
                        <span>
                          {items.weight}
                          {items.attribute_type}
                        </span>
                        <span>
                          <FaStar color="#FF9D00" /> 4.5
                        </span>
                      </div>

                    
                         <div className="d-flex flex-column flex-sm-row align-items-start align-items-sm-center">
                           <span className="cart_color fw-bold fs-6 fs-sm-5 me-sm-2">
                            {items.price}€
                          </span>
                          <span className="text-muted">
                            <s>{items.mrp}€</s>
                          </span>
                    
                        <button
                       
                           className="btn btn-dark px-2 px-sm-3 px-md-3 py-1 py-sm-2 fw-semibold d-flex align-items-center gap-1"
                          onClick={() => {
                            handleAddToCartproduct(items);
                          }}
                        >
                          Add
                          <BiSolidCartAdd size={22} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center text-muted">
                  No products available
                </div>
              )}
            </div> */}

              <div className="row row-cols-1 row-cols-sm-2 row-cols-md-2 row-cols-lg-3  row-cols-xl-5 ">
                          {fetchOurrecomment?.length > 0 ? (
                            fetchOurrecomment.map((items) => (
                              <div className="col mb-4" key={items.id}>
                                <div className="card h-100 w-100 px-1 product-card py-1 rounded position-relative">
                                  <img
                                    src={`${img_path}/products/${items.image}`}
                                    alt={items.product_name}
                                    className="img-fluid"
                                    onClick={() => editcategorypreview(items.id)}
                                  />
                                  {token &&
                                  favoriteData?.some(
                                    (favorite) => favorite?.id === items?.id
                                  ) ? (
                                    <FaHeart
                                      size={20}
                                      className="position-absolute text-danger"
                                      style={{
                                        top: "15px",
                                        left: "15px",
                                        cursor: "pointer",
                                      }}
                                      // onClick={() => handlewishlist(productitem)}
                                      onClick={() => handleProductConfirmDelete(items?.id)}
                                    />
                                  ) : (
                                    <>
                                      <CiHeart
                                        size={24}
                                        className="position-absolute text-danger"
                                        style={{
                                          top: "15px",
                                          left: "15px",
                                          cursor: "pointer",
                                        }}
                                        onClick={() => handlewishlistcart(items)}
                                      />
                                    </>
                                  )}
                                  {/* <CiHeart
                                    size={25}
                                    className="heart_color position-absolute"
                                    onClick={() => {
                                      handlewishlistOurpro(items);
                                      // handleWishlistCount();
                                    }}
                                    style={{ top: "25px", left: "20px" }}
                                  /> */}
            
                                  <h6 className="fw-bold ps-2 pt-2">
                                    {/* {items.product_name} */}
                                     {" "}
              {items?.product_name?.length > 16
                ? items.product_name.slice(0, 16) + "..."
                : items.product_name}
                                  </h6>
            
                                  <div className="d-flex justify-content-between py-2 px-2">
                                    <span>
                                      {items.weight}
                                      {items.attribute_type}
                                    </span>
                                    <span>
                                      <FaStar color="#FF9D00" /> 4.5
                                    </span>
                                  </div>
            
                                  <div className="d-flex justify-content-between align-items-center ps-2 py-1">
                                    <div>
                                      <span className="cart_color fw-bold fs-5 me-2">
                                        {items.price}€
                                      </span>
                                      <span className="text-muted">
                                        <s>{items.mrp}€</s>
                                      </span>
                                    </div>
                                    <button
                                      className="btn btn-dark btn-sm me-2"
                                      onClick={() => {
                                        handleAddToCartproduct(items);
                                        // handleAddToCartCount();
                                      }}
                                    >
                                      Add
                                      <BiSolidCartAdd size={22} />
                                    </button>
                                  </div>
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="text-center text-muted">
                              No products available
                            </div>
                          )}
               </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Wishlist;
