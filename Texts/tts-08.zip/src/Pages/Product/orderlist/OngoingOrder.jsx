import { ConfigProvider, Tag } from "antd";
import React from "react";
import { FaRegCircleCheck } from "react-icons/fa6";
import basmatirice from "../../../Assets/fd71f6518b357678996c850b48023ed9 1.png";
import basmati from "../../../Assets/61ded8e828f0693eba9198b9ba78f727 1.png";
import sampamati from "../../../Assets/fc63c555bde41112fe8e00cd232f343b 1.png";
import onion from "../../../Assets/b08f48585f510825bebbe1a9acdbc725 1.png";
import { Steps } from "antd";
import dayjs from "dayjs";
import Common from "../../../common/Common";
import { setOrderTrackId } from "../../../store/cartSlice";
const OngoingOrder = ({ order }) => {
  //   const currentIndex = item?.findIndex((item) => item.status === currentStatus);
  const { dispatch, navigate } = Common();
  // Step structure
  const item = [
    {
      label: "Order Placed",
      status: "order_placed",
    },
    {
      label: "Processing",
      status: "processing",
    },
    {
      label: "Packed",
      status: "Picked Up",
    },
    {
      label: "Shipped",
      status: "Shipped",
    },
    {
      label: "Delivery",
      status: "delivery",
    },
  ];
  const stepItems = item.map((item) => ({
    title: item.label,
    description: item.date,
  }));
  const handleClick = (id) => {
    if (!id) {
      return;
    } else {
      dispatch(setOrderTrackId(id));
      navigate("/trackorder", { state: { id } });
    }
  };
  return (
    <>
      <div className="d-flex flex-column gap-3">
        {order?.map((order) => (
          <div
            className="bg-white p-3 md:p-3"
            style={{ cursor: "pointer" }}
            onClick={() => handleClick(order?.id)}
          >
            <div className="d-flex flex-column flex-md-row align-items-center justify-content-center gap-3">
              <div className="col-12 col-md-2 col-lg-2">
                <Tag
                  key={order?.status}
                  color={`${
                    order.delivery_type === "pickup" ? "lime" : "orange"
                  }`}
                >
                  {order?.delivery_type}
                </Tag>
                <div className="d-flex p-md-3 justify-content-center">
                  <div className="d-flex border rounded p-2 h-100 ms-3">
                    <img
                      src={basmatirice}
                      alt="basmatirice"
                      className="img-fluid"
                      style={{
                        width: "80px",
                        height: "80px",
                        objectFit: "contain",
                      }}
                    />
                  </div>
                  {/* <div className="d-flex border rounded p-2 h-100 ms-3">
                    <img
                      src={sampamati}
                      alt="basmatirice"
                      className="img-fluid"
                      style={{
                        width: "80px",
                        height: "80px",
                        objectFit: "contain",
                      }}
                    />
                  </div>
                  <div className="d-flex border rounded p-2 h-100 ms-3">
                    <img
                      src={basmati}
                      alt="basmatirice"
                      className="img-fluid"
                      style={{
                        width: "80px",
                        height: "80px",
                        objectFit: "contain",
                      }}
                    />
                  </div>
                  <div className="d-flex border rounded p-2 h-100 ms-3">
                    <img
                      src={onion}
                      alt="basmatirice"
                      className="img-fluid"
                      style={{
                        width: "80px",
                        height: "80px",
                        objectFit: "contain",
                      }}
                    />
                  </div> */}
                </div>
              </div>
              <div className="col-12 col-md-10 col-lg-10">
                <div className="steps_full_width">
                  <ConfigProvider
                    theme={{
                      components: {
                        Steps: {
                          dotSize: 12,
                          iconSize: 12,
                          colorPrimary: "#ff0000",
                          colorSplit: "#ff0000",
                          lineHeight: 8,
                        },
                      },
                    }}
                  >
                    <Steps
                      current={item?.findIndex(
                        (item) => item.status === order.status
                      )}
                      type="dot"
                      size="default"
                      items={item?.map((item) => ({
                        title: item?.label,
                        content: (
                          <div className="fw-small">
                            {dayjs(
                              order?.updated_at,
                              "YYYY-MM-DD HH:mm:ss"
                            ).format("DD-MM-YY")}
                          </div>
                        ),
                      }))}
                      // items={stepItems}
                    />
                  </ConfigProvider>
                </div>
                <div className="row align-items-center">
                  <div className="col-6 col-md-2 col-lg-4">
                    <h6 className="fw-semibold m-0 fs-13 my_order_content_head">
                      Prices
                    </h6>
                    <span className="cart_color fw-medium fs-4 me-2 cardfamily my_order_content_value">
                      {order?.total_amount}€
                    </span>
                  </div>
                  <div className="col-6 col-md-4 col-lg-4">
                    <h6 className="fw-semibold fs-13 m-0 my_order_content_head">
                      ORDER ID :{" "}
                    </h6>
                    <span className="fw-medium my_order_content_value">
                      {order?.order_no}
                    </span>
                  </div>

                  <div className="col-12 col-md-6 col-lg-4 order_status_row ">
                    <FaRegCircleCheck className="order_status_icon" />

                    <div>
                      <h3 className="order_status_title">
                        Order at Processing
                      </h3>
                      <p className="order_status_sub">
                        Placed at{" "}
                        {dayjs(order?.updated_at).format(
                          "Do MMMM YYYY, hh:mma"
                        )}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default OngoingOrder;
