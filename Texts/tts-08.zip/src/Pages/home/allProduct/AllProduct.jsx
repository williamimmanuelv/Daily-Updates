import React from 'react'

const AllProduct = () => {
  
  const ourproductTemplate = (item) => {
    if (!item) return null;
    console.log("item ourproductTemplate", item);
    const { token } = Common();
    return (
      <div className="ps-3">
        <div
          className="card shadow-sm position-relative h-100"
          style={{
            cursor: "pointer",
            minHeight: "330px",
            maxHeight: "340px",
            // minWidth: "140px",
            // minWidth: "140px",
          }}
        >
          <div
            className="d-flex justify-content-center  align-items-center bg-light"
            style={{
              height: "200px",
              width: "100%",
              overflow: "hidden",
              borderTopLeftRadius: "12px",
              borderTopRightRadius: "12px",
            }}
            onClick={() => editcategorypreview(item.id)}
          >
            <img
              src={`${img_path}/products/${item.image}`}
              alt={item.product_name}
              className="img-fluid"
              style={{
                height: "100%",
                width: "100%",
                objectFit: "contain",
                padding: "10px",
              }}
            />
          </div>

          {token &&
          favoriteData?.some((favorite) => favorite?.id === item?.id) ? (
            <FaHeart
              size={20}
              className="position-absolute text-danger"
              style={{ top: "15px", left: "15px", cursor: "pointer" }}
              // onClick={() => handlewishlist(productitem)}
              onClick={() => handleProductConfirmDelete(item?.id)}
            />
          ) : (
            <CiHeart
              size={24}
              className="position-absolute text-danger"
              style={{ top: "15px", left: "15px", cursor: "pointer" }}
              onClick={() => handlewishlistProduct(item)}
            />
          )}

          {/* Heart Icon
          {token && (
            <CiHeart
              size={24}
              className="position-absolute text-danger"
              onClick={() => {
                handlewishlistProduct(item);
                // handleWishlistCount();
              }}
              style={{ top: "15px", left: "15px" }}
            />
          )} */}
          {/* Product Info */}
          <div className="p-2">
            <h6
              className="fw-bold text-truncate mb-1 text-wrap"
              style={{ fontSize: "15px" }}
            >
              {item.product_name}
            </h6>

            <div className="d-flex justify-content-between align-items-center py-1">
              <span className="small text-muted">
                {item.weight}
                {item.attribute_type}
              </span>
              <span className="d-flex align-items-center">
                <FaStar color="#FF9D00" size={14} />{" "}
                <small className="ms-1 fw-semibold">4.5</small>
              </span>
            </div>

            <div className="d-flex justify-content-between align-items-center mt-2">
              <div>
                <span className="cart_color fs-6 fw-bold">{item.price}€</span>{" "}
                <small className="text-muted">
                  <s>{item.mrp}€</s>
                </small>
              </div>

              <button
                className="btn btn-dark btn-sm d-flex align-items-center"
                onClick={() => {
                  handleAddToCartproduct(item);
                  // handleAddToCartCount();
                }}
              >
                Add <BiSolidCartAdd size={18} className="ms-1" />
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };
  return (
  <div className=" py-4">
            <h3 className="text-center fw-semibold family_fraunces">
              Our Product
            </h3>
            <div className="row">
              <div className="d-flex flex-column flex-md-row py-2  ">
                {fetchcategorys.length > 0 && (
                  <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                    <div
                      className="card rounded position-relative"
                      style={{ width: "250px", height: "330px" }}
                    >
                      <img
                        src={`${img_path}/categories/${fetchcategorys[0].thumbnail}`}
                        alt={fetchcategorys[0].title}
                        className="img-fluid mt-5 mx-auto"
                        style={{ width: "214px", height: "214px" }}
                      />

                      <h5 className="fw-bold mb-2 text-center">
                        {fetchcategorys[0].title}
                      </h5>
                    </div>
                  </div>
                )}

                <div className="flex-grow-1 ps-0 ps-md-0">
                  <Carousel
                    value={vegetablesData}
                    numVisible={4}
                    numScroll={1}
                    responsiveOptions={ourresponsiveOption}
                    itemTemplate={ourproductTemplate}
                    // autoplayInterval={2000} // Optional
                  />
                </div>
              </div>
            </div>
            <div className="row">
              <div className="d-flex flex-column flex-md-row py-2">
                {/* Left static category card */}
                <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                  <div
                    className="card rounded position-relative"
                    style={{ width: "250px", height: "330px" }}
                  >
                    <img
                      src={Grocerys}
                      alt="Vege"
                      className="img-fluid mt-5 mx-auto"
                      style={{ width: "200px", height: "214px" }}
                    />
                    <h5 className="fw-bold text-center">Grocery</h5>
                  </div>
                </div>
                <div className="flex-grow-1 ps-0 ps-md-0">
                  <Carousel
                    value={GroceryData}
                    numVisible={4}
                    numScroll={1}
                    responsiveOptions={ourresponsiveOption}
                    itemTemplate={ourproductTemplate}
                    //   autoplayInterval={2000}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="d-flex flex-column flex-md-row py-2">
                {/* Left static category card */}
                <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                  <div
                    className="card rounded position-relative"
                    style={{ width: "250px", height: "330px" }}
                  >
                    <img
                      src={Vessel}
                      alt="Vege"
                      className="img-fluid mt-5 mx-auto"
                      style={{ width: "200px", height: "214px" }}
                    />
                    <h5 className="fw-bold text-center">Vessel</h5>
                  </div>
                </div>

                <div className="flex-grow-1 ps-0 ps-md-0">
                  <Carousel
                    value={vesselData}
                    numVisible={4}
                    numScroll={1}
                    responsiveOptions={ourresponsiveOption}
                    itemTemplate={ourproductTemplate}
                    //   autoplayInterval={2000}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="d-flex flex-column flex-md-row py-2">
                {/* Left static category card */}
                <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                  <div
                    className="card rounded position-relative"
                    style={{ width: "250px", height: "330px" }}
                  >
                    <img
                      src={Garments}
                      alt="Vege"
                      className="img-fluid mt-5 mx-auto"
                      style={{ width: "200px", height: "214px" }}
                    />
                    <h5 className="fw-bold text-center">Garments</h5>
                  </div>
                </div>

                {/* <div style={{ minWidth: "1000px" }}>  */}
                <div className="flex-grow-1 ps-0 ps-md-0"></div>
                <Carousel
                  value={garmentsData}
                  numVisible={4}
                  numScroll={1}
                  responsiveOptions={ourresponsiveOption}
                  itemTemplate={ourproductTemplate}
                  //   autoplayInterval={2000}
                />
                {/* </div>  */}
              </div>
            </div>
            <div className="row">
              <div className="d-flex flex-column flex-md-row py-2">
                {/* Left static category card */}
                <div className="mb-3 mb-md-0" style={{ minWidth: "250px" }}>
                  <div
                    className="card rounded position-relative"
                    style={{ width: "250px", height: "330px" }}
                  >
                    <img
                      src={RoseGold}
                      alt="Vege"
                      className="img-fluid mt-5 mx-auto"
                      style={{ width: "200px", height: "214px" }}
                    />
                    <h5 className="fw-bold text-center">Rose Gold</h5>
                  </div>
                </div>

                {/* <div style={{ minWidth: "1000px" }}>  */}
                <div className="flex-grow-1 ps-0 ps-md-0">
                  <Carousel
                    value={rosegoldData}
                    numVisible={4}
                    numScroll={1}
                    responsiveOptions={ourresponsiveOption}
                    itemTemplate={ourproductTemplate}
                    //   autoplayInterval={2000}
                  />
                  {/* </div>  */}
                </div>
              </div>
            </div>
          </div>
  )
}

export default AllProduct


   <div className="product_container">
            <p className="heading">Product</p>
            {/* leftcard */}
            <div className="product_card">
              <div className="left_card_container">
                <div className="left_card">
                  <div className="left_card_image_container">
                    <img src={image_left} alt="image_left" />
                  </div>
                  <p className="left_card_text">Vegetables</p>
                </div>
              </div>
              <div className="right_card_container">
                <div className="right_card">
                  <div className="right_card_image_container">
                    <img src={image_left} alt="image_left" />
                  </div>
                  <FaHeart
                    size={20}
                    className="whilist_heart"
                    // onClick={() => handlewishlist(productitem)}
                    // onClick={() => handleProductConfirmDelete(item?.id)}
                  />
                  <div className="right_card_content">
                    <p className="product_name">green chilies </p>
                    <div className="kg_container">
                      <p className="kg_text">(1kg)</p>

                      <div>
                        <FaStar color="#FF9D00" size={14} />
                        <span className="star">4.5</span>
                      </div>
                    </div>
                    <div className="d-flex justify-content-between mt-2">
                      <p className="product_price">
                        50€ <span>100€</span>
                      </p>
                      <button
                        className="btn btn-dark btn-sm d-flex align-items-center"
                        onClick={() => {
                          // handleAddToCartproduct(item);
                          // handleAddToCartCount();
                        }}
                      >
                        Add <BiSolidCartAdd size={18} className="ms-1" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>