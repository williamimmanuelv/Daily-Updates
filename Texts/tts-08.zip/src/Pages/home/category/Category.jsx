import React from "react";
import { img_path } from "../../../BaseUrls/BaseUrl";

const Category = ({ fetchcategorys, editcategory }) => {
  return (
    <>
      <h3 className="text-center pb-4 fw-semibold panerfamis">Our Category</h3>
      <div className="row justify-content-center g-5">
        {fetchcategorys?.length > 0 ? (
          fetchcategorys.map((item) => (
            <div
              key={item.id}
              className="col-6 col-sm-4 col-md-2 text-center"
              onClick={(e) => {
                e.preventDefault();
                editcategory(item.id);
              }}
              style={{ cursor: "pointer" }}
            >
              <img
                src={`${img_path}/categories/${item.thumbnail}`}
                alt={item.title}
                className="img-fluid mb-2 w-100"
              />
              <div className="fw-semibold fs-5">{item.title}</div>
            </div>
          ))
        ) : (
          <div className="text-center text-muted">No categories available</div>
        )}
      </div>
    </>
  );
};

export default Category;
