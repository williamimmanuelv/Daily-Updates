import React from "react";
import { FaHeart } from "react-icons/fa";
import { CiHeart } from "react-icons/ci";
import "./categoryProduct.css";

const CategoryProduct = () => {
  // 🔥 Dummy Category Data
  const category = {
    name: "Vegetables",
    image: "https://pngimg.com/uploads/vegetables/vegetables_PNG188.png",
  };

  // 🔥 Dummy Product Data
  const products = [
    {
      id: 1,
      name: "Green Chilies",
      weight: "2kg",
      newPrice: 8,
      oldPrice: 14,
      rating: 4.5,
      like: true,
      image: "https://pngimg.com/uploads/chili_pepper/chili_pepper_PNG42.png",
    },
    {
      id: 2,
      name: "Tomato",
      weight: "3kg",
      newPrice: 26,
      oldPrice: 45,
      rating: 4.5,
      like: false,
      image: "https://pngimg.com/uploads/tomato/tomato_PNG12572.png",
    },
    {
      id: 3,
      name: "Red Onion",
      weight: "1kg",
      newPrice: 15,
      oldPrice: 18,
      rating: 4.5,
      like: false,
      image: "https://pngimg.com/uploads/onion/onion_PNG99203.png",
    },
    {
      id: 4,
      name: "Potatoes",
      weight: "5kg",
      newPrice: 15,
      oldPrice: 18,
      rating: 4.5,
      like: false,
      image: "https://pngimg.com/uploads/potato/potato_PNG99266.png",
    },
  ];

  // ❤️ Like Handler
  const handleLike = (item) => {
    console.log("Like clicked:", item);
  };

  // 🛒 Add Button Handler
  const handleAdd = (item) => {
    console.log("Add Item:", item);
  };

  return (
    <div className="products-row-container">
      {/* LEFT CATEGORY CARD */}
      <div className="category-card">
        <img src={category.image} alt="category" className="category-img" />
        <h4 className="category-title">{category.name}</h4>
      </div>

      {/* PRODUCT SCROLL ROW */}
      <div className="product-scroll">
        {products.map((item) => (
          <div className="product-card" key={item.id}>
            {/* Wishlist Icon */}
            <div className="wishlist-icon" onClick={() => handleLike(item)}>
              {item.like ? (
                <FaHeart size={20} className="text-danger" />
              ) : (
                <CiHeart size={20} className="text-danger" />
              )}
            </div>

            {/* Product Image */}
            <img src={item.image} alt={item.name} className="product-img" />

            {/* Product Name */}
            <h5 className="product-name">{item.name}</h5>

            {/* Weight */}
            <p className="product-weight">{item.weight}</p>

            {/* Price */}
            <p className="product-price">
              <span className="new">{item.newPrice}€</span>
              <span className="old">{item.oldPrice}€</span>
            </p>

            {/* Add Button */}
            <button className="add-btn" onClick={() => handleAdd(item)}>
              Add 🛒
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CategoryProduct;
