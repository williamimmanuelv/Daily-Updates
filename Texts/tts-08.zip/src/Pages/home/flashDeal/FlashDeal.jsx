import React from 'react'

const FlashDeal = () => {
  return (
    <div>FlashDeal</div>
  )
}

export default FlashDeal