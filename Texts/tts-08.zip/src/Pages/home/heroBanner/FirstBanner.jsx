import React from "react";
import { img_path } from "../../../BaseUrls/BaseUrl";


const FirstBanner = ({ heroBanners }) => {
  return (
    <div className=" py-4">
      {heroBanners?.length > 0 && (
        <div className="position-relative banner_button">
          {/* Background Image */}
          <img
            src={`${img_path}/webbanner/${heroBanners[0]?.image}`}
            alt={heroBanners[0]?.title}
            className="img-fluid w-100 rounded"
          />

          {/* Overlay Content */}
          <div
            className="text-white position-absolute banner-overlay"
            style={{
              top: "20%",
              left: "5%",
            }}
          >
            <h1 className="fw-semibold paner_heading banner_family">
              {heroBanners[0].title}
            </h1>
            <p className="banner_para">{heroBanners[0].description}</p>

            {heroBanners[0].button_text && heroBanners[0].button_url && (
              <a
                href={heroBanners[0].button_url}
                className="btn btn-dark banner_button"
              >
                {heroBanners[0].button_text}
              </a>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default FirstBanner;
