import "./banner.css";
import img from "../../../Assets/__INDIAN_ROYAL_FARMER_BRAND_BASMATI_RICE___TRADITIONAL_BASMATI_RAW_WHITE__7_25mm___-removebg-preview 1.png";
import { Link } from "react-router-dom";
import { img_path } from "../../../BaseUrls/BaseUrl";

const ThirdBanner = ({ heroPromoting }) => {
  return (
    <>
      {heroPromoting?.length > 0 && (
        <div className="banner_container">
          <div className="banner_content">
            <h1> {heroPromoting[0].title}</h1>
            <p>{heroPromoting[0].description}</p>
            <button className="banner_rice_button">
              {heroPromoting[0].button_text && heroPromoting[0].button_url && (
                <Link to={heroPromoting[0].button_url}>
                  {heroPromoting[0].button_text}
                </Link>
              )}
            </button>
          </div>

          <div className="banner_image">
            <img
              src={`${img_path}/webbanner/${heroPromoting[0].image}`}
              alt="Premium Rice"
            />
          </div>
        </div>
      )}
    </>
  );
};

export default ThirdBanner;
