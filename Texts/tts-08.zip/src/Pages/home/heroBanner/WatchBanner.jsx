import { Link } from "react-router-dom";
import "./banner.css";
import { img_path } from "../../../BaseUrls/BaseUrl";

const WatchBanner = ({ heroadverting }) => {
  return (
    <>
      {heroadverting?.length > 0 && (
        <div className="banner_watch_container">
          <div className="banner_content">
            <h1> {heroadverting[0].title}</h1>
            <p>{heroadverting[0].description}</p>
            <button className="banner_rice_button">
              {heroadverting[0].button_text && heroadverting[0].button_url && (
                <Link to={heroadverting[0].button_url}>
                  {heroadverting[0].button_text}
                </Link>
              )}
            </button>
          </div>

          <div className="banner_watch_image">
            <img
              src={`${img_path}/webbanner/${heroadverting[0].image}`}
              alt="Premium Rice"
            />
          </div>
        </div>
      )}
    </>
  );
};

export default WatchBanner;
