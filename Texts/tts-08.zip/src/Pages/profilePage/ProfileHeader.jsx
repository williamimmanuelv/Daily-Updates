import React from "react";
import Common from "../../common/Common";
import profileimg from "../../Assets/Mask group (47).png";
import { IoMenuOutline } from "react-icons/io5";
const ProfileHeader = () => {
  const { user } = Common();
  console.log("ee", user);
  return (
    <div className="">
      {/* <div className="col-12 col-md-4"> */}
      <div className="profile-card d-flex align-items-center p-3 shadow-sm">
        <img
          src={user?.image || profileimg}
          alt="profile"
          className="rounded-circle me-3"
          style={{ width: "60px", height: "60px", objectFit: "cover" }}
        />
        <div>
          <div className="fw-semibold">{user?.name}</div>
          <div className="text-muted">{user?.phone}</div>
        </div>
        <IoMenuOutline className="ms-auto" fontSize={30} />
      </div>
      {/* </div> */}
    </div>
  );
};
export default ProfileHeader;
