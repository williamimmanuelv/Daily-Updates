import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaUser, FaHeart, FaGift, FaBell } from "react-icons/fa";
import { SlEarphones } from "react-icons/sl";
import {
  TbExclamationCircleFilled,
  TbLanguageKatakana,
  TbMessage2Star,
} from "react-icons/tb";
import { CiLocationOn } from "react-icons/ci";
import { ImSwitch } from "react-icons/im";

// import Profilelabel from "./Pages/Profilelabel";
// import WishlistProfile from "./Pages/WishlistProfile";
// import OffersCoupon from "./Pages/OffersCoupon";
// import Notifications from "./Pages/Notifications";
// import ChooseLanguage from "./Pages/ChooseLanguage";
// import Address from "./Pages/Address";
// import LegalPolicies from "./Pages/LegalPolicies";
// import Orders from "./Pages/Orders";

import "./pro.css";
import { PiNotebookBold } from "react-icons/pi";
import Profilelabel from "../../Component/Profilepage/Profilelabel";
import WishlistProfile from "../../Component/Profilepage/WishlistProfile";
import OffersCoupon from "../../Component/Profilepage/OffersCoupon";
import Notifications from "../../Component/Profilepage/Notifications";
import ChooseLanguage from "../../Component/Profilepage/ChooseLanguage";
import Address from "../../Component/Profilepage/Address";
import LegalPolicies from "../../Component/Profilepage/LegalPolicies";
import MyOrders from "../Product/MyOrders";
import Header from "../../Component/Header/Header";
import Footer from "../../Component/Footer/Footer";
import Common from "../../common/Common";
import { logout, setUserData } from "../../store/authSlice";
import axios from "axios";
import { base_url } from "../../BaseUrls/BaseUrl";
import ProfileHeader from "./ProfileHeader";
import SidebarMenu from "./SidebarMenu";
import { Modal } from "antd";
import { AiOutlineExclamationCircle } from "react-icons/ai";

const ProfilePage = () => {
  const navigate = useNavigate();

  const savedPage = localStorage.getItem("activePage") || "profilelabel";
  const [activePage, setActivePage] = useState(savedPage);
  const { user, dispatch, token } = Common();

  useEffect(() => {
    localStorage.setItem("activePage", activePage);
  }, [activePage]);

  const handleLogout = async () => {
    try {
      const response = await axios.post(
        `${base_url}/logout`,
        {},
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      localStorage.removeItem("token");
      localStorage.removeItem("selectedRoute");
      localStorage.removeItem("selectedTitle");
      localStorage.removeItem("email");
      localStorage.removeItem("user_id");
      localStorage.removeItem("customer_id");
      localStorage.removeItem("name");
      navigate("/signin");
      dispatch(logout());
    } catch (error) {
      console.log("error message");
    }
  };

  const fetchUser = async () => {
    try {
      const encryptedUserId = localStorage.getItem("user_id");
      const token = localStorage.getItem("token");

      if (!encryptedUserId || !token) {
        console.error("User ID or token missing in localStorage");
        return;
      }

      const response = await axios.get(`${base_url}/user/${encryptedUserId}`, {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
      console.log("My Profile", response);
      //   setUseredit(response?.data?.data);
      dispatch(setUserData(response?.data?.data));
      console.log("User details:", response.data);
    } catch (error) {
      console.error("Error fetching user details:", error);

      if (error.response && error.response.status === 401) {
        console.warn("Unauthorized: Invalid or expired token.");
        // Optional: redirect to login or refresh token
      }
    }
  };

  useEffect(() => {
    fetchUser();
  }, []);

  const LogoutModal = () => {
    Modal.confirm({
      title: "Do you want to Logout?",
      //   icon: React.createElement(AiOutlineExclamationCircle),
      content:
        "When clicked the OK button, you will be redirect to the login page",
      okType: "default",
      okButtonProps: {
        style: {
          backgroundColor: "#e15360",
          borderColor: "#e15360",
          color: "#fff",
        },
      },
      cancelButtonProps: {
        style: {
          background: "#fff",
          borderColor: "#e15360",
          color: "#e15360 ",
        },
      },
      onOk() {
        handleLogout();
      },
      onCancel() {},
    });
  };
  const menuItems = [
    { key: "profilelabel", label: "Profile", icon: <FaUser /> },
    {
      key: "order",
      label: "My Orders",
      icon: <FaUser />,
      onClick: () => navigate("/myorders"),
    },
    { key: "wishlistprofile", label: "Wishlist", icon: <FaHeart /> },
    { key: "offersCoupon", label: "Offers & Coupons", icon: <FaGift /> },
    { key: "notification", label: "Notifications", icon: <FaBell /> },
    { key: "helpsupport", label: "Help & Support", icon: <SlEarphones /> },
    {
      key: "chooselanguage",
      label: "Choose Language",
      icon: <TbLanguageKatakana />,
    },
    { key: "address", label: "Address Management", icon: <CiLocationOn /> },
    { key: "reviewrating", label: "Review & Rating", icon: <TbMessage2Star /> },
    { key: "legalpolicies", label: "Legal Policies", icon: <PiNotebookBold /> },
    {
      key: "logout",
      label: "Log Out",
      icon: <ImSwitch />,
      onClick: LogoutModal,
      danger: true,
    },
  ];

  return (
    <>
      <Header />
      <div className="body_bgcolor">
        <div className="container pt-3 pb-5">
          <h4 className="fw-bold cardfamily">My Profile</h4>

          {/* <ProfileHeader /> */}

          <div className="d-flex profile-container gap-2">
            {/* Sidebar */}
            <SidebarMenu
              menuItems={menuItems}
              activePage={activePage}
              setActivePage={setActivePage}
            />

            {/* Main Content */}
            <div className="flex-grow-1 bg-white  ">
              {activePage === "profilelabel" && <Profilelabel />}
              {activePage === "wishlistprofile" && <WishlistProfile />}
              {activePage === "offersCoupon" && <OffersCoupon />}
              {activePage === "notification" && <Notifications />}
              {activePage === "chooselanguage" && <ChooseLanguage />}
              {activePage === "address" && <Address />}
              {activePage === "helpsupport" && <h4>Help & Support</h4>}
              {activePage === "reviewrating" && <h4>Review & Rating</h4>}
              {activePage === "legalpolicies" && <LegalPolicies />}
              {activePage === "order" && <MyOrders />}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default ProfilePage;
