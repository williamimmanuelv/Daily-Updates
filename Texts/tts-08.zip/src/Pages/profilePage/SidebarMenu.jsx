import React, { useEffect, useState } from "react";
import ProfileHeader from "./ProfileHeader";
import Common from "../../common/Common";
import profileimg from "../../Assets/Mask group (47).png";
import { IoMenuOutline } from "react-icons/io5";
import { Drawer } from "antd";

const SidebarMenu = ({ menuItems, activePage, setActivePage }) => {
  const { user } = Common();
  const [isMobile, setIsMobile] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    handleResize();
    window.addEventListener("resize", handleResize);

    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const MenuContent = () => (
    <ul className="list-unstyled p-3 m-0">
      {menuItems.map((item) => (
        <li
          key={item.key}
          className={`menu-item ${activePage === item.key ? "active" : ""} ${
            item.danger ? "text-danger fw-bold" : ""
          }`}
          onClick={() => {
            item.onClick ? item.onClick() : setActivePage(item.key);
            isMobile && setOpen(false); // Close drawer on mobile after click
          }}
        >
          <span className="me-2">{item.icon}</span>
          {item.label}
        </li>
      ))}
    </ul>
  );
  return (
    <div className="sidebar shadow-sm  ">
      <div className="profile-card d-flex align-items-center p-3 shadow-sm">
        <img
          src={user?.image || profileimg}
          alt="profile"
          className="rounded-circle me-3"
          style={{ width: "60px", height: "60px", objectFit: "cover" }}
        />
        <div>
          <div className="fw-semibold">{user?.name}</div>
          <div className="text-muted">{user?.phone}</div>
        </div>
        {isMobile && (
          <IoMenuOutline
            className="ms-auto"
            fontSize={30}
            onClick={() => setOpen(true)}
            style={{ cursor: "pointer" }}
          />
        )}
      </div>
      {!isMobile && (
        <>
          <MenuContent />
        </>
      )}
      <Drawer
        title="Menu"
        placement="right"
        onClose={() => setOpen(false)}
        open={open}
        width={250}
      >
        <MenuContent />
      </Drawer>
      {/* <ul className="list-unstyled p-3 m-0">
        {menuItems.map((item) => (
          <li
            key={item.key}
            className={`menu-item ${activePage === item.key ? "active" : ""} ${
              item.danger ? "text-danger fw-bold" : ""
            }`}
            onClick={() =>
              item.onClick ? item.onClick() : setActivePage(item.key)
            }
          >
            <span className="me-2">{item.icon}</span>
            {item.label}
          </li>
        ))}
      </ul> */}
    </div>
  );
};
export default SidebarMenu;
