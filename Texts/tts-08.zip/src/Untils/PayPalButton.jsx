import React, { useState } from "react";
import {
  PayPalButtons,
  usePayPalScriptReducer,
} from "@paypal/react-paypal-js";

const PayPalButton = ({ amount, description = "Order", onSuccess, onError }) => {
  const [{ isPending }] = usePayPalScriptReducer();
  const [error, setError] = useState(null);

  // Create the PayPal order
  const createOrder = (data, actions) => {
    return actions.order
      .create({
        purchase_units: [
          {
            description,
            amount: {
              currency_code: "USD",
              value: amount,
            },
          },
        ],
      })
      .catch((err) => {
        setError(err);
        if (onError) onError(err);
      });
  };

  // Handle approval
  const onApprove = async (data, actions) => {
    if (!actions.order) return;
    const capture = await actions.order.capture();

    if (onSuccess) onSuccess(capture);
    console.log("Payment Success:", capture);
  };

  if (isPending) return <div>Loading PayPal…</div>;
  if (error) return <div>Error: {String(error)}</div>;

  return (
    <PayPalButtons
      style={{ layout: "vertical", color: "gold", shape: "rect", label: "paypal" }}
      createOrder={createOrder}
      onApprove={onApprove}
      onError={(err) => {
        setError(err);
        if (onError) onError(err);
      }}
    />
  );
};

export default PayPalButton;
