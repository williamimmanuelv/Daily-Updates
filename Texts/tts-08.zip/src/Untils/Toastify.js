// CustomToast.js
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";

const Toastify = () => {
  const navigate = useNavigate();

  const showAddToCartToast = () => {
    toast(
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          width: "100%",
        }}
      >
        <span style={{ fontWeight: 500 }}>Added to cart</span>

        <button
          onClick={() => navigate("/addtocart")}
          style={{
            color: "#333",
            border: "none",
            borderRadius: "25px",
            padding: "4px 12px",
            cursor: "pointer",
            fontWeight: "600",
          }}
        >
          View
        </button>
      </div>,
      {
        style: {
          background: "#333",
          color: "#fff",
          borderRadius: "30px",
          padding: "10px 20px",
          minWidth: "600px",
          display: "flex",
          alignItems: "center",
        },
        autoClose: 3000,
        position: "bottom-center",
      }
    );
  };

  return { showAddToCartToast };
};

export default Toastify;
