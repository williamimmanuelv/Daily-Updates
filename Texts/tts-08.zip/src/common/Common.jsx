import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

const Common = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const token = useSelector((state) => state.auth.token);
  const user = useSelector((state) => state.auth.userData);
  const favoriteData = useSelector((state) => state.favorite.favoriteData);
  const cartCount = useSelector((state) => state.card.cartCount);
  const deliveryType = useSelector((state) => state.card.deliveryTypeData);
  const orderTrackId = useSelector((state) => state.card.orderTrackId);
  const firstRender = useSelector((state) => state.auth.firstRender);
  const couponId = useSelector((state) => state.card.couponId);
  return {
    navigate,
    dispatch,
    token,
    user,
    favoriteData,
    cartCount,
    deliveryType,
    orderTrackId,
    firstRender,
    couponId,
  };
};

export default Common;
