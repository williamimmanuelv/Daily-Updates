import axios from "axios";
import Common from "../common/Common";
import { base_url } from "../BaseUrls/BaseUrl";
import { setFavoriteData } from "../store/favoriteSlice";
import { setCartCount } from "../store/cartSlice";

const UpdateFilterData = () => {
  const { dispatch, token } = Common();
  const fetchFavoriteItem = async () => {
    try {
      if (!token) {
        return;
      }

      const response = await axios.get(`${base_url}/wishlist`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
      });
      dispatch(setFavoriteData(response.data));
      console.log("response.data", response.data);
    } catch (error) {
      console.log(error);
    }
  };
  const handleAddToCartProduct = async () => {
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        return;
      }

      const response = await axios.post(
        `${base_url}/cart/count`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      console.log("res Count", response);
      dispatch(setCartCount(response?.data?.cartCount));
    } catch (error) {}
  };
  const updateAllFilters = async () => {
    await Promise.all([fetchFavoriteItem(), handleAddToCartProduct()]);
  };

  const Update = async (type) => {
    switch (type) {
      case "all":
        await updateAllFilters();
        break;
      case "favorite":
        await fetchFavoriteItem();
        break;
      case "cart":
        await handleAddToCartProduct();
        break;

      default:
        console.error("Invalid filter type:", type);
    }
  };

  return { Update };
};

export default UpdateFilterData;
