import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  token: localStorage.getItem("token") ? localStorage.getItem("token") : null,
  isCollapsed: localStorage.getItem("isCollapsed")
    ? localStorage.getItem("isCollapsed")
    : false,
  userData: localStorage.getItem("userData")
    ? JSON.parse(localStorage.getItem("userData"))
    : [],
  firstRender: sessionStorage.getItem("firstRender") || true,
};

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setToken: (state, action) => {
      state.token = action.payload;
      localStorage.setItem("token", JSON.stringify(action.payload));
    },
    setIsCollapsed: (state, action) => {
      state.isCollapsed = action.payload;
      localStorage.setItem("isCollapsed", JSON.stringify(action.payload));
    },
    setUserData: (state, action) => {
      state.userData = action.payload;
      localStorage.setItem("userData", JSON.stringify(action.payload));
    },
    setFirstRender: (state, action) => {
      state.firstRender = action.payload;
      sessionStorage.setItem("firstRender", JSON.stringify(action.payload));
    },
    logout: (state) => {
      state.auth = null;
      state.isCollapsed = false;
      state.accessToken = null;
      state.userData = null;
      state.firstRender = true;
      localStorage.removeItem("token");
      localStorage.removeItem("userData");
      sessionStorage.removeItem("firstRender");
    },
  },
});

export const { setToken, logout, setUserData, setFirstRender } =
  authSlice.actions;
export default authSlice.reducer;
