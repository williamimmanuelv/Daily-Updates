import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  cartCount: localStorage.getItem("cartCount") || 0,
  deliveryTypeData: localStorage.getItem("deliveryTypeData")
    ? JSON.parse(localStorage.getItem("deliveryTypeData"))
    : "delivery",
  orderTrackId: localStorage.getItem("orderTrackId") || "",
  couponId: localStorage.getItem("couponId") || null,
};

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    setCartCount: (state, action) => {
      console.log("ruk");
      state.cartCount = action.payload ?? 0;
      localStorage.setItem("cartCount", JSON.stringify(state.cartCount));
    },
    setDeliveryType: (state, action) => {
      state.deliveryTypeData = action.payload;
      localStorage.setItem(
        "deliveryTypeData",
        JSON.stringify(state.deliveryTypeData)
      );
    },
    setOrderTrackId: (state, action) => {
      state.orderTrackId = action.payload;
      localStorage.setItem("orderTrackId", JSON.stringify(state.orderTrackId));
    },
    setCouponId: (state, action) => {
      state.couponId = action.payload;
      localStorage.setItem("couponId", JSON.stringify(state.couponId));
    },
  },
});

export const { setCartCount, setDeliveryType, setOrderTrackId, setCouponId } =
  cartSlice.actions;
export default cartSlice.reducer;
