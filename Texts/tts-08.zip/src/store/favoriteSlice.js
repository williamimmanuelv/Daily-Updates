import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  favoriteData: localStorage.getItem("favoriteData")
    ? JSON.parse(localStorage.getItem("favoriteData"))
    : [],
};

const favSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setFavoriteData: (state, action) => {
      state.favoriteData = action.payload;

      localStorage.setItem("favoriteData", JSON.stringify(action.payload));
    },
    removeFavorite: (state, action) => {
      state.favoriteData = state?.favoriteData?.filter(
        (item) => item.id !== action.payload
      );

      localStorage.setItem("favoriteData", JSON.stringify(state.favoriteData));
    },
  },
});

export const { setFavoriteData, removeFavorite } = favSlice.actions;
export default favSlice.reducer;
