import { configureStore } from "@reduxjs/toolkit";
import authSlice from "./authSlice";
import favoriteSlice from "./favoriteSlice";
import cardSlice from "./cartSlice";

const store = configureStore({
  reducer: {
    auth: authSlice,
    favorite: favoriteSlice,
    card: cardSlice,
  },
});

export default store;
