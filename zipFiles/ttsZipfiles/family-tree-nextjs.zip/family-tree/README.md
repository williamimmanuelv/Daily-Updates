# 🌳 Family Tree — YouTube Lineage Visualizer

A cinematic Next.js app that renders a vertical family lineage (father above, mother below, glowing ring connectors) designed for YouTube videos at 1920×1080.

---

## Project Structure

```
family-tree/
├── app/
│   ├── layout.tsx          # Fonts, global styles
│   ├── page.tsx            # Root page
│   └── globals.css
├── components/
│   ├── FamilyCard.tsx      # Father/Mother vertical card layout
│   └── LineagePage.tsx     # Main orchestration + canvas overlay
├── lib/
│   ├── lineageData.ts      # ✏️  EDIT THIS to change the lineage
│   └── canvasEngine.ts     # Canvas: particles, glow rings, connectors
├── public/
│   └── assets/             # 📸 Put your images here
├── scripts/
│   ├── generate-placeholders.js   # Generates temp images
│   └── export-frames.js           # Puppeteer + FFmpeg video export
└── README.md
```

---

## Quick Start

```bash
npm install
node scripts/generate-placeholders.js   # creates temp images
npm run dev                              # open http://localhost:3000
```

---

## Adding Your Own Images

Place images in `/public/assets/` following this naming convention:

| File                    | Description              |
|-------------------------|--------------------------|
| `familyNo1father.jpg`   | Generation 1 – Father    |
| `familyNo1mother.jpg`   | Generation 1 – Mother    |
| `familyNo2father.jpg`   | Generation 2 – Father    |
| `familyNo2mother.jpg`   | Generation 2 – Mother    |
| `familyNo3father.jpg`   | Generation 3 – Father    |
| `familyNo3mother.jpg`   | Generation 3 – Mother    |
| ...                     | ...                      |

- Recommended: **square images, 400×400px minimum**, JPEG or PNG
- Image is circular-cropped automatically in the UI
- The `id` field in `lineageData.ts` determines which number is used

---

## Customising the Lineage

Edit `lib/lineageData.ts`:

```ts
export const CHANNEL_NAME = "Family Tree";
export const LINEAGE_SUBJECT = "Jon Snow · Aegon Targaryen";
export const VIDEO_TITLE = "The True Lineage of Jon Snow";

export const LINEAGE_DATA: Family[] = [
  {
    id: 1,               // controls image filenames: familyNo1father.jpg etc.
    era: "The Conquest · 1 AC",
    father: {
      name: "Aegon I Targaryen",
      life: "27 BC – 37 AC",
      title: "Aegon the Conqueror · King of the Seven Kingdoms",
      desc: "United the realm through fire and blood",
    },
    mother: {
      name: "Visenya Targaryen",
      life: "29 BC – 44 AC",
      title: "Queen · Warrior of House Targaryen",
      desc: "Dragon-riding queen who wielded Dark Sister",
    },
  },
  // Add more generations...
];
```

Set `mother: null` for the final subject if they have no partner shown.
Set `isSubject: true` on the last generation to add the gold ✦ THE SUBJECT ✦ badge.

---

## Exporting to YouTube Video (FFmpeg)

### Requirements
```bash
npm install puppeteer
# macOS:
brew install ffmpeg
# Ubuntu:
sudo apt install ffmpeg
```

### Steps
```bash
# 1. Start the dev server
npm run dev

# 2. In a new terminal, run the export
node scripts/export-frames.js
```

### Output
- `output/frames/frame_000001.png` … (all captured frames)
- `output/family-tree-video.mp4` — **1920×1080, H.264, 30fps, YouTube-ready**

### FFmpeg settings used
| Setting       | Value     | Reason                          |
|---------------|-----------|---------------------------------|
| Codec         | libx264   | Maximum YouTube compatibility   |
| CRF           | 18        | Near-lossless quality           |
| Preset        | slow      | Better compression              |
| Pixel format  | yuv420p   | Required by YouTube             |
| Bitrate       | 20 Mbps   | Recommended for 1080p uploads   |
| faststart     | enabled   | Enables streaming before full download |

---

## Controls (in browser)

| Input           | Action                  |
|-----------------|-------------------------|
| `→` / `↓`       | Next generation         |
| `←` / `↑`       | Previous generation     |
| Nav dots        | Jump to generation      |
| Auto-play       | Advances every 6 seconds (configurable in LineagePage.tsx: `AUTO_ADVANCE_MS`) |

---

## Visual System

- **Gold ring** — Father's profile image glow (pulsing, rotating dashes, wave ripple)
- **Silver-blue ring** — Mother's profile image glow
- **Gold connector line** — Bezier curve: father image bottom → mother image top (waves from glow)
- **Gold connector line** — Bezier curve: mother image bottom → next generation father top
- **Travelling dot** — Animated gold dot moves along each connector
- **Arrowhead** — Appears at connector endpoint to show direction
- **Gold particles** — Ambient floating dust particles on canvas layer
