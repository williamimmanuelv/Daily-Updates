import { NextResponse } from "next/server";
import path from "path";
import fs from "fs";

/**
 * GET /api/load-project
 * Returns the saved project: meta + lineageJSON + all images as base64 data URLs.
 */
export async function GET() {
  try {
    const saveDir = path.join(process.cwd(), "output", "saved-project");
    const metaPath    = path.join(saveDir, "meta.json");
    const lineagePath = path.join(saveDir, "lineage.json");
    const imgDir      = path.join(saveDir, "images");

    if (!fs.existsSync(metaPath) || !fs.existsSync(lineagePath)) {
      return NextResponse.json({ ok: false, error: "No saved project found." });
    }

    const meta    = JSON.parse(fs.readFileSync(metaPath, "utf8"));
    const lineage = JSON.parse(fs.readFileSync(lineagePath, "utf8"));

    // Load all saved images back as base64 data URLs
    const images: Record<string, string> = {};
    if (fs.existsSync(imgDir)) {
      const files = fs.readdirSync(imgDir);
      for (const file of files) {
        const fp  = path.join(imgDir, file);
        const buf = fs.readFileSync(fp);
        const ext = path.extname(file).toLowerCase().replace(".", "");
        const mime = ext === "png" ? "image/png"
                   : ext === "gif" ? "image/gif"
                   : ext === "webp" ? "image/webp"
                   : "image/jpeg";
        images[file] = `data:${mime};base64,${buf.toString("base64")}`;
      }
    }

    return NextResponse.json({ ok: true, meta, lineage, images });
  } catch (e) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
