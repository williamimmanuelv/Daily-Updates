import { NextRequest, NextResponse } from "next/server";
import path from "path";
import fs from "fs";

/**
 * POST /api/save-images
 * Body: { images: { filename: base64DataURL } }
 *
 * Saves each image to output/images-export/{filename}
 * so the Puppeteer export script can find and inject them.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as { images: Record<string, string> };
    const { images } = body;

    if (!images || typeof images !== "object") {
      return NextResponse.json({ error: "Missing images" }, { status: 400 });
    }

    // Save to project_root/output/images-export/
    const outDir = path.join(process.cwd(), "output", "images-export");
    fs.mkdirSync(outDir, { recursive: true });

    let saved = 0;
    for (const [filename, dataURL] of Object.entries(images)) {
      if (!dataURL || !dataURL.startsWith("data:")) continue;
      // Strip the data:mime;base64, prefix
      const base64 = dataURL.split(",")[1];
      if (!base64) continue;
      const buf = Buffer.from(base64, "base64");
      const safeName = path.basename(filename); // prevent path traversal
      fs.writeFileSync(path.join(outDir, safeName), buf);
      saved++;
    }

    return NextResponse.json({ ok: true, saved, dir: outDir });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
