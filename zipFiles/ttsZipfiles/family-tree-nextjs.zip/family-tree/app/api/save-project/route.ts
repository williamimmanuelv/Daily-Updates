import { NextRequest, NextResponse } from "next/server";
import path from "path";
import fs from "fs";

/**
 * POST /api/save-project
 * Body: { theme, fontChoice, lineageJSON, images: { filename: base64DataURL } }
 * Saves everything to output/saved-project/ so the project survives restarts.
 */
export async function POST(req: NextRequest) {
  try {
    const body = await req.json() as {
      theme: string;
      fontChoice: string;
      lineageJSON: unknown;
      images: Record<string, string>;
    };

    const { theme, fontChoice, lineageJSON, images } = body;
    const saveDir = path.join(process.cwd(), "output", "saved-project");
    const imgDir  = path.join(saveDir, "images");
    fs.mkdirSync(imgDir, { recursive: true });

    // Save project metadata
    const meta = { theme, fontChoice, savedAt: new Date().toISOString() };
    fs.writeFileSync(path.join(saveDir, "meta.json"), JSON.stringify(meta, null, 2));

    // Save lineage JSON
    fs.writeFileSync(
      path.join(saveDir, "lineage.json"),
      JSON.stringify(lineageJSON, null, 2)
    );

    // Save images
    let imgCount = 0;
    for (const [filename, dataURL] of Object.entries(images || {})) {
      if (!dataURL?.startsWith("data:")) continue;
      const base64 = dataURL.split(",")[1];
      if (!base64) continue;
      fs.writeFileSync(path.join(imgDir, path.basename(filename)), Buffer.from(base64, "base64"));
      imgCount++;
    }

    return NextResponse.json({ ok: true, imgCount, dir: saveDir });
  } catch (e) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
