import type { Metadata } from "next";
import "./globals.css";
import { AppStateProvider } from "@/lib/appState";

export const metadata: Metadata = {
  title: "Family Tree Studio",
  description: "Create cinematic YouTube lineage videos",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head />
      <body style={{ margin: 0, padding: 0, background: "#060810" }}>
        <AppStateProvider>
          {children}
        </AppStateProvider>
      </body>
    </html>
  );
}
