"use client";
import React, { useState, useRef, useCallback, useEffect } from "react";
import { useRouter } from "next/navigation";
import { THEMES, FONT_OPTIONS } from "@/lib/themes";
import { validateLineageJSON, SAMPLE_JSON, LineageJSON } from "@/lib/jsonFormat";
import { useAppState } from "@/lib/appState";
import type { Theme } from "@/lib/themes";

// ── Image slot type ─────────────────────────────────────────
interface ImageSlot {
  filename: string;
  label:    string;
  role:     "father"|"mother"|"child"|"wf-father"|"wf-mother"|"wf-child";
  genId:    number;
  preview?: string;
  uploaded: boolean;
}

// ── Build slots from JSON (includes wife's family tree images) ──
function buildSlots(data: LineageJSON): ImageSlot[] {
  const slots: ImageSlot[] = [];
  data.families.forEach(fam => {
    // Father
    slots.push({ filename:fam.father.image, role:"father", genId:fam.id, uploaded:false,
      label:`${fam.father.name} — Father` });
    if(fam.mother) {
      // Mother
      slots.push({ filename:fam.mother.image, role:"mother", genId:fam.id, uploaded:false,
        label:`${fam.mother.name} — Mother (Wife)` });
      // Wife's family tree
      const wf = (fam.mother as unknown as Record<string,unknown>)?.wifeFamily as
        {father:{name:string,image:string}, mother:{name:string,image:string}, siblings:{name:string,image:string}[]} | undefined;
      if(wf) {
        slots.push({ filename:wf.father.image, role:"wf-father", genId:fam.id, uploaded:false,
          label:`${wf.father.name} — Wife's Father` });
        slots.push({ filename:wf.mother.image, role:"wf-mother", genId:fam.id, uploaded:false,
          label:`${wf.mother.name} — Wife's Mother` });
        (wf.siblings||[]).forEach(sib => {
          slots.push({ filename:sib.image, role:"wf-child", genId:fam.id, uploaded:false,
            label:`${sib.name} — Wife's Sibling` });
        });
      }
    }
    // Children (heir's siblings)
    (fam.children??[]).forEach(ch => {
      slots.push({ filename:ch.image, role:"child", genId:fam.id, uploaded:false,
        label:ch.name });
    });
  });
  return slots;
}

// ── Component ───────────────────────────────────────────────
export default function HomePage() {
  const router = useRouter();
  const { theme, setTheme, fontChoice, setFontChoice, setLineage, setImageMap } = useAppState();

  const [draggingJson, setDraggingJson] = useState(false);
  const [fileName,     setFileName]     = useState<string|null>(null);
  const [errors,       setErrors]       = useState<string[]>([]);
  const [jsonOk,       setJsonOk]       = useState(false);
  const [parsed,       setParsed]       = useState<LineageJSON|null>(null);
  const [showSample,   setShowSample]   = useState(false);
  const [mounted,      setMounted]      = useState(false);
  const [slots,        setSlots]        = useState<ImageSlot[]>([]);
  const [saving,       setSaving]       = useState(false);
  const [saveMsg,      setSaveMsg]      = useState<string|null>(null);
  const [loading,      setLoading]      = useState(false);
  const [loadMsg,      setLoadMsg]      = useState<string|null>(null);

  const [testMode, setTestMode] = useState(false);
  const [testBase64, setTestBase64] = useState<string|null>(null);

  // In test mode: one image fills every slot
  const allUploaded = testMode
    ? (testBase64 !== null)
    : slots.length > 0 && slots.every(s=>s.uploaded);
  const jsonInputRef = useRef<HTMLInputElement>(null);

  useEffect(()=>{ setMounted(true); },[]);

  const t      = THEMES[theme]       ?? THEMES.history;
  const fonts  = FONT_OPTIONS[theme] ?? FONT_OPTIONS.history;
  const accent = mounted ? t.timelineDot : "#c9a84c";
  const bgPage = mounted ? t.bgTo        : "#0d0a04";
  const hFont  = mounted ? t.headingFont : "'Cinzel', serif";
  const bFont  = mounted ? t.bodyFont    : "'Cormorant Garamond', serif";
  const nColor = mounted ? t.nameColor   : "#f0d080";
  const dColor = mounted ? t.descColor   : "#8a8070";

  // ── JSON processing ───────────────────────────────────────
  const processJson = useCallback((file: File) => {
    if(!file.name.endsWith(".json")) {
      setErrors(["Please upload a .json file."]); setJsonOk(false);
      setFileName(null); setParsed(null); setSlots([]); return;
    }
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const raw = JSON.parse(e.target?.result as string);
        const result = validateLineageJSON(raw);
        if(result.ok) {
          setErrors([]); setJsonOk(true);
          setParsed(raw as LineageJSON);
          setSlots(buildSlots(raw as LineageJSON));
        } else {
          setErrors(result.errors); setJsonOk(false); setParsed(null); setSlots([]);
        }
      } catch { setErrors(["Invalid JSON syntax."]); setJsonOk(false); setParsed(null); setSlots([]); }
    };
    reader.readAsText(file);
  }, []);

  // ── Slot upload ───────────────────────────────────────────
  const handleSlotUpload = (filename: string, file: File) => {
    if(!file.type.startsWith("image/")) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      if(!base64) return;
      if(testMode) {
        // Test mode: one image fills ALL slots
        setTestBase64(base64);
        setSlots(prev => prev.map(s => ({...s, uploaded:true, preview:base64})));
      } else {
        setSlots(prev => prev.map(s => s.filename===filename ? {...s, uploaded:true, preview:base64} : s));
      }
    };
    reader.readAsDataURL(file);
  };

  // ── Create / Navigate ────────────────────────────────────
  const handleCreate = () => {
    if(!parsed || !allUploaded) return;
    const map: Record<string,string> = {};
    if(testMode && testBase64) {
      // Test mode: every image filename maps to the same image
      slots.forEach(s => { map[s.filename] = testBase64; });
    } else {
      slots.forEach(s => { if(s.preview) map[s.filename] = s.preview; });
    }
    if(typeof window !== "undefined") (window as Record<string,unknown>).__ftImages = map;
    setImageMap(map);
    setLineage(parsed);
    router.push("/preview");
  };
  const handleDemo = () => { setLineage(SAMPLE_JSON as unknown as LineageJSON); router.push("/preview"); };

  // ── Save Project ─────────────────────────────────────────
  const handleSaveProject = async () => {
    if(!parsed) { setSaveMsg("❌ No project loaded yet."); return; }
    setSaving(true); setSaveMsg(null);
    try {
      const map: Record<string,string> = {};
      slots.forEach(s => { if(s.preview) map[s.filename] = s.preview; });
      const res = await fetch("/api/save-project", {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ theme, fontChoice, lineageJSON: parsed, images: map }),
      });
      const j = await res.json();
      if(j.ok) setSaveMsg(`✅ Saved! (${j.imgCount} images → output/saved-project/)`);
      else setSaveMsg(`❌ ${j.error}`);
    } catch(e) { setSaveMsg(`❌ ${String(e)}`); }
    finally { setSaving(false); setTimeout(()=>setSaveMsg(null), 5000); }
  };

  // ── Load Project ─────────────────────────────────────────
  const handleLoadProject = async () => {
    setLoading(true); setLoadMsg(null);
    try {
      const res = await fetch("/api/load-project");
      const j   = await res.json();
      if(!j.ok) { setLoadMsg(`❌ ${j.error}`); setLoading(false); return; }
      // Restore theme & font
      setTheme(j.meta.theme || "history");
      setFontChoice(j.meta.fontChoice || "default");
      // Restore lineage
      setParsed(j.lineage as LineageJSON);
      setFileName("saved-project/lineage.json");
      setJsonOk(true); setErrors([]);
      // Build slots and mark uploaded ones
      const newSlots = buildSlots(j.lineage as LineageJSON);
      const imgs = j.images as Record<string,string>;
      newSlots.forEach(s => {
        if(imgs[s.filename]) { s.preview = imgs[s.filename]; s.uploaded = true; }
      });
      setSlots(newSlots);
      // Restore image map
      if(typeof window !== "undefined") (window as Record<string,unknown>).__ftImages = imgs;
      setImageMap(imgs);
      setLoadMsg(`✅ Project loaded! (${Object.keys(imgs).length} images, saved ${new Date(j.meta.savedAt).toLocaleDateString()})`);
      setTimeout(()=>setLoadMsg(null), 6000);
    } catch(e) { setLoadMsg(`❌ ${String(e)}`); }
    finally { setLoading(false); }
  };

  // ── Group slots by gen for grid ───────────────────────────
  const slotsByGen = parsed ? parsed.families.map(fam => {
    const wf = (fam.mother as unknown as Record<string,unknown>)?.wifeFamily;
    return {
      fam,
      fatherSlots: slots.filter(s=>s.genId===fam.id && s.role==="father"),
      motherSlots: slots.filter(s=>s.genId===fam.id && s.role==="mother"),
      childSlots:  slots.filter(s=>s.genId===fam.id && s.role==="child"),
      wfFather:    slots.filter(s=>s.genId===fam.id && s.role==="wf-father"),
      wfMother:    slots.filter(s=>s.genId===fam.id && s.role==="wf-mother"),
      wfSiblings:  slots.filter(s=>s.genId===fam.id && s.role==="wf-child"),
      hasWf:       !!wf,
    };
  }) : [];

  // ── Render ────────────────────────────────────────────────
  return (
    <div style={{minHeight:"100vh",background:bgPage,overflowY:"auto",overflowX:"hidden"}}>
      {mounted && <link key={theme} rel="stylesheet" href={t.fontImport}/>}

      {/* HEADER */}
      <div style={{position:"sticky",top:0,zIndex:100,background:"rgba(0,0,0,0.9)",
        backdropFilter:"blur(14px)",borderBottom:"1px solid rgba(255,255,255,0.07)",
        padding:"14px 48px",display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{fontFamily:hFont,fontSize:19,color:nColor,letterSpacing:"0.08em"}}>
          🌳 Family Tree Studio
        </div>
        <div style={{display:"flex",gap:10,alignItems:"center"}}>
          {/* Load Project */}
          <button onClick={handleLoadProject} disabled={loading}
            style={{...ghostBtn(accent,bFont),opacity:loading?0.5:1}}>
            {loading?"⏳ LOADING...":"📂 LOAD SAVED PROJECT"}
          </button>
          {/* Save Project */}
          {parsed && (
            <button onClick={handleSaveProject} disabled={saving}
              style={{...ghostBtn(accent,bFont),opacity:saving?0.5:1,
                background:`${accent}11`,border:`1px solid ${accent}88`}}>
              {saving?"⏳ SAVING...":"💾 SAVE PROJECT"}
            </button>
          )}
          <button onClick={handleDemo} style={ghostBtn(accent,bFont)}>DEMO PREVIEW →</button>
        </div>
      </div>

      {/* Status messages */}
      {(saveMsg||loadMsg) && (
        <div style={{background:"rgba(0,0,0,0.7)",padding:"10px 48px",
          fontFamily:bFont,fontSize:13,color:saveMsg?.startsWith("✅")||loadMsg?.startsWith("✅")?"#80e890":"#e88080"}}>
          {saveMsg||loadMsg}
        </div>
      )}

      {/* HERO */}
      <div style={{textAlign:"center",padding:"52px 40px 36px"}}>
        <div style={{fontFamily:hFont,fontSize:48,fontWeight:700,color:nColor,
          letterSpacing:"0.05em",lineHeight:1.15,marginBottom:10,
          textShadow:`0 0 60px ${accent}80`}}>
          Create Your Lineage Video
        </div>
        <div style={{fontFamily:bFont,fontStyle:"italic",fontSize:18,color:dColor,letterSpacing:"0.1em"}}>
          Choose a theme · Upload your data · Generate a cinematic YouTube video
        </div>
      </div>

      <div style={{maxWidth:1080,margin:"0 auto",padding:"0 34px 80px"}}>

        {/* STEP 1 — Theme */}
        <StepBox id="step1" num="01" title="Choose a Theme" accent={accent} hFont={hFont} nColor={nColor}>
          <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:12}}>
            {Object.values(THEMES).map(th=>(
              <button key={th.id} onClick={()=>{setTheme(th.id);setFontChoice("default");}}
                style={{all:"unset",display:"block",cursor:"pointer",textAlign:"center",
                  boxSizing:"border-box",borderRadius:12,padding:"14px 8px 14px",
                  background:theme===th.id?`linear-gradient(145deg,${th.bgFrom},${th.bgTo})`:"rgba(255,255,255,0.04)",
                  border:`2px solid ${theme===th.id?th.timelineDot:"rgba(255,255,255,0.1)"}`,
                  boxShadow:theme===th.id?`0 0 28px ${th.timelineDot}66`:"none",
                  transition:"all 0.3s"}}>
                <div style={{fontSize:24,marginBottom:5}}>{th.icon}</div>
                <div style={{fontFamily:th.headingFont,fontSize:12,fontWeight:700,
                  color:theme===th.id?th.nameColor:"#888",letterSpacing:"0.04em",marginBottom:3}}>{th.name}</div>
                <div style={{fontFamily:th.bodyFont,fontStyle:"italic",fontSize:9,
                  color:theme===th.id?th.descColor:"#555",lineHeight:1.4,marginBottom:8}}>{th.desc}</div>
                <div style={{display:"flex",justifyContent:"center"}}>
                  <RingPreview th={th} active={theme===th.id}/>
                </div>
                <div style={{marginTop:5,fontFamily:"Consolas,monospace",fontSize:8,letterSpacing:"0.1em",
                  color:theme===th.id?th.timelineDot:"#444"}}>{th.ringStyle.toUpperCase()}</div>
              </button>
            ))}
          </div>
        </StepBox>

        {/* STEP 2 — Font */}
        <StepBox id="step2" num="02" title="Choose a Font Style" accent={accent} hFont={hFont} nColor={nColor}>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
            {fonts.map(f=>(
              <button key={f.id} onClick={()=>setFontChoice(f.id)}
                style={{all:"unset",display:"block",cursor:"pointer",boxSizing:"border-box",
                  borderRadius:10,padding:"14px 16px",
                  background:fontChoice===f.id?`${accent}18`:"rgba(255,255,255,0.03)",
                  border:`2px solid ${fontChoice===f.id?accent:"rgba(255,255,255,0.08)"}`,
                  boxShadow:fontChoice===f.id?`0 0 18px ${accent}44`:"none",transition:"all 0.3s"}}>
                <div style={{fontFamily:f.headingFont,fontSize:15,color:fontChoice===f.id?nColor:"#888",marginBottom:4}}>{f.name}</div>
                <div style={{fontFamily:f.bodyFont,fontStyle:"italic",fontSize:11,color:fontChoice===f.id?dColor:"#555"}}>{f.preview}</div>
              </button>
            ))}
          </div>
        </StepBox>

        {/* STEP 3 — JSON Upload */}
        <StepBox id="step3" num="03" title="Upload Lineage Data (JSON)" accent={accent} hFont={hFont} nColor={nColor}>
          <button onClick={()=>setShowSample(s=>!s)} style={ghostBtn(accent,bFont)}>
            {showSample?"▲ HIDE":"▼ VIEW"} SAMPLE JSON FORMAT
          </button>
          {showSample && (
            <pre style={{marginTop:12,background:"#05080f",border:"1px solid rgba(255,255,255,0.1)",
              borderRadius:10,padding:"14px 16px",fontFamily:"Consolas,monospace",fontSize:11,
              color:"#90c880",lineHeight:1.75,maxHeight:320,overflow:"auto"}}>
              {JSON.stringify(SAMPLE_JSON, null, 2)}
            </pre>
          )}
          <div onDragOver={e=>{e.preventDefault();setDraggingJson(true);}}
            onDragLeave={()=>setDraggingJson(false)}
            onDrop={e=>{e.preventDefault();setDraggingJson(false);const f=e.dataTransfer.files[0];if(f)processJson(f);}}
            onClick={()=>jsonInputRef.current?.click()}
            style={{marginTop:14,border:`2px dashed ${draggingJson?accent:"rgba(255,255,255,0.15)"}`,
              borderRadius:12,padding:"40px 28px",textAlign:"center",cursor:"pointer",
              background:draggingJson?"rgba(255,255,255,0.04)":"rgba(0,0,0,0.14)",transition:"all 0.3s"}}>
            <input ref={jsonInputRef} type="file" accept=".json" style={{display:"none"}}
              onChange={e=>{const f=e.target.files?.[0];if(f)processJson(f);}}/>
            <div style={{fontSize:36,marginBottom:10}}>📂</div>
            <div style={{fontFamily:hFont,fontSize:15,color:nColor,letterSpacing:"0.1em",marginBottom:4}}>
              {fileName??"Drop your JSON file here"}</div>
            <div style={{fontFamily:bFont,fontStyle:"italic",fontSize:12,color:dColor}}>
              {fileName?"Click to replace":"or click to browse · .json only"}</div>
          </div>
          {fileName && (
            <div style={{marginTop:12}}>
              {jsonOk ? (
                <div style={{background:"rgba(80,200,100,0.08)",border:"1px solid rgba(80,200,100,0.28)",
                  borderRadius:8,padding:"11px 16px",fontFamily:bFont,fontSize:13,color:"#80e890",
                  display:"flex",alignItems:"center",gap:10}}>
                  <span>✅</span>
                  <span><strong>{parsed?.families.length} generations</strong> · <strong>{parsed?.lineageSubject}</strong> · {slots.length} images required</span>
                </div>
              ) : (
                <div style={{background:"rgba(220,80,80,0.07)",border:"1px solid rgba(220,80,80,0.28)",
                  borderRadius:8,padding:"11px 16px"}}>
                  <div style={{fontFamily:bFont,fontSize:13,color:"#e88080",fontWeight:700,marginBottom:6}}>❌ Errors:</div>
                  {errors.map((e,i)=><div key={i} style={{fontFamily:"Consolas,monospace",fontSize:12,color:"#c06060",marginBottom:2}}>• {e}</div>)}
                </div>
              )}
            </div>
          )}
        </StepBox>

        {/* STEP 4 — Image Upload Grid */}
        {jsonOk && slots.length > 0 && (
          <StepBox id="step4" num="04" title="Upload Portrait Images" accent={accent} hFont={hFont} nColor={nColor}>

            {/* ── Test / Real Mode Toggle ── */}
            <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:16,
              padding:"10px 16px",borderRadius:8,
              background:testMode?"rgba(255,160,60,0.08)":"rgba(255,255,255,0.03)",
              border:`1px solid ${testMode?"rgba(255,160,60,0.35)":"rgba(255,255,255,0.10)"}`}}>
              <div style={{display:"flex",borderRadius:6,overflow:"hidden",border:"1px solid rgba(255,255,255,0.12)"}}>
                <button onClick={()=>{setTestMode(false);}}
                  style={{padding:"6px 18px",fontFamily:hFont,fontSize:11,letterSpacing:"0.14em",
                    cursor:"pointer",border:"none",
                    background:!testMode?accent:"transparent",
                    color:!testMode?"#000":dColor,transition:"all 0.2s"}}>
                  🎬 REAL
                </button>
                <button onClick={()=>{setTestMode(true);}}
                  style={{padding:"6px 18px",fontFamily:hFont,fontSize:11,letterSpacing:"0.14em",
                    cursor:"pointer",border:"none",
                    background:testMode?"#ff9f40":"transparent",
                    color:testMode?"#000":dColor,transition:"all 0.2s"}}>
                  🧪 TEST
                </button>
              </div>
              <div style={{fontFamily:bFont,fontSize:12,color:testMode?"#ff9f40":dColor,lineHeight:1.5}}>
                {testMode
                  ? "Drop ONE image anywhere — it will be used for every slot."
                  : "Upload individual portraits for every slot below."}
              </div>
            </div>

            <div style={{fontFamily:bFont,fontStyle:"italic",fontSize:13,color:dColor,marginBottom:16,lineHeight:1.7}}>
              {testMode
                ? <span style={{color:"#ff9f40"}}>Testing mode: drop any single image below and it fills all {slots.length} slots instantly.</span>
                : <><span>Upload portraits for every slot below.</span><span style={{color:accent}}> All {slots.length} images must be uploaded to continue.</span></>
              }
            </div>

            {/* Progress bar */}
            <div style={{marginBottom:18}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:5}}>
                <span style={{fontFamily:bFont,fontSize:13,color:dColor}}>
                  {slots.filter(s=>s.uploaded).length} / {slots.length} uploaded
                </span>
                {allUploaded && <span style={{fontFamily:bFont,fontSize:13,color:"#80e890"}}>✅ All images ready!</span>}
              </div>
              <div style={{height:4,borderRadius:2,background:"rgba(255,255,255,0.1)"}}>
                <div style={{height:"100%",borderRadius:2,transition:"width 0.4s",
                  width:`${(slots.filter(s=>s.uploaded).length/slots.length)*100}%`,
                  background:`linear-gradient(to right,${accent}88,${accent})`,
                  boxShadow:`0 0 10px ${accent}`}}/>
              </div>
            </div>

            {slotsByGen.map(({fam,fatherSlots,motherSlots,childSlots,wfFather,wfMother,wfSiblings,hasWf})=>(
              <div key={fam.id} style={{marginBottom:24,background:"rgba(255,255,255,0.025)",
                borderRadius:12,border:"1px solid rgba(255,255,255,0.07)",overflow:"hidden"}}>
                {/* Gen header */}
                <div style={{padding:"9px 16px",borderBottom:"1px solid rgba(255,255,255,0.06)",
                  background:"rgba(0,0,0,0.22)",display:"flex",alignItems:"center",gap:10}}>
                  <span style={{fontFamily:"Consolas,monospace",fontSize:9,color:accent,
                    background:`${accent}1a`,border:`1px solid ${accent}44`,padding:"2px 7px",borderRadius:3}}>
                    GEN {fam.id}</span>
                  <span style={{fontFamily:hFont,fontSize:13,color:nColor,letterSpacing:"0.06em"}}>{fam.era}</span>
                </div>

                <div style={{padding:"12px 16px"}}>
                  {/* Parents row */}
                  <div style={{fontFamily:bFont,fontSize:11,color:`${accent}88`,
                    letterSpacing:"0.12em",marginBottom:8}}>SON / FATHER + MOTHER</div>
                  <div style={{display:"flex",gap:10,flexWrap:"wrap",marginBottom:childSlots.length>0?12:0}}>
                    {[...fatherSlots,...motherSlots].map(s=>(
                      <SlotCard key={s.filename} slot={s} accent={accent} hFont={hFont}
                        bFont={bFont} nColor={nColor} dColor={dColor} onUpload={handleSlotUpload}/>
                    ))}
                  </div>

                  {/* Children */}
                  {childSlots.length > 0 && (
                    <div style={{paddingLeft:20,borderLeft:`2px solid ${accent}22`,marginBottom:hasWf?12:0}}>
                      <div style={{fontFamily:bFont,fontSize:11,color:`${accent}88`,
                        letterSpacing:"0.12em",marginBottom:8}}>↳ SON&apos;S SIBLINGS</div>
                      <div style={{display:"flex",gap:10,flexWrap:"wrap"}}>
                        {childSlots.map(s=>(
                          <SlotCard key={s.filename} slot={s} small accent={accent} hFont={hFont}
                            bFont={bFont} nColor={nColor} dColor={dColor} onUpload={handleSlotUpload}/>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Wife's family tree */}
                  {hasWf && (
                    <div style={{marginTop:12,paddingLeft:20,
                      borderLeft:`2px solid ${accent}44`,
                      background:`${accent}06`,borderRadius:8,padding:"10px 14px"}}>
                      <div style={{fontFamily:bFont,fontSize:11,color:accent,
                        letterSpacing:"0.12em",marginBottom:10}}>
                        ↳ WIFE&apos;S FAMILY TREE (shown on right side of screen)
                      </div>
                      {/* Wife's parents */}
                      <div style={{display:"flex",gap:10,flexWrap:"wrap",marginBottom:wfSiblings.length>0?10:0}}>
                        {[...wfFather,...wfMother].map(s=>(
                          <SlotCard key={s.filename} slot={s} accent={accent} hFont={hFont}
                            bFont={bFont} nColor={nColor} dColor={dColor} onUpload={handleSlotUpload}/>
                        ))}
                      </div>
                      {/* Wife's siblings */}
                      {wfSiblings.length > 0 && (
                        <div style={{paddingLeft:16,borderLeft:`2px solid ${accent}22`}}>
                          <div style={{fontFamily:bFont,fontSize:10,color:`${accent}66`,
                            letterSpacing:"0.12em",marginBottom:7}}>↳ WIFE&apos;S SIBLINGS</div>
                          <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                            {wfSiblings.map(s=>(
                              <SlotCard key={s.filename} slot={s} small accent={accent} hFont={hFont}
                                bFont={bFont} nColor={nColor} dColor={dColor} onUpload={handleSlotUpload}/>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </StepBox>
        )}

        {/* STEP 5 — Create */}
        <StepBox id="step5" num={jsonOk&&slots.length>0?"05":"04"} title="Generate Preview"
          accent={accent} hFont={hFont} nColor={nColor}>
          <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:14,padding:"8px 0"}}>
            {!jsonOk && (
              <div style={{fontFamily:bFont,fontStyle:"italic",fontSize:14,color:dColor,opacity:.5}}>
                Complete steps 1–3 first</div>
            )}
            {jsonOk && !allUploaded && slots.length > 0 && (
              <div style={{fontFamily:bFont,fontStyle:"italic",fontSize:14,color:`${accent}88`}}>
                Upload all {slots.length} images in Step 04 to continue</div>
            )}
            <button onClick={handleCreate}
              disabled={!jsonOk||(slots.length>0&&!allUploaded)}
              style={{background:jsonOk&&(slots.length===0||allUploaded)
                  ?`linear-gradient(135deg,${t.bgFrom},${t.bgTo})`:"rgba(255,255,255,0.04)",
                border:`2px solid ${jsonOk&&(slots.length===0||allUploaded)?accent:"rgba(255,255,255,0.1)"}`,
                color:jsonOk&&(slots.length===0||allUploaded)?nColor:"#444",
                fontFamily:hFont,fontSize:16,fontWeight:700,letterSpacing:"0.28em",
                padding:"18px 66px",cursor:jsonOk&&(slots.length===0||allUploaded)?"pointer":"not-allowed",
                borderRadius:8,transition:"all 0.4s",
                boxShadow:jsonOk&&(slots.length===0||allUploaded)?`0 0 30px ${accent}55`:"none",
                pointerEvents:jsonOk&&(slots.length===0||allUploaded)?"auto":"none"}}>
              CREATE NOW →
            </button>
            {jsonOk && (slots.length===0||allUploaded) && (
              <div style={{fontFamily:bFont,fontStyle:"italic",fontSize:13,color:dColor}}>
                {mounted&&THEMES[theme]?.icon} {mounted&&THEMES[theme]?.name} theme · {parsed?.families.length} generations
              </div>
            )}
          </div>
        </StepBox>
      </div>
    </div>
  );
}

// ── Image Slot Card ───────────────────────────────────────────
function SlotCard({slot,small,accent,hFont,bFont,nColor,dColor,onUpload}:{
  slot:ImageSlot;small?:boolean;accent:string;hFont:string;bFont:string;
  nColor:string;dColor:string;onUpload:(fn:string,f:File)=>void;
}){
  const [drag,setDrag]=useState(false);
  const inputRef=useRef<HTMLInputElement>(null);
  const size=small?90:118;
  const roleColors:Record<string,string>={
    "father":"#c9a84c","mother":"#9fbfcf","child":"#a0a0c0",
    "wf-father":"#e0a060","wf-mother":"#80c0d0","wf-child":"#b0b8c8"
  };
  const rc=roleColors[slot.role]??accent;
  const handle=(file:File)=>{ if(file.type.startsWith("image/")) onUpload(slot.filename,file); };
  return(
    <div onDragOver={e=>{e.preventDefault();setDrag(true);}} onDragLeave={()=>setDrag(false)}
      onDrop={e=>{e.preventDefault();setDrag(false);const f=e.dataTransfer.files[0];if(f)handle(f);}}
      onClick={()=>inputRef.current?.click()}
      title={slot.filename}
      style={{width:size,flexShrink:0,cursor:"pointer",borderRadius:10,overflow:"hidden",
        border:`2px solid ${drag?accent:slot.uploaded?rc+"88":"rgba(255,255,255,0.12)"}`,
        background:drag?"rgba(255,255,255,0.06)":"rgba(0,0,0,0.25)",
        boxShadow:slot.uploaded?`0 0 14px ${rc}44`:drag?`0 0 20px ${accent}44`:"none",
        transition:"all 0.25s",position:"relative"}}>
      <input ref={inputRef} type="file" accept="image/*" style={{display:"none"}}
        onChange={e=>{const f=e.target.files?.[0];if(f)handle(f);}}/>
      <div style={{width:size,height:size,position:"relative",background:"rgba(0,0,0,0.3)",
        display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden"}}>
        {slot.preview?(
          // eslint-disable-next-line @next/next/no-img-element
          <img src={slot.preview} alt={slot.label}
            style={{width:"100%",height:"100%",objectFit:"cover"}}/>
        ):(
          <div style={{textAlign:"center",padding:4}}>
            <div style={{fontSize:small?18:22,opacity:.3}}>👤</div>
            <div style={{fontFamily:"Consolas,monospace",fontSize:7,color:"rgba(255,255,255,0.22)",
              marginTop:3,wordBreak:"break-all",lineHeight:1.3,padding:"0 3px"}}>
              {slot.filename}</div>
          </div>
        )}
        {drag&&!slot.preview&&(
          <div style={{position:"absolute",inset:0,display:"flex",alignItems:"center",
            justifyContent:"center",background:"rgba(0,0,0,0.55)"}}>
            <span style={{fontSize:20}}>⬆️</span>
          </div>
        )}
        {slot.uploaded&&(
          <div style={{position:"absolute",top:3,right:3,background:"rgba(80,200,80,0.9)",
            borderRadius:"50%",width:16,height:16,display:"flex",alignItems:"center",
            justifyContent:"center",fontSize:9}}>✓</div>
        )}
      </div>
      <div style={{padding:"4px 5px",borderTop:"1px solid rgba(255,255,255,0.07)",background:"rgba(0,0,0,0.4)"}}>
        <div style={{fontFamily:bFont,fontSize:small?9:10,color:slot.uploaded?rc:dColor,
          lineHeight:1.3,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}
          title={slot.label}>{slot.label}</div>
        <div style={{fontFamily:"Consolas,monospace",fontSize:8,
          color:slot.uploaded?"rgba(80,200,80,0.7)":"rgba(255,255,255,0.18)",
          marginTop:1,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis"}}>
          {slot.uploaded?"✓ "+slot.filename:slot.filename}</div>
      </div>
    </div>
  );
}

// ── Ring Preview Canvas ───────────────────────────────────────
function RingPreview({th,active}:{th:Theme;active:boolean}){
  const ref=useRef<HTMLCanvasElement>(null);
  const rafRef=useRef(0);
  useEffect(()=>{
    const c=ref.current; if(!c) return;
    const ctx=c.getContext("2d"); if(!ctx) return;
    const W=110,H=110,cx=55,cy=55,r=30;
    const [cr,cg,cb]=th.fatherColor;
    const style=th.ringStyle;
    const rgba=(a:number)=>`rgba(${cr},${cg},${cb},${Math.max(0,a).toFixed(3)})`;
    let t=0;
    function draw(){
      t++;
      const alpha=active?1:0.38;
      const pulse=.65+.35*Math.sin(t*.04);
      ctx!.clearRect(0,0,W,H);
      const bg=ctx!.createRadialGradient(cx,cy,0,cx,cy,60);
      bg.addColorStop(0,th.bgFrom+"ee"); bg.addColorStop(1,th.bgTo+"ff");
      ctx!.fillStyle=bg; ctx!.fillRect(0,0,W,H);
      if(style==="glow"){
        const g=ctx!.createRadialGradient(cx,cy,r*.5,cx,cy,r*2.2);
        g.addColorStop(0,rgba(.22*pulse*alpha)); g.addColorStop(1,rgba(0));
        ctx!.beginPath(); ctx!.arc(cx,cy,r*2.2,0,Math.PI*2); ctx!.fillStyle=g; ctx!.fill();
        ctx!.save(); ctx!.shadowBlur=22*pulse; ctx!.shadowColor=rgba(alpha);
        ctx!.strokeStyle=rgba(.9*pulse*alpha); ctx!.lineWidth=3.5;
        ctx!.beginPath(); ctx!.arc(cx,cy,r,0,Math.PI*2); ctx!.stroke(); ctx!.restore();
        ctx!.save(); ctx!.translate(cx,cy); ctx!.rotate(t*.018);
        ctx!.strokeStyle=rgba(.24*pulse*alpha); ctx!.lineWidth=1.2; ctx!.setLineDash([9,7]);
        ctx!.beginPath(); ctx!.arc(0,0,r+13,0,Math.PI*2); ctx!.stroke(); ctx!.setLineDash([]); ctx!.restore();
        for(let i=0;i<2;i++){const wt=(t*.8+i*30)%44;const wA=Math.max(0,1-wt/44)*.4*pulse*alpha;
          if(wA<.01)continue;ctx!.beginPath();ctx!.arc(cx,cy,r+wt*.7,0,Math.PI*2);
          ctx!.strokeStyle=rgba(wA);ctx!.lineWidth=1.5;ctx!.stroke();}
      } else if(style==="sharp"){
        ctx!.save(); ctx!.shadowBlur=10*pulse; ctx!.shadowColor=rgba(alpha*.7);
        ctx!.strokeStyle=rgba(.95*alpha); ctx!.lineWidth=2.5; ctx!.beginPath();
        for(let i=0;i<8;i++){const ang=i/8*Math.PI*2-Math.PI/8;
          i===0?ctx!.moveTo(cx+r*Math.cos(ang),cy+r*Math.sin(ang)):ctx!.lineTo(cx+r*Math.cos(ang),cy+r*Math.sin(ang));}
        ctx!.closePath(); ctx!.stroke(); ctx!.restore();
        ctx!.save(); ctx!.translate(cx,cy); ctx!.rotate(t*.025);
        ctx!.strokeStyle=rgba(.5*alpha); ctx!.lineWidth=1.8;
        for(let i=0;i<4;i++){const ang=i/4*Math.PI*2;ctx!.beginPath();
          ctx!.moveTo(r*Math.cos(ang),r*Math.sin(ang));ctx!.lineTo((r+13)*Math.cos(ang),(r+13)*Math.sin(ang));ctx!.stroke();}
        ctx!.restore();
      } else if(style==="dashed"){
        [[r,.022],[r+10,-.015],[r+20,.009]].forEach(([ri,sp],i)=>{
          ctx!.save(); ctx!.translate(cx,cy); ctx!.rotate(t*(sp as number));
          ctx!.strokeStyle=rgba((.85-.2*i)*pulse*alpha);
          ctx!.lineWidth=[3,1.8,1.3][i]; ctx!.setLineDash([[7,7],[5,10],[9,5]][i]);
          ctx!.shadowBlur=16-i*4; ctx!.shadowColor=rgba(alpha*.8);
          ctx!.beginPath(); ctx!.arc(0,0,ri as number,0,Math.PI*2); ctx!.stroke();
          ctx!.setLineDash([]); ctx!.restore();
        });
        ctx!.save(); ctx!.translate(cx,cy); ctx!.rotate(t*.01);
        for(let i=0;i<6;i++){const ang=i/6*Math.PI*2;ctx!.beginPath();
          ctx!.arc((r+10)*Math.cos(ang),(r+10)*Math.sin(ang),2,0,Math.PI*2);
          ctx!.fillStyle=rgba(.65*pulse*alpha);ctx!.fill();}
        ctx!.restore();
      } else if(style==="double"){
        const gv=ctx!.createRadialGradient(cx,cy,r*.6,cx,cy,r*2.4);
        gv.addColorStop(0,rgba(.22*pulse*alpha)); gv.addColorStop(.5,rgba(.08*pulse*alpha)); gv.addColorStop(1,rgba(0));
        ctx!.beginPath(); ctx!.arc(cx,cy,r*2.4,0,Math.PI*2); ctx!.fillStyle=gv; ctx!.fill();
        ctx!.save(); ctx!.shadowBlur=20*pulse; ctx!.shadowColor=rgba(alpha);
        ctx!.strokeStyle=rgba(.88*pulse*alpha); ctx!.lineWidth=3.5;
        ctx!.beginPath(); ctx!.arc(cx,cy,r,0,Math.PI*2); ctx!.stroke(); ctx!.restore();
        ctx!.save(); ctx!.translate(cx,cy); ctx!.rotate(-t*.012);
        ctx!.strokeStyle=rgba(.5*pulse*alpha); ctx!.lineWidth=2; ctx!.setLineDash([14,6]);
        ctx!.beginPath(); ctx!.arc(0,0,r-8,0,Math.PI*2); ctx!.stroke(); ctx!.setLineDash([]); ctx!.restore();
        ctx!.save(); ctx!.translate(cx,cy); ctx!.rotate(t*.019);
        for(let i=0;i<4;i++){const ang=i/4*Math.PI*2;ctx!.beginPath();
          ctx!.arc((r+16)*Math.cos(ang),(r+16)*Math.sin(ang),3,0,Math.PI*2);
          ctx!.fillStyle=rgba(.78*pulse*alpha);ctx!.fill();}
        ctx!.restore();
      }
      rafRef.current=requestAnimationFrame(draw);
    }
    rafRef.current=requestAnimationFrame(draw);
    return()=>cancelAnimationFrame(rafRef.current);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  },[th.id,active]);
  return <canvas ref={ref} width={110} height={110}
    style={{width:110,height:110,borderRadius:"50%",opacity:active?1:0.5,transition:"opacity 0.3s"}}/>;
}

// ── Helpers ───────────────────────────────────────────────────
function StepBox({id,num,title,accent,hFont,nColor,children}:{
  id?:string;num:string;title:string;accent:string;hFont:string;nColor:string;children:React.ReactNode;
}){
  return(
    <div id={id} style={{marginBottom:36,padding:"26px 32px",background:"rgba(0,0,0,0.22)",
      border:"1px solid rgba(255,255,255,0.07)",borderRadius:16}}>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        <span style={{fontFamily:"Consolas,monospace",fontSize:10,color:accent,
          background:`${accent}22`,border:`1px solid ${accent}55`,padding:"3px 9px",borderRadius:4}}>
          STEP {num}</span>
        <span style={{fontFamily:hFont,fontSize:18,color:nColor,letterSpacing:"0.06em"}}>{title}</span>
      </div>
      {children}
    </div>
  );
}
function ghostBtn(accent:string,bFont:string):React.CSSProperties{
  return{background:"none",border:`1px solid ${accent}66`,color:accent,
    fontFamily:bFont,fontSize:12,letterSpacing:"0.15em",padding:"8px 16px",
    cursor:"pointer",borderRadius:6,display:"inline-block",
    textDecoration:"none",outline:"none",boxSizing:"border-box"};
}
