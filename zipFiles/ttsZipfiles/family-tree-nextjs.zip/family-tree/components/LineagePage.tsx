"use client";

/**
 * LAYOUT (matches the hand-drawn sketch):
 *
 *  ┌─────────────────────────────────────────────────────────────┐
 *  │                     HEADING / ERA                           │
 *  │                                                             │
 *  │  [details]  ●Father ────────────►  ●Father(next gen)        │
 *  │             │                      │                        │
 *  │             │ (arrow down then →)  │                        │
 *  │             ▼                      ▼                        │
 *  │  [details]  ●Mother ────────────►  ●Mother(next gen)        │
 *  │                                                             │
 *  │  ─────────────────── TIMELINE BAR ───────────────────────── │
 *  └─────────────────────────────────────────────────────────────┘
 *
 *  - Left column  = current generation (father top, mother bottom)
 *  - Right column = NEXT generation   (father top, mother bottom)
 *  - Arrows: father-left → father-right  AND  mother-left → mother-right
 *  - Plus:   father-left → mother-left   (vertical, within same gen)
 *  - Canvas draws all arrows + glow rings
 *  - The whole scene slides left each time user advances
 */

import React, { useRef, useEffect, useState, useCallback } from "react";
import Image from "next/image";
import { useLineageCanvas, RingNode, ArrowDef } from "@/lib/canvasEngine";
import { LINEAGE_DATA, CHANNEL_NAME, VIDEO_TITLE, LINEAGE_SUBJECT, Family } from "@/lib/lineageData";

// ── Layout constants ────────────────────────────────────────
const W  = 1920;
const H  = 1080;
const IMG = 200;          // profile circle diameter px
const R   = IMG / 2;      // radius
const AUTO_MS = 7000;

// Positions for LEFT column (current gen) and RIGHT column (next gen)
// Placed deliberately so arrows are long and visible
const COL_LEFT  = 380;    // center-x of left  column
const COL_RIGHT = 1380;   // center-x of right column
const ROW_TOP   = 330;    // center-y of father row
const ROW_BOT   = 700;    // center-y of mother row

// ── Person card (image + text) ──────────────────────────────
function PersonCard({
  person,
  imgSrc,
  role,
  side,
  onImgRef,
  visible,
  delay,
}: {
  person: { name: string; life: string; title: string; desc: string };
  imgSrc: string;
  role: "father" | "mother";
  side: "left" | "right";
  onImgRef: (el: HTMLDivElement | null) => void;
  visible: boolean;
  delay: number;
}) {
  const isGold   = role === "father";
  const textLeft = side === "left";

  return (
    <div style={{
      display: "flex",
      flexDirection: textLeft ? "row" : "row-reverse",
      alignItems: "center",
      gap: 36,
      opacity: visible ? 1 : 0,
      transform: visible ? "none" : `translateX(${textLeft ? -40 : 40}px)`,
      transition: `opacity 0.85s ease ${delay}ms, transform 0.85s ease ${delay}ms`,
    }}>
      {/* Text block */}
      <div style={{
        display: "flex", flexDirection: "column", gap: 9,
        maxWidth: 360,
        textAlign: textLeft ? "right" : "left",
      }}>
        <div style={{
          fontFamily: "'Cinzel', serif",
          fontSize: 30, fontWeight: 700,
          letterSpacing: "0.06em", lineHeight: 1.2,
          color: isGold ? "#f0d080" : "#c2d6e2",
          textShadow: isGold
            ? "0 0 28px rgba(201,168,76,0.75), 0 2px 6px rgba(0,0,0,0.7)"
            : "0 0 24px rgba(159,191,207,0.65), 0 2px 6px rgba(0,0,0,0.7)",
        }}>{person.name}</div>

        <div style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontStyle: "italic", fontSize: 20, letterSpacing: "0.13em",
          color: isGold ? "#8a7840" : "#5a7888",
        }}>{person.life}</div>

        <div style={{
          fontFamily: "'Cinzel', serif",
          fontSize: 17, fontWeight: 600, letterSpacing: "0.07em",
          color: isGold ? "#c9a84c" : "#7aaabb",
          lineHeight: 1.45,
        }}>{person.title}</div>

        <div style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontStyle: "italic", fontSize: 19, letterSpacing: "0.03em",
          color: "#8a8070", lineHeight: 1.65,
        }}>{person.desc}</div>
      </div>

      {/* Profile circle */}
      <div
        ref={onImgRef}
        style={{
          width: IMG, height: IMG,
          borderRadius: "50%",
          overflow: "hidden",
          flexShrink: 0,
          position: "relative",
          background: isGold ? "#1a1308" : "#080d14",
          border: `2px solid ${isGold ? "rgba(201,168,76,0.25)" : "rgba(159,191,207,0.2)"}`,
        }}
      >
        <Image src={imgSrc} alt={person.name} fill style={{ objectFit: "cover" }} unoptimized />
      </div>
    </div>
  );
}

// ── Refs for one generation's DOM elements ──────────────────
interface GenRefs {
  fatherEl: HTMLDivElement | null;
  motherEl: HTMLDivElement | null;
}

// ── Main page ───────────────────────────────────────────────
export default function LineagePage() {
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const scaleRef   = useRef(1);
  const autoRef    = useRef<ReturnType<typeof setInterval> | null>(null);

  // DOM refs: refsMap[i] = { fatherEl, motherEl } for generation i
  const refsMap = useRef<Map<number, GenRefs>>(new Map());

  const [currentGen,  setCurrentGen]  = useState(-1);
  const [visibleSet,  setVisibleSet]  = useState<Set<number>>(new Set());
  const [introShow,   setIntroShow]   = useState(true);
  const [started,     setStarted]     = useState(false);
  const [scale,       setScale]       = useState(1);

  const { start, stop, setRings, setArrows } = useLineageCanvas(canvasRef);

  // ── Scale ─────────────────────────────────────────────────
  useEffect(() => {
    const upd = () => {
      const s = Math.min(window.innerWidth / W, window.innerHeight / H);
      setScale(s); scaleRef.current = s;
    };
    upd();
    window.addEventListener("resize", upd);
    return () => window.removeEventListener("resize", upd);
  }, []);

  useEffect(() => { start(); return () => stop(); }, [start, stop]);

  // ── Convert DOM el → canvas coords ────────────────────────
  const toCanvas = useCallback((el: HTMLElement) => {
    const canvas = canvasRef.current!;
    const er = el.getBoundingClientRect();
    const cr = canvas.getBoundingClientRect();
    const s  = scaleRef.current;
    return {
      cx: (er.left + er.width  / 2 - cr.left) / s,
      cy: (er.top  + er.height / 2 - cr.top ) / s,
    };
  }, []);

  // ── Rebuild canvas rings + arrows ─────────────────────────
  const updateCanvas = useCallback(() => {
    if (!canvasRef.current) return;
    const rings:  RingNode[] = [];
    const arrows: Omit<ArrowDef, "progress" | "travelT">[] = [];

    visibleSet.forEach(gi => {
      const cur  = refsMap.current.get(gi);
      const next = refsMap.current.get(gi + 1);
      if (!cur) return;

      // ── Rings for current gen ──
      if (cur.fatherEl) {
        const f = toCanvas(cur.fatherEl);
        rings.push({ cx: f.cx, cy: f.cy, radius: R, color: "gold",   phase: gi * 1.1 });

        if (cur.motherEl) {
          const m = toCanvas(cur.motherEl);
          rings.push({ cx: m.cx, cy: m.cy, radius: R, color: "silver", phase: gi * 2.2 + 0.5 });

          // Arrow: father → mother  (vertical, right-side of circle)
          arrows.push({
            id: `fm-${gi}`,
            fromX: f.cx + R * 0.6, fromY: f.cy + R + 8,
            toX:   m.cx + R * 0.6, toY:   m.cy - R - 8,
          });
        }
      }

      // ── Arrows: current gen → next gen ──
      if (next?.fatherEl && cur.fatherEl) {
        const f  = toCanvas(cur.fatherEl);
        const nf = toCanvas(next.fatherEl);
        // Father-left → Father-right: exits right edge of left circle
        arrows.push({
          id: `ff-${gi}`,
          fromX: f.cx  + R + 8, fromY: f.cy,
          toX:   nf.cx - R - 8, toY:   nf.cy,
        });
      }

      if (next?.motherEl && cur.motherEl) {
        const m  = toCanvas(cur.motherEl);
        const nm = toCanvas(next.motherEl);
        // Mother-left → Mother-right
        arrows.push({
          id: `mm-${gi}`,
          fromX: m.cx  + R + 8, fromY: m.cy,
          toX:   nm.cx - R - 8, toY:   nm.cy,
        });
      }

      // Also: mother-left → next father (diagonal — lineage continuation)
      if (next?.fatherEl && cur.motherEl) {
        const m  = toCanvas(cur.motherEl);
        const nf = toCanvas(next.fatherEl);
        arrows.push({
          id: `mn-${gi}`,
          fromX: m.cx + R + 8, fromY: m.cy - R * 0.3,
          toX:   nf.cx - R - 8, toY:   nf.cy + R * 0.3,
        });
      }

      // Rings for NEXT gen too (so they glow when visible)
      if (next?.fatherEl) {
        const nf = toCanvas(next.fatherEl);
        rings.push({ cx: nf.cx, cy: nf.cy, radius: R, color: "gold",  phase: (gi+1)*1.1 });
      }
      if (next?.motherEl) {
        const nm = toCanvas(next.motherEl);
        rings.push({ cx: nm.cx, cy: nm.cy, radius: R, color: "silver", phase: (gi+1)*2.2+0.5 });
      }
    });

    setRings(rings);
    setArrows(arrows);
  }, [visibleSet, toCanvas, setRings, setArrows]);

  useEffect(() => {
    const id = setTimeout(updateCanvas, 160);
    return () => clearTimeout(id);
  }, [updateCanvas, scale]);

  // ── Navigation ────────────────────────────────────────────
  const goToGen = useCallback((idx: number) => {
    setCurrentGen(idx);
    setVisibleSet(prev => {
      const s = new Set(prev);
      s.add(idx);
      if (idx > 0) s.add(idx - 1);
      return s;
    });
  }, []);

  const startAuto = useCallback(() => {
    let i = 0; goToGen(i);
    autoRef.current = setInterval(() => {
      i++;
      if (i >= LINEAGE_DATA.length) { clearInterval(autoRef.current!); return; }
      goToGen(i);
    }, AUTO_MS);
  }, [goToGen]);

  const handleStart = useCallback(() => {
    setIntroShow(false); setStarted(true);
    setTimeout(startAuto, 900);
  }, [startAuto]);

  useEffect(() => () => { if (autoRef.current) clearInterval(autoRef.current); }, []);

  const manualNav = useCallback((dir: number) => {
    if (autoRef.current) clearInterval(autoRef.current);
    setCurrentGen(prev => {
      const nx = Math.max(0, Math.min(LINEAGE_DATA.length - 1, prev + dir));
      goToGen(nx); return nx;
    });
  }, [goToGen]);

  const jumpTo = useCallback((i: number) => {
    if (autoRef.current) clearInterval(autoRef.current);
    goToGen(i); setCurrentGen(i);
  }, [goToGen]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === "ArrowDown") manualNav(1);
      if (e.key === "ArrowLeft"  || e.key === "ArrowUp")   manualNav(-1);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [manualNav]);

  // ── Horizontal slide offset ───────────────────────────────
  // Each "slide" shows gen[i] on left, gen[i+1] on right.
  // We shift the strip by currentGen * W.
  const stripX = started ? currentGen * W : 0;

  return (
    <>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Cinzel:wght@400;600;700&family=Cinzel+Decorative:wght@400;700&display=swap');`}</style>

      <div style={{ width: "100vw", height: "100vh", background: "#060810", overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center" }}>

        {/* ── Scaled stage (1920×1080) ── */}
        <div style={{
          width: W, height: H,
          transform: `scale(${scale})`,
          transformOrigin: "center center",
          position: "relative",
          overflow: "hidden",
          flexShrink: 0,
        }}>
          {/* Canvas layer */}
          <canvas ref={canvasRef} width={W} height={H} style={{ position: "absolute", inset: 0, zIndex: 0 }} />

          {/* ── INTRO ── */}
          <div style={{
            position: "absolute", inset: 0, zIndex: 50,
            display: "flex", flexDirection: "column",
            alignItems: "center", justifyContent: "center", gap: 30,
            opacity: introShow ? 1 : 0,
            pointerEvents: introShow ? "auto" : "none",
            transition: "opacity 1s ease",
          }}>
            <div style={{
              fontFamily: "'Cinzel Decorative', serif",
              fontSize: 90, letterSpacing: "0.1em", lineHeight: 1,
              color: "#f0d080",
              textShadow: "0 0 80px rgba(201,168,76,0.7), 0 0 160px rgba(201,168,76,0.35)",
            }}>
              {CHANNEL_NAME.split(" ").map((w, i) => (
                <span key={i} style={{ color: i === 1 ? "#c2d6e2" : "#f0d080" }}>{w} </span>
              ))}
            </div>
            <div style={{ width: 380, height: 1, background: "linear-gradient(to right,transparent,#c9a84c,transparent)" }} />
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: 32, letterSpacing: "0.18em", color: "#9b8e7a" }}>
              The Lineage of
            </div>
            <div style={{ fontFamily: "'Cinzel', serif", fontSize: 26, fontWeight: 700, letterSpacing: "0.2em", color: "#c2d6e2" }}>
              {LINEAGE_SUBJECT}
            </div>
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: 22, color: "#7a6030" }}>
              {VIDEO_TITLE}
            </div>
            <button onClick={handleStart} style={{
              marginTop: 44, background: "none",
              border: "1px solid rgba(201,168,76,0.5)", color: "#c9a84c",
              fontFamily: "'Cinzel', serif", fontSize: 15, letterSpacing: "0.35em",
              padding: "18px 60px", cursor: "pointer",
              textShadow: "0 0 14px rgba(201,168,76,0.5)", transition: "all 0.3s",
            }}
              onMouseEnter={e => { e.currentTarget.style.background = "rgba(201,168,76,0.12)"; e.currentTarget.style.boxShadow = "0 0 40px rgba(201,168,76,0.4)"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "none"; e.currentTarget.style.boxShadow = "none"; }}
            >
              BEGIN THE LINEAGE ›
            </button>
          </div>

          {/* ── CONTENT STRIP ── */}
          <div style={{
            position: "absolute", inset: 0, zIndex: 1,
            overflow: "hidden",
            opacity: started ? 1 : 0,
            transition: "opacity 0.8s ease",
          }}>
            <div style={{
              display: "flex", flexDirection: "row", height: "100%",
              transform: `translateX(-${stripX}px)`,
              transition: "transform 1.5s cubic-bezier(0.25,0.46,0.45,0.94)",
              willChange: "transform",
            }}>
              {LINEAGE_DATA.map((fam, idx) => (
                <SlidePanel
                  key={fam.id}
                  family={fam}
                  genIdx={idx}
                  nextFamily={LINEAGE_DATA[idx + 1] ?? null}
                  visible={visibleSet.has(idx)}
                  onRefs={refs => refsMap.current.set(idx, refs)}
                />
              ))}
            </div>
          </div>

          {/* ── CHANNEL HEADER ── */}
          {started && (
            <div style={{
              position: "absolute", top: 0, left: 0, right: 0, zIndex: 10,
              display: "flex", justifyContent: "space-between", alignItems: "center",
              padding: "30px 80px 56px",
              background: "linear-gradient(to bottom, rgba(6,8,16,0.96) 50%, transparent)",
              pointerEvents: "none",
            }}>
              <div style={{ fontFamily: "'Cinzel Decorative', serif", fontSize: 24, letterSpacing: "0.1em", color: "#f0d080", textShadow: "0 0 20px rgba(201,168,76,0.55)" }}>
                {CHANNEL_NAME.split(" ").map((w, i) => <span key={i} style={{ color: i===1?"#c2d6e2":"#f0d080" }}>{w} </span>)}
              </div>
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: 17, letterSpacing: "0.2em", color: "rgba(155,142,122,0.5)" }}>
                Every name carries a story
              </div>
            </div>
          )}

          {/* ── BOTTOM TIMELINE + NAV ── */}
          {started && currentGen >= 0 && (
            <div style={{
              position: "absolute", bottom: 0, left: 0, right: 0, zIndex: 10,
              background: "linear-gradient(to top, rgba(6,8,16,0.97) 55%, transparent)",
              padding: "36px 100px 40px",
            }}>
              {/* Generation label */}
              <div style={{
                textAlign: "center",
                fontFamily: "'Cinzel', serif", fontSize: 11, letterSpacing: "0.55em",
                color: "rgba(201,168,76,0.35)", marginBottom: 18,
              }}>
                GENERATION {currentGen + 1} OF {LINEAGE_DATA.length}
              </div>

              {/* Timeline nodes */}
              <div style={{ display: "flex", alignItems: "center" }}>
                {LINEAGE_DATA.map((fam, i) => (
                  <React.Fragment key={i}>
                    {i > 0 && (
                      <div style={{
                        flex: 1, height: 1,
                        background: i <= currentGen
                          ? "linear-gradient(to right,rgba(201,168,76,0.7),rgba(201,168,76,0.45))"
                          : "rgba(201,168,76,0.1)",
                        transition: "background 0.8s ease",
                      }} />
                    )}
                    <div onClick={() => jumpTo(i)} style={{
                      display: "flex", flexDirection: "column", alignItems: "center",
                      gap: 8, cursor: "pointer", padding: "0 14px", flexShrink: 0,
                    }}>
                      <div style={{
                        width: i === currentGen ? 14 : 8, height: i === currentGen ? 14 : 8,
                        borderRadius: "50%",
                        background: i === currentGen ? "#c9a84c" : i < currentGen ? "rgba(201,168,76,0.5)" : "rgba(201,168,76,0.15)",
                        boxShadow: i === currentGen ? "0 0 18px rgba(201,168,76,1),0 0 36px rgba(201,168,76,0.5)" : "none",
                        transition: "all 0.4s ease",
                      }} />
                      <div style={{
                        fontFamily: "'Cinzel', serif", fontSize: 10, letterSpacing: "0.18em",
                        color: i === currentGen ? "#c9a84c" : "rgba(201,168,76,0.28)",
                        textShadow: i === currentGen ? "0 0 10px rgba(201,168,76,0.7)" : "none",
                        transition: "all 0.4s ease", whiteSpace: "nowrap",
                      }}>
                        {fam.father.name.split(" ")[0].toUpperCase()}
                      </div>
                      <div style={{
                        fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic",
                        fontSize: 11, color: "rgba(155,142,122,0.35)", whiteSpace: "nowrap",
                      }}>
                        {fam.era.split("·")[1]?.trim() ?? ""}
                      </div>
                    </div>
                  </React.Fragment>
                ))}
              </div>

              {/* Prev / Next */}
              <div style={{ display: "flex", justifyContent: "center", gap: 24, marginTop: 20 }}>
                <NavBtn label="‹ PREV" onClick={() => manualNav(-1)} />
                <NavBtn label="NEXT ›" onClick={() => manualNav(1)}  />
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ── SlidePanel: one 1920×1080 slide showing current gen (left) + next gen (right) ──
function SlidePanel({
  family, genIdx, nextFamily, visible, onRefs,
}: {
  family: Family;
  genIdx: number;
  nextFamily: Family | null;
  visible: boolean;
  onRefs: (r: GenRefs) => void;
}) {
  const fRef = useRef<HTMLDivElement | null>(null);
  const mRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => { onRefs({ fatherEl: fRef.current, motherEl: mRef.current }); });

  const isSubject = !!family.isSubject;
  const fImg = `/assets/familyNo${family.id}father.jpg`;
  const mImg = `/assets/familyNo${family.id}mother.jpg`;

  return (
    <div
      data-gen-id={genIdx}
      style={{
        width: W, height: H,
        flexShrink: 0, position: "relative",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}
    >
      {/* ── ERA HEADING ── */}
      <div style={{
        position: "absolute", top: 110, left: 0, right: 0,
        textAlign: "center",
        fontFamily: "'Cinzel', serif", fontSize: 15, letterSpacing: "0.55em",
        color: isSubject ? "rgba(201,168,76,0.7)" : "rgba(201,168,76,0.3)",
        textTransform: "uppercase",
        textShadow: isSubject ? "0 0 20px rgba(201,168,76,0.5)" : "none",
        opacity: visible ? 1 : 0, transition: "opacity 0.9s ease 0.1s",
      }}>
        {family.era}
        {isSubject && " · ✦ THE SUBJECT ✦"}
      </div>

      {/* ── LEFT COLUMN: current gen father (top) + mother (bottom) ── */}
      <div style={{
        position: "absolute",
        left: 60,
        top: 0, bottom: 0,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        gap: 0,
      }}>
        {/* Father */}
        <div style={{ position: "absolute", top: ROW_TOP - IMG/2 - 20, left: 0 }}>
          <PersonCard
            person={family.father}
            imgSrc={fImg}
            role="father"
            side="left"
            onImgRef={el => (fRef.current = el)}
            visible={visible}
            delay={0}
          />
        </div>

        {/* Mother */}
        {family.mother && (
          <div style={{ position: "absolute", top: ROW_BOT - IMG/2 - 20, left: 0 }}>
            <PersonCard
              person={family.mother}
              imgSrc={mImg}
              role="mother"
              side="left"
              onImgRef={el => (mRef.current = el)}
              visible={visible}
              delay={200}
            />
          </div>
        )}

        {/* Subject-only: no mother */}
        {!family.mother && (
          <div style={{
            position: "absolute", top: ROW_BOT - 20, left: 0,
            display: "flex", alignItems: "center", gap: 14,
            opacity: visible ? 1 : 0, transition: "opacity 0.9s ease 0.3s",
          }}>
            <div style={{ width: 90, height: 1, background: "linear-gradient(to right,transparent,rgba(201,168,76,0.4))" }} />
            <div style={{
              fontFamily: "'Cinzel', serif", fontSize: 13, letterSpacing: "0.4em",
              color: "#c9a84c", textShadow: "0 0 14px rgba(201,168,76,0.7)",
              whiteSpace: "nowrap",
            }}>✦ THE SUBJECT ✦</div>
            <div style={{ width: 90, height: 1, background: "linear-gradient(to left,transparent,rgba(201,168,76,0.4))" }} />
          </div>
        )}
      </div>

      {/* ── RIGHT COLUMN: next gen preview (father top, mother bottom) ── */}
      {nextFamily && (
        <div style={{ position: "absolute", right: 0, top: 0, bottom: 0 }}>
          <NextGenPreview family={nextFamily} visible={visible} />
        </div>
      )}

      {/* ── CENTER DECORATION ── */}
      <div style={{
        position: "absolute",
        left: W / 2 - 1, top: "20%", bottom: "20%",
        width: 1,
        background: "linear-gradient(to bottom, transparent, rgba(201,168,76,0.12) 30%, rgba(201,168,76,0.12) 70%, transparent)",
        pointerEvents: "none",
      }} />
    </div>
  );
}

// ── Next gen preview: right side, circles only (no heavy text) ──
function NextGenPreview({ family, visible }: { family: Family; visible: boolean }) {
  const fImg = `/assets/familyNo${family.id}father.jpg`;
  const mImg = `/assets/familyNo${family.id}mother.jpg`;

  return (
    <>
      {/* Father top-right */}
      <div style={{
        position: "absolute",
        right: 80,
        top: ROW_TOP - IMG/2 - 20,
        display: "flex", flexDirection: "row-reverse", alignItems: "center", gap: 28,
        opacity: visible ? 0.7 : 0,
        transform: visible ? "none" : "translateX(40px)",
        transition: "opacity 0.9s ease 0.4s, transform 0.9s ease 0.4s",
      }}>
        <PreviewCircle imgSrc={fImg} name={family.father.name} role="father" />
        <div style={{ textAlign: "right" }}>
          <div style={{ fontFamily: "'Cinzel', serif", fontSize: 20, fontWeight: 700, color: "#f0d080", opacity: 0.8 }}>{family.father.name}</div>
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: 16, color: "#7a7060" }}>{family.era}</div>
        </div>
      </div>

      {/* Mother bottom-right */}
      {family.mother && (
        <div style={{
          position: "absolute",
          right: 80,
          top: ROW_BOT - IMG/2 - 20,
          display: "flex", flexDirection: "row-reverse", alignItems: "center", gap: 28,
          opacity: visible ? 0.7 : 0,
          transform: visible ? "none" : "translateX(40px)",
          transition: "opacity 0.9s ease 0.6s, transform 0.9s ease 0.6s",
        }}>
          <PreviewCircle imgSrc={mImg} name={family.mother.name} role="mother" />
          <div style={{ textAlign: "right" }}>
            <div style={{ fontFamily: "'Cinzel', serif", fontSize: 20, fontWeight: 700, color: "#c2d6e2", opacity: 0.8 }}>{family.mother.name}</div>
          </div>
        </div>
      )}
    </>
  );
}

function PreviewCircle({ imgSrc, name, role }: { imgSrc: string; name: string; role: "father" | "mother" }) {
  const isGold = role === "father";
  return (
    <div style={{
      width: IMG * 0.85, height: IMG * 0.85,
      borderRadius: "50%", overflow: "hidden", flexShrink: 0, position: "relative",
      background: isGold ? "#1a1308" : "#080d14",
      border: `2px solid ${isGold ? "rgba(201,168,76,0.2)" : "rgba(159,191,207,0.15)"}`,
    }}>
      <Image src={imgSrc} alt={name} fill style={{ objectFit: "cover" }} unoptimized />
    </div>
  );
}

function NavBtn({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button onClick={onClick} style={{
      background: "rgba(201,168,76,0.07)", border: "1px solid rgba(201,168,76,0.28)",
      color: "#c9a84c", fontFamily: "'Cinzel', serif", fontSize: 12,
      letterSpacing: "0.25em", padding: "10px 32px", cursor: "pointer",
      backdropFilter: "blur(8px)", transition: "all 0.3s",
    }}
      onMouseEnter={e => { e.currentTarget.style.background = "rgba(201,168,76,0.18)"; e.currentTarget.style.boxShadow = "0 0 22px rgba(201,168,76,0.35)"; }}
      onMouseLeave={e => { e.currentTarget.style.background = "rgba(201,168,76,0.07)"; e.currentTarget.style.boxShadow = "none"; }}
    >{label}</button>
  );
}
