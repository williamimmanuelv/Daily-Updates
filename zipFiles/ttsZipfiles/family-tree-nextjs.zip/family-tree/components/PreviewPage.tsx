"use client";
/**
 * SINGLE CONTINUOUS HORIZONTAL SCROLL
 * ════════════════════════════════════════════════════════════════════
 *
 * One infinite filmstrip scrolling right. Each generation = one VW=1920px slot.
 * The viewport (camera) smoothly pans right. NEVER a page flip.
 *
 * WORLD LAYOUT  (per slot, x relative to slot left edge)
 * ──────────────────────────────────────────────────────
 *  Father  cx = slotStart+220  cy=320  r=100
 *  Mother  cx = slotStart+220  cy=760  r=100
 *  Branch spine  x = 220 → 820
 *  Children      cx = slotStart+910  r=50
 *
 * PHASE SEQUENCE  (~46s per generation)
 * ──────────────────────────────────────
 *  Ph0 [ 0– 3s]  ERA title + tracker
 *  Ph1 [ 3– 7s]  Father circle + details
 *  Ph2 [ 7– 9s]  F→M connector line
 *  Ph3 [ 9–13s]  Mother circle + details
 *  Ph4 [13–20s]  Branch + children (heir included, gold)
 *  Ph5 [20–27s]  Siblings fade; heir GROWS + slides right into next slot father pos.
 *                Viewport pans right with heir.
 *  Ph6 [27–31s]  Old gen fades. Heir settled at father position + details appear.
 *  Ph7 [31–37s]  Wife's family tree animates on RIGHT side of screen.
 *                Wife's father (top-right) + wife's mother, horizontal line between them,
 *                vertical trunk down, horizontal bar, siblings below. Wife at bottom.
 *                NO connection between heir and wife yet.
 *  Ph8 [37–41s]  Wife's family tree (father/mother/siblings) fades out. Wife stays.
 *  Ph9 [41–46s]  F→M connector draws heir→wife. Wife slides up to mother position.
 *                Wife details appear.
 *
 * VIEWPORT
 * ─────────────────────────────────────────────────────
 *  viewX = lerp(genIdx*VW, (genIdx+1)*VW, easeInOut(p5))
 *  Ph0–Ph4: static at genIdx*VW
 *  Ph5:     smoothly → (genIdx+1)*VW
 *  Ph6+:    locked at (genIdx+1)*VW
 *
 * All DOM:    left = worldX − viewX
 * Canvas:     ctx.translate(−viewX, 0) already applied by engine
 */

import React, { useRef, useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { useCanvasEngine } from "@/lib/canvasEngine";
import type { RingTarget, LineTarget } from "@/lib/canvasEngine";
import { useAppState } from "@/lib/appState";
import { THEMES, FONT_OPTIONS } from "@/lib/themes";
import type { Theme, FontChoice } from "@/lib/themes";
import { SAMPLE_JSON } from "@/lib/jsonFormat";
import type { LineageJSON } from "@/lib/jsonFormat";

// ── LAYOUT ────────────────────────────────────────────────────────────
const VW = 1920, VH = 1080;

// Per-slot (relative to slot's left edge)
const P_CX       = 220;
const F_CY       = 320;
const M_CY       = 760;
const MID_Y      = (F_CY + M_CY) / 2;  // 540

const D_BIG = 200, R_BIG = 100;
const D_SM  = 100, R_SM  =  50;

// Parent text
const PT_X_OFF = R_BIG + 28;
const PT_W     = 360;

// Children branch
const BRANCH_X_OFF = 820 - P_CX;   // 600
const CH_CX_OFF    = 910 - P_CX;   // 690
const CH_TXT_W     = 160;

// Wife's family tree — positioned in NEXT slot world coords
// Parents near screen centre-right; children well spread below
const WF_F_CX  = 1060;   // wife's father (left of tree)
const WF_M_CX  = 1620;   // wife's mother (right of tree)
const WF_MID_X = (WF_F_CX + WF_M_CX) / 2;  // 1340 — trunk x
const WF_P_CY    = 290;  // parents row y — below era tracker
const WF_JUNC_Y  = 560;  // junction point y (trunk lands here, spokes radiate out)
const WF_CH_Y    = 720;  // children circle centres y
const WF_SPREAD  = 480;  // total horizontal spread of children row

const INFO_EST_H = 212;

// ── TIMING ────────────────────────────────────────────────────────────
//           Ph0  Ph1  Ph2  Ph3  Ph4  Ph5  Ph6  Ph7  Ph8  Ph9
const PH  = [ 3,   4,   2,   4,   7,   7,   4,   6,   4,   5] as const;
const PS: number[] = [];
PH.forEach((d, i) => PS.push(i === 0 ? 0 : PS[i-1] + PH[i-1]));
const GEN_DUR = PS[9] + PH[9];  // 46s

// ── EASING ────────────────────────────────────────────────────────────
const eO  = (t: number) => 1 - Math.pow(Math.max(0, 1 - t), 3);
const eIO = (t: number) => t < .5 ? 4*t*t*t : 1 - Math.pow(-2*t+2, 3) / 2;
const cl  = (t: number, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, t));
const lp  = (a: number, b: number, t: number) => a + (b - a) * t;
const pv  = (lt: number, i: number) => cl((lt - PS[i]) / PH[i]);

function childY(i: number, n: number): number {
  if (n <= 1) return MID_Y;
  const minGap = D_SM + 20;
  const natural = (M_CY - R_SM - 20) - (F_CY + R_SM + 20);
  const needed  = (n - 1) * minGap;
  const span    = Math.max(natural, needed);
  return MID_Y - span / 2 + i * (span / (n - 1));
}

function firstWord(s: string) { return s.split(" ")[0].toUpperCase(); }

type WifeFamily = {
  father:   { name: string; life: string; title: string; desc: string; image: string };
  mother:   { name: string; life: string; title: string; desc: string; image: string };
  siblings: { name: string; image: string }[];
};

// ── COMPONENT ─────────────────────────────────────────────────────────
export default function PreviewPage() {
  const router = useRouter();
  const { theme, fontChoice, lineageData, imageMap } = useAppState();
  const thm  = THEMES[theme]       ?? THEMES.history;
  const fonts = FONT_OPTIONS[theme] ?? FONT_OPTIONS.history;
  const fc   = fonts.find(f => f.id === fontChoice) ?? fonts[0];
  const data = (lineageData ?? SAMPLE_JSON) as LineageJSON;
  const fams = data.families;
  const N    = fams.length;

  const iS = (fn: string) => {
    if (imageMap[fn]) return imageMap[fn];
    if (typeof window !== "undefined") {
      const w = (window as Record<string, unknown>).__ftImages as Record<string, string> | undefined;
      if (w?.[fn]) return w[fn];
    }
    return `/assets/${fn}`;
  };

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [scale, setScale]           = useState(1);
  const [showIntro, setShowIntro]   = useState(true);
  const [generating, setGenerating] = useState(false);
  const [savingI, setSavingI]       = useState(false);
  const [savedI, setSavedI]         = useState(false);
  const [saveErr, setSaveErr]       = useState<string | null>(null);
  const [savingP, setSavingP]       = useState(false);
  const [savedP, setSavedP]         = useState(false);

  const doSaveI = async () => {
    const imgs = typeof window !== "undefined"
      ? ((window as Record<string, unknown>).__ftImages as Record<string, string> | undefined)
      : undefined;
    if (!imgs || !Object.keys(imgs).length) { setSaveErr("No images found."); return; }
    setSavingI(true); setSaveErr(null);
    try {
      const r = await fetch("/api/save-images", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ images: imgs }),
      });
      const j = await r.json();
      if (j.ok) setSavedI(true); else setSaveErr(j.error || "Failed");
    } catch(e) { setSaveErr(String(e)); }
    finally { setSavingI(false); }
  };

  const doSaveP = async () => {
    setSavingP(true); setSavedP(false);
    try {
      const imgs = typeof window !== "undefined"
        ? ((window as Record<string, unknown>).__ftImages as Record<string, string> | undefined)
        : undefined;
      const r = await fetch("/api/save-project", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ theme, fontChoice, lineageJSON: data, images: imgs || {} }),
      });
      const j = await r.json();
      if (j.ok) { setSavedP(true); setTimeout(() => setSavedP(false), 4000); }
      else alert("Save failed: " + j.error);
    } catch(e) { alert(String(e)); }
    finally { setSavingP(false); }
  };

  const clockRef  = useRef(0);
  const [clock, setClock] = useState(0);
  const rafRef    = useRef(0);
  const lastTRef  = useRef(0);
  const playRef   = useRef(false);

  const { start: startC, stop: stopC, setRings, setLines, setClockSeconds, setViewX } =
    useCanvasEngine(canvasRef, thm);

  const gC: [number, number, number] = thm.fatherColor;
  const sC: [number, number, number] = thm.motherColor;
  const mC: [number, number, number] = [
    Math.round((gC[0] + sC[0]) / 2),
    Math.round((gC[1] + sC[1]) / 2),
    Math.round((gC[2] + sC[2]) / 2),
  ];

  useEffect(() => {
    const u = () => setScale(Math.min(window.innerWidth / VW, (window.innerHeight - 56) / VH));
    u(); window.addEventListener("resize", u);
    return () => window.removeEventListener("resize", u);
  }, []);
  useEffect(() => { startC(); return () => stopC(); }, [startC, stopC]);

  // ── Animation state (pure function of clock) ──────────────────────
  const totalT  = N * GEN_DUR;
  const genIdx  = Math.min(Math.floor(clock / GEN_DUR), N - 1);
  const localT  = clock - genIdx * GEN_DUR;

  const fam      = fams[genIdx]     ?? fams[0];
  const nextFam  = fams[genIdx + 1] ?? null;
  const children = fam.children ?? [];
  const heir     = nextFam?.father ?? null;
  const heirIdx  = heir ? children.findIndex(c => c.name === heir.name) : -1;

  // Wife's family tree comes from the NEXT gen's mother's wifeFamily field
  const wifeMother = nextFam?.mother ?? null;
  const wifeFamily = wifeMother
    ? ((wifeMother as unknown as Record<string, unknown>).wifeFamily as WifeFamily | undefined)
    : undefined;

  // Phase progress
  const p0 = eO(pv(localT, 0));
  const p1 = eO(pv(localT, 1));
  const p2 = eO(pv(localT, 2));
  const p3 = eO(pv(localT, 3));
  const p4 = eO(pv(localT, 4));
  const p5 = eIO(pv(localT, 5));
  const p6 = eO(pv(localT, 6));
  const p7 = eO(pv(localT, 7));
  const p8 = eO(pv(localT, 8));
  const p9 = eIO(pv(localT, 9));

  // ── VIEWPORT — follows heir during Ph5 ───────────────────────────
  const viewX = lp(genIdx * VW, (genIdx + 1) * VW, p5);
  setViewX(viewX);
  setClockSeconds(clock);

  const sx = (wx: number) => wx - viewX;  // world → screen x

  // ── WORLD POSITIONS ───────────────────────────────────────────────
  const slotW  = genIdx * VW;
  const nslotW = (genIdx + 1) * VW;

  const fWX  = slotW + P_CX;               // father + mother x (same column)
  const chWX = slotW + P_CX + CH_CX_OFF;   // children x
  const brWX = slotW + P_CX + BRANCH_X_OFF; // branch spine x

  // Heir: grows from child pos → next slot father pos during Ph5
  const rawHCY   = heirIdx >= 0 ? childY(heirIdx, children.length) : MID_Y;
  const heirDstX = nslotW + P_CX;
  const heirWX   = lp(chWX, heirDstX, p5);
  const heirWY   = lp(rawHCY, F_CY, p5);
  const heirD    = lp(D_SM, D_BIG, p5);
  const heirR    = heirD / 2;
  const heirA    = cl(p5 * 2.5);

  // Old gen fades during Ph6
  const oldA = localT < PS[6] ? 1 : Math.max(0, 1 - p6 * 1.8);

  // Siblings fade during Ph5
  const sibA = p4 > 0 ? Math.max(0, 1 - p5 * 2.2) : 0;

  // For gen > 0: father and mother are already present from start of gen (heir arrived at end of prev gen).
  // Don't fade them in — they are immediately visible at oldA.
  const fatherA = genIdx === 0 ? p1 * oldA : oldA;
  const motherA = genIdx === 0 ? p3 * oldA : (fam.mother && localT >= 0 ? oldA : 0);
  const fmLineA = genIdx === 0 ? cl(p2 * 3) * oldA : oldA;  // FM line always drawn for gen>0
  const fmLineProg = genIdx === 0 ? p2 : 1;  // always fully drawn for gen>0

  // Wife's family tree world positions (in next slot) — must be declared FIRST
  const wfFWX   = nslotW + WF_F_CX;
  const wfMWX   = nslotW + WF_M_CX;
  const wfMidWX = nslotW + WF_MID_X;
  const wSibN   = wifeFamily ? wifeFamily.siblings.length + 1 : 1;
  const wfStep  = wSibN > 1 ? WF_SPREAD / (wSibN - 1) : 0;
  const wfLeft  = wfMidWX - WF_SPREAD / 2;
  const wfChX   = (si: number) => wSibN > 1 ? wfLeft + si * wfStep : wfMidWX;

  // Wife: slides from her tree position (right side) to mother pos in Ph9
  const wifeTreeWX = wSibN > 1 ? wfLeft + (wSibN - 1) * wfStep : wfMidWX;
  const wifeTreeWY = WF_CH_Y;
  const wifeDstX   = nslotW + P_CX;
  const wifeWX     = lp(wifeTreeWX, wifeDstX, p9);
  const wifeWY     = lp(wifeTreeWY, M_CY, p9);
  const wifeR      = lp(R_SM, R_BIG, p9);
  const wifeA      = p9 > 0 ? cl(p9 * 3) : 0;

  // Wife's family tree alpha: Ph7 in, Ph8 fades (for father/mother/siblings/lines only)
  const wfA = p7 > 0 ? p7 * Math.max(0, 1 - p8 * 2) : 0;
  // Wife's OWN alpha: appears in Ph7, stays visible through Ph8, slides in Ph9
  // She does NOT fade with the tree — she remains at her tree position until Ph9 starts
  const wifeVisA = p7 > 0 ? Math.min(1, p7 * 3) : 0;  // fades in fast in Ph7, stays at 1

  // Era title — always visible, text updates as genIdx changes (no per-gen fade reset)
  const eraA = 1;

  // ── Canvas rings + lines ──────────────────────────────────────────
  useEffect(() => {
    const rings: RingTarget[] = [];
    const lns:   LineTarget[] = [];

    // Father ring — Gen 0 fades in; Gen 1+ immediately visible
    if (localT >= PS[1] || genIdx > 0)
      rings.push({ id: "F", cx: fWX, cy: F_CY, r: R_BIG, alpha: fatherA, color: gC, phase: 0 });

    // F→M connector — Gen 0 draws in; Gen 1+ always fully drawn
    if (fam.mother && (localT >= PS[2] || genIdx > 0))
      lns.push({
        id: "FM", x1: fWX, y1: F_CY + R_BIG + 6, x2: fWX, y2: M_CY - R_BIG - 6,
        progress: fmLineProg, alpha: fmLineA, color: mC,
      });

    // Mother ring — Gen 0 fades in; Gen 1+ immediately visible
    if (fam.mother && (localT >= PS[3] || genIdx > 0))
      rings.push({ id: "M", cx: fWX, cy: M_CY, r: R_BIG, alpha: motherA, color: sC, phase: 1.8 });

    // Branch spine + children (ALL including heir)
    if (localT >= PS[4] && children.length > 0) {
      lns.push({
        id: "BH", x1: fWX, y1: MID_Y, x2: brWX, y2: MID_Y,
        progress: p4, alpha: cl(p4 * 2) * oldA, color: mC,
      });
      children.forEach((_, ci) => {
        const isH = ci === heirIdx;
        const del  = ci * (0.55 / Math.max(children.length, 1));
        const cP   = eO(cl((p4 - del) / 0.45));
        if (cP <= 0) return;
        const cy2   = childY(ci, children.length);
        const hFade = isH ? Math.max(0, 1 - p5 * 3) : 1;
        const la    = cl(cP * 2) * oldA * hFade;
        if (Math.abs(cy2 - MID_Y) > 2)
          lns.push({ id: `BV${ci}`, x1: brWX, y1: MID_Y, x2: brWX, y2: cy2, progress: cP, alpha: la, color: mC });
        lns.push({ id: `BT${ci}`, x1: brWX, y1: cy2, x2: brWX + 55, y2: cy2, progress: cP, alpha: la, color: mC });
        rings.push({
          id: `C${ci}`, cx: chWX, cy: cy2, r: R_SM,
          alpha: isH ? cP * Math.max(0, 1 - p5 * 3) * oldA : cP * sibA * oldA,
          color: isH ? gC : mC, phase: ci * .5 + 2,
        });
      });
    }

    // Heir ring — migrates in world space
    if (p5 > 0 && heir)
      rings.push({ id: "H", cx: heirWX, cy: heirWY, r: heirR, alpha: heirA, color: gC, phase: .4 });

    // Wife's family tree (Ph7)
    // Structure:
    //   Ph7 0.0–0.4: wife's father ring appears
    //   Ph7 0.1–0.5: horizontal line father→mother draws
    //   Ph7 0.3–0.6: wife's mother ring appears
    //   Ph7 0.4–0.75: vertical trunk draws down from parent midpoint to JUNC_Y
    //   Ph7 0.75+:  spokes radiate from JUNC_Y directly to each child circle top
    //               children rings appear staggered
    if (wfA > 0.005 && wifeFamily) {
      const ph7p = Math.min(1, p7 * 2), hzA = wfA * cl(ph7p);

      // Wife's father ring
      rings.push({ id: "WFF", cx: wfFWX, cy: WF_P_CY, r: R_BIG, alpha: wfA, color: gC, phase: 1.2 });
      // Horizontal line between parents
      lns.push({
        id: "WFHZ", x1: wfFWX + R_BIG + 4, y1: WF_P_CY, x2: wfMWX - R_BIG - 4, y2: WF_P_CY,
        progress: ph7p, alpha: hzA, color: mC,
      });
      // Wife's mother ring
      rings.push({ id: "WFM", cx: wfMWX, cy: WF_P_CY, r: R_BIG, alpha: hzA, color: sC, phase: 2.6 });

      // Vertical trunk: parent midpoint → junction point
      const vtP = cl((p7 - 0.38) / 0.37);
      if (vtP > 0)
        lns.push({
          id: "WFVT", x1: wfMidWX, y1: WF_P_CY + R_BIG + 6,
          x2: wfMidWX, y2: WF_JUNC_Y,
          progress: vtP, alpha: wfA * cl(vtP * 3), color: mC,
        });

      // Spokes + children — only after trunk reaches junction
      const nSibs = wifeFamily.siblings.length;
      const spokeStart = 0.75;  // p7 threshold when spokes begin
      for (let si = 0; si <= nSibs; si++) {  // 0..nSibs-1 = siblings, nSibs = wife
        const isWife = si === nSibs;
        const del  = si * (0.18 / Math.max(wSibN, 1));
        const spkP = eO(cl((p7 - spokeStart - del) / 0.20));
        if (spkP <= 0) continue;
        const chX2 = wfChX(si);
        const la   = spkP * wfA;
        // Spoke: from junction point directly to child circle top
        lns.push({
          id: `WSP${si}`,
          x1: wfMidWX, y1: WF_JUNC_Y,
          x2: chX2,    y2: WF_CH_Y - R_SM - 4,
          progress: spkP, alpha: la, color: mC,
        });
        // Child ring (not wife — wife ring is handled by unified block)
        if (!isWife)
          rings.push({ id: `WC${si}`, cx: chX2, cy: WF_CH_Y, r: R_SM, alpha: la, color: mC, phase: si * .6 + 3 });
      }
    }

    // Wife — single unified ring, always pushed when visible, never gaps
    // Before Ph9: stays at tree position (wifeTreeWX/WY) at R_SM
    // During Ph9: slides to mother position, grows to R_BIG
    // Alpha: wifeVisA once she appears (Ph7), stays 1 through Ph8, cl(p9*3) during Ph9 start
    if (wifeVisA > 0.005 && wifeMother) {
      const wCX = p9 > 0 ? wifeWX : wifeTreeWX;
      const wCY = p9 > 0 ? wifeWY : wifeTreeWY;
      const wR  = p9 > 0 ? wifeR  : R_SM;
      // Alpha: during Ph7/Ph8 use wifeVisA (stays 1). During Ph9 transition, max of both so no dip.
      const wA  = p9 > 0 ? Math.max(wifeVisA, wifeA) : wifeVisA;
      rings.push({ id: "W", cx: wCX, cy: wCY, r: wR, alpha: wA, color: sC, phase: 2.4 });
    }

    // Ph9 connector: heir→wife line draws once wife starts moving
    if (p9 > 0 && wifeMother) {
      lns.push({
        id: "NF", x1: heirDstX, y1: F_CY + R_BIG + 6, x2: wifeDstX, y2: M_CY - R_BIG - 6,
        progress: p9, alpha: cl(p9 * 3), color: mC,
      });
    }

    setRings(rings);
    setLines(lns);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clock]);

  // ── RAF ───────────────────────────────────────────────────────────
  const tick = useCallback((now: number) => {
    if (!playRef.current) return;
    if (!lastTRef.current) lastTRef.current = now;
    const dt = Math.min((now - lastTRef.current) / 1000, .05);
    lastTRef.current = now;
    const next = clockRef.current + dt;
    if (next >= totalT + 3) { playRef.current = false; return; }
    clockRef.current = next; setClock(next);
    rafRef.current = requestAnimationFrame(tick);
  }, [totalT]);

  // ── Export API ────────────────────────────────────────────────────
  useEffect(() => {
    const w = window as Record<string, unknown>;
    w.__seekTo        = (s: number) => { clockRef.current = s; setClock(s); };
    w.__TOTAL_SECS    = totalT + 4;
    w.__TOTAL_GENS    = N;
    w.__IMAGES_NEEDED = fams.flatMap((f: LineageJSON["families"][0]) => {
      const m  = f.mother as unknown as Record<string, unknown> | null;
      const wf = m?.wifeFamily as WifeFamily | undefined;
      return [
        f.father.image,
        ...(f.mother ? [f.mother.image] : []),
        ...(f.children ?? []).map((c: { image: string }) => c.image),
        ...(wf ? [wf.father.image, wf.mother.image, ...wf.siblings.map(s => s.image)] : []),
      ];
    });
    w.__injectImages = (map: Record<string, string>) => { w.__ftImages = map; setClock(t => t + 0.0001); };
    return () => { delete w.__seekTo; delete w.__injectImages; delete w.__IMAGES_NEEDED; };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [totalT, N]);

  const beginPlay = () => {
    clockRef.current = 0; lastTRef.current = 0; setClock(0);
    playRef.current = true; setShowIntro(false);
    rafRef.current = requestAnimationFrame(tick);
  };
  useEffect(() => () => cancelAnimationFrame(rafRef.current), []);

  const acl = thm.timelineDot;

  // ── RENDER ────────────────────────────────────────────────────────
  return (<>
    <link rel="stylesheet" href={thm.fontImport} />
    {fc.fontImport !== thm.fontImport && <link rel="stylesheet" href={fc.fontImport} />}

    {/* NAV */}
    <div style={{
      position: "fixed", top: 0, left: 0, right: 0, height: 56, zIndex: 200,
      background: "rgba(0,0,0,0.92)", backdropFilter: "blur(14px)",
      borderBottom: "1px solid rgba(255,255,255,0.06)",
      display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 44px",
    }}>
      <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
        <button onClick={() => router.push("/")} style={nb("#777", "rgba(255,255,255,0.1)", fc.bodyFont)}>← Back</button>
        <span style={{ fontFamily: fc.headingFont, fontSize: 14, color: thm.headerColor, letterSpacing: "0.08em" }}>
          {thm.icon} {thm.name} · {data.videoTitle}
        </span>
      </div>
      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
        {!showIntro && <button onClick={beginPlay} style={nb(acl, `${acl}55`, fc.headingFont)}>↺ Replay</button>}
        <button onClick={doSaveP} disabled={savingP} style={nb(savedP ? "#80e890" : acl, savedP ? "rgba(80,200,80,0.4)" : `${acl}44`, fc.headingFont)}>
          {savingP ? "⏳…" : savedP ? "✅ Saved" : "💾 Save Project"}
        </button>
        <button onClick={() => router.push("/")} style={nb("#e08080", "rgba(255,80,80,0.25)", fc.headingFont)}>✗ Start Over</button>
        <button onClick={() => setGenerating(true)} style={{
          background: `linear-gradient(135deg,${thm.bgFrom},${thm.bgTo})`,
          border: `2px solid ${acl}`, color: thm.nameColor,
          fontFamily: fc.headingFont, fontSize: 12, fontWeight: 700,
          letterSpacing: "0.2em", padding: "7px 22px", borderRadius: 4,
          cursor: "pointer", boxShadow: `0 0 18px ${acl}55`,
        }}>🎬 Generate Video</button>
      </div>
    </div>

    {/* GENERATE MODAL */}
    {generating && (
      <div style={{ position: "fixed", inset: 0, zIndex: 300, background: "rgba(0,0,0,0.94)", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ background: "#0b0e16", border: `1px solid ${acl}55`, borderRadius: 16, padding: "36px 48px", maxWidth: 640, width: "100%" }}>
          <div style={{ fontFamily: fc.headingFont, fontSize: 20, color: thm.nameColor, marginBottom: 22 }}>🎬 Generate Video</div>
          <div style={{ marginBottom: 18, padding: "16px 20px", borderRadius: 10, background: "rgba(255,255,255,0.03)", border: `1px solid ${acl}22` }}>
            <div style={{ fontFamily: fc.headingFont, fontSize: 12, color: acl, letterSpacing: "0.12em", marginBottom: 10 }}>STEP 1 — SAVE IMAGES TO DISK</div>
            {saveErr && <div style={{ color: "#e88080", fontSize: 12, marginBottom: 8 }}>❌ {saveErr}</div>}
            <button onClick={doSaveI} disabled={savingI || savedI} style={{
              background: savedI ? "rgba(80,200,80,0.08)" : "transparent",
              border: `1px solid ${savedI ? "rgba(80,200,80,0.4)" : acl + "55"}`,
              color: savedI ? "#80e890" : acl, fontFamily: fc.headingFont,
              fontSize: 12, letterSpacing: "0.12em", padding: "8px 20px",
              borderRadius: 5, cursor: "pointer", opacity: savingI ? 0.5 : 1,
            }}>{savingI ? "⏳ Saving…" : savedI ? "✅ Images Saved" : "💾 Save Images to Disk"}</button>
          </div>
          <div style={{ padding: "16px 20px", borderRadius: 10, background: "rgba(255,255,255,0.03)", border: `1px solid ${acl}22`, opacity: savedI ? 1 : 0.4, transition: "opacity 0.3s" }}>
            <div style={{ fontFamily: fc.headingFont, fontSize: 12, color: acl, letterSpacing: "0.12em", marginBottom: 10 }}>STEP 2 — RUN EXPORT SCRIPT</div>
            <pre style={{ fontFamily: "Consolas,monospace", fontSize: 12, color: "#a0d880", lineHeight: 2, background: "#050810", padding: "12px 16px", borderRadius: 8, border: "1px solid rgba(255,255,255,0.07)", margin: "0 0 10px" }}>
              {`npm run dev                     # terminal 1\nnode scripts/export-frames.js  # terminal 2`}
            </pre>
            <div style={{ fontFamily: fc.bodyFont, fontSize: 12, color: thm.descColor }}>
              Requires FFmpeg · <span style={{ color: acl }}>brew install ffmpeg</span> (Mac) · <span style={{ color: thm.nameColor }}>gyan.dev/ffmpeg</span> (Win)
            </div>
          </div>
          <button onClick={() => { setGenerating(false); setSaveErr(null); }} style={{
            marginTop: 18, background: "none", border: `1px solid ${acl}33`,
            color: acl, fontFamily: fc.headingFont, fontSize: 11,
            letterSpacing: "0.18em", padding: "9px 24px", borderRadius: 4, cursor: "pointer",
          }}>Close</button>
        </div>
      </div>
    )}

    {/* STAGE */}
    <div style={{ width: "100vw", height: "calc(100vh - 56px)", marginTop: 56, overflow: "hidden", display: "flex", alignItems: "center", justifyContent: "center", background: thm.bgTo }}>
      <div style={{ width: VW, height: VH, transform: `scale(${scale})`, transformOrigin: "center center", position: "relative", overflow: "hidden", flexShrink: 0 }}>
        <canvas ref={canvasRef} width={VW} height={VH} style={{ position: "absolute", top: 0, left: 0, width: VW, height: VH, zIndex: 0 }} />

        {/* INTRO */}
        {showIntro && (
          <div style={{ position: "absolute", inset: 0, zIndex: 40, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 24 }}>
            <div style={{ fontFamily: fc.headingFont, fontSize: 82, fontWeight: 800, color: thm.nameColor, letterSpacing: "0.05em", lineHeight: 1, textShadow: `0 0 80px ${acl}99,0 0 160px ${acl}44` }}>{data.channelName}</div>
            <div style={{ width: 480, height: 1, background: `linear-gradient(to right,transparent,${acl},transparent)` }} />
            <div style={{ fontFamily: fc.bodyFont, fontStyle: "italic", fontSize: 28, letterSpacing: "0.16em", color: thm.descColor }}>The Lineage of</div>
            <div style={{ fontFamily: fc.headingFont, fontSize: 24, fontWeight: 700, letterSpacing: "0.22em", color: acl, textShadow: `0 0 28px ${acl}` }}>{data.lineageSubject}</div>
            <div style={{ fontFamily: fc.bodyFont, fontStyle: "italic", fontSize: 18, color: thm.lifeColor }}>{data.videoTitle}</div>
            <button onClick={beginPlay} style={{ background: "none", border: `1px solid ${acl}99`, color: thm.nameColor, fontFamily: fc.headingFont, fontSize: 14, letterSpacing: "0.38em", padding: "18px 68px", cursor: "pointer", marginTop: 34, textShadow: `0 0 16px ${acl}aa`, boxShadow: `0 0 44px ${acl}33,inset 0 0 44px ${acl}0d` }}>
              BEGIN THE LINEAGE ›
            </button>
          </div>
        )}

        {/* ═══════════════════════════════════════════════════════════
            ANIMATION — all elements: left = worldX − viewX
            ═══════════════════════════════════════════════════════════ */}
        {!showIntro && (
          <div style={{ position: "absolute", inset: 0, zIndex: 1 }}>

            {/* ERA TITLE + GENERATION TRACKER */}
            {eraA > 0.005 && (
              <div style={{ position: "absolute", top: 32, left: 0, right: 0, textAlign: "center", zIndex: 20, pointerEvents: "none", opacity: eraA }}>
                <div style={{ fontFamily: fc.headingFont, fontSize: 50, fontWeight: 900, letterSpacing: "0.07em", color: thm.nameColor, lineHeight: 1.1, textShadow: `0 0 60px ${acl}cc,0 0 120px ${acl}55` }}>{fam.era}</div>
                {fam.isSubject && <div style={{ fontFamily: fc.headingFont, fontSize: 13, letterSpacing: "0.6em", color: acl, marginTop: 4, textShadow: `0 0 22px ${acl}` }}>✦ THE SUBJECT ✦</div>}
                <div style={{ marginTop: 12, display: "flex", alignItems: "flex-start", justifyContent: "center", gap: 0 }}>
                  {fams.map((f2, i) => {
                    const isA = i === genIdx, isDn = i < genIdx;
                    return (
                      <React.Fragment key={i}>
                        {i > 0 && <div style={{ width: 28, height: 2, marginTop: 6, flexShrink: 0, background: isDn || isA ? `linear-gradient(to right,${acl}cc,${acl}55)` : `${acl}18` }} />}
                        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
                          <div style={{ width: isA ? 14 : 7, height: isA ? 14 : 7, borderRadius: "50%", background: isA ? acl : isDn ? `${acl}77` : `${acl}22`, boxShadow: isA ? `0 0 14px ${acl},0 0 28px ${acl}88` : "none", transition: "all 0.5s" }} />
                          <div style={{ fontFamily: fc.headingFont, fontSize: isA ? 13 : isDn ? 10 : 9, fontWeight: isA ? 800 : isDn ? 600 : 400, letterSpacing: "0.1em", color: isA ? acl : isDn ? `${acl}66` : `${acl}22`, whiteSpace: "nowrap", textShadow: isA ? `0 0 12px ${acl},0 0 24px ${acl}66` : "none", transition: "all 0.5s" }}>{firstWord(f2.father.name)}</div>
                        </div>
                      </React.Fragment>
                    );
                  })}
                </div>
              </div>
            )}

            {/* FATHER circle + text — gen 0 fades in, gen 1+ immediately visible */}
            {(p1 > 0.01 || genIdx > 0) && fatherA > 0.01 && (() => {
              const scrX = sx(fWX);
              return (<>
                <CC cx={scrX} cy={F_CY} r={R_BIG} src={iS(fam.father.image)} alt={fam.father.name} alpha={fatherA} bg={thm.bgTo} z={6} />
                <InfoBlock person={fam.father} role="father" x={scrX + PT_X_OFF} cy={F_CY} w={PT_W} opacity={fatherA} thm={thm} fc={fc} />
              </>);
            })()}

            {/* MOTHER circle + text — gen 0 fades in, gen 1+ immediately visible */}
            {fam.mother && (p3 > 0.01 || genIdx > 0) && motherA > 0.01 && (() => {
              const scrX = sx(fWX);
              return (<>
                <CC cx={scrX} cy={M_CY} r={R_BIG} src={iS(fam.mother.image)} alt={fam.mother.name} alpha={motherA} bg={thm.bgTo} z={6} />
                <InfoBlock person={fam.mother} role="mother" x={scrX + PT_X_OFF} cy={M_CY} w={PT_W} opacity={motherA} thm={thm} fc={fc} />
              </>);
            })()}

            {/* CHILDREN — all including heir (heir is gold, fades as he starts moving) */}
            {p4 > 0 && children.map((ch, ci) => {
              const isH   = ci === heirIdx;
              const del   = ci * (0.55 / Math.max(children.length, 1));
              const cP    = eO(cl((p4 - del) / 0.45));
              const hFade = isH ? Math.max(0, 1 - p5 * 3) : 1;
              const ca    = cP * (isH ? hFade : sibA) * oldA;
              if (ca < 0.01) return null;
              const cy2   = childY(ci, children.length);
              const scrX  = sx(chWX);
              return (
                <React.Fragment key={ci}>
                  <CC cx={scrX} cy={cy2} r={R_SM} src={iS(ch.image)} alt={ch.name} alpha={ca} bg={thm.bgTo} z={7} />
                  <div style={{ position: "absolute", zIndex: 7, opacity: ca, left: scrX + R_SM + 10, top: cy2 - 12, width: CH_TXT_W, pointerEvents: "none" }}>
                    <span style={{ fontFamily: fc.headingFont, fontSize: 14, color: isH ? thm.nameColor : thm.descColor, fontWeight: isH ? 700 : 400, whiteSpace: "nowrap" }}>{ch.name}</span>
                  </div>
                </React.Fragment>
              );
            })}

            {/* HEIR — grows and slides to next slot father position */}
            {heir && p5 > 0 && (() => {
              const scrX = sx(heirWX);
              const detA = cl((p5 - 0.88) / 0.12);
              return (<>
                <CC cx={scrX} cy={heirWY} r={heirR} src={iS(heir.image)} alt={heir.name} alpha={heirA} bg={thm.bgTo} z={9} />
                {detA > 0.01 && (
                  <InfoBlock person={heir} role="father" x={scrX + R_BIG + 28} cy={F_CY} w={PT_W} opacity={detA} thm={thm} fc={fc} />
                )}
              </>);
            })()}

            {/* WIFE'S FAMILY TREE (Ph7) — right side, appears after heir settled */}
            {wifeFamily && wfA > 0.005 && (() => {
              const wfFSX = sx(wfFWX), wfMSX = sx(wfMWX);
              const mA2   = Math.min(1, p7 * 2) * wfA;
              const nSibs = wifeFamily.siblings.length;
              return (<>
                {/* Wife's father */}
                <CC cx={wfFSX} cy={WF_P_CY} r={R_BIG} src={iS(wifeFamily.father.image)} alt={wifeFamily.father.name} alpha={wfA} bg={thm.bgTo} z={7} />
                <div style={{ position: "absolute", zIndex: 7, opacity: wfA, left: wfFSX - 120, top: WF_P_CY + R_BIG + 10, width: 240, textAlign: "center", pointerEvents: "none" }}>
                  <div style={{ fontFamily: fc.headingFont, fontSize: 18, fontWeight: 700, color: thm.nameColor, lineHeight: 1.2 }}>{wifeFamily.father.name}</div>
                  <div style={{ fontFamily: fc.bodyFont, fontStyle: "italic", fontSize: 14, color: thm.lifeColor, marginTop: 3 }}>{wifeFamily.father.life}</div>
                </div>

                {/* Wife's mother */}
                <CC cx={wfMSX} cy={WF_P_CY} r={R_BIG} src={iS(wifeFamily.mother.image)} alt={wifeFamily.mother.name} alpha={mA2} bg={thm.bgTo} z={7} />
                <div style={{ position: "absolute", zIndex: 7, opacity: mA2, left: wfMSX - 120, top: WF_P_CY + R_BIG + 10, width: 240, textAlign: "center", pointerEvents: "none" }}>
                  <div style={{ fontFamily: fc.headingFont, fontSize: 18, fontWeight: 700, color: thm.titleColor, lineHeight: 1.2 }}>{wifeFamily.mother.name}</div>
                  <div style={{ fontFamily: fc.bodyFont, fontStyle: "italic", fontSize: 14, color: thm.lifeColor, marginTop: 3 }}>{wifeFamily.mother.life}</div>
                </div>

                {/* Siblings (only when wSibN > 1) */}
                {wSibN > 1 && wifeFamily.siblings.map((sib, si) => {
                  const del = si * (0.25 / Math.max(wSibN, 1));
                  const sP  = eO(cl((p7 - 0.88 - del) / 0.28));
                  if (sP <= 0) return null;
                  const chSX = sx(wfChX(si)), sA = sP * wfA;
                  return (
                    <React.Fragment key={si}>
                      <CC cx={chSX} cy={WF_CH_Y} r={R_SM} src={iS(sib.image)} alt={sib.name} alpha={sA} bg={thm.bgTo} z={7} />
                      <div style={{ position: "absolute", zIndex: 7, opacity: sA, left: chSX - 65, top: WF_CH_Y + R_SM + 8, width: 130, textAlign: "center", pointerEvents: "none" }}>
                        <span style={{ fontFamily: fc.headingFont, fontSize: 13, color: thm.descColor, whiteSpace: "nowrap" }}>{sib.name}</span>
                      </div>
                    </React.Fragment>
                  );
                })}


              </>);
            })()}

            {/* WIFE — single unified element, never disappears once visible */}
            {wifeMother && wifeVisA > 0.01 && (() => {
              // Before Ph9: at tree position (small). During Ph9: slides to mother pos (grows).
              const wCX  = p9 > 0 ? sx(wifeWX)   : sx(wifeTreeWX);
              const wCY  = p9 > 0 ? wifeWY        : WF_CH_Y;
              const wR   = p9 > 0 ? wifeR         : R_SM;
              const wA   = p9 > 0 ? Math.max(wifeVisA, wifeA) : wifeVisA;
              const detA = p9 > 0.75 ? cl((p9 - 0.75) / 0.25) : 0;
              return (<>
                <CC cx={wCX} cy={wCY} r={wR} src={iS(wifeMother.image)} alt={wifeMother.name} alpha={wA} bg={thm.bgTo} z={9} />
                {/* Name label at tree position (fades as she starts moving) */}
                {p9 < 0.1 && (
                  <div style={{ position: "absolute", zIndex: 9, opacity: wifeVisA * Math.max(0, 1 - p9 * 10), left: sx(wifeTreeWX) - 65, top: WF_CH_Y + R_SM + 8, width: 130, textAlign: "center", pointerEvents: "none" }}>
                    <span style={{ fontFamily: fc.headingFont, fontSize: 13, color: thm.titleColor, fontWeight: 700, whiteSpace: "nowrap" }}>{wifeMother.name} ★</span>
                  </div>
                )}
                {/* Full info block once she arrives at mother position */}
                {detA > 0.01 && (
                  <InfoBlock person={wifeMother} role="mother" x={sx(wifeDstX) + PT_X_OFF} cy={M_CY} w={PT_W} opacity={detA} thm={thm} fc={fc} />
                )}
              </>);
            })()}

            {/* Subject label top-right */}
            <div style={{ position: "absolute", top: 20, right: 48, zIndex: 25, textAlign: "right", pointerEvents: "none" }}>
              <div style={{ fontFamily: fc.headingFont, fontSize: 15, fontWeight: 700, color: thm.nameColor, letterSpacing: "0.1em", textShadow: `0 0 18px ${acl}88` }}>{data.lineageSubject}</div>
            </div>

          </div>
        )}
      </div>
    </div>
  </>);
}

// ── Sub-components ─────────────────────────────────────────────────────
function CC({ cx, cy, r, src, alt, alpha, bg, z }: {
  cx: number; cy: number; r: number; src: string; alt: string; alpha: number; bg: string; z: number;
}) {
  return (
    <div style={{ position: "absolute", zIndex: z, left: cx - r, top: cy - r, width: r * 2, height: r * 2, borderRadius: "50%", overflow: "hidden", opacity: Math.max(0, Math.min(1, alpha)), background: bg, pointerEvents: "none" }}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt={alt} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
    </div>
  );
}

function InfoBlock({ person, role, x, cy, w, opacity, thm, fc }: {
  person: { name: string; life: string; title: string; desc: string; fatherName?: string; motherName?: string };
  role: "father" | "mother"; x: number; cy: number; w: number; opacity: number; thm: Theme; fc: FontChoice;
}) {
  const isF = role === "father", acl = thm.timelineDot;
  return (
    <div style={{ position: "absolute", left: x, top: cy - INFO_EST_H / 2, width: w, zIndex: 7, opacity, display: "flex", flexDirection: "column", gap: 8, pointerEvents: "none" }}>
      <div style={{ fontFamily: fc.headingFont, fontSize: 32, fontWeight: 800, letterSpacing: "0.04em", lineHeight: 1.1, color: isF ? thm.nameColor : thm.titleColor, textShadow: `0 0 28px ${isF ? acl : thm.titleColor}aa` }}>{person.name}</div>
      <div style={{ fontFamily: fc.bodyFont, fontStyle: "italic", fontSize: 20, fontWeight: 600, letterSpacing: "0.08em", color: thm.lifeColor }}>{person.life}</div>
      <div style={{ fontFamily: fc.headingFont, fontSize: 17, fontWeight: 700, letterSpacing: "0.05em", color: thm.titleColor, lineHeight: 1.4 }}>{person.title}</div>
      <div style={{ fontFamily: fc.bodyFont, fontStyle: "italic", fontSize: 17, letterSpacing: "0.02em", color: thm.descColor, lineHeight: 1.6 }}>{person.desc}</div>
      {(person.fatherName || person.motherName) && (
        <div style={{ padding: "5px 10px", border: `1px solid ${acl}44`, background: `${acl}0d`, borderRadius: 4 }}>
          {person.fatherName && <div style={{ fontFamily: fc.bodyFont, fontSize: 13, color: thm.descColor, marginBottom: 2 }}><span style={{ color: thm.titleColor, fontWeight: 700 }}>Father: </span>{person.fatherName}</div>}
          {person.motherName && <div style={{ fontFamily: fc.bodyFont, fontSize: 13, color: thm.descColor }}><span style={{ color: thm.titleColor, fontWeight: 700 }}>Mother: </span>{person.motherName}</div>}
        </div>
      )}
    </div>
  );
}

function nb(c: string, b: string, f: string): React.CSSProperties {
  return { background: "transparent", border: `1px solid ${b}`, color: c, fontFamily: f, fontSize: 11, letterSpacing: "0.15em", padding: "7px 16px", borderRadius: 4, cursor: "pointer" };
}
