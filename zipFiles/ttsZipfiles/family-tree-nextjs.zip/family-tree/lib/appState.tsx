"use client";
import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { LineageJSON } from "@/lib/jsonFormat";

interface AppState {
  theme:        string;
  fontChoice:   string;
  lineageData:  LineageJSON | null;
  // filename → base64 data URL (survives page navigation via sessionStorage)
  imageMap:     Record<string, string>;
  setTheme:     (t: string) => void;
  setFontChoice:(f: string) => void;
  setLineage:   (d: LineageJSON) => void;
  setImageMap:  (m: Record<string, string>) => void;
  clearLineage: () => void;
}

const Ctx = createContext<AppState>({
  theme: "history", fontChoice: "default", lineageData: null, imageMap: {},
  setTheme: () => {}, setFontChoice: () => {},
  setLineage: () => {}, setImageMap: () => {}, clearLineage: () => {},
});

const SS_LINEAGE   = "ft_lineage";
const SS_IMAGEMAP  = "ft_imagemap";
const SS_THEME     = "ft_theme";
const SS_FONT      = "ft_font";

function ssGet<T>(key: string, fallback: T): T {
  if(typeof window === "undefined") return fallback;
  try { const v = sessionStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch { return fallback; }
}
function ssSet(key: string, value: unknown) {
  if(typeof window === "undefined") return;
  try { sessionStorage.setItem(key, JSON.stringify(value)); } catch {}
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const [theme,       setThemeState]      = useState("history");
  const [fontChoice,  setFontChoiceState] = useState("default");
  const [lineageData, setLineageState]    = useState<LineageJSON | null>(null);
  const [imageMap,    setImageMapState]   = useState<Record<string, string>>({});

  // Rehydrate from sessionStorage on mount
  useEffect(() => {
    setThemeState(ssGet(SS_THEME, "history"));
    setFontChoiceState(ssGet(SS_FONT, "default"));
    const ld = ssGet<LineageJSON | null>(SS_LINEAGE, null);
    if(ld) setLineageState(ld);
    // For imageMap: prefer window.__ftImages (set by setImageMap, survives SPA nav)
    // Fall back to sessionStorage only if window version is absent
    if (typeof window !== "undefined") {
      const winImages = (window as Record<string, unknown>).__ftImages as Record<string,string> | undefined;
      if (winImages && Object.keys(winImages).length > 0) {
        setImageMapState(winImages);
        return;
      }
    }
    // sessionStorage fallback (only works for small datasets)
    const im = ssGet<Record<string,string>>(SS_IMAGEMAP, {});
    if (im && Object.keys(im).length > 0) setImageMapState(im);
  }, []);

  const setTheme = (t: string) => {
    setThemeState(t); ssSet(SS_THEME, t);
  };
  const setFontChoice = (f: string) => {
    setFontChoiceState(f); ssSet(SS_FONT, f);
  };
  const setLineage = (d: LineageJSON) => {
    setLineageState(d); ssSet(SS_LINEAGE, d);
  };
  const setImageMap = (m: Record<string, string>) => {
    setImageMapState(m);
    // Also store on window so it survives any navigation edge cases
    if (typeof window !== "undefined") {
      (window as Record<string, unknown>).__ftImages = m;
    }
    // Don't try sessionStorage for images — base64 data is too large (>5MB quota)
  };
  const clearLineage = () => {
    setLineageState(null);
    sessionStorage.removeItem(SS_LINEAGE);
  };

  return (
    <Ctx.Provider value={{
      theme, fontChoice, lineageData, imageMap,
      setTheme, setFontChoice, setLineage, setImageMap, clearLineage,
    }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAppState = () => useContext(Ctx);
