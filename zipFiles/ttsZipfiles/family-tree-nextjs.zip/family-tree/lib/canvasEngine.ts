"use client";
import { useRef, useCallback, RefObject } from "react";
import type { Theme } from "@/lib/themes";

// All coordinates are in WORLD space.
// Canvas engine applies ctx.translate(-viewX, 0) before drawing rings/lines
// so everything scrolls correctly as viewX increases.
export interface RingTarget {
  id: string; cx: number; cy: number; r: number;
  alpha: number; color: [number,number,number]; phase: number;
  scrollX?: number;  // additional translate X (for old-gen scroll)
}
export interface LineTarget {
  id: string; x1: number; y1: number; x2: number; y2: number;
  progress: number; alpha: number; color: [number,number,number];
  scrollX?: number;  // additional translate X
}

interface Particle { x:number; y:number; vx:number; vy:number; r:number; a:number; ph:number; }

export function useCanvasEngine(canvasRef: RefObject<HTMLCanvasElement>, theme: Theme) {
  const rings  = useRef<Map<string,RingTarget>>(new Map());
  const lines  = useRef<Map<string,LineTarget>>(new Map());
  const raf    = useRef(0);
  const parts  = useRef<Particle[]>([]);
  const clockS = useRef(0);  // seconds — for deterministic ring rotation
  const viewX  = useRef(0);  // world-space viewport left edge

  const init = (w:number, h:number) => {
    parts.current = Array.from({length:200}, () => ({
      x:Math.random()*w, y:Math.random()*h,
      vx:(Math.random()-.5)*.20, vy:(Math.random()-.5)*.20,
      r:Math.random()*1.4+.3, a:Math.random()*.22+.04,
      ph:Math.random()*Math.PI*2,
    }));
  };

  const drawParticles = (ctx:CanvasRenderingContext2D, w:number, h:number) => {
    const [pr,pg,pb] = theme.fatherColor;
    parts.current.forEach(p => {
      p.x+=p.vx; p.y+=p.vy; p.ph+=.009;
      if(p.x<0)p.x=w; if(p.x>w)p.x=0; if(p.y<0)p.y=h; if(p.y>h)p.y=0;
      const a = p.a*(.45+.55*Math.sin(p.ph));
      ctx.beginPath(); ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle=`rgba(${pr},${pg},${pb},${a.toFixed(3)})`; ctx.fill();
    });
  };

  const drawRing = (ctx:CanvasRenderingContext2D, ring:RingTarget, t:number) => {
    const {cx,cy,r,alpha,color:[cr,cg,cb],phase,scrollX=0} = ring;
    if(alpha<.01) return;
    const style = theme.ringStyle ?? "glow";
    const pulse = .65+.35*Math.sin(t*.04+phase);
    const rgba  = (a:number) => `rgba(${cr},${cg},${cb},${Math.max(0,a).toFixed(3)})`;

    ctx.save();
    if(scrollX!==0) ctx.translate(scrollX, 0);
    if(style==="glow") {
      const g=ctx.createRadialGradient(cx,cy,r*.5,cx,cy,r*2.5);
      g.addColorStop(0,rgba(.20*pulse*alpha)); g.addColorStop(1,rgba(0));
      ctx.beginPath(); ctx.arc(cx,cy,r*2.5,0,Math.PI*2); ctx.fillStyle=g; ctx.fill();
      ctx.save(); ctx.shadowBlur=36*pulse; ctx.shadowColor=rgba(alpha);
      ctx.strokeStyle=rgba(.92*pulse*alpha); ctx.lineWidth=5;
      ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.stroke(); ctx.restore();
      ctx.save(); ctx.translate(cx,cy); ctx.rotate(t*.018+phase);
      ctx.strokeStyle=rgba(.24*pulse*alpha); ctx.lineWidth=1.5; ctx.setLineDash([14,10]);
      ctx.beginPath(); ctx.arc(0,0,r+22,0,Math.PI*2); ctx.stroke();
      ctx.setLineDash([]); ctx.restore();
      for(let i=0;i<3;i++){
        const wt=(t*.8+phase*20+i*42)%58;
        const wA=Math.max(0,1-wt/58)*.45*pulse*alpha; if(wA<.01)continue;
        ctx.beginPath(); ctx.arc(cx,cy,r+wt,0,Math.PI*2);
        ctx.strokeStyle=rgba(wA); ctx.lineWidth=1.8; ctx.stroke();
      }

    } else if(style==="sharp") {
      ctx.save(); ctx.shadowBlur=10*pulse; ctx.shadowColor=rgba(alpha*.7);
      ctx.strokeStyle=rgba(.95*alpha); ctx.lineWidth=3;
      ctx.beginPath();
      for(let i=0;i<8;i++){
        const ang=i/8*Math.PI*2-Math.PI/8;
        i===0?ctx.moveTo(cx+r*Math.cos(ang),cy+r*Math.sin(ang)):ctx.lineTo(cx+r*Math.cos(ang),cy+r*Math.sin(ang));
      }
      ctx.closePath(); ctx.stroke(); ctx.restore();
      ctx.save(); ctx.translate(cx,cy); ctx.rotate(t*.025+phase);
      ctx.strokeStyle=rgba(.55*alpha); ctx.lineWidth=2;
      for(let i=0;i<4;i++){
        const ang=i/4*Math.PI*2;
        ctx.beginPath(); ctx.moveTo(r*Math.cos(ang),r*Math.sin(ang));
        ctx.lineTo((r+20)*Math.cos(ang),(r+20)*Math.sin(ang)); ctx.stroke();
      }
      ctx.restore();
      const g2=ctx.createRadialGradient(cx,cy,r*.8,cx,cy,r*1.6);
      g2.addColorStop(0,rgba(.10*pulse*alpha)); g2.addColorStop(1,rgba(0));
      ctx.beginPath(); ctx.arc(cx,cy,r*1.6,0,Math.PI*2); ctx.fillStyle=g2; ctx.fill();

    } else if(style==="dashed") {
      [[r,.022],[r+16,-.015],[r+32,.009]].forEach(([ri,sp],i)=>{
        ctx.save(); ctx.translate(cx,cy); ctx.rotate(t*(sp as number)+phase*(.7+i*.3));
        ctx.strokeStyle=rgba((.85-.2*i)*pulse*alpha);
        ctx.lineWidth=[3.5,2,1.5][i]; ctx.setLineDash([[8,8],[6,12],[10,6]][i]);
        ctx.shadowBlur=20-i*5; ctx.shadowColor=rgba(alpha*.8);
        ctx.beginPath(); ctx.arc(0,0,ri as number,0,Math.PI*2); ctx.stroke();
        ctx.setLineDash([]); ctx.restore();
      });
      const gd=ctx.createRadialGradient(cx,cy,0,cx,cy,r);
      gd.addColorStop(0,rgba(.14*pulse*alpha)); gd.addColorStop(1,rgba(0));
      ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.fillStyle=gd; ctx.fill();
      ctx.save(); ctx.translate(cx,cy); ctx.rotate(t*.01+phase);
      for(let i=0;i<6;i++){
        const ang=i/6*Math.PI*2;
        ctx.beginPath(); ctx.arc((r+16)*Math.cos(ang),(r+16)*Math.sin(ang),3,0,Math.PI*2);
        ctx.fillStyle=rgba(.7*pulse*alpha); ctx.fill();
      }
      ctx.restore();

    } else if(style==="double") {
      const gv=ctx.createRadialGradient(cx,cy,r*.6,cx,cy,r*2.8);
      gv.addColorStop(0,rgba(.22*pulse*alpha)); gv.addColorStop(.5,rgba(.08*pulse*alpha)); gv.addColorStop(1,rgba(0));
      ctx.beginPath(); ctx.arc(cx,cy,r*2.8,0,Math.PI*2); ctx.fillStyle=gv; ctx.fill();
      ctx.save(); ctx.shadowBlur=28*pulse; ctx.shadowColor=rgba(alpha);
      ctx.strokeStyle=rgba(.88*pulse*alpha); ctx.lineWidth=4.5;
      ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.stroke(); ctx.restore();
      ctx.save(); ctx.translate(cx,cy); ctx.rotate(-t*.012+phase);
      ctx.strokeStyle=rgba(.55*pulse*alpha); ctx.lineWidth=2.5; ctx.setLineDash([18,8]);
      ctx.beginPath(); ctx.arc(0,0,r-12,0,Math.PI*2); ctx.stroke(); ctx.setLineDash([]); ctx.restore();
      ctx.save(); ctx.translate(cx,cy); ctx.rotate(t*.019+phase);
      ctx.strokeStyle=rgba(.28*pulse*alpha); ctx.lineWidth=1.2; ctx.setLineDash([4,26]);
      ctx.beginPath(); ctx.arc(0,0,r+26,0,Math.PI*2); ctx.stroke(); ctx.setLineDash([]);
      for(let i=0;i<4;i++){
        const ang=i/4*Math.PI*2;
        ctx.beginPath(); ctx.arc((r+26)*Math.cos(ang),(r+26)*Math.sin(ang),4,0,Math.PI*2);
        ctx.fillStyle=rgba(.82*pulse*alpha); ctx.fill();
      }
      ctx.restore();
    }
    ctx.restore(); // undo scrollX
  };

  const drawLine = (ctx:CanvasRenderingContext2D, line:LineTarget) => {
    const {x1,y1,x2,y2,progress,alpha,color:[lr,lg,lb],scrollX=0} = line;
    if(alpha<.01||progress<=0) return;
    const ex=x1+(x2-x1)*progress, ey=y1+(y2-y1)*progress;
    ctx.save();
    if(scrollX!==0) ctx.translate(scrollX, 0);
    ctx.shadowBlur=18; ctx.shadowColor=`rgba(${lr},${lg},${lb},${alpha*.9})`;
    ctx.strokeStyle=`rgba(${lr},${lg},${lb},${(alpha*.88).toFixed(3)})`;
    ctx.lineWidth=3; ctx.lineCap="round";
    ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(ex,ey); ctx.stroke();
    ctx.shadowBlur=24; ctx.shadowColor=`rgba(${lr},${lg},${lb},1)`;
    ctx.beginPath(); ctx.arc(ex,ey,5.5,0,Math.PI*2);
    ctx.fillStyle=`rgba(${lr},${lg},${lb},${alpha.toFixed(3)})`; ctx.fill();
    ctx.restore();
  };

  const render = useCallback(() => {
    const canvas=canvasRef.current; if(!canvas) return;
    const ctx=canvas.getContext("2d"); if(!ctx) return;
    const W=canvas.width, H=canvas.height;
    ctx.clearRect(0,0,W,H);

    // Background fills full screen (not affected by scroll)
    const bg=ctx.createRadialGradient(W*.35,H*.45,0,W*.5,H*.5,W*.88);
    bg.addColorStop(0,theme.bgFrom);
    bg.addColorStop(.55,(theme as Record<string,string>).bgMid??theme.bgTo);
    bg.addColorStop(1,theme.bgTo);
    ctx.fillStyle=bg; ctx.fillRect(0,0,W,H);

    // Particles in screen space
    drawParticles(ctx,W,H);

    // Apply viewport scroll — shift world coordinates into screen space
    ctx.save();
    ctx.translate(-viewX.current, 0);
    lines.current.forEach(l => drawLine(ctx,l));
    const t = clockS.current * 60; // deterministic: same angle at same time always
    rings.current.forEach(r => drawRing(ctx,r,t));
    ctx.restore();

    raf.current = requestAnimationFrame(render);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canvasRef, theme]);

  const start = useCallback(() => {
    const c=canvasRef.current; if(!c) return;
    init(c.width, c.height);
    cancelAnimationFrame(raf.current);
    raf.current = requestAnimationFrame(render);
  }, [canvasRef, render]);

  const stop = useCallback(() => cancelAnimationFrame(raf.current), []);

  const setRings = useCallback((next:RingTarget[], vx?:number) => {
    const m=new Map<string,RingTarget>(); next.forEach(r=>m.set(r.id,r)); rings.current=m;
    if(vx!==undefined) viewX.current=vx;
  }, []);

  const setLines = useCallback((next:LineTarget[], vx?:number) => {
    const m=new Map<string,LineTarget>(); next.forEach(l=>m.set(l.id,l)); lines.current=m;
    if(vx!==undefined) viewX.current=vx;
  }, []);

  const clearAll = useCallback(() => { rings.current=new Map(); lines.current=new Map(); }, []);
  const setClockSeconds = useCallback((s:number) => { clockS.current=s; }, []);
  const setViewX        = useCallback((vx:number) => { viewX.current=vx; }, []);

  return {start, stop, setRings, setLines, clearAll, setClockSeconds, setViewX};
}
