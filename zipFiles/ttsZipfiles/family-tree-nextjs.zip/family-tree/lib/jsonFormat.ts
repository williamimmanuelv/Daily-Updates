// ─────────────────────────────────────────────────────────────
//  JSON INPUT FORMAT  v3
//  New: mother.wifeFamily — her own family tree shown in Ph6
// ─────────────────────────────────────────────────────────────

export interface PersonInput {
  name:  string;
  life:  string;
  title: string;
  desc:  string;
  image: string;
  fatherName?: string;
  motherName?: string;
}

export interface ChildInput {
  name:  string;
  image: string;
}

// Wife's own family tree — shown on the right side of the screen
// after the son arrives at father's position (Step 4 in sketch)
export interface WifeFamilyInput {
  father: PersonInput;          // wife's father
  mother: PersonInput;          // wife's mother
  siblings: ChildInput[];       // wife's siblings (wife herself is NOT listed here)
}

export interface FamilyInput {
  id:          number;
  era:         string;
  father:      PersonInput;
  mother:      PersonInput | null;
  children:    ChildInput[];
  isSubject?:  boolean;
}

export interface LineageJSON {
  channelName:    string;
  lineageSubject: string;
  videoTitle:     string;
  families:       FamilyInput[];
}

// ── Validation ────────────────────────────────────────────────
export interface ValidationResult { ok: boolean; errors: string[]; }

export function validateLineageJSON(raw: unknown): ValidationResult {
  const errors: string[] = [];
  if (!raw || typeof raw !== "object") return { ok: false, errors: ["Not a valid JSON object."] };
  const d = raw as Record<string, unknown>;
  if (!d.channelName    || typeof d.channelName    !== "string") errors.push("Missing: channelName");
  if (!d.lineageSubject || typeof d.lineageSubject !== "string") errors.push("Missing: lineageSubject");
  if (!d.videoTitle     || typeof d.videoTitle     !== "string") errors.push("Missing: videoTitle");
  if (!Array.isArray(d.families) || d.families.length === 0) {
    errors.push("Missing or empty: families[]");
    return { ok: false, errors };
  }
  (d.families as unknown[]).forEach((f, i) => {
    const px = `families[${i}]`;
    if (!f || typeof f !== "object") { errors.push(`${px}: not an object`); return; }
    const fam = f as Record<string, unknown>;
    if (typeof fam.id !== "number") errors.push(`${px}.id: must be a number`);
    if (!fam.era || typeof fam.era !== "string") errors.push(`${px}.era: must be a string`);
    if (!Array.isArray(fam.children)) errors.push(`${px}.children: must be an array (can be [])`);
    const chk = (p: unknown, lbl: string) => {
      if (!p || typeof p !== "object") { errors.push(`${lbl}: missing`); return; }
      const pp = p as Record<string, unknown>;
      ["name","life","title","desc","image"].forEach(k => {
        if (!pp[k] || typeof pp[k] !== "string") errors.push(`${lbl}.${k}: required string`);
      });
    };
    chk(fam.father, `${px}.father`);
    if (fam.mother !== null && fam.mother !== undefined) chk(fam.mother, `${px}.mother`);
  });
  return { ok: errors.length === 0, errors };
}

// ── Sample JSON ───────────────────────────────────────────────
export const SAMPLE_JSON: LineageJSON = {
  channelName:    "Family Tree",
  lineageSubject: "Aegon I → Jon Snow",
  videoTitle:     "The True Lineage of Jon Snow",
  families: [
    {
      id: 1, era: "The Conquest · 1 AC",
      father: { name: "Aegon I Targaryen", life: "27 BC – 37 AC",
        title: "Aegon the Conqueror", desc: "United the realm through fire and blood", image: "familyNo1father.jpg" },
      mother: { name: "Visenya Targaryen", life: "29 BC – 44 AC",
        title: "Queen · Warrior", desc: "Dragon-riding queen who wielded Dark Sister", image: "familyNo1mother.jpg" },
      children: [
        { name: "Aenys I",  image: "child1a.jpg" },
        { name: "Maegor I", image: "child1b.jpg" },
      ],
    },
    {
      id: 2, era: "The Dragon Kings · ~50 AC",
      father: { name: "Maekar I Targaryen", life: "66 AC – 221 AC",
        title: "King of the Seven Kingdoms", desc: "Stern ruler who claimed the throne through duty", image: "familyNo2father.jpg" },
      mother: { name: "Dyanna Dayne", life: "73 AC – 232 AC",
        title: "Queen Consort", desc: "Of House Dayne, graceful queen of Starfall",
        image: "familyNo2mother.jpg", fatherName: "Lord Dayne of Starfall", motherName: "Lady Dayne" },
      children: [
        { name: "Daeron", image: "child2a.jpg" },
        { name: "Aerion", image: "child2b.jpg" },
        { name: "Aemon",  image: "child2c.jpg" },
      ],
    },
    {
      id: 3, era: "The Mad King's Reign · ~259 AC",
      father: { name: "Rhaegar Targaryen", life: "259 AC – 283 AC",
        title: "Prince of Dragonstone", desc: "Melancholic prince whose choices ignited Robert's Rebellion", image: "familyNo3father.jpg" },
      mother: { name: "Lyanna Stark", life: "266 AC – 283 AC",
        title: "Lady of Winterfell", desc: "Spirited daughter of Winterfell whose secret marriage changed history",
        image: "familyNo3mother.jpg", fatherName: "Rickard Stark", motherName: "Lyarra Stark" },
      children: [],
    },
    {
      id: 4, era: "The War of Five Kings · 283 AC", isSubject: true,
      father: { name: "Jon Snow", life: "283 AC – Present",
        title: "Aegon VI Targaryen · King in the North", desc: "Raised a bastard, revealed as rightful heir to the Iron Throne", image: "familyNo4father.jpg" },
      mother: null, children: [],
    },
  ],
};
