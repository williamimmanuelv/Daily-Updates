// ─────────────────────────────────────────────────────────────
//  FAMILY TREE DATA
//  Edit LINEAGE_DATA to use for any historical / fictional /
//  celebrity lineage. Images live in /public/assets/
//  Naming convention:  familyNo1father.jpg  familyNo1mother.jpg
//                      familyNo2father.jpg  familyNo2mother.jpg  …
// ─────────────────────────────────────────────────────────────

export interface Person {
  name: string;
  life: string;       // e.g. "259 AC – 283 AC"
  title: string;      // short title / role
  desc: string;       // one-line achievement
}

export interface Family {
  id: number;         // determines image filename: familyNo{id}father.jpg
  era: string;        // shown as generation label
  father: Person;
  mother: Person | null;  // null = subject has no partner yet
  isSubject?: boolean;    // highlight this family as the end-subject
}

export const CHANNEL_NAME = "Family Tree";
export const LINEAGE_SUBJECT = "Jon Snow · Aegon Targaryen";
export const VIDEO_TITLE = "The True Lineage of Jon Snow";

export const LINEAGE_DATA: Family[] = [
  {
    id: 1,
    era: "The Conquest · 1 AC",
    father: {
      name: "Aegon I Targaryen",
      life: "27 BC – 37 AC",
      title: "Aegon the Conqueror · King of the Seven Kingdoms",
      desc: "United the realm through fire and blood, founding the Iron Throne",
    },
    mother: {
      name: "Visenya Targaryen",
      life: "29 BC – 44 AC",
      title: "Queen · Warrior of House Targaryen",
      desc: "Fierce dragon-riding queen who wielded Dark Sister into conquest",
    },
  },
  {
    id: 2,
    era: "The Dragon Kings · ~50 AC",
    father: {
      name: "Maekar I Targaryen",
      life: "66 AC – 221 AC",
      title: "King of the Seven Kingdoms",
      desc: "Stern and dutiful ruler who survived years of rebellion to claim the throne",
    },
    mother: {
      name: "Dyanna Dayne",
      life: "73 AC – 232 AC",
      title: "Queen Consort · Lady of Starfall",
      desc: "Of House Dayne, graceful queen and mother to the next king",
    },
  },
  {
    id: 3,
    era: "The Mad King's Reign · ~259 AC",
    father: {
      name: "Rhaegar Targaryen",
      life: "259 AC – 283 AC",
      title: "Prince of Dragonstone · Crown Prince",
      desc: "Melancholic prince whose choices ignited Robert's Rebellion",
    },
    mother: {
      name: "Lyanna Stark",
      life: "266 AC – 283 AC",
      title: "Lady of Winterfell · The Wolf Maid",
      desc: "Spirited daughter of Winterfell whose secret marriage changed history",
    },
  },
  {
    id: 4,
    era: "The War of Five Kings · 283 AC",
    isSubject: true,
    father: {
      name: "Jon Snow",
      life: "283 AC – Present",
      title: "Aegon VI Targaryen · King in the North",
      desc: "Raised a bastard, revealed as the rightful heir to the Iron Throne",
    },
    mother: null,
  },
];
