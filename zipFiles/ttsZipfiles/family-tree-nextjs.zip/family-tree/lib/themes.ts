export interface FontChoice {
  id: string;
  name: string;
  preview: string;
  headingFont: string;
  bodyFont: string;
  fontImport: string;
}

export interface Theme {
  id: string;
  name: string;
  icon: string;
  desc: string;
  bgFrom: string;
  bgTo: string;
  bgMid?: string;
  fatherColor: [number, number, number];
  motherColor: [number, number, number];
  arrowColor: string;
  arrowGlow: string;
  particleColor: string;
  headingFont: string;
  bodyFont: string;
  nameColor: string;
  lifeColor: string;
  titleColor: string;
  descColor: string;
  eraColor: string;
  ringStyle: "glow" | "sharp" | "dashed" | "double";
  headerColor: string;
  timelineDot: string;
  timelineActive: string;
  buttonBorder: string;
  buttonText: string;
  fontImport: string;
}

export const THEMES: Record<string, Theme> = {
  history: {
    id: "history", name: "History", icon: "⚔️", desc: "Aged parchment, sepia & gold",
    bgFrom: "#1a1208", bgTo: "#0d0a04", bgMid: "#14100a",
    fatherColor: [201,168,76], motherColor: [180,140,90],
    arrowColor: "rgba(201,168,76,0.9)", arrowGlow: "rgba(201,168,76,0.6)",
    particleColor: "201,168,76",
    headingFont: "'Cinzel', serif", bodyFont: "'Cormorant Garamond', serif",
    nameColor: "#f0d080", lifeColor: "#8a7840", titleColor: "#c9a84c", descColor: "#8a8070",
    eraColor: "rgba(201,168,76,0.4)", ringStyle: "glow",
    headerColor: "#f0d080", timelineDot: "#c9a84c", timelineActive: "#f0d080",
    buttonBorder: "rgba(201,168,76,0.5)", buttonText: "#c9a84c",
    fontImport: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,300;0,400;0,600;1,300;1,400&family=Cinzel:wght@400;600;700&family=Cinzel+Decorative:wght@400;700&display=swap",
  },
  royal: {
    id: "royal", name: "Royal", icon: "👑", desc: "Deep navy, platinum & crimson",
    bgFrom: "#080c1a", bgTo: "#04060f", bgMid: "#0a0e18",
    fatherColor: [192,160,255], motherColor: [220,180,100],
    arrowColor: "rgba(220,180,100,0.9)", arrowGlow: "rgba(192,160,255,0.6)",
    particleColor: "192,160,255",
    headingFont: "'Playfair Display', serif", bodyFont: "'EB Garamond', serif",
    nameColor: "#e8d8ff", lifeColor: "#7060a0", titleColor: "#c0a0ff", descColor: "#806880",
    eraColor: "rgba(192,160,255,0.4)", ringStyle: "double",
    headerColor: "#e8d8ff", timelineDot: "#c0a0ff", timelineActive: "#e8d8ff",
    buttonBorder: "rgba(192,160,255,0.5)", buttonText: "#c0a0ff",
    fontImport: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=EB+Garamond:ital,wght@0,400;0,600;1,400&display=swap",
  },
  fantasy: {
    id: "fantasy", name: "Fantasy", icon: "🐉", desc: "Arcane teal & emerald glow",
    bgFrom: "#060f0e", bgTo: "#030908", bgMid: "#050d0c",
    fatherColor: [80,220,180], motherColor: [140,255,140],
    arrowColor: "rgba(80,220,180,0.9)", arrowGlow: "rgba(80,220,180,0.6)",
    particleColor: "80,220,180",
    headingFont: "'Uncial Antiqua', cursive", bodyFont: "'Philosopher', serif",
    nameColor: "#aaffee", lifeColor: "#407060", titleColor: "#50dca0", descColor: "#608878",
    eraColor: "rgba(80,220,180,0.4)", ringStyle: "dashed",
    headerColor: "#aaffee", timelineDot: "#50dca0", timelineActive: "#aaffee",
    buttonBorder: "rgba(80,220,180,0.5)", buttonText: "#50dca0",
    fontImport: "https://fonts.googleapis.com/css2?family=Uncial+Antiqua&family=Philosopher:ital,wght@0,400;0,700;1,400&display=swap",
  },
  modern: {
    id: "modern", name: "Modern", icon: "🏙️", desc: "Clean white on black, geometric",
    bgFrom: "#0a0a0a", bgTo: "#050505", bgMid: "#080808",
    fatherColor: [255,255,255], motherColor: [180,220,255],
    arrowColor: "rgba(255,255,255,0.85)", arrowGlow: "rgba(180,220,255,0.5)",
    particleColor: "200,200,200",
    headingFont: "'Inter', sans-serif", bodyFont: "'Inter', sans-serif",
    nameColor: "#ffffff", lifeColor: "#606060", titleColor: "#b0b0b0", descColor: "#707070",
    eraColor: "rgba(255,255,255,0.3)", ringStyle: "sharp",
    headerColor: "#ffffff", timelineDot: "#ffffff", timelineActive: "#ffffff",
    buttonBorder: "rgba(255,255,255,0.4)", buttonText: "#ffffff",
    fontImport: "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap",
  },
  classic: {
    id: "classic", name: "Classic", icon: "🏛️", desc: "Warm ivory & terracotta",
    bgFrom: "#120e08", bgTo: "#0a0704", bgMid: "#0e0b06",
    fatherColor: [220,160,80], motherColor: [200,130,100],
    arrowColor: "rgba(220,160,80,0.9)", arrowGlow: "rgba(220,160,80,0.6)",
    particleColor: "220,160,80",
    headingFont: "'Libre Baskerville', serif", bodyFont: "'Lora', serif",
    nameColor: "#f5e8cc", lifeColor: "#907050", titleColor: "#dca050", descColor: "#907868",
    eraColor: "rgba(220,160,80,0.4)", ringStyle: "glow",
    headerColor: "#f5e8cc", timelineDot: "#dca050", timelineActive: "#f5e8cc",
    buttonBorder: "rgba(220,160,80,0.5)", buttonText: "#dca050",
    fontImport: "https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Lora:ital,wght@0,400;0,600;1,400&display=swap",
  },
};

export const DEFAULT_THEME = "history";

// ── Font options per theme ────────────────────────────────────
export const FONT_OPTIONS: Record<string, FontChoice[]> = {
  history: [
    { id: "default",  name: "Cinzel Classic",      preview: "Imperial Roman lettering",  headingFont: "'Cinzel', serif",             bodyFont: "'Cormorant Garamond', serif", fontImport: "https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,600;1,400&family=Cinzel:wght@400;700&display=swap" },
    { id: "trajan",   name: "Trajan Serif",         preview: "Ancient stone inscription",  headingFont: "'Cinzel Decorative', serif",  bodyFont: "'EB Garamond', serif",        fontImport: "https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@400;700&family=EB+Garamond:ital,wght@0,400;1,400&display=swap" },
    { id: "oldstyle", name: "Old Style",            preview: "Scholarly medieval script",  headingFont: "'Libre Baskerville', serif",  bodyFont: "'Lora', serif",               fontImport: "https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Lora:ital,wght@0,400;1,400&display=swap" },
  ],
  royal: [
    { id: "default",   name: "Playfair Regal",      preview: "Victorian aristocracy",      headingFont: "'Playfair Display', serif",   bodyFont: "'EB Garamond', serif",        fontImport: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=EB+Garamond:ital,wght@0,400;1,400&display=swap" },
    { id: "cormorant", name: "Cormorant Grand",     preview: "Baroque ornamental style",   headingFont: "'Cormorant SC', serif",       bodyFont: "'Cormorant Garamond', serif", fontImport: "https://fonts.googleapis.com/css2?family=Cormorant+SC:wght@400;700&family=Cormorant+Garamond:ital,wght@0,400;1,400&display=swap" },
    { id: "crimson",   name: "Crimson Text",        preview: "Classical European court",   headingFont: "'Cinzel', serif",             bodyFont: "'Crimson Text', serif",       fontImport: "https://fonts.googleapis.com/css2?family=Cinzel:wght@400;700&family=Crimson+Text:ital,wght@0,400;1,400&display=swap" },
  ],
  fantasy: [
    { id: "default",   name: "Uncial Antiqua",      preview: "Celtic illuminated script",  headingFont: "'Uncial Antiqua', cursive",   bodyFont: "'Philosopher', serif",        fontImport: "https://fonts.googleapis.com/css2?family=Uncial+Antiqua&family=Philosopher:ital,wght@0,400;0,700;1,400&display=swap" },
    { id: "medievalsharp", name: "Medieval Sharp",  preview: "Rune-carved stone text",     headingFont: "'MedievalSharp', cursive",    bodyFont: "'Lora', serif",               fontImport: "https://fonts.googleapis.com/css2?family=MedievalSharp&family=Lora:ital,wght@0,400;1,400&display=swap" },
    { id: "inkfree",   name: "Ink Sigil",           preview: "Hand-drawn wizard's tome",   headingFont: "'Cinzel Decorative', serif",  bodyFont: "'Philosopher', serif",        fontImport: "https://fonts.googleapis.com/css2?family=Cinzel+Decorative:wght@400;700&family=Philosopher:ital,wght@0,400;1,400&display=swap" },
  ],
  modern: [
    { id: "default",   name: "Inter Clean",         preview: "Minimal sans-serif precision", headingFont: "'Inter', sans-serif",        bodyFont: "'Inter', sans-serif",        fontImport: "https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" },
    { id: "mono",      name: "Monospace Code",      preview: "Terminal data readout",        headingFont: "'JetBrains Mono', monospace",bodyFont: "'JetBrains Mono', monospace", fontImport: "https://fonts.googleapis.com/css2?family=JetBrains+Mono:ital,wght@0,400;0,700;1,400&display=swap" },
    { id: "futura",    name: "Jost Geometric",      preview: "Bauhaus geometric modern",     headingFont: "'Jost', sans-serif",         bodyFont: "'Jost', sans-serif",          fontImport: "https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,300;0,500;0,700;1,300&display=swap" },
  ],
  classic: [
    { id: "default",   name: "Baskerville",         preview: "Refined English serif",       headingFont: "'Libre Baskerville', serif", bodyFont: "'Lora', serif",               fontImport: "https://fonts.googleapis.com/css2?family=Libre+Baskerville:ital,wght@0,400;0,700;1,400&family=Lora:ital,wght@0,400;1,400&display=swap" },
    { id: "garamond",  name: "EB Garamond",         preview: "Renaissance Italian press",   headingFont: "'EB Garamond', serif",       bodyFont: "'Crimson Text', serif",       fontImport: "https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,700;1,400&family=Crimson+Text:ital,wght@0,400;1,400&display=swap" },
    { id: "spectral",  name: "Spectral",            preview: "Literary editorial elegance", headingFont: "'Spectral', serif",          bodyFont: "'Spectral', serif",           fontImport: "https://fonts.googleapis.com/css2?family=Spectral:ital,wght@0,300;0,400;0,600;1,300;1,400&display=swap" },
  ],
};
