#!/usr/bin/env node
/**
 * export-frames.js — Family Tree Video Exporter
 * ═══════════════════════════════════════════════
 * 60fps · 1920×1080 · H.264 CRF14 · YouTube-ready
 *
 * HOW IMAGES WORK IN EXPORT:
 *   Puppeteer opens a fresh browser — it has none of the user's uploaded
 *   images in memory.  This script solves that by:
 *
 *   1. After page loads, reading  window.__IMAGES_NEEDED  (list of filenames).
 *   2. For each filename, looking in these locations IN ORDER:
 *        a) output/images-export/  (auto-saved by the app on export click)
 *        b) public/assets/         (user may have placed real photos here)
 *   3. Reading each file as base64 and building a { filename: dataURL } map.
 *   4. Calling window.__injectImages(map) which injects them into React state.
 *   5. Waiting for re-render, then capturing frames.
 *
 * SETUP:
 *   Terminal 1:   npm run dev
 *   Terminal 2:   node scripts/export-frames.js
 *
 * REQUIREMENTS:  npm install puppeteer   +   FFmpeg in PATH
 *
 * IMAGES:
 *   Option A — Use the app's "Export Images" button to auto-save to output/images-export/
 *   Option B — Place portrait photos in public/assets/ with exact filenames from JSON
 */

var puppeteer = require("puppeteer");
var spawn     = require("child_process").spawn;
var path      = require("path");
var fs        = require("fs");

var ROOT = path.join(__dirname, "..");

var CFG = {
  url:          "http://localhost:3000/preview",
  width:        1920,
  height:       1080 + 56,
  fps:          60,
  framesDir:    path.join(ROOT, "output", "frames"),
  outDir:       path.join(ROOT, "output"),
  outFile:      "family-tree-video.mp4",
  // Locations to search for image files (checked in order)
  imageDirs:    [
    path.join(ROOT, "output", "images-export"),  // saved by the app
    path.join(ROOT, "public", "assets"),         // static assets
  ],
  introSecs:    4,
  outroSecs:    4,
  frameDelay:   12,
  batchSize:    120,
  batchPause:   400,
};

function sleep(ms) { return new Promise(function(r){ setTimeout(r,ms); }); }
function pad(n,len) { var s=String(n); while(s.length<len) s="0"+s; return s; }

// Read a file as base64 data URL from any of the search dirs
function findImageAsDataURL(filename) {
  for (var i = 0; i < CFG.imageDirs.length; i++) {
    var fp = path.join(CFG.imageDirs[i], filename);
    if (fs.existsSync(fp)) {
      var buf  = fs.readFileSync(fp);
      var ext  = path.extname(filename).toLowerCase().replace(".", "");
      var mime = ext === "png" ? "image/png"
               : ext === "gif" ? "image/gif"
               : ext === "webp" ? "image/webp"
               : "image/jpeg";
      return "data:" + mime + ";base64," + buf.toString("base64");
    }
  }
  return null;  // not found anywhere
}

async function main() {
  console.log("╔════════════════════════════════════════════════════╗");
  console.log("║   Family Tree — 60fps Video Exporter               ║");
  console.log("╚════════════════════════════════════════════════════╝\n");

  // Check dev server
  try {
    await new Promise(function(res,rej){
      require("http").get("http://localhost:3000", res).on("error", rej);
    });
    console.log("✅ Dev server running");
  } catch(e) {
    console.error("❌ Dev server not found. Run:  npm run dev");
    process.exit(1);
  }

  // Setup dirs
  fs.mkdirSync(CFG.framesDir, {recursive:true});
  fs.mkdirSync(CFG.outDir,    {recursive:true});
  var old = fs.readdirSync(CFG.framesDir).filter(function(f){return f.endsWith(".png");});
  if(old.length){
    console.log("🗑  Deleted "+old.length+" old frames");
    old.forEach(function(f){ fs.unlinkSync(path.join(CFG.framesDir,f)); });
  }

  // Launch browser
  console.log("🌐 Launching Chrome "+CFG.width+"×"+CFG.height+"...");
  var browser = await puppeteer.launch({
    headless: "new",
    protocolTimeout: 180000,
    defaultViewport: { width:CFG.width, height:CFG.height },
    args: [
      "--no-sandbox", "--disable-setuid-sandbox", "--disable-web-security",
      "--font-render-hinting=none", "--disable-gpu",
      "--disable-background-timer-throttling",
      "--disable-renderer-backgrounding",
      "--disable-backgrounding-occluded-windows",
      // Allow data: URLs in img src (important for injected base64 images)
      "--allow-file-access-from-files",
    ],
  });

  var page = await browser.newPage();
  await page.setViewport({width:CFG.width, height:CFG.height, deviceScaleFactor:1});
  page.on("console", function(m){ if(m.type()==="error") console.log("  [page]", m.text().slice(0,120)); });
  page.on("pageerror", function(e){ console.log("  [page error]", String(e).slice(0,120)); });

  // Load page
  console.log("📄 Loading "+CFG.url+"...");
  for(var attempt=1; attempt<=3; attempt++){
    try {
      await page.goto(CFG.url, {waitUntil:"domcontentloaded", timeout:45000});
      console.log("   ✓ Loaded (attempt "+attempt+")"); break;
    } catch(e) {
      console.log("   ⚠ Attempt "+attempt+": "+e.message.slice(0,60));
      if(attempt===3){ await browser.close(); process.exit(1); }
      await sleep(2500);
    }
  }

  console.log("⏳ Waiting for React hydration...");
  await sleep(5000);
  try {
    await page.waitForFunction(function(){
      return document.fonts && document.fonts.status==="loaded";
    }, {timeout:8000});
  } catch(e){ console.log("   ⚠ Font timeout — continuing"); }
  await sleep(1000);

  // Kill CSS transitions for deterministic frames
  await page.addStyleTag({content:"*,*::before,*::after{transition:none!important;animation-duration:0.001ms!important;}"});

  // ──────────────────────────────────────────────────────────
  //  INJECT IMAGES
  //  The page exposes window.__IMAGES_NEEDED  (list of filenames)
  //  We read each from disk and inject via window.__injectImages()
  // ──────────────────────────────────────────────────────────
  console.log("\n🖼  Loading images for injection...");

  var needed = await page.evaluate(function(){
    return window.__IMAGES_NEEDED || [];
  });

  console.log("   Need "+needed.length+" images");

  var imageMap = {};
  var missing  = [];

  needed.forEach(function(filename) {
    var dataURL = findImageAsDataURL(filename);
    if(dataURL){
      imageMap[filename] = dataURL;
      console.log("   ✓ "+filename+" ("+Math.round(dataURL.length/1024)+"KB)");
    } else {
      missing.push(filename);
      console.log("   ✗ "+filename+" — NOT FOUND (will use placeholder)");
    }
  });

  if(missing.length > 0){
    console.log("\n⚠  "+missing.length+" images not found.");
    console.log("   Place them in one of these folders:");
    CFG.imageDirs.forEach(function(d){ console.log("     "+d); });
    console.log("   Or use the app's Export Images button to auto-save them.\n");
  }

  if(Object.keys(imageMap).length > 0){
    console.log("\n💉 Injecting "+Object.keys(imageMap).length+" images into page...");
    await page.evaluate(function(map){
      if(typeof window.__injectImages === "function"){
        window.__injectImages(map);
      } else {
        // Fallback: set directly
        window.__ftImages = map;
      }
    }, imageMap);
    await sleep(800);  // wait for React re-render
    console.log("   ✓ Images injected");
  }

  // ──────────────────────────────────────────────────────────
  //  START ANIMATION
  // ──────────────────────────────────────────────────────────
  console.log("\n▶  Starting animation...");
  await page.evaluate(function(){
    var b = Array.from(document.querySelectorAll("button")).find(function(b){
      return b.textContent && b.textContent.toUpperCase().indexOf("BEGIN") !== -1;
    });
    if(b) b.click();
    else console.warn("BEGIN button not found");
  });
  await sleep(2000);

  // Read timing info
  var info = await page.evaluate(function(){
    return { totalSecs: window.__TOTAL_SECS||100, totalGens: window.__TOTAL_GENS||4 };
  });
  var totalSecs   = info.totalSecs;
  var videoSecs   = CFG.introSecs + totalSecs + CFG.outroSecs;
  var totalFrames = Math.round(videoSecs * CFG.fps);
  var estMins     = Math.round(totalFrames * (CFG.frameDelay + 8) / 1000 / 60);

  console.log("\n📊 Video info:");
  console.log("   Generations : "+info.totalGens);
  console.log("   Anim time   : "+totalSecs.toFixed(1)+"s");
  console.log("   Total video : "+videoSecs.toFixed(1)+"s");
  console.log("   Frames      : "+totalFrames+" @ "+CFG.fps+"fps");
  console.log("   Est. time   : ~"+estMins+" mins\n");

  var frameIndex = 0;
  var clip = {x:0, y:56, width:1920, height:1080};

  async function snap(label) {
    var fname = "frame_"+pad(frameIndex+1, 6)+".png";
    await page.screenshot({path:path.join(CFG.framesDir,fname), type:"png", clip});
    frameIndex++;
    if(frameIndex%60===0 || frameIndex===totalFrames){
      var pct = Math.round(frameIndex/totalFrames*100);
      process.stdout.write("  ["+label+"] "+frameIndex+"/"+totalFrames+" ("+pct+"%)      \r");
    }
    await sleep(CFG.frameDelay);
    if(frameIndex%CFG.batchSize===0) await sleep(CFG.batchPause);
  }

  // Intro frames
  console.log("📽  Intro ("+CFG.introSecs+"s)...");
  await page.evaluate(function(){if(typeof window.__seekTo==="function")window.__seekTo(0);});
  for(var i=0; i<Math.round(CFG.introSecs*CFG.fps); i++) await snap("INTRO");

  // Animation frames
  console.log("\n📽  Animation ("+totalSecs.toFixed(1)+"s)...");
  var animFrames = Math.round(totalSecs * CFG.fps);
  for(var fi=0; fi<animFrames; fi++){
    await page.evaluate(function(t){if(typeof window.__seekTo==="function")window.__seekTo(t);}, fi/CFG.fps);
    await sleep(14);
    await snap("ANIM");
  }

  // Outro frames
  console.log("\n📽  Outro ("+CFG.outroSecs+"s)...");
  await page.evaluate(function(t){if(typeof window.__seekTo==="function")window.__seekTo(t);}, totalSecs-0.5);
  await sleep(400);
  for(var j=0; j<Math.round(CFG.outroSecs*CFG.fps); j++) await snap("OUTRO");

  await browser.close();
  console.log("\n\n✅ Captured "+frameIndex+" frames\n");

  // FFmpeg encode
  var outPath = path.join(CFG.outDir, CFG.outFile);
  var inPat   = path.join(CFG.framesDir, "frame_%06d.png");
  console.log("🎬 Encoding with FFmpeg (CRF 14, 60fps)...\n");

  await new Promise(function(resolve, reject){
    var args = [
      "-y", "-framerate", String(CFG.fps), "-i", inPat,
      "-c:v", "libx264", "-preset", "slow", "-crf", "14",
      "-pix_fmt", "yuv420p", "-vf", "scale=1920:1080",
      "-movflags", "+faststart",
      "-b:v", "40M", "-maxrate", "50M", "-bufsize", "80M",
      outPath,
    ];
    var proc = spawn("ffmpeg", args, {stdio:"inherit", shell:false});
    proc.on("close", function(code){ code===0?resolve(null):reject(new Error("FFmpeg exit: "+code)); });
    proc.on("error", function(err){
      console.error("❌ FFmpeg not found:", err.message);
      console.error("   Windows: https://www.gyan.dev/ffmpeg/builds/");
      console.error("   Mac:     brew install ffmpeg");
      reject(err);
    });
  });

  var mb = (fs.statSync(outPath).size/1024/1024).toFixed(1);
  console.log("\n╔════════════════════════════════════════════════════╗");
  console.log("║  🎉 VIDEO CREATED!                                 ║");
  console.log("╚════════════════════════════════════════════════════╝");
  console.log("   File  : "+outPath);
  console.log("   Size  : "+mb+" MB");
  console.log("   Spec  : 1920×1080 · H.264 CRF14 · 60fps · YouTube-ready\n");
}

main().catch(function(e){
  console.error("\n❌ Fatal:", e.message||e);
  process.exit(1);
});
