#!/usr/bin/env node
/**
 * generate-placeholders.js
 * ─────────────────────────
 * Reads targaryen-lineage.json and generates SVG placeholder images
 * for every image filename in the data.
 *
 * Run:   node scripts/generate-placeholders.js
 *
 * Then replace files in public/assets/ with real portrait photos (same filenames).
 * Images should be square (400×400px min), JPEG or PNG format.
 */

var fs   = require("fs");
var path = require("path");

var ASSETS  = path.join(__dirname, "..", "public", "assets");
var JSON_FILE = path.join(__dirname, "..", "public", "targaryen-lineage.json");

fs.mkdirSync(ASSETS, { recursive: true });

var data = JSON.parse(fs.readFileSync(JSON_FILE, "utf8"));

// Collect all images + labels
var images = [];

data.families.forEach(function(fam) {
  images.push({ filename: fam.father.image, name: fam.father.name, role: "Father", color: "#6b4e20", accent: "#c9a84c" });
  if(fam.mother) {
    images.push({ filename: fam.mother.image, name: fam.mother.name, role: "Mother", color: "#1e3a4a", accent: "#9fbfcf" });
  }
  (fam.children||[]).forEach(function(ch, i) {
    images.push({ filename: ch.image, name: ch.name, role: "Child", color: "#2a2a3a", accent: "#b8a880" });
  });
});

// Deduplicate by filename
var seen = {};
images = images.filter(function(img) {
  if(seen[img.filename]) return false;
  seen[img.filename] = true;
  return true;
});

function lighten(hex) {
  var r=parseInt(hex.slice(1,3),16), g=parseInt(hex.slice(3,5),16), b=parseInt(hex.slice(5,7),16);
  return "rgb("+Math.min(255,r+50)+","+Math.min(255,g+50)+","+Math.min(255,b+50)+")";
}

function initials(name) {
  return name.split(" ").filter(function(w){ return /^[A-Z]/.test(w); })
    .map(function(w){ return w[0]; }).join("").slice(0,2).toUpperCase();
}

function makeSVG(img) {
  var size = img.role==="Child" ? 200 : 400;
  var h = size/2;
  var bg = img.color, ac = img.accent;
  var ini = initials(img.name);
  var fontSize = size===400 ? 110 : 52;
  var labelSize = size===400 ? 18 : 10;
  return [
    '<svg xmlns="http://www.w3.org/2000/svg" width="'+size+'" height="'+size+'">',
    '<defs>',
    '<radialGradient id="g" cx="38%" cy="32%" r="70%">',
    '<stop offset="0%" stop-color="'+lighten(bg)+'"/>',
    '<stop offset="100%" stop-color="'+bg+'"/>',
    '</radialGradient>',
    '</defs>',
    '<circle cx="'+h+'" cy="'+h+'" r="'+h+'" fill="url(#g)"/>',
    '<circle cx="'+h+'" cy="'+h+'" r="'+(h*0.86)+'" stroke="'+ac+'" stroke-width="1.5" fill="none" opacity="0.22"/>',
    '<circle cx="'+h+'" cy="'+(h*0.70)+'" r="'+(h*0.28)+'" fill="'+ac+'" opacity="0.38"/>',
    '<ellipse cx="'+h+'" cy="'+(h*1.26)+'" rx="'+(h*0.36)+'" ry="'+(h*0.24)+'" fill="'+ac+'" opacity="0.30"/>',
    '<text x="'+h+'" y="'+(h+fontSize*0.14)+'" font-family="Georgia,serif" font-size="'+fontSize+'" font-weight="bold"',
    '  fill="'+ac+'" text-anchor="middle" dominant-baseline="middle" opacity="0.72">'+ini+'</text>',
    '<text x="'+h+'" y="'+(size-28)+'" font-family="Georgia,serif" font-size="'+labelSize+'"',
    '  fill="'+ac+'" text-anchor="middle" opacity="0.4" letter-spacing="3">'+img.role.toUpperCase()+'</text>',
    '</svg>',
  ].join("\n");
}

var count = 0;
console.log("\n🎨 Generating placeholder images for Targaryen lineage...\n");

images.forEach(function(img) {
  var svg  = makeSVG(img);
  var fpath = path.join(ASSETS, img.filename);
  fs.writeFileSync(fpath, svg);
  console.log("  ✓ "+img.filename+"  ←  "+img.name+" ("+img.role+")");
  count++;
});

console.log("\n✅ Created "+count+" placeholder images in public/assets/\n");
console.log("📸 TO ADD REAL IMAGES:");
console.log("   Replace the files above with actual portrait photos (same filenames).");
console.log("   Format: square JPEG or PNG, at least 400×400px (800×800 recommended).");
console.log("   Portrait orientation, centered face, no border.\n");
console.log("   To load targaryen-lineage.json in the app:");
console.log("   1. Go to the Home page");
console.log("   2. Upload public/targaryen-lineage.json as your lineage file");
console.log("   3. Click CREATE VIDEO\n");
