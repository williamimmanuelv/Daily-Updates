import { BrowserRouter, Navigate, Route, Routes, useNavigate } from 'react-router-dom';
import './App.css';
import "primereact/resources/themes/lara-light-cyan/theme.css";
import { ToastContainer } from 'react-toastify';
import React, { useEffect } from 'react';
import 'react-toastify/dist/ReactToastify.css';
// import Header from './Component/Header/Header';
// import Sidebarmenu from './Component/Sidebar/Sidebarmenu';
import CreateCategory from './Pages/Category/CreateCategory';
import EditCategory from './Pages/Category/EditCategory';
import ListCategory from './Pages/Category/ListCategory';
import CreateSubcategory from './Pages/SubCategory/CreateSubcategory';
import ListSubcategory from './Pages/SubCategory/ListSubcategory';
import CreateProduct from './Pages/Products/CreateProduct';
import ListProduct from './Pages/Products/ListProduct';
import CreateAttribute from './Pages/Attribute/CreateAttribute';
import ListAttribute from './Pages/Attribute/ListAttribute';
import Layout from './Component/Sidebar/Layout';
import ManageOrders from './Pages/Orders/ManageOrders';
import ConfirmedOrder from './Pages/Orders/ConfirmedOrder';
import Inprocess from './Pages/Orders/Inprocess';
import ShippedOrder from './Pages/Orders/ShippedOrder';
import DeliveredOrder from './Pages/Orders/DeliveredOrder';
import OntransiteOrder from './Pages/Orders/OntransiteOrder';
import CancelledOrder from './Pages/Orders/CancelledOrder';
import ChecklistorOrdersummery from './Pages/Orders/ChecklistorOrdersummery';
import Bucketlist from './Pages/Orders/Bucketlist';
import TackawayOrder from './Pages/Orders/TackawayOrder';
import Stock from './Pages/Inventory/Stock';
import Customers from './Pages/Customers/Customers';
import EditSubcategory from './Pages/SubCategory/EditSubcategory';
import EditProduct from './Pages/Products/EditProduct';
import EditAttribute from './Pages/Attribute/EditAttribute';
import Coupon from './Pages/Marketing/Coupon';
import CustomeAlert from './Pages/Marketing/CustomeAlert';
import DynamicPopup from './Pages/Marketing/DynamicPopup';
import FlashDeals from './Pages/Marketing/FlashDeals';
import Notifications from './Pages/Marketing/Notifications';
import CouponCreate from './Pages/Marketing/CouponCreate';
import CouponEdit from './Pages/Marketing/CouponEdit';
import FlashDealsCreate from './Pages/Marketing/FlashDealsCreate';
import FlashDealsEdit from './Pages/Marketing/FlashDealsEdit';
import DynamicPopupCreate from './Pages/Marketing/DynamicPopupCreate';
import DynamicPopupEdit from './Pages/Marketing/DynamicPopupEdit';
import CustomeAlertCreate from './Pages/Marketing/CustomeAlertCreate';
import CustomeAlertEdit from './Pages/Marketing/CustomeAlertEdit';
import NotificationCreate from './Pages/Marketing/NotificationCreate';
import NotificationEdit from './Pages/Marketing/NotificationEdit';
import Queries from './Pages/Support/Queries';
import AllStaff from './Pages/StaffManagement/AllStaff';
// import Permission from './Pages/StaffManagement/Permission';
import Addrole from './Pages/RoleAndPermissionManagement/Addrole';
import RoleList from './Pages/RoleAndPermissionManagement/RoleList';
import Editrole from './Pages/RoleAndPermissionManagement/Editrole';
import Police from './Pages/Polices/Police';
import TrackingOrder from './Pages/TrackingOrder/TrackingOrder';
import PaymentSuccess from './Pages/Payments/PaymentSuccess';
import PaymentFailed from './Pages/Payments/PaymentFailed';

import TaxSetting from './Pages/Settings/TaxSetting';
import TaxCreation from './Pages/Settings/TaxCreation';
import TaxEdit from './Pages/Settings/TaxEdit';
import NotesInformation from './Pages/Notes/NotesInformation';
import Dailysalesreport from './Pages/Report/Dailysalesreport';
import EarningReport from './Pages/Report/EarningReport';
import Productwishlist from './Pages/Report/Productwishlist';
import Usersearchreport from './Pages/Report/Usersearchreport';
import Dashboard from './Pages/Dashboard/Dashboard';
import Login from './Component/LoginPages/Login';
import BulkUpload from './Pages/Products/BulkUpload';
import RefundandReplacement from './Pages/TrackingOrder/RefundandReplacement';
import CreateDeliveryCharges from './Pages/DeliveryCharges/CreateDeliveryCharges';
import ListDeliveryCharges from './Pages/DeliveryCharges/ListDeliveryCharges';
import EditDeliveryCharges from './Pages/DeliveryCharges/EditDeliveryCharges';
import ListRoles from './Pages/RoleCreation/ListRoles';
import Private from './Component/LoginPages/Private';
import AutoGenerateCoupon from './Pages/Marketing/AutoGenerateCoupon';
import AutogenCpnCreate from './Pages/Marketing/AutogenCpnCreate';
import AutogenCpnEdit from './Pages/Marketing/AutogenCpnEdit';
import BackgroundBanner from './Pages/BannerImage/App/BackgroundBanner';


import Advertising2Banner from './Pages/BannerImage/App/Advertising2Banner';
import Advertising3 from './Pages/BannerImage/App/Advertising3';
import Advertising4 from './Pages/BannerImage/App/Advertising4';
import FooterBanner from './Pages/BannerImage/App/FooterBanner';
import PromotingBanner from './Pages/BannerImage/Web/PromotingBanner';
import HeroBannerApp from './Pages/BannerImage/App/HeroBannerApp';
import HeroBanner from './Pages/BannerImage/Web/HeroBanner';
import Advertising1Banner from './Pages/BannerImage/App/Advertising1Banner';
import AdvertisingBanner from './Pages/BannerImage/Web/AdvertisingBanner';
import TaxCreations from './Pages/Tax/TaxCreations';
import TaxEdits from './Pages/Tax/TaxEdits';
import TaxSettings from './Pages/Tax/TaxSettings';
import QrScanner from './Pages/QRScanner/QrScanner';
import ProtectedRoute from './Component/LoginPages/ProtectedRoute';
import OrderPlaced from './Pages/Orders/ManageOrder/PickupOrder/OrderPlaced';
import ProcessingPickup from './Pages/Orders/ManageOrder/PickupOrder/ProcessingPickup';
import Packed from './Pages/Orders/ManageOrder/PickupOrder/Packed';
import ReadyforPickup from './Pages/Orders/ManageOrder/PickupOrder/ReadyforPickup';
import PickedUp from './Pages/Orders/ManageOrder/PickupOrder/PickedUp';
import OrderPlacedDelivery from './Pages/Orders/ManageOrder/DeliveryOrder/OrderPlacedDelivery';
import ProcessingDelivery from './Pages/Orders/ManageOrder/DeliveryOrder/ProcessingDelivery';
import PackedDelivery from './Pages/Orders/ManageOrder/DeliveryOrder/PackedDelivery';
import ShippedDelivery from './Pages/Orders/ManageOrder/DeliveryOrder/ShippedDelivery';
import DeliveryDeliOrder from './Pages/Orders/ManageOrder/DeliveryOrder/DeliveryDeliOrder';
import BillingAddress from './Pages/BillingAddress/BillingAddress';
import Allpickuporders from './Pages/Orders/ManageOrder/PickupOrder/Allpickuporders';
import Alldeliveryorder from './Pages/Orders/ManageOrder/DeliveryOrder/Alldeliveryorder';
import Language_Pending from './Pages/Products/LanguagePending';

function App() {
  //    const navigate=useNavigate()
  //   useEffect(() => {
  //   const token = localStorage.getItem("token");

  //   if (!token) {
  //     navigate("/login");
  //   }
  // }, [navigate]);
  return (
    <>
      {/* <BrowserRouter basename='adminpanel' > */}
      <BrowserRouter basename='adminpanelnew' >
        <Routes>
          <Route
            path="/login"
            element={
              <Private>
                <Login />
              </Private>
            }
          />
          {/* <Route path="/" element={<Private> <Layout /></Private>} /> */}

          <Route path="/" element={
            // <Private>
            <ProtectedRoute>
              <Layout />

            </ProtectedRoute>
            // </Private>
          }>
            {/* <Route path="/dashbord" element={<Dashboard />} />   */}
            <Route index element={<Dashboard />} />

            {/* BannerWeb........................................ */}
            <Route path="/herobannerweb" element={<HeroBanner />} />
            <Route path="/promotingbanner" element={<PromotingBanner />} />
            <Route path="/advertisingbannerweb" element={<AdvertisingBanner />} />

            {/* BannerApp........................................ */}
            <Route path="/backgroundbanner" element={<BackgroundBanner />} />
            <Route path="/herobannerApp" element={<HeroBannerApp />} />
            <Route path="/advertisingbannerapp" element={<Advertising1Banner />} />
            <Route path="/advertising2banner" element={<Advertising2Banner />} />
            <Route path="/advertising3" element={<Advertising3 />} />
            <Route path="/advertising4" element={<Advertising4 />} />
            <Route path="/footerbanner" element={<FooterBanner />} />


            {/* RoleCreation............................................. .........*/}

            {/* <Route path="/listrole" element={<ListRoles />} /> */}

            <Route path="/listrole" element={<Private> <ListRoles /></Private>} />
            {/* Category............................................. .........*/}
            {/* <Route path="/create" element={<CreateCategory />} /> */}
            <Route path="/create" element={<Private> <CreateCategory /></Private>} />
            <Route path="/edit" element={<EditCategory />} />
            <Route path="/list" element={<ListCategory />} />

            {/* subcategory... ...................................... ................*/}

            <Route path="/createsubcategory" element={<CreateSubcategory />} />
            <Route path="/editsubcategory" element={<EditSubcategory />} />

            <Route path="/listsubcategory" element={<ListSubcategory />} />

            {/* Products............................. .................... ............*/}
            <Route path="/createproduct" element={<CreateProduct />} />
            <Route path="/editproducts" element={<EditProduct />} />
            <Route path="/bulkupload" element={<BulkUpload />} />
            <Route path="/listproduct" element={<ListProduct />} />
            <Route path="/languagepending" element={<Language_Pending/>} />

            {/* Attribute.......... .............................................. */}
            <Route path="/createAttribute" element={<CreateAttribute />} />
            <Route path="/editattribute" element={<EditAttribute />} />

            <Route path="/listAttribute" element={<ListAttribute />} />

            {/* Orders.......... .............................................. */}
            {/* Pickup  */}
            <Route path="/orderplaced" element={<OrderPlaced />} />
            <Route path="/processingpickup" element={<ProcessingPickup />} />
            <Route path="/packed" element={<Packed />} />
            <Route path="/readyforpickup" element={<ReadyforPickup />} />
            <Route path="/pickedup" element={<PickedUp />} />
            <Route path="/allpickuporders" element={<Allpickuporders />} />

            <Route path="/manageOrders" element={<ManageOrders />} />
            {/* <Route path="/confirmedOrder" element={<ConfirmedOrder />} />
            <Route path="/inprocess" element={<Inprocess />} />
            <Route path="/shippedOrder" element={<ShippedOrder />} />
            <Route path="/tackawayorder" element={<TackawayOrder />} /> */}

            {/* delivery */}
            <Route path="/orderplaceddelivery" element={<OrderPlacedDelivery />} />
            <Route path="/processingdelivery" element={<ProcessingDelivery />} />
            <Route path="/packeddelivery" element={<PackedDelivery />} />
            <Route path="/shippeddelivery" element={<ShippedDelivery />} />
            <Route path="/deliverydeliOrder" element={<DeliveryDeliOrder />} />
            <Route path="/alldeliveryOrder" element={<Alldeliveryorder />} />

            {/* <Route path="/deliveredOrder" element={<DeliveredOrder />} />
            <Route path="/ontransiteorder" element={<OntransiteOrder />} /> */}
            <Route path="/cancelledOrder" element={<CancelledOrder />} />
            <Route path="/checklist" element={<ChecklistorOrdersummery />} />
            <Route path="/bucketlist" element={<Bucketlist />} />


            {/* Stock....... ......................................................... */}
            <Route path="/stock" element={<Stock />} />

            {/* Customer................. ..................................... */}
            <Route path="/customers" element={<Customers />} />

            {/* Report................. ..................................... */}
            <Route path="/dailysalesreport" element={<Dailysalesreport />} />
            <Route path="/earningreport" element={<EarningReport />} />
            <Route path="/productwishlist" element={<Productwishlist />} />
            <Route path="/usersearchreport" element={<Usersearchreport />} />


            {/* Marketing............ .................................. */}
            <Route path="/couponmarketing" element={<Coupon />} />
            <Route path="/couponCreate" element={<CouponCreate />} />
            <Route path="/couponEdit" element={<CouponEdit />} />

            <Route path="/autogeneratecoupon" element={<AutoGenerateCoupon />} />
            <Route path="/autogencpncreate" element={<AutogenCpnCreate />} />
            <Route path="/autogencpnedit" element={<AutogenCpnEdit />} />

            <Route path="/flashdeals" element={<FlashDeals />} />
            <Route path="/flashdealscreate" element={<FlashDealsCreate />} />
            <Route path="/flashdealsedit" element={<FlashDealsEdit />} />

            <Route path="/dynamicpopup" element={<DynamicPopup />} />
            <Route path="/dynamicpopupcreate" element={<DynamicPopupCreate />} />
            <Route path="/dynamicpopupedit" element={<DynamicPopupEdit />} />

            <Route path="/customeralert" element={<CustomeAlert />} />
            <Route path="/customeralertCreate" element={<CustomeAlertCreate />} />
            <Route path="/customeralertEdit" element={<CustomeAlertEdit />} />


            <Route path="/notification" element={<Notifications />} />
            <Route path="/notificationcreation" element={<NotificationCreate />} />
            <Route path="/notificationedit" element={<NotificationEdit />} />

            {/* Support..... ................... .............................................. */}
            <Route path="/queries" element={<Queries />} />


            {/* Staff Management..... ................... .............................................. */}
            <Route path="/allstaff" element={<AllStaff />} />
            {/* <Route path="/permission" element={<Permission />} /> */}

            {/* Role and permission Management..... ................... .............................................. */}
            <Route path="/addrole" element={<Addrole />} />
            <Route path="/rolelist" element={<RoleList />} />
            <Route path="/editrole" element={<Editrole />} />


            {/* Polices..... ................... .............................................. */}
            <Route path="/police" element={<Police />} />

            {/* TrackingOrder.................................................................... */}
            <Route path="/trackingorder" element={<TrackingOrder />} />
            <Route path="/refundandreplacement" element={<RefundandReplacement />} />


            {/* Payments.................................................................... */}
            <Route path="/paymentsuccess" element={<PaymentSuccess />} />
            <Route path="/paymentfailed" element={<PaymentFailed />} />

            {/* QR Scanner.................................................................... */}
            <Route path="/qrscanner" element={<QrScanner />} />


            {/* DeliveryCharges.................................................................... */}

            <Route path="/CreateDeliveryCharges" element={<CreateDeliveryCharges />} />
            <Route path="/EditDeliveryCharges" element={<EditDeliveryCharges />} />
            <Route path="/ListDeliveryCharges" element={<ListDeliveryCharges />} />

            {/* Settings.................................................................... */}

            <Route path="/taxcreation" element={<TaxCreation />} />
            <Route path="/taxedit" element={<TaxEdit />} />
            <Route path="/taxsetting" element={<TaxSetting />} />

            {/* BillingAddress..................  */}
            <Route path="/billingaddress" element={<BillingAddress />} />

            {/* Tax.................................................................... */}

            <Route path="/taxcreations" element={<TaxCreations />} />
            <Route path="/taxedits" element={<TaxEdits />} />
            <Route path="/taxsettings" element={<TaxSettings />} />

            {/* Polices..... ................... .............................................. */}
            <Route path="/notes" element={<NotesInformation />} />

            {/* More routes can go here */}
            {/* </main>
              </div>
              }
              /> */}
          </Route>
          <Route path="*" element={<Navigate to="/login" replace />} />
        </Routes>
        {/* </main>
        </div>
      </div> */}

      </BrowserRouter>
      <ToastContainer position="top-center" autoClose={1000} />
    </>
  );
}

export default App;

// const orders = [...Array(1000)].map((_, i) => ({
//   orderId: "ORD" + (i + 1),
//   customerName: "Customer " + (i + 1),
//   amount: Math.floor(Math.random() * 5000),
//   status: i % 2 ? "Delivered" : "Pending",
//   date: "2025-01-01",
// }));

// export default function App() {
//   return (
// <button onClick={() => GenerateOrderSummaryPdf(orders)}>
//   Download 1000 Orders PDF
// </button>
//   );
// }
