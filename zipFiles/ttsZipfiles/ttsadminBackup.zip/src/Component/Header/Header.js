import React, { useState, useEffect } from 'react'
import logo from "../../Assets/logo.png"
import adminimg from "../../Assets/adminimage.jpg"
import adminimg2 from "../../Assets/5951752.png"
import './header.css'
import { CiHeart } from "react-icons/ci";
import { HiOutlineBell } from "react-icons/hi";
import { HiOutlineShoppingBag } from "react-icons/hi2";
import { RiMoonFill } from "react-icons/ri";
import { BiSolidBell } from "react-icons/bi";
import { IoMdSettings } from "react-icons/io";
import { FaClock } from "react-icons/fa6";
import { Badge } from 'primereact/badge';
import avatar from "../../Assets/avatar-1.jpg"
import { CgProfile } from "react-icons/cg";
import { TbLogout2 } from "react-icons/tb";
import { IoIosHelpCircleOutline } from "react-icons/io";
import axios from 'axios';
import { base_url } from '../../Api/BaseUrl';
import { useNavigate } from 'react-router-dom';

// 


import axiosInstance from '../../utils/axiosinstance';


const Header = ({ pagePath }) => {


  console.log("pageHederapth", pagePath)

  const token = localStorage.getItem("tokenAdmin")
  const role = localStorage.getItem("adminRole");


  const navigate = useNavigate()
  console.log("tokenAdmin", token)
  const handleLogout = async () => {

    try {
      const response = await axios.post(`${base_url}/admin/logout`, {}, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      })
      localStorage.removeItem("tokenAdmin")
      navigate("/login")
    }
    catch (error) {
      console.log("error message")
    }
  }
  // notify for language

  const [pendingLength, setPendingLength] = useState(0)

  const notifyForPendingLang = async () => {
    try {
      const response = await axiosInstance.get(`/products/lang/pending`)
      setPendingLength(response.data.data);
      console.log("responsedata_langpending", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  console.log("pendingLength", pendingLength.length);

  useEffect(() => {
    notifyForPendingLang()
    console.log("pendingLength", pendingLength.length);

  }, [])

  // const navigateToEdit = () =>{
  //   navigate('/editproducts')
  // }



  return (
    <>
      <div className="header_bgcolor p-2 ">
        <div className='d-flex'>

          <div className='pt-2'>
            <span className='fw-semibold fs-5  text-nowrap ps-3'>{pagePath}</span>
          </div>
          <div className="container-fluid d-flex justify-content-end">

            <div className='d-flex align-items-center position-relative'>
              <HiOutlineBell size={25} />
              <span className='position-absolute'
                style={{
                  top: "1px",
                  left: "5px",
                  borderRadius: "50%",
                  backgroundColor: "red",
                  color: "white",
                  width: "20px",
                  height: "20px",
                  textAlign: "center",
                  // fontSize:"12px"

                }}>
                {pendingLength.length}
              </span>
              {/* <Badge value={1}  className='position-absolute'
                style={{
                  top:"1px",
                  left:"2px",
                  width:"6px",
                  height:"6px"
                
                }}
              /> */}
            </div>

            <div className="dropdown">
              <img
                src={adminimg2}
                className="img-fluid btn btnicons dropdown-toggle rounded-circle"
                alt="avatar"
                style={{ width: "60px", cursor: "pointer", objectFit: "cover" }}
                data-bs-toggle="dropdown"
                aria-expanded="false"
              />
              <span>{role}</span>

              <ul className="dropdown-menu mt-2">
                {/* <li>
    <a className="dropdown-item d-flex align-items-center gap-2 text-muted" href="#">
      <CgProfile size={18} className="" />
      Profile
    </a>
  </li> */}
                <li>
                  <a className="dropdown-item d-flex align-items-center gap-2 text-danger" href="#" onClick={() => handleLogout()}>
                    <TbLogout2 size={18} className="text-danger" />
                    Log Out
                  </a>
                </li>
              </ul>

            </div>


            {/* <div className="d-flex align-items-center gap-3 order-1 order-lg-2 mt-2 mt-lg-0">
        <RiMoonFill size={22} />
        <BiSolidBell size={23} />
        <IoMdSettings size={23} />
        <FaClock size={18} />
       
        <button className="btn header_color text-white fw-bold ms-3">LogOut</button>
      </div> */}


          </div>
        </div>

      </div>

    </>
  )
}

export default Header