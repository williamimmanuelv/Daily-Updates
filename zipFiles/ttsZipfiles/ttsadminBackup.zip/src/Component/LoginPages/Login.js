import React, { useState } from 'react'
import "./login.css"
import loginlogo from "../../Assets/logo.png"

import { useFormik } from 'formik'
import * as yup from "yup";
import loginbgimage from "../../Assets/bgimage.png"
import axios from 'axios';
import { base_url } from "../../Api/BaseUrl"
import { useNavigate } from 'react-router-dom';
import Toast from '../../utils/Toast';

 const Login = () => {
  
 const [token,setToken] = useState([])

 console.log("tokenss",token)
  const navigate=useNavigate()

  const onSubmit = async (values) => {
    console.log("values", values)
    
    try {
      //  const response = await axios.post( "https://rooptek.com/ttsbrothers/api/admin/login", values)
       const response = await axios.post(`${base_url}/admin/login`, values) 
      
      setToken(response.data)
      console.log("response.data",response.data)
       localStorage.setItem("tokenAdmin",response?.data?.token)
       localStorage.setItem("adminRole",response?.data?.data?.role)

      // localStorage.removeItem("token")
       if (!token) {
      Toast({ message: "Token not found in API response!", type: "error" });
      return;
    }
        Toast({ message: "Successfully Login", type: "success" });
      formik.resetForm()
     navigate('/')
    }
   catch (error) {
  if (error.response?.data?.message === "Invalid username") {
    formik.setFieldError("username", "Invalid username");
  } else if (error.response?.data?.message === "Invalid password") {
    formik.setFieldError("password", "Invalid password");
  } else {
    Toast({ message: "Login failed. Please try again.", type: "error" });
  }
  }

  }

  const formik = useFormik(
    {
      initialValues: {
        username: "",
        password: ""
      },
      validationSchema: yup.object().shape({
        username: yup.string().required("username is required!"),
        password: yup.string().required("Password is required")
      }),
      onSubmit,
    }
  )
  return (
    <>
      <div className="d-flex justify-content-center mt-5 pt-5">
        <div className="d-flex pt-4" style={{ height: "450px" }}>

          {/* Left Box */}
          <div
            className="box_shadow p-4 rounded w-100 bg-dark"
            style={{ maxWidth: "450px" }}
          >
            <div className="text-center mb-4 mt-2">
              <img src={loginbgimage} alt="Logo" className="img-fluid" />
            </div>
            <div className="text-white">
              <h3>New Marketing Tools</h3>
              <h3>Available</h3>
            </div>
          </div>

          {/* Right Box */}
          <div
            className="box_shadow p-4 rounded w-100  bgcolor"
            style={{ maxWidth: "450px" }}
          >
            <div className="text-center mb-4">
              <img
                src={loginlogo}
                alt="Logo"
                className="img-fluid"
                style={{ maxHeight: "50px", objectFit: "cover" }}
              />
            </div>

            <form onSubmit={formik.handleSubmit} autoComplete="off">
             <div className="mb-3 ">
                <label htmlFor="username" className="form-label fw-semibold">
                  UserName
                </label>
                <input
                  type="username"
                  className="form-control bg-white"
                  id="username"
                  name="username"
                  placeholder="Enter UserName"
                  value={formik.values.username}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  autoComplete='off'
                />
                {formik.errors.username && formik.touched.username && (
                  <p style={{ color: "red", fontSize: "12px", marginTop: "2px" }}>
                    {formik.errors.username}
                  </p>
                )}
              </div>

              {/* Password */}
              <div className="mb-3 ">
                <label htmlFor="password" className="form-label fw-semibold">
                  Password
                </label>
                <input
                  type="password"
                  className="form-control bg-white"
                  id="password"
                  name="password"
                  placeholder="Enter password"
                  value={formik.values.password}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                  autoComplete='off'
                />
                {formik.errors.password && formik.touched.password && (
                  <p style={{ color: "red", fontSize: "12px" , marginTop: "2px"}}>
                    {formik.errors.password}
                  </p>
                )}
              </div>

              {/* Remember Me & Forgot Password */}
              {/* <div className="d-flex justify-content-between align-items-center mb-4 mt-4">
                <div className="form-check ">
                  <input
                    type="checkbox"
                    className="form-check-input bg-white"
                    id="rememberMe"
                  />
                  <label className="form-check-label" htmlFor="rememberMe">
                    Remember Me
                  </label>
                </div>
                <a href="#" className="text-decoration-none">
                  Forgot Password?
                </a>
              </div> */}

              {/* Submit Button */}
              <div className="text-center pt-3  mb-5">
                <button type="submit" className="btn btn-dark mt-1">Login</button>
              </div>

            </form>
          </div>
        </div>
      </div>

    </>
  )
}

export default Login