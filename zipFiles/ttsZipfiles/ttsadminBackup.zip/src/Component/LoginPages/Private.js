// import React from "react";
// import { Navigate } from "react-router-dom";

// const Private = ({ children }) => {
//   const token = localStorage.getItem("token");

//   if (!token) {
//     return <Navigate to="/login" replace />;
//   }

//   return children;
  
// };

// export default Private;
import React from "react";
import { Navigate, useLocation } from "react-router-dom";

const Private = ({ children }) => {
  const token = localStorage.getItem("tokenAdmin");
  const location = useLocation();

  // If logged in and trying to go to login page → redirect to dashboard
  if (token && location.pathname === "/login") {
    return <Navigate to="/" replace />;
  }

  // If NOT logged in and trying to access any other page → redirect to login
  if (!token && location.pathname !== "/login") {
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default Private;

