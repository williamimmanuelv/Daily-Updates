// Layout.jsx
import React, { useEffect, useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Header from '../Header/Header';
import Sidebarmenu from './Sidebarmenu';
import './sidebar.css'; 


const Layout = () => {
  // const [pagePath, setPagePath] = useState("");

  const [pagePath, setPagePath] = useState("");
  const location = useLocation();

  useEffect(() => {
    // Load title from localStorage so it works across tabs
    const savedTitle = localStorage.getItem("selectedTitle");
    if (savedTitle) {
      setPagePath(savedTitle);
    }
  }, [location]);
  return (
    // <div className="layout-container">
    //   <div className="sidebar">
    //     <Sidebarmenu setPagePath={setPagePath}/>
    //   </div>
    //   <div className="main-content">
    //     <Header pagePath={pagePath}/>
    //     <div className="page-content">
    //       <Outlet />
    //     </div>
    //   </div>
    // </div>
    <div className="layout-container">
      <div className="sidebar">
        <Sidebarmenu setPagePath={(title) => {
          setPagePath(title);
          localStorage.setItem("selectedTitle", title); // save in localStorage
        }} />
      </div>
      <div className="main-content">
        <Header pagePath={pagePath} />
        <div className="page-content">
          <Outlet />
        </div>
      </div>
    </div>
  );
};

export default Layout;
