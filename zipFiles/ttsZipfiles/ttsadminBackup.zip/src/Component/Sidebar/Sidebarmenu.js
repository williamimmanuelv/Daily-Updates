import React, { useState } from 'react'
import { Sidebar, Menu, MenuItem, SubMenu, } from 'react-pro-sidebar';
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Box, IconButton, Typography } from "@mui/material";
import ReceiptOutlinedIcon from "@mui/icons-material/ReceiptOutlined";
import './sidebar.css'
import logo from "../../Assets/logo.png"
import Header from '../Header/Header';
// import Header from '../Header/Header';
import { TbCategoryPlus } from "react-icons/tb";
import { RiProductHuntLine } from "react-icons/ri";
import { TbCategoryMinus } from "react-icons/tb";
// import { FaFirstOrderAlt } from "react-icons/fa";
import { LiaJediOrder } from "react-icons/lia";
import { MdOutlineInventory } from "react-icons/md";
import { LiaUserPlusSolid } from "react-icons/lia";
import { LiaHomeSolid } from "react-icons/lia";
import { HiOutlineHome } from "react-icons/hi2";
import { HiOutlineDocumentReport } from "react-icons/hi";
import { SiGooglemarketingplatform } from "react-icons/si";
import { CgSupport } from "react-icons/cg";
import { SiStaffbase } from "react-icons/si";
import { MdPolicy } from "react-icons/md";
import { MdPayments } from "react-icons/md";
import { LuSettings } from "react-icons/lu";
import { FaNotesMedical } from "react-icons/fa6";
import { CiDeliveryTruck } from "react-icons/ci";

//  const Item = ({ title, to, icon, selected, setSelected }) => {
const Item = ({ title, to, icon, selected, setSelected, setPagePath }) => {
  const isActive = selected === to;

  return (
    // <MenuItem
    //   className={`sidenav ${selected === to ? "active-menu-item" : ""}`}
    //   onClick={() => setSelected(to)}
    //   icon={icon}
    //   component={<Link to={to} />}
    // >
    <MenuItem
      className={`sidenav ${isActive ? "active-menu-item" : ""}`}
      // onClick={(e) => {
      //    e.preventDefault()
      //   setSelected(to);
      //   sessionStorage.setItem("selectedRoute", to);
      //   setPagePath(title);
      //   console.log("titttttt",title)
      // }}
      onClick={() => {
        setSelected(to);
        localStorage.setItem("selectedRoute", to);
        setPagePath(title);
        localStorage.setItem("selectedTitle", title); // store in localStorage
      }}
      icon={icon}
      component={<Link to={to} />}
      style={{
        backgroundColor: isActive ? "#d32f2f" : "",
        color: isActive ? "#fff" : undefined,
        borderRadius: isActive ? 8 : undefined,
      }}
    >
      <Typography sx={{ color: isActive ? "#fff" : undefined }}>{title}</Typography>
    </MenuItem>
  );
};

const Sidebarmenu = ({ setPagePath }) => {


  const [activeItem, setActiveItem] = useState('');
  const [isCollapsed, setIsCollapsed] = useState(false);
  // const [selected, setSelected] = useState("")
  const [selected, setSelected] = useState(() => {
    return sessionStorage.getItem('selectedRoute') || "";
  });
  const [openSubMenus, setOpenSubMenus] = useState(() => {
    return JSON.parse(sessionStorage.getItem('openSubMenus')) || {};
  });

  const toggleSubMenu = (menu) => {
    setOpenSubMenus((prev) => {
      const updated = { ...prev, [menu]: !prev[menu] };
      sessionStorage.setItem('openSubMenus', JSON.stringify(updated));
      return updated;
    });
  };


  return (
    <>
      {/* <Header /> */}
      <Sidebar className='bgcolor' style={{ height: "100vh" }} collapsed={isCollapsed}>
        <div className='pt-3 ps-5 pb-4'>
          <img
            src={logo}
            alt="Logo"
            className="img-fluid"
            style={{ maxHeight: '50px', objectFit: "cover" }}
            onClick={() => setIsCollapsed((pre) => (!pre))}
          />
        </div>
        <Menu>
          {/* <SubMenu label="Dashboard" icon={<LiaHomeSolid  fontSize='18'/>}  open={openSubMenus['Dashboard']} onClick={() => toggleSubMenu('Dashboard')}>  */}
          <Item
            title="Dashboard"
            to="/"
            icon={<HiOutlineHome size={18} />}
            selected={selected}
            setSelected={setSelected}
            setPagePath={setPagePath}

          />
          <SubMenu label="Master" icon={<TbCategoryMinus fontSize='18' />} open={openSubMenus['Master']} onClick={() => toggleSubMenu('Master')}>

            <SubMenu label="Banner" icon={<TbCategoryMinus fontSize='18' />} open={openSubMenus['Banner']} onClick={() => toggleSubMenu('Banner')}>


              <SubMenu label="Web" icon={<TbCategoryMinus fontSize='18' />} open={openSubMenus['Web']} onClick={() => toggleSubMenu('Web')}>


                <Item
                  title="HeroBanner"
                  to="/herobannerweb"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}

                />
                <Item
                  title="PromotingBanner"
                  to="/promotingbanner"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="AdvertisingBanner"
                  to="/advertisingbannerweb"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
              </SubMenu>
              <SubMenu label="App" icon={<TbCategoryMinus fontSize='18' />} open={openSubMenus['App']} onClick={() => toggleSubMenu('App')}>

                <Item
                  title="BackgroundBanner"
                  to="/backgroundbanner"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="HeroBanner"
                  to="/herobannerApp"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Advertising Banner"
                  to="/advertisingbannerapp"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Advertising2 Banner"
                  to="/advertising2banner"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Advertising3"
                  to="/advertising3"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Advertising4"
                  to="/advertising4"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />

                <Item
                  title="FooterBanner"
                  to="/footerbanner"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />

              </SubMenu>
            </SubMenu>

            <SubMenu label="Role Creation" icon={<TbCategoryMinus fontSize='18' />} open={openSubMenus['Role Creation']} onClick={() => toggleSubMenu('Role Creation')}>


              <Item
                title="Role List"
                to="/listrole"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
            </SubMenu>

            <SubMenu label="Category" icon={<TbCategoryMinus fontSize='18' />} open={openSubMenus['category']} onClick={() => toggleSubMenu('category')}>

              <Item
                title="Category Create"
                to="/create"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
              <Item
                title="Category List"
                to="/list"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />

              {/* <Item
     title="Edit"
       to="/edit"
       selected={selected}
        setSelected={setSelected}
       /> */}


            </SubMenu>
            <SubMenu label="SubCategory" icon={<TbCategoryPlus fontSize='18' />} open={openSubMenus['Subcategory']} onClick={() => toggleSubMenu('Subcategory')}>
              <Item
                title="SubCategory Create"
                to="/createsubcategory"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
              {/* <MenuItem> Edit </MenuItem> */}
              <Item
                title="SubCategory List"
                to="/listsubcategory"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
            </SubMenu>

            <SubMenu label="Staff Management" icon={<SiStaffbase fontSize='15' />} open={openSubMenus['Staff Management']} onClick={() => toggleSubMenu('Staff Management')}>
              <Item
                title="AllStaff"
                to="/allstaff"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
            </SubMenu>

            <SubMenu label="Role And Permission" icon={<ReceiptOutlinedIcon fontSize='18' />} open={openSubMenus['Role And Permission']} onClick={() => toggleSubMenu('Role And Permission')}>
              <Item
                title="AddRole"
                to="/addrole"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
              <Item
                title="RoleList"
                to="/rolelist"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
            </SubMenu>

            <SubMenu label="Delivery Charges" icon={<CiDeliveryTruck fontSize='18' />} open={openSubMenus['Delivery Charges']} onClick={() => toggleSubMenu('Delivery Charges')}>
              <Item
                title="Delivery Charges Creation"
                to="/CreateDeliveryCharges"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
              <Item
                title="Delivery Charges List"
                to="/ListDeliveryCharges"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
            </SubMenu>
            <SubMenu label="Attribute" icon={<ReceiptOutlinedIcon fontSize='12' />} open={openSubMenus['Attribute']} onClick={() => toggleSubMenu('Attribute')}>
              <Item
                title="Attribute Create"
                to="/createAttribute"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
              <Item
                title="Attribute List"
                to="/listAttribute"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />

            </SubMenu>
            <SubMenu label="Shop Address" icon={<LuSettings fontSize='18' />} open={openSubMenus['Shop Address']} onClick={() => toggleSubMenu('Shop Address')}>

              <Item
                title="Shop"
                to="/billingaddress"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}
              />
            </SubMenu>
            {/* <SubMenu label="Tax" icon={<LuSettings fontSize='18' />} open={openSubMenus['Tax']} onClick={() => toggleSubMenu('Tax')}>
              <Item
                title="TaxCreation"
                to="/taxcreations"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
              <Item
                title="TaxSetting"
                to="/taxsettings"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}

              />
            </SubMenu> */}


          </SubMenu>


          {/* </SubMenu>  */}

          {/* <SubMenu label="Master Page" icon={<ReceiptOutlinedIcon />} style={{ color: "black" }} open={openSubMenus['MasterPage']} onClick={() => toggleSubMenu('MasterPage')}>
    <Item
     title="Sub Property Type"
       to="/document"
       selected={selected}
        setSelected={setSelected}
       />

       </SubMenu> */}


          <SubMenu label="Product" icon={<RiProductHuntLine fontSize='18' />} open={openSubMenus['Product']} onClick={() => toggleSubMenu('Product')}>
            <Item
              title="Product Create"
              to="/createproduct"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title="Product List"
              to="/listproduct"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title="Language pending"
              to="/languagepending"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title="Bulk Upload"
              to="/bulkupload"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            {/* <MenuItem> Create </MenuItem> */}
          </SubMenu>

          <SubMenu label="Orders" icon={<LiaJediOrder fontSize='15' />} open={openSubMenus['Orders']} onClick={() => toggleSubMenu('Orders')}>

            <Item
              title="Manage Orders"
              to="/manageOrders"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}
            />
            <SubMenu label="Pickup" icon={<TbCategoryMinus fontSize='18' />} open={openSubMenus['Pickup']} onClick={() => toggleSubMenu('Pickup')}>
              <Item
                title="Allpickuporders"
                to="/allpickuporders"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}
              />

              {/* <Item
                  title="Order Placed"
                  to="/orderplaced"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                 />
                <Item
                  title="Processing"
                  to="/processingpickup"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Packed"
                  to="/packed"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Ready for Pickup"
                  to="/readyforpickup"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Picked Up"
                  to="/pickedup"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                /> */}
            </SubMenu>


            <SubMenu label="Delivery " icon={<TbCategoryMinus fontSize='18' />} open={openSubMenus['Delivery ']} onClick={() => toggleSubMenu('Delivery ')}>
              <Item
                title="AlldeliveryOrder"
                to="/alldeliveryOrder"
                selected={selected}
                setSelected={setSelected}
                setPagePath={setPagePath}
              />
              {/* <Item
                  title="Order Placed"
                  to="/orderplaceddelivery"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Processing"
                  to="/processingdelivery"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Packed"
                  to="/packeddelivery"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Shipped"
                  to="/shippeddelivery"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                />
                <Item
                  title="Delivered"
                  to="/deliverydeliOrder"
                  selected={selected}
                  setSelected={setSelected}
                  setPagePath={setPagePath}
                /> */}

            </SubMenu>
            {/* <Item
              title="Confirmed order"
              to="/confirmedOrder"
              selected={selected}
              setSelected={setSelected}
            setPagePath={setPagePath}
            />
            <Item
              title="Inprocess"
              to="/inprocess"
              selected={selected}
              setSelected={setSelected}
            setPagePath={setPagePath}

            />
            <Item
              title="Ready to dispatch order"
              to="/shippedOrder"
              selected={selected}
              setSelected={setSelected}
            setPagePath={setPagePath}

            />
            <Item
              title="Pickup Orders"
              to="/tackawayorder"
              selected={selected}
              setSelected={setSelected}
            setPagePath={setPagePath}

            />

            <Item
              title="On Transite order"
              to="/ontransiteorder"
              selected={selected}
              setSelected={setSelected}
            setPagePath={setPagePath}

            />
            <Item
              title="Delivered Order"
              to="/deliveredOrder"
              selected={selected}
              setSelected={setSelected}
            setPagePath={setPagePath}

            /> */}
            <Item
              title="Cancelled Order"
              to="/cancelledOrder"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title=" Order summery"
              to="/checklist"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title="Bucket list"
              to="/bucketlist"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />

          </SubMenu>

          <SubMenu label="Inventory" icon={<MdOutlineInventory fontSize='16' />} open={openSubMenus['Inventory']} onClick={() => toggleSubMenu('Inventory')}>
            <Item
              title="Stock"
              to="/stock"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu>
          <SubMenu label="Customers" icon={<LiaUserPlusSolid fontSize='18' />} open={openSubMenus['Customers']} onClick={() => toggleSubMenu('Customers')}>
            <Item
              title="CustomerList"
              to="/Customers"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu>
          <SubMenu label="Reports" icon={<HiOutlineDocumentReport fontSize='18' />} open={openSubMenus['Reports']} onClick={() => toggleSubMenu('Reports')}>
            <Item
              title="Earning Report"
              to="/earningreport"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            {/* <Item
       title="Daily sales report"
       to="/dailysalesreport"
       selected={selected}
        setSelected={setSelected}
       /> */}
            {/* <Item
              title="Product wish list"
              to="/productwishlist"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}
             />
            <Item
              title="User search report"
              to="/usersearchreport"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}
            /> */}
          </SubMenu>
          <SubMenu label="Marketing" icon={<SiGooglemarketingplatform fontSize='15' />} open={openSubMenus['Marketing']} onClick={() => toggleSubMenu('Marketing')}>
            <Item
              title="Coupon"
              to="/couponmarketing"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}
            />
            <Item
              title="Autogenerate Coupon"
              to="/autogeneratecoupon"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}
            />
            <Item
              title="FlashDeals"
              to="/flashdeals"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title="DynamicPopup"
              to="/dynamicpopup"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            {/* <Item
              title="CustomeAlert"
              to="/customeralert"
              selected={selected}
              setSelected={setSelected}
            setPagePath={setPagePath}

            /> */}


            <Item
              title="Notifications"
              to="/notification  "
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu>
          <SubMenu label="Support" icon={<CgSupport fontSize='18' />} open={openSubMenus['Support']} onClick={() => toggleSubMenu('Support')}>
            <Item
              title="Queries"
              to="/queries"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu>


          <SubMenu label="Order Tracking " icon={<ReceiptOutlinedIcon fontSize='12' />} open={openSubMenus['Order Tracking ']} onClick={() => toggleSubMenu('Order Tracking ')}>
            <Item
              title="TrackingOrder"
              to="/trackingorder"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title="Refund & Replacement"
              to="/refundandreplacement"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu>
          <SubMenu label="Payment Tracking" icon={<MdPayments fontSize='18' />} open={openSubMenus['Payment Tracking']} onClick={() => toggleSubMenu('Payment Tracking')}>
            <Item
              title="PaymentSuccess"
              to="/paymentsuccess"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title="PaymentFailed"
              to="/paymentfailed"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu>


          {/* <SubMenu label="Settings" icon={<LuSettings fontSize='18' />} open={openSubMenus['Settings']} onClick={() => toggleSubMenu('Settings')}>
            <Item
              title="TaxCreation"
              to="/taxcreation"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
            <Item
              title="TaxSetting"
              to="/taxsetting"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu> */}

          <SubMenu label="QR Scanner" icon={<LuSettings fontSize='18' />} open={openSubMenus['QR Scanner']} onClick={() => toggleSubMenu('QR Scanner')}>
            <Item
              title="QR Scanner"
              to="/qrscanner"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}
            />
          </SubMenu>

          {/* <SubMenu label="Notes" icon={<FaNotesMedical fontSize='15' />} open={openSubMenus['Notes']} onClick={() => toggleSubMenu('Notes')}>
            <Item
              title="NotesInformation"
              to="/notes"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu>
          <SubMenu label="Legal Policies" icon={<MdPolicy fontSize='15' />} open={openSubMenus[' Legal Policies']} onClick={() => toggleSubMenu(' Legal Policies')}>
            <Item
              title="Terms & Conditions"
              to="/police"
              selected={selected}
              setSelected={setSelected}
              setPagePath={setPagePath}

            />
          </SubMenu> */}
          {/* <MenuItem> Documentation </MenuItem> */}

        </Menu>
      </Sidebar>
    </>
  )
}

export default Sidebarmenu