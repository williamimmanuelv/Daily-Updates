import pdfMake from "pdfmake/build/pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";

pdfMake.vfs = pdfFonts.vfs;

export const GenerateOrderSummaryPdf = (orders) => {
  const pageSize = 30;

  const tableBody = [
    [
      { text: "Order ID", style: "tableHeader" },
      { text: "Customer", style: "tableHeader" },
      { text: "Amount", style: "tableHeader" },
      { text: "Status", style: "tableHeader" },
      { text: "Date", style: "tableHeader" },
    ],
  ];

  orders.forEach((o) => {
    tableBody.push([
      o.orderId,
      o.customerName,
      `₹${o.amount}`,
      o.status,
      o.date,
    ]);
  });

  const docDefinition = {
    pageSize: "A4",
    pageMargins: [20, 20, 20, 20],

    content: [
      { text: "Order Summary Report", style: "title", margin: [0, 0, 0, 10] },

      {
        table: {
          headerRows: 1,
          widths: ["*", "*", "*", "*", "*"],
          body: tableBody,
        },
        layout: "lightHorizontalLines",
      },
    ],

    defaultStyle: { fontSize: 9 },

    styles: {
      title: { fontSize: 16, bold: true, alignment: "center" },
      tableHeader: { bold: true, fillColor: "#efefef" },
    },

    // Page-break every 30 rows + header
    pageBreakBefore: function (currentNode) {
      return (
        currentNode.table &&
        currentNode.table.body &&
        currentNode.table.body.length > 1 &&
        currentNode.table.body.length % 31 === 0
      );
    },
  };

  pdfMake.createPdf(docDefinition).download("order-summary.pdf");
};
    


// // Example: pdf-download-fix.js (works in React or plain browser JS)
// import pdfMake from "pdfmake/build/pdfmake";
// import vfsFonts from "pdfmake/build/vfs_fonts";

// // ensure vfs is assigned first
// pdfMake.vfs = vfsFonts.pdfMake ? vfsFonts.pdfMake.vfs : vfsFonts.vfs;

// /**
//  * generatePdf - builds doc and triggers download (reliable)
//  * @param {Array} orders - array of order objects
//  */
// export async function GenerateOrderSummaryPdf(orders = []) {
//   try {
//     // --- sanity sample if orders is empty (for quick testing) ---
//     if (!Array.isArray(orders) || orders.length === 0) {
//       orders = [
//         { orderId: "1001", customerName: "Test Customer", amount: 123.45, status: "Paid", date: "2025-12-09" },
//         { orderId: "1002", customerName: "Another Customer", amount: 67.0, status: "Pending", date: "2025-12-10" },
//       ];
//     }

//     // --- calculate totals safely ---
//     const subtotal = orders.reduce((s, o) => s + (Number(o.amount) || 0), 0);
//     const discount = 0;
//     const gross = subtotal - discount;

//     // --- build table body ---
//     const tableBody = [
//       [
//         { text: "Order ID", style: "tableHeader" },
//         { text: "Customer", style: "tableHeader" },
//         { text: "Amount", style: "tableHeader" },
//         { text: "Status", style: "tableHeader" },
//         { text: "Date", style: "tableHeader" },
//       ]
//     ];

//     orders.forEach((o) => {
//       tableBody.push([
//         String(o.orderId ?? ""),
//         String(o.customerName ?? ""),
//         typeof o.amount !== "undefined" ? `₹${Number(o.amount).toFixed(2)}` : "₹0.00",
//         String(o.status ?? ""),
//         String(o.date ?? ""),
//       ]);
//     });

//     // --- doc definition (simplified for clarity) ---
//     const docDefinition = {
//       pageSize: "A4",
//       pageMargins: [30, 30, 30, 40],
//       content: [
//         {
//           columns: [
//             {
//               width: "auto",
//               stack: [
//                 { image: "dummyLogo", width: 80, margin: [0, 0, 10, 0] },
//                 { text: "TTS BROTHERS GmbH & Co.KG", style: "companyTitle" }
//               ]
//             },
//             {
//               width: "*",
//               text: ""
//             }
//           ]
//         },

//         { canvas: [{ type: "line", x1: 0, y1: 10, x2: 520, y2: 10, lineWidth: 1 }], margin: [0, 10, 0, 10] },

//         { text: "RECHNUNG / Order Summary", style: "title", margin: [0, 5, 0, 10] },

//         {
//           table: {
//             headerRows: 1,
//             widths: ["auto", "*", "auto", "auto", "auto"],
//             body: tableBody
//           },
//           layout: "lightHorizontalLines"
//         },

//         {
//           margin: [0, 12, 0, 0],
//           columns: [
//             { width: "*", text: "" },
//             {
//               width: "auto",
//               table: {
//                 body: [
//                   [{ text: "Netto gesamt", bold: true }, { text: `₹${subtotal.toFixed(2)}`, alignment: "right" }],
//                   [{ text: "Rabatt gesamt", bold: true }, { text: `₹${discount.toFixed(2)}`, alignment: "right" }],
//                   [{ text: "Brutto gesamt", bold: true }, { text: `₹${gross.toFixed(2)}`, alignment: "right" }]
//                 ]
//               },
//               layout: "noBorders"
//             }
//           ]
//         }
//       ],
//       styles: {
//         companyTitle: { fontSize: 16, bold: true, color: "red" },
//         title: { fontSize: 12, bold: true, alignment: "center" },
//         tableHeader: { bold: true, fillColor: "#efefef" }
//       },
//       defaultStyle: { fontSize: 9 },

//       // dummy embedded tiny logo so layout matches
//       images: {
//         dummyLogo:
//           "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAAAfFcSJAAAAXElEQVR4nO3QQQkAMAwDsPz/p7uEIgENOt5tF5t0xGcBC7TDIrQAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAyKwAwjoBUPgE7vAVWFKqmAAAAAElFTkSuQmCC"
//       },

//       // break pages every 30 body rows (header row excluded)
//       pageBreakBefore(currentNode) {
//         return (
//           currentNode.table &&
//           currentNode.table.body &&
//           currentNode.table.body.length > 1 &&
//           (currentNode.table.body.length - 1) % 30 === 0
//         );
//       }
//     };

//     // --- createPdf -> getBlob (more reliable in some browsers) ---
//     const pdfDocGenerator = pdfMake.createPdf(docDefinition);

//     // Use getBlob callback to create a downloadable blob URL:
//     pdfDocGenerator.getBlob((blob) => {
//       try {
//         // Create an object URL for the blob
//         const url = URL.createObjectURL(blob);

//         // Programmatically create <a> and click to download
//         const a = document.createElement("a");
//         a.href = url;
//         a.download = "invoice-report.pdf";
//         document.body.appendChild(a);
//         a.click();
//         a.remove();

//         // free memory
//         setTimeout(() => URL.revokeObjectURL(url), 1000);
//       } catch (innerErr) {
//         console.error("Download fallback error:", innerErr);
//         // fallback: open in new tab
//         pdfDocGenerator.open();
//       }
//     });

//     // Also return the pdf generator if caller wants to open manually
//     return pdfDocGenerator;

//   } catch (err) {
//     console.error("PDF generation failed:", err);
//     alert("PDF generation failed - see console for details.");
//     return null;
//   }
// }
