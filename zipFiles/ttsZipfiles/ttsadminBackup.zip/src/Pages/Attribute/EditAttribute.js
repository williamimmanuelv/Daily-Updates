import React, { useEffect, useState } from 'react'
import './attribute.css'
import { useLocation, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';
import axiosInstance from '../../utils/axiosinstance';
import * as yup from "yup"
import Toast from '../../utils/Toast';
import { RadioButton } from 'primereact/radiobutton';

const EditAttribute = () => {
    const navigate = useNavigate()
    const { state } = useLocation();
    const AttributeData = state;
    console.log("AttributeDataAAAA", AttributeData)

    const [language, setLanguage] = useState("en");
    const [fetchAttribute, setFetchAttribute] = useState("en");

    // useEffect(() => {
    //     formik.setFieldValue('attribute_title', AttributeData?.attribute_title)

    //     formik.setFieldValue('language_code', AttributeData?.language)
    //     formik.setFieldValue('status', AttributeData?.status)

    //     formik.setFieldValue('id', AttributeData?.id)
    //     }, [])
    useEffect(() => {
        if (!fetchAttribute || !fetchAttribute.id) return;
        formik.setValues({
            attribute_title: fetchAttribute?.translation?.attribute_title || "",
            status: fetchAttribute?.status || "",
            language_code: fetchAttribute?.translation?.language_code ? fetchAttribute?.translation?.language_code : language,
            id: fetchAttribute?.id || "",
        });


        console.log("fetchAttribute", fetchAttribute?.data);

    }, [fetchAttribute]);


    const fetchAttributes = async () => {
        try {
            const response = await axiosInstance.get(`/attributes/${AttributeData?.id}`, {
                params: {
                    lang: language,
                },
            });
            setFetchAttribute(response.data);
            console.log("response.data", response.data)
        } catch (error) {
            console.error("Error fetching data", error);
        }
    };
    useEffect(() => {
        fetchAttributes()
    }, [language])

    useEffect(() => {
        if (AttributeData?.language) {
            setLanguage(AttributeData.language)
            formik.setFieldValue("language_code", AttributeData.language)
        }
    }, [AttributeData])

    const handleLanguage = (e, lang) => {
        e.preventDefault();
        formik.setFieldValue("language_code", lang);
        setLanguage(lang)
    };
    const onSubmit = async (values) => {
        try {
            const response = await axiosInstance.post(`/attributes/${values.id}?_method=PUT`, values, {
                headers: {
                    "Content-Type": "application/json",
                },
            });
            Toast({ message: "Successfully Updated", type: "success" });

            console.log("response", response)

            formik.resetForm()
            navigate('/listAttribute')

        } catch (error) {
            Toast({ message: "Error to taken project", type: "error" });

            // console.log("Suberror", error)
        }
    }
    const formik = useFormik(
        {
            initialValues: {
                attribute_title: "",
                // attribute_id: "",
                // attribute_value: "",
                // option: "",
                language_code: "",
                status: "",

            },
            validationSchema: yup.object().shape({
                attribute_title: yup.string().required("attribute_title is required!"),
                // attribute_id: yup.string().required("attribute_id By is required"),
                // attribute_value: yup.string().required("attribute_value is required!"),
                // option: yup.string().required("option is required!"),
                // language_code: yup.string().required("language_code is required!"),
                status: yup.string().required("status is required!"),
            }),
            onSubmit,
        }
    )

    return (
        <>
            <div className="d-flex justify-content-start ps-5">
                <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => navigate('/listAttribute')}
                >
                    ← Back
                </button>
            </div>

            <div className='container px-5 '>
                {/* <h4 className='py-4'>Attribute Create</h4> */}

                <div className='box_shadow p-4 rounded mt-4 bg-white'>
                    <ul className="nav nav-tabs mb-3 ">
                        <li className="nav-item">
                            <button
                                type="button"
                                className={`nav-link ${language === "en" ? "active text-primary" : "text-black"}`}
                                onClick={(e) => handleLanguage(e, "en")}
                            >
                                English
                            </button>
                        </li>
                        <li className="nav-item">
                            <button
                                type="button"
                                className={`nav-link ${language === "de" ? "active text-primary" : "text-black"}`}
                                onClick={(e) => handleLanguage(e, "de")}
                            >
                                German
                            </button>
                        </li>
                    </ul>
                    <div className='d-flex'>
                        <h5>Edit Attribute</h5>
                        {/* <div className="dropdown ms-4">
                            <button
                                className="btn btn-outline-primary dropdown-toggle"
                                data-bs-toggle="dropdown"
                                type="button"
                            >
                                {formik.values.language_code === "en"
                                    ? "English"
                                    : formik.values.language_code === "de"
                                        ? "German"
                                        : "Select a language"}
                            </button>

                            <ul className="dropdown-menu">
                                <li>
                                    <button
                                        type="button"
                                        className="dropdown-item"
                                        onClick={() => formik.setFieldValue("language_code", "en")}
                                    >
                                        English
                                    </button>
                                </li>

                                <li>
                                    <button
                                        type="button"
                                        className="dropdown-item"
                                        onClick={() => formik.setFieldValue("language_code", "de")}
                                    >
                                        German
                                    </button>
                                </li>
                            </ul>
                            {formik.errors.language_code && formik.touched.language_code && (
                                <p style={{ color: "red", fontSize: "12px" }}>
                                    {formik.errors.language_code}
                                </p>
                            )}
                        </div> */}
                    </div>
                    {/* <hr /> */}
                    <form onSubmit={formik.handleSubmit} autoComplete="off">
                        <div className='row g-4'>

                            <div className='col-12 col-md-6 mt-5'>
                                <div className='mb-3'>
                                    <label htmlFor="attribute_title" className='form-label text-muted '>Attribute Title</label>
                                    <input
                                        type='text'
                                        className='form-control opacity-75'
                                        id="attribute_title"
                                        name='attribute_title'
                                        placeholder='Enter Title'
                                        value={formik.values.attribute_title}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                    />
                                    {formik.errors.attribute_title && formik.touched.attribute_title && (
                                        <p style={{ color: "red", fontSize: "12px" }}>
                                            {formik.errors.attribute_title}
                                        </p>
                                    )}
                                </div>

                                {/* <div className='mb-3'>
                                    <label htmlFor="option" className='form-label text-muted'>Option</label>
                                    <select className="form-select opacity-75" id="option" name="option"
                                        value={formik.values.option}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                    >
                                        <option value=''>Select Dropdown</option>
                                        <option>Dropdown</option>
                                        <option>Dropdown</option>
                                        <option>Radio</option>
                                    </select>
                                    {formik.errors.option && formik.touched.option && (
                                        <p style={{ color: "red", fontSize: "12px" }}>
                                            {formik.errors.option}
                                        </p>
                                    )}
                                </div> */}

                                {/* <div className='mb-3'>
                                    <label htmlFor="attribute_id" className='form-label text-muted'>Attribute ID</label>
                                    <select

                                        className="form-select text-muted"
                                        id="attribute_id"
                                        name="attribute_id"
                                        value={formik.values.attribute_id}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}

                                    >
                                        <option>Select AttributeId</option>

                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </select>
                                    {formik.errors.attribute_id && formik.touched.attribute_id && (
                                        <p style={{ color: "red", fontSize: "12px" }}>
                                            {formik.errors.attribute_id}
                                        </p>
                                    )}
                                </div> */}
                            </div>


                            <div className='col-12 col-md-6 mt-5'>
                                {/* <div className='mb-3'>
                                    <label htmlFor="attribute_value" className='form-label text-muted'>Attribute Value</label>
                                    <input
                                        type='text'
                                        className='form-control opacity-75'
                                        id="attribute_value"
                                        name='attribute_value'
                                        placeholder='Enter Creator'
                                        value={formik.values.attribute_value}
                                        onChange={formik.handleChange}
                                        onBlur={formik.handleBlur}
                                    />
                                    {formik.errors.attribute_value && formik.touched.attribute_value && (
                                        <p style={{ color: "red", fontSize: "12px" }}>
                                            {formik.errors.attribute_value}
                                        </p>
                                    )}
                                </div> */}
                                <div className="mb-3 ms-3 ">
                                    <label className="form-label text-muted ps-4">Status</label>
                                    <div className="d-flex  gap-2">
                                        <div className="form-check">

                                            <RadioButton inputId="ingredient1" name="status" value="active" id="status-active"
                                                checked={formik.values.status === "active"}
                                                onChange={formik.handleChange}
                                            />
                                            <label className="form-check-label ms-2" htmlFor="status-active">
                                                Active
                                            </label>
                                        </div>
                                        <div className="form-check">

                                            <RadioButton inputId="ingredient2" name="status" value="inactive" id="status-inactive"
                                                checked={formik.values.status === "inactive"}
                                                onChange={formik.handleChange}
                                            />
                                            <label className="form-check-label ms-2" htmlFor="status-inactive">
                                                Inactive
                                            </label>
                                        </div>

                                    </div>
                                    {formik.errors.status && formik.touched.status && (
                                        <p style={{ color: "red", fontSize: "12px" }}>
                                            {formik.errors.status}
                                        </p>
                                    )}
                                </div>


                            </div>
                            <div className='col-12 d-flex justify-content-end gap-3'>
                                <button className='btn btn-danger bg_color' onClick={() => formik.resetForm()}>Cancel</button>

                                <button className='btn btn-outline-success'>Update </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </>
    )
}

export default EditAttribute