import React, { useEffect, useMemo, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import Toast from '../../utils/Toast';
import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';
import { FiPlus } from "react-icons/fi";


const ListAttribute = () => {
  //  const [products, setProducts] = useState([]);
  const navigate = useNavigate()
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [viewattributeconfirmmodal, setViewattributeconfirmmodal] = useState(false)

  const [fetchAttribute, setFetchAttribute] = useState([])
  const [deleteAttribute, setDeleteAttribute] = useState([])
  const [viewAttribute, setViewAttribute] = useState([])



  console.log("fetchAttributeeeee", fetchAttribute)

  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "ID",
    //   selector: (row) => row.attribute_id,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Variant",
      selector: (row) => row.attribute_title,
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "Value",
    //   selector: (row) => row.attribute_value,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Option",
    //   selector: (row) => row.option,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Created On	",
    //   selector: (row) => row.CreatedOn,
    //   wrap: true,
    //   sortable: true,
    //   width: "170px",
    // },
    // {
    //   name: "Published",
    //   selector: (row) => row.Published,
    //   wrap: true,
    //   sortable: true,
    // },

    {
      name: "Actions",
      cell: (row, index) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-3 me-5">
          <div style={{ backgroundColor: "#eef2f7", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
            <GrFormView size={20} color="black" onClick={() => {
              setViewAttribute(row);
              console.log("listattribute", index);

              setViewattributeconfirmmodal(true);
            }} />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}
            onClick={() => editAttribute(row)}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}
            onClick={() => { setDeleteAttribute(row); setDeleteconfirmmodal(true); }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  const [language, setLanguage] = useState("all");

  const fetchAttributes = async () => {
    try {
      const response = await axiosInstance.get(`/attributes`, {
        params: {
          lang: language,
        },
      });
      setFetchAttribute(response.data.data);

      console.log("responsedataAttirbute", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchAttributes()
  }, [language])

  const editAttribute = (row) => {
    navigate('/editattribute', { state: row })
  }

  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['attribute_id', 'attribute_title', 'attribute_value', 'option', 'file', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchAttribute, filterText, searchColumns);


  const handleConfirmCloseAttribute = () => {
    setDeleteconfirmmodal(false)
  }
  const handleAttributedelete = async (item) => {
    try {
      await axiosInstance.delete(`/attributes/${item.id}`, {
        params: {
          lang: item.language,
        },
      })
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchAttributes()
    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });

      // console.log("error", error)
    }
    setDeleteconfirmmodal(false)

  }

  const indexedData = useMemo(() => (
    filterdata.map((row, index) => ({
      ...row,
      __index: `${row.someStableField}-${index}`
    }))
  ), [filterdata]);


  return (
    <>
      <div className='container'>
        <div className='mt-3 box_shadow  bg-white rounded-1'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3 d-flex'>
              <h5 className='pt-1'>All Attribute List</h5>
              <div className="dropdown ms-3">
                <button
                  type="button"
                  className="btn btn-outline-primary dropdown-toggle"
                  data-bs-toggle="dropdown"
                >
                  {language === "all"
                    ? "All"
                    : language === "en"
                      ? "English"
                      : "German"}
                  {/* select language */}
                </button>

                <ul className="dropdown-menu">
                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("all")}
                    >
                      All
                    </button>
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("en")}
                    >
                      English
                    </button>
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("de")}
                    >
                      German
                    </button>
                  </li>
                </ul>
              </div>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <Link to="/createAttribute" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div></Link>
            </div>
          </div>

          <div className='pt-2'>


            <DataTable
              columns={columns}

              // data={filterdata}
              data={indexedData}
              customStyles={customStyle}
              pagination
              keyField="__index"
              // selectableRows
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />

          </div>
        </div>
      </div>

      <Dialog header="Confirm Delete" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmCloseAttribute()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleAttributedelete(deleteAttribute)}>Yes </Button>
        </div>

      </Dialog>

      <Dialog header="View Attribute Details"
        visible={viewattributeconfirmmodal}
        position="top" style={{ width: '50vw' }}
        onHide={() => {
          if (!viewattributeconfirmmodal)
            return; setViewattributeconfirmmodal(false);
        }}
      >

        {viewAttribute && (
          <div className='row'>
            <div className='col'>
              {/* <p>Variant :{viewAttribute?.attribute_title}</p>
              <p>Value :{viewAttribute?.attribute_value}</p> */}
              <p>Attribute id : {viewAttribute?.id}</p>
              <p>Attribute Title : {viewAttribute?.attribute_title}</p>
            </div>
            <div className='col'>
              {/* <p>Created Id :{viewAttribute?.attribute_id}</p>
              <p>Option :{viewAttribute?.option}</p> */}
              <p>Language : {viewAttribute?.language}</p>
              <p>Status : {viewAttribute?.status}</p>

              {/* <p>Published :</p>
            <p>Stock :</p> */}
            </div>

          </div>
        )}

      </Dialog>
    </>
  )
}

export default ListAttribute