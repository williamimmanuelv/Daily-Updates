import React, { useEffect, useMemo, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";

import { FiPlus } from "react-icons/fi";
import axiosInstance from '../../../utils/axiosinstance';
import Toast from '../../../utils/Toast';
import customStyle from '../../../utils/Customstyle';
import { SearchData } from '../../../utils/Search';
import { Modal } from 'rsuite';
import { useFormik } from 'formik';
import * as yup from "yup"
import axios from 'axios';
import { base_url, img_path } from '../../../Api/BaseUrl';


// 
import './app.css'

const Advertising1Banner = () => {

  const navigate = useNavigate()

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [deleteCoupon, setDeleteCoupon] = useState(null)

  const [previewImage, setPreviewImage] = useState(null);
  const [selectedRows, setSelectedRows] = useState([]);
  const [fetcadvertisingbanner, setFetcadvertisingbanner] = useState([])
  console.log("fetcadvertisingbanner", fetcadvertisingbanner)
  const [newDialog, setNewDialog] = useState(false)
  const [editDialog, setEditDialog] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isEditing, setIsEditing] = useState(false)
  const [fetchproducts, setFetchproducts] = useState([])
  const [languageslist, setLanguageslist] = useState("all");

  const token = localStorage.getItem("tokenAdmin")

  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products`, {
        params: {
          lang: language,
        },
      });
      setFetchproducts(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchproduct()
  }, [])

  const fetchadvertising = async () => {
    try {
      const response = await axiosInstance.get(`/bannerapp`, {
        headers: {
          "tts-request": 'advertising1_banner'
        },
        params: {
          lang: languageslist,
        },
      });
      setFetcadvertisingbanner(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchadvertising()
  }, [languageslist])

  // const columns = [
  const columns = useMemo(() => [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
    },
    {
      name: "Banner Image",
      cell: (row) =>
        row.image ? (
          <img
            src={`${img_path}/appbanner/${row.image}`}
            alt={row.title}
            style={{
              width: "30px",
              height: "30px",
              objectFit: "cover",
              borderRadius: "6px",
            }}
          />
        ) : (
          <span className="text-muted">No image</span>
        ),
      wrap: true,
      sortable: false,
    },
    // {
    //   name: "Product ",
    //   selector: (row) => row.navigate,
    //    cell: (row) => (
    //     <span className=" product-name-ellipsis  ">
    //       {row.navigate}
    //     </span>
    //   ),
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Title",
      selector: (row) => row.title,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.title}
        </span>
      ),
      wrap: true,
      sortable: true,
    },
    {
      name: "language",
      selector: (row) => row.language,
      wrap: true,
      sortable: true,
    },
    {
      name: "Description",
      selector: (row) => row.description,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.description}
        </span>
      ),
      wrap: true,
      sortable: true,
      // width: "170px",
    },
    {
      name: "Button Text",
      selector: (row) => row.button_text,
      wrap: true,
      sortable: true,
    },
    {
      name: "Button Url",
      selector: (row) => row.button_url,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.button_url}
        </span>
      ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Status",
      selector: (row) => row.status,
      wrap: true,
      sortable: true,
    },

    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => handleEdit(row)}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setDeleteCoupon(row.id); setDeleteconfirmmodal(true); }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
    // ];
  ], [img_path]);

  const [language, setLanguage] = useState("en");

  const [rowId, setRowId] = useState(null)


  const handleEdit = async (row) => {
    setEditDialog(true);
    setRowId(row.id);
    setLanguage(row.language);

    setPreviewImage(`${img_path}/appbanner/${row.image}`);

    try {
      const response = await axiosInstance.get(`/bannerapp/${row.id}`, {
        params: { lang: row.language },
      });

      console.log("appad1", response.data);


      const data = response.data;

      formik.setValues({
        id: row.id,
        image: row.image || null,
        old_image: row.image || null,
        navigate: row.navigate || null,
        title: data.title || "",
        description: data.description || "",
        button_text: data.button_text || "",
        button_url: data.button_url || "",
        status: data.status || "",
        banner_type: data.banner_type,
        language_code: row.language,
      });

    } catch (error) {
      console.error(error);
    }

    // formik.setFieldValue("id", row.id || "");
    // formik.setFieldValue("image", row.image || "");
    // setPreviewImage(`${img_path}/appbanner/${row.image}`);
    // formik.setFieldValue("old_image", row.image || "");
    // formik.setFieldValue("navigate", row.navigate || "");
    // formik.setFieldValue("title", row.title || "");
    // formik.setFieldValue("description", row.description || "");
    // formik.setFieldValue("button_text", row.button_text || "");
    // formik.setFieldValue("button_url", row.button_url || "");
    // formik.setFieldValue("language_code", row.language || "");

    // formik.setFieldValue("status", row.status || "");
  };
  // 
  useEffect(() => {
    if (language?.language) {
      setLanguage(language?.language)
      formik.setFieldValue("language_code", language?.language)
    }
  }, [language])

  // 

  // useEffect((row) => {
  //   if (row?.language) {
  //     setLanguage(row.language)
  //     formik.setFieldValue("language_code", row.language)
  //   }
  // }, [])

  const handleLanguage = async (e, lang) => {
    e.preventDefault();
    if (!rowId) return;

    setLanguage(lang);
    formik.setFieldValue("language_code", lang);

    try {
      const response = await axiosInstance.get(`/bannerapp/${rowId}`, {
        params: { lang },
      });

      const data = response.data;

      console.log("testing_ad1app", data);


      formik.setValues((prev) => ({
        ...prev,
        title: data.title || "",
        description: data.description || "",
        button_text: data.button_text || "",
        button_url: data.button_url || "",
      }));

    } catch (error) {
      console.error(error);
    }
  };

  const onSubmit = async (values) => {
    console.log("onsubmit_app_ad1", values);
    console.log("onsubmit_app_ad1", values.image);

    if (isEditing) {
      console.log("edit")
      try {
        const formData = new FormData();
        formData.append("title", values.title);
        formData.append("description", values.description);
        formData.append("navigate", values.navigate);
        formData.append("button_text", values.button_text);
        formData.append("button_url", values.button_url);
        formData.append("status", values.status);
        formData.append("image", values.image);
        formData.append("banner_type", values.banner_type);
        formData.append("language_code", values.language_code);

        const response = await axiosInstance.post(`${base_url}/bannerapp/${values.id}?_method=PUT`, formData, {
          headers: {

            "Content-Type": "multipart/form-data",
            // Authorization: `Bearer ${token}`,
          },
        });
        Toast({ message: response.data.message, type: "success" });

        await fetchadvertising()
        formik.resetForm();
        setPreviewImage(null)
        setEditDialog(false)
      }
      catch (error) {
        const errorMessage =
          error.response?.data?.messages?.message || "Error while creating banner";

        Toast({ message: errorMessage, type: "error" });
      }
      finally {
        setIsSubmitting(false);
      }
    } else {
      console.log("createt")
      try {
        const formData = new FormData();
        formData.append("title", values.title);
        formData.append("description", values.description);
        formData.append("navigate", values.navigate);
        formData.append("button_text", values.button_text);
        formData.append("button_url", values.button_url);
        formData.append("status", values.status);
        formData.append("image", values.image);
        formData.append("banner_type", values.banner_type);
        formData.append("language_code", values.language_code);
        const response = await axiosInstance.post(`${base_url}/bannerapp`, formData, {
          headers: {
            "Content-Type": "multipart/form-data",
            // Authorization: `Bearer ${token}`,
          },
        });
        setNewDialog(false)
        await fetchadvertising()
        formik.resetForm();
        setPreviewImage(null)
        Toast({ message: response.data.message, type: "success" });

      } catch (error) {
        const errorMessage =
          error.response?.data?.messages?.message || "Error while creating banner";

        Toast({ message: errorMessage, type: "error" });
      }
      finally {
        setIsSubmitting(false);
      }

    }
  };

  const formik = useFormik({
    initialValues: {
      image: "",
      banner_type: "advertising1_banner",
      title: "",
      description: "",
      navigate: "",
      button_text: "",
      button_url: "",
      status: "",
      language_code: language,
    },
    validationSchema: yup.object().shape({
      image: yup.string().required("image is required!"),
      title: yup.string().required("title is required!"),

      description: yup.string().required("description is required!"),
      navigate: yup.string().required("product is required!"),
      button_text: yup.string().required("button text is required!"),
      button_url: yup.string().required("button url is required!"),
      //  language_code: yup.string().required("language_code is required!"),

      status: yup.string().required("Status is required"),
    }),
    onSubmit,
  });

  const handleConfirmClsDltCpn = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmOpnDltCoupon = async () => {
    try {
      await axiosInstance.delete(`/bannerapp/${deleteCoupon}`)
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchadvertising()

    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });
    }
    setDeleteconfirmmodal(false)
  }
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['url', 'title', 'language', 'description', 'button_text', 'button_url', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  // const filterdata = SearchData(fetcadvertisingbanner, filterText, searchColumns);
  const uniqueData = useMemo(() => {
    const map = new Map();
    fetcadvertisingbanner.forEach(item => {
      map.set(`${item.id}-${item.language}`, item);
    });
    return Array.from(map.values());
  }, [fetcadvertisingbanner]);

  const filterdata = useMemo(() => {
    return SearchData(uniqueData, filterText, searchColumns);
  }, [uniqueData, filterText]);


  return (

    <>
      <div className='container'>


        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3 d-flex'>
              <h5 className='pt-2'> Advertising Banner 1</h5>
              <div className="dropdown ms-3">
                <button
                  type="button"
                  className="btn btn-outline-primary dropdown-toggle"
                  data-bs-toggle="dropdown"
                >
                  {languageslist === "all"
                    ? "All"
                    : languageslist === "en"
                      ? "English"
                      : "German"}
                  {/* select language */}
                </button>

                <ul className="dropdown-menu">
                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguageslist("all")}
                    >
                      All
                    </button>
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguageslist("en")}
                    >
                      English
                    </button>
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguageslist("de")}
                    >
                      German
                    </button>
                  </li>
                </ul>
              </div>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <div className='mt-1  me-2' onClick={() => setNewDialog(true)}>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div>
            </div>
          </div>

          <div className='pt-2'>

            <DataTable
              columns={columns}

              data={filterdata}
              customStyles={customStyle}
              pagination
              // selectableRows
              className='appAdvert1DataTable'
              keyField={row => `${row.id}-${row.language}`}
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />
          </div>
        </div>
      </div>

      {/* <Modal

        size={"40rem"}

        open={newDialog}
        onClose={() => {
          setNewDialog(false);
          formik.resetForm();
          setPreviewImage(null)
        }}
      >
        <Modal.Header>
          <Modal.Title>Advertising1Banner</Modal.Title>
        </Modal.Header>

        <Modal.Body
          className="p-2"
          style={{ overflow: "scroll", overflowX: "hidden" }}
        >
          <form onSubmit={formik.handleSubmit}>



            <div className="mb-3">
              <label htmlFor="image" className="form-label">
                Banner Image
              </label>

              {previewImage && (
                <div className="mb-2">
                  <img
                    src={previewImage}
                    alt="preview"
                    style={{
                      width: "120px",
                      height: "90px",
                      objectFit: "cover",
                      borderRadius: "6px",
                    }}
                  />
                </div>
              )}

              <input
                type="file"
                className="form-control w-50"
                id="image"
                name="image"
                accept="image/*"
                onChange={(event) => {
                  const file = event.currentTarget.files[0];
                  formik.setFieldValue("image", file);
                  if (file) {
                    setPreviewImage(URL.createObjectURL(file));
                  }
                }}
              />
              {formik.errors.image && formik.touched.image && (
                <small className="text-danger">{formik.errors.image}</small>
              )}
            </div>

            <div className="mb-3">
              <label className="form-label" htmlFor="navigate">
                Product
              </label>
              <select
                name="navigate"
                className="form-select"
                value={formik.values.navigate}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              >
                <option value="">Select ...</option>
                {fetchproducts?.map((item) => (
                  <option value={item.id} key={item.id}>
                    {item.product_name}
                  </option>
                ))}

              </select>
              {formik.errors.navigate && formik.touched.navigate && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.navigate}
                </p>
              )}
            </div>

            <div className="mb-3">
              <label htmlFor="title" className="form-label">
                Title
              </label>
              <textarea
                type="text"
                name="title"
                className="form-control"
                placeholder="Enter title"
                value={formik.values.title}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.title && formik.touched.title && (
                <small className="text-danger">{formik.errors.title}</small>
              )}
            </div>

            <div className="mb-3">
              <label htmlFor="description" className="form-label">
                Description
              </label>
              <textarea
                type="text"
                name="description"
                className="form-control"
                placeholder="Enter description"
                value={formik.values.description}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.description && formik.touched.description && (
                <small className="text-danger">{formik.errors.description}</small>
              )}
            </div>

            <div className=" mb-3 ">
              <label htmlFor="button_text"
                className="form-label"> ButtonText </label>
              <input
                type="text"
                name="button_text"
                className="form-control"
                placeholder="Enter button_text"
                value={formik.values.button_text}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.button_text && formik.touched.button_text && (
                <small className="text-danger">{formik.errors.button_text}</small>
              )}
            </div>
            <div className=" mb-3 ">
              <label htmlFor="button_url"
                className="form-label"> ButtonUrl </label>
              <input
                type="text"
                name="button_url"
                className="form-control"
                placeholder="Enter button_url"
                value={formik.values.button_url}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.button_url && formik.touched.button_url && (
                <small className="text-danger">{formik.errors.button_url}</small>
              )}
            </div>

            <div className="mb-3">
              <label htmlFor="status" className="form-label">Status</label>
              <select
                id="status"
                name="status"
                className="form-select w-50"
                value={formik.values.status}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              >
                <option value="">-- Select Status --</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
              {formik.errors.status && formik.touched.status && (
                <small className="text-danger">{formik.errors.status}</small>
              )}
            </div>


            <div className=" d-flex gap-2 justify-content-end">
              <Button

                // appearance="primary"
                color="success"
                variant="contained"
                type="submit"
                disabled={isSubmitting}
                onClick={() => setIsEditing(false)}
              >
                {isSubmitting ? "Saving..." : "Save"}
              </Button>
              <Button

                // appearance="ghost"
                variant="outlined"
                color="error"
                onClick={() => {
                  formik.resetForm();
                  setPreviewImage(null)
                }}
              >
                Clear
              </Button>
            </div>
          </form>
        </Modal.Body>
        <Modal.Footer></Modal.Footer>
      </Modal> */}

      <Dialog header="Advertising Banner 1"
        visible={newDialog} position="top"
        style={{ width: '50vw' }} onHide={() => {
          if (!newDialog) return;
          setNewDialog(false);
          formik.resetForm();
          setPreviewImage(null)
        }}
      >
        <ul className="nav nav-tabs mb-3">
          <li className="nav-item">
            <button
              type="button"
              className='nav-link active text-primary'
            // className={`nav-link ${language === "en" ? "active" : "black"}`}
            // onClick={(e) => handleLanguage(e, "en")}
            >
              English
            </button>
          </li>
          {/* <li className="nav-item">
            <button
              type="button"
              className={`nav-link ${language === "de" ? "active" : "black"}`}
              onClick={(e) => handleLanguage(e, "de")}
            >
              German
            </button>
          </li> */}
        </ul>
        <form onSubmit={formik.handleSubmit}>



          <div className="mb-3">
            <label htmlFor="image" className="form-label">
              Banner Image
            </label>

            {previewImage && (
              <div className="mb-2">
                <img
                  src={previewImage}
                  alt="preview"
                  style={{
                    width: "120px",
                    height: "90px",
                    objectFit: "cover",
                    borderRadius: "6px",
                  }}
                />
              </div>
            )}

            <input
              type="file"
              className="form-control w-50"
              id="image"
              name="image"
              accept="image/*"
              onChange={(event) => {
                const file = event.currentTarget.files[0];
                formik.setFieldValue("image", file);
                if (file) {
                  setPreviewImage(URL.createObjectURL(file));
                }
              }}
            />
            {formik.errors.image && formik.touched.image && (
              <small className="text-danger">{formik.errors.image}</small>
            )}
          </div>

          <div className="mb-3">
            <label className="form-label" htmlFor="navigate">
              Product
            </label>
            <select
              name="navigate"
              className="form-select"
              value={formik.values.navigate}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            >
              <option value="">Select ...</option>
              {fetchproducts?.map((item) => (
                <option value={item.id} key={item.id}>
                  {item?.translations?.en?.product_name}
                </option>
              ))}

            </select>
            {formik.errors.navigate && formik.touched.navigate && (
              <p style={{ color: "red", fontSize: "12px" }}>
                {formik.errors.navigate}
              </p>
            )}
          </div>

          <div className="mb-3">
            <label htmlFor="title" className="form-label">
              Title
            </label>
            <textarea
              type="text"
              name="title"
              className="form-control"
              placeholder="Enter title"
              value={formik.values.title}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.title && formik.touched.title && (
              <small className="text-danger">{formik.errors.title}</small>
            )}
          </div>

          <div className="mb-3">
            <label htmlFor="description" className="form-label">
              Description
            </label>
            <textarea
              type="text"
              name="description"
              className="form-control"
              placeholder="Enter description"
              value={formik.values.description}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.description && formik.touched.description && (
              <small className="text-danger">{formik.errors.description}</small>
            )}
          </div>

          <div className=" mb-3 ">
            <label htmlFor="button_text"
              className="form-label"> Button Text </label>
            <input
              type="text"
              name="button_text"
              className="form-control"
              placeholder="Enter button text"
              value={formik.values.button_text}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.button_text && formik.touched.button_text && (
              <small className="text-danger">{formik.errors.button_text}</small>
            )}
          </div>
          <div className=" mb-3 ">
            <label htmlFor="button_url"
              className="form-label"> Button Url </label>
            <input
              type="text"
              name="button_url"
              className="form-control"
              placeholder="Enter button url"
              value={formik.values.button_url}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.button_url && formik.touched.button_url && (
              <small className="text-danger">{formik.errors.button_url}</small>
            )}
          </div>

          <div className="mb-3">
            <label htmlFor="status" className="form-label">Status</label>
            <select
              id="status"
              name="status"
              className="form-select w-50"
              value={formik.values.status}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            >
              <option value="">-- Select Status --</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
            {formik.errors.status && formik.touched.status && (
              <small className="text-danger">{formik.errors.status}</small>
            )}
          </div>


          <div className=" d-flex gap-2 justify-content-end">
            <Button

              // appearance="primary"
              color="success"
              variant="contained"
              type="submit"
              disabled={isSubmitting}
              onClick={() => setIsEditing(false)}
            >
              {isSubmitting ? "Saving..." : "Save"}
            </Button>
            <Button

              // appearance="ghost"
              variant="outlined"
              color="error"
              onClick={() => {
                formik.resetForm();
                setPreviewImage(null)
              }}
            >
              Clear
            </Button>
          </div>
        </form>
      </Dialog>

      <Dialog header="Advertising Banner 1"
        visible={editDialog} position="top"
        style={{ width: '50vw' }} onHide={() => {
          if (!editDialog) return;
          setEditDialog(false);
          formik.resetForm();
          setPreviewImage(null)
        }}
      >
        <ul className="nav nav-tabs mb-3">
          <li className="nav-item">
            <button
              type="button"
              className={`nav-link ${language === "en" ? "active text-primary" : "text-black"}`}
              onClick={(e) => handleLanguage(e, "en")}
            >
              English
            </button>
          </li>
          <li className="nav-item">
            <button
              type="button"
              className={`nav-link ${language === "de" ? "active text-primary" : "text-black"}`}
              onClick={(e) => handleLanguage(e, "de")}
            >
              German
            </button>
          </li>
        </ul>
        <form onSubmit={formik.handleSubmit}>
          {language == "en" && (
            <div>
              <div className="mb-3">
                <label htmlFor="image" className="form-label">
                  Banner Image
                </label>

                {previewImage && (
                  <div className="mb-2">
                    <img
                      src={previewImage}
                      alt="preview"
                      style={{
                        width: "120px",
                        height: "90px",
                        objectFit: "cover",
                        borderRadius: "6px",
                      }}
                    />
                  </div>
                )}

                <input
                  type="file"
                  className="form-control w-50"
                  id="image"
                  name="image"
                  accept="image/*"
                  onChange={(event) => {
                    const file = event.currentTarget.files[0];
                    formik.setFieldValue("image", file);
                    if (file) {
                      setPreviewImage(URL.createObjectURL(file));
                    }
                  }}
                />
                {formik.errors.image && formik.touched.image && (
                  <small className="text-danger">{formik.errors.image}</small>
                )}
              </div>

              <div className="mb-3">
                <label className="form-label" htmlFor="navigate">
                  Product
                </label>
                <select
                  name="navigate"
                  className="form-select"
                  value={formik.values.navigate}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                >
                  <option value="">Select ...</option>
                  {fetchproducts?.map((item) => (
                    <option value={item.id} key={item.id}>
                      {item?.translations?.en?.product_name}
                    </option>
                  ))}

                </select>
                {formik.errors.navigate && formik.touched.navigate && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.navigate}
                  </p>
                )}
              </div>

              <div className="mb-3">
                <label htmlFor="title" className="form-label">
                  Title
                </label>
                <textarea
                  type="text"
                  name="title"
                  className="form-control"
                  placeholder="Enter title"
                  value={formik.values.title}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.title && formik.touched.title && (
                  <small className="text-danger">{formik.errors.title}</small>
                )}
              </div>

              <div className="mb-3">
                <label htmlFor="description" className="form-label">
                  Description
                </label>
                <textarea
                  type="text"
                  name="description"
                  className="form-control"
                  placeholder="Enter description"
                  value={formik.values.description}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.description && formik.touched.description && (
                  <small className="text-danger">{formik.errors.description}</small>
                )}
              </div>

              <div className=" mb-3 ">
                <label htmlFor="button_text"
                  className="form-label"> Button Text </label>
                <input
                  type="text"
                  name="button_text"
                  className="form-control"
                  placeholder="Enter button text"
                  value={formik.values.button_text}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.button_text && formik.touched.button_text && (
                  <small className="text-danger">{formik.errors.button_text}</small>
                )}
              </div>
              <div className=" mb-3 ">
                <label htmlFor="button_url"
                  className="form-label"> Button Url </label>
                <input
                  type="text"
                  name="button_url"
                  className="form-control"
                  placeholder="Enter button url"
                  value={formik.values.button_url}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.button_url && formik.touched.button_url && (
                  <small className="text-danger">{formik.errors.button_url}</small>
                )}
              </div>

              <div className="mb-3">
                <label htmlFor="status" className="form-label">Status</label>
                <select
                  id="status"
                  name="status"
                  className="form-select w-50"
                  value={formik.values.status}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                >
                  <option value="">-- Select Status --</option>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
                {formik.errors.status && formik.touched.status && (
                  <small className="text-danger">{formik.errors.status}</small>
                )}
              </div>
            </div>
          )}
          {language == "de" && (
            <div>
              <div className="mb-3">
                <label htmlFor="title" className="form-label">
                  Title
                </label>
                <textarea
                  type="text"
                  name="title"
                  className="form-control"
                  placeholder="Enter title"
                  value={formik.values.title}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.title && formik.touched.title && (
                  <small className="text-danger">{formik.errors.title}</small>
                )}
              </div>

              <div className="mb-3">
                <label htmlFor="description" className="form-label">
                  Description
                </label>
                <textarea
                  type="text"
                  name="description"
                  className="form-control"
                  placeholder="Enter description"
                  value={formik.values.description}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.description && formik.touched.description && (
                  <small className="text-danger">{formik.errors.description}</small>
                )}
              </div>

              <div className=" mb-3 ">
                <label htmlFor="button_text"
                  className="form-label"> Button Text </label>
                <input
                  type="text"
                  name="button_text"
                  className="form-control"
                  placeholder="Enter button text"
                  value={formik.values.button_text}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.button_text && formik.touched.button_text && (
                  <small className="text-danger">{formik.errors.button_text}</small>
                )}
              </div>
            </div>
          )}
          <div className=" d-flex gap-2 justify-content-end">
            <Button
              // appearance="primary"
              color="success"
              variant="contained"
              type="submit"
              disabled={isSubmitting}
              onClick={() => setIsEditing(true)}
            >
              {isSubmitting ? "Updateing..." : "Update"}
            </Button>
            <Button

              // appearance="ghost"
              variant="outlined"
              color="error"
              onClick={() => {
                formik.resetForm();
                setPreviewImage(null)
              }}
            >
              Clear
            </Button>
          </div>
        </form>
      </Dialog>

      <Dialog header="Confirm Delete" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmClsDltCpn()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmOpnDltCoupon(deleteCoupon)}>Yes </Button>
        </div>

      </Dialog>


    </>
  )
}

export default Advertising1Banner