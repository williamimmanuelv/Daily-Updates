import React, { useEffect, useState } from 'react'
import imge1 from "../../Assets/Frame 21.png"
import imge2 from "../../Assets/Frame 17.png"
import image3 from "../../Assets/Frame 18.png"
import image4 from "../../Assets/Frame 19.png"
import image5 from "../../Assets/Frame 20.png"
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { IoSearchOutline } from "react-icons/io5";
import { FiPlus } from "react-icons/fi";

// import { DataTable } from 'primereact/datatable';
// import { Column } from 'primereact/column';
// import { InputSwitch } from 'primereact/inputswitch';
// import { ProductService } from './service/ProductService';

import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import axiosInstance from '../../utils/axiosinstance'
import { img_path } from '../../Api/BaseUrl'
import { SearchData } from '../../utils/Search'
import Toast from '../../utils/Toast'
import customStyle from '../../utils/Customstyle'
import { useFormik } from 'formik'
import * as yup from "yup"

// 
import './billingaddress.css'



const BillingAddress = () => {


  const token = localStorage.getItem("tokenAdmin")
  const navigate = useNavigate();
  const [fetchcategory, setFetchcategory] = useState([])
  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false);
  const [viewconfirmmodal, setViewconfirmmodal] = useState(false);
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [viewCategory, setViewCategory] = useState(null);
  const [fetchbillingaddress, setFetchbillingaddress] = useState([])
  const [deletebilling, setDeletebilling] = useState(null)

  const [editcategoryrowId, setEditcategoryrowId] = useState(null);


  const fetchbilling = async () => {
    try {
      const response = await axiosInstance.get(`/billingaddress`,);
      setFetchbillingaddress(response.data.data);
      console.log("billing", response.data.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchbilling()
  }, [])

  //    const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [billingviewconfirmmodal, setBillingviewconfirmmodal] = useState(false);
  const [billingviewconfirmmodaledit, setBillingviewconfirmmodaledit] = useState(false);
  const [isEditing, setIsEditing] = useState(false)

  const [selectedRows, setSelectedRows] = useState([]);

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };



  const handleEditbilling = (row) => {
    formik.setValues({
      shop_name: row.shop_name,
      building_block_no: row.building_block_no,
      street_area: row.street_area,
      landmark: row.landmark,
      zip_code: row.zip_code,
      city: row.city,
      country: row.country,
      is_default: row.is_default,
      id: row.id,
    });

    setBillingviewconfirmmodaledit(true)
  };

  const columns = [
    {
      name: "S.no",
      cell: (row, index) => (
        <div className="px-3 py-2">
          {index + 1}
        </div>
      ),
      wrap: true,
      sortable: true,
      width: "120px",
      className: ""
    },
    // {
    //   name: "shop_name",
    //   selector: (row) => row.shop_name,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Shop Name",
      selector: (row) => row.shop_name,
      sortable: true,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.shop_name}
        </span>
      ),
    },

    {
      name: "Building Block No",
      selector: (row) => row.building_block_no,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.building_block_no}
        </span>
      ),
      wrap: true,
      sortable: true,
      width: "170px",
    },
    {
      name: "Street Area",
      selector: (row) => row.street_area,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.street_area}
        </span>
      ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Landmark",
      selector: (row) => row.landmark,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.landmark}
        </span>
      ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Zip Code",
      selector: (row) => row.zip_code,
      wrap: true,
      sortable: true,
    },
    {
      name: "City",
      selector: (row) => row.city,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.city}
        </span>
      ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Country",
      selector: (row) => row.country,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.country}
        </span>
      ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Action",
      cell: (row) => (

        <div className="d-flex gap-1 me-5">


          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => {

            handleEditbilling(row)
          }}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => {
            setDeletebilling(row.id);
            setDeleteconfirmmodal(true);
          }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  // const products = [{
  //   SNo: "1",
  //   CreatedDate: "15/12/2025 ",
  //   Price: "$636",
  //   Createby: "user",
  //   ID: "FS16276	",
  //   Stock: "5566",
  //   Actions: ""
  // }]
  const handleRowClick = (row) => {

  };


  // useEffect(() => {
  //     ProductService.getProductsMini().then((data) => setProducts(data));
  // }, []);
  const handleConfirmClose = () => {
    setDeleteconfirmmodal(false);
  };


  const handleConfirmDelete = async () => {

    try {
      await axiosInstance.delete(`/billingaddress/${deletebilling}`);
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchbilling()
    } catch (error) {
      console.error("Delete error:", error);
    } finally {
      setDeleteconfirmmodal(false);
    }
  };

  const onSubmit = async (values) => {

    if (isEditing) {
      try {
        const response = await axiosInstance.post(`/billingaddress/${values.id}?_method=PUT`, values, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        Toast({ message: "Successfully Created", type: "success" });
        setBillingviewconfirmmodaledit(false);
        formik.resetForm();
        fetchbilling()

      } catch (error) {
        console.error("API Error:", error);
      }
    } else {

      try {
        const response = await axiosInstance.post(`/billingaddress`, values, {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        });

        Toast({ message: "Successfully Created", type: "success" });
        setBillingviewconfirmmodal(false);
        formik.resetForm();
        fetchbilling()

      } catch (error) {
        console.error("API Error:", error);
      }
    }
  };

  const formik = useFormik(
    {
      initialValues: {
        shop_name: "",
        building_block_no: "",
        street_area: "",
        landmark: "",
        zip_code: "",
        city: "",
        country: "",
        is_default: 0,


      },
      validationSchema: yup.object().shape({
        shop_name: yup.string().required("build name is required!"),

        building_block_no: yup.string().required("building block no is required!"),
        street_area: yup.string().required("street area  is required"),
        landmark: yup.string().required("landmark is required!"),
        zip_code: yup.string().required("zip code is required!"),
        city: yup.string().required("city is required!"),
        country: yup.string().required("country is required!"),
        is_default: yup.string().required("default is required!"),
      }),
      onSubmit,
    }
  )

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['shop_name', 'building_block_no', 'street_area', 'landmark', 'zip_code', 'city', 'country'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchbillingaddress, filterText, searchColumns);

  return (
    <>
      <div className='container  '>

        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3'>
              <h5>All Shop</h5>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <div className='mt-1  me-2' onClick={() => setBillingviewconfirmmodal(true)}>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div>
            </div>
          </div>


          <div className='pt-2'>
            <DataTable
              columns={columns}
              data={filterdata}
              //  selectableRows
              className='billingDataTable'
              customStyles={customStyle}
              pagination
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />
          </div>

        </div>
      </div>

      <Dialog header="Confirm Deleted"
        visible={deleteconfirmmodal}
        position="top" style={{ width: '30vw' }}
        onHide={() => {
          if (!deleteconfirmmodal) return;
          setDeleteconfirmmodal(false);
        }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp;

          <button
            className="btn btn-success"
            type="button"
            onClick={() => handleConfirmDelete(selectedRowId)}
          >
            Yes
          </button>
        </div>

      </Dialog>

      <Dialog header="Add Billing Address" visible={billingviewconfirmmodal} position="top" style={{ width: '40vw' }} onHide={() => { if (!billingviewconfirmmodal) return; setBillingviewconfirmmodal(false); }}>
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className="px-3 mb-4">
            <h6 className="fw-semibold mb-2">Address Details:</h6>

            <label htmlFor="shop_name" className="form-label">Building Name & Shop Name: (Optional)</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="shop_name"
              name="shop_name"
              placeholder="Enter Shop Name"
              value={formik.values.shop_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.shop_name && formik.touched.shop_name && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.shop_name}
              </p>
            )}
            <label htmlFor="building_block_no" className="form-label">Building & Block No: (Optional)</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="building_block_no"
              name="building_block_no"
              placeholder="Enter Builfing Block No."
              value={formik.values.building_block_no}
              // onChange={formik.handleChange}
              onChange={(e) => {
                const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                formik.setFieldValue("building_block_no", onlyNumbers);
              }}
              onBlur={formik.handleBlur}
            />
            {formik.errors.building_block_no && formik.touched.building_block_no && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.building_block_no}
              </p>
            )}

            <label htmlFor="street_area" className="form-label">Street & Area Name : *</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="street_area"
              name="street_area"
              placeholder="Enter Street"
              value={formik.values.street_area}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.street_area && formik.touched.street_area && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.street_area}
              </p>
            )}

            <label htmlFor="landmark" className="form-label">Landmark:</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="landmark"
              name="landmark"
              placeholder="Enter Landmark"
              value={formik.values.landmark}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.landmark && formik.touched.landmark && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.landmark}
              </p>
            )}
            <div className='d-flex'>
              <div>
                <label htmlFor="zip_code" className="form-label"> ZIP code :</label>
                <input
                  type="text"
                  className="form-control bg-white mb-1"
                  id="zip_code"
                  name="zip_code"
                  placeholder="Enter Zip Code"
                  value={formik.values.zip_code}
                  // onChange={formik.handleChange}
                  onChange={(e) => {
                    const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                    formik.setFieldValue("zip_code", onlyNumbers);
                  }}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.zip_code && formik.touched.zip_code && (
                  <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                    {formik.errors.zip_code}
                  </p>
                )}
              </div>
              <div className='px-3'>
                <label htmlFor="city" className="form-label">  City :</label>
                <input
                  type="text"
                  className="form-control bg-white mb-1"
                  id="city"
                  name="city"
                  placeholder="Enter City"
                  value={formik.values.city}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.city && formik.touched.city && (
                  <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                    {formik.errors.city}
                  </p>
                )}
              </div>
            </div>

            <label htmlFor="country" className="form-label">Country :</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="country"
              name="country"
              placeholder="Enter Country"
              value={formik.values.country}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.country && formik.touched.country && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.country}
              </p>
            )}
            <div className="form-check mb-3 ms-3">
              <input
                type="checkbox"
                className="form-check-input"
                id="is_default"
                name="is_default"
                checked={formik.values.is_default === 1} //  checked if value is 1
                onChange={(e) => {
                  const checked = e.target.checked ? 1 : 0;
                  formik.setFieldValue("is_default", checked);
                }}
              />
              <label htmlFor="is_default" className="form-check-label px-2">
                Set as default
              </label>

              {formik.touched.is_default && formik.errors.is_default && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.is_default}
                </p>
              )}
            </div>


          </div>
          <div className='d-flex justify-content-end'>
            <button type='submit' className='btn btn-success'
              onClick={() => setIsEditing(false)}
            >Save</button>
          </div>
        </form>
      </Dialog>
      <Dialog header="Edit Billing Address"
        visible={billingviewconfirmmodaledit} position="top"
        style={{ width: '40vw' }}
        onHide={() => {
          if (!billingviewconfirmmodaledit) return;
          setBillingviewconfirmmodaledit(false);
          formik.resetForm()
        }}>

        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className="px-3 mb-4">
            <h6 className="fw-semibold mb-2">Address Details:</h6>

            <label htmlFor="shop_name" className="form-label">Building Name & Shop Name: (Optional)</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="shop_name"
              name="shop_name"
              placeholder="Enter Shop Name"
              value={formik.values.shop_name}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.shop_name && formik.touched.shop_name && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.shop_name}
              </p>
            )}
            <label htmlFor="building_block_no" className="form-label">Building & Block No: (Optional)</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="building_block_no"
              name="building_block_no"
              placeholder="Enter Building Block NO."
              value={formik.values.building_block_no}
              // onChange={formik.handleChange}
              onChange={(e) => {
                const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                formik.setFieldValue("building_block_no", onlyNumbers);
              }}
              onBlur={formik.handleBlur}
            />
            {formik.errors.building_block_no && formik.touched.building_block_no && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.building_block_no}
              </p>
            )}

            <label htmlFor="street_area" className="form-label">Street & Area Name : *</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="street_area"
              name="street_area"
              placeholder="Enter Street"
              value={formik.values.street_area}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.street_area && formik.touched.street_area && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.street_area}
              </p>
            )}

            <label htmlFor="landmark" className="form-label">Landmark:</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="landmark"
              name="landmark"
              placeholder="Enter Landmark"
              value={formik.values.landmark}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.landmark && formik.touched.landmark && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.landmark}
              </p>
            )}
            <div className='d-flex'>
              <div>
                <label htmlFor="zip_code" className="form-label"> ZIP code :</label>
                <input
                  type="text"
                  className="form-control bg-white mb-1"
                  id="zip_code"
                  name="zip_code"
                  placeholder="Enter Zip Code"
                  value={formik.values.zip_code}
                  // onChange={formik.handleChange}
                  onChange={(e) => {
                    const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                    formik.setFieldValue("zip_code", onlyNumbers);
                  }}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.zip_code && formik.touched.zip_code && (
                  <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                    {formik.errors.zip_code}
                  </p>
                )}
              </div>
              <div className='px-3'>
                <label htmlFor="city" className="form-label">  City :</label>
                <input
                  type="text"
                  className="form-control bg-white mb-1"
                  id="city"
                  name="city"
                  placeholder="Enter City"
                  value={formik.values.city}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.city && formik.touched.city && (
                  <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                    {formik.errors.city}
                  </p>
                )}
              </div>
            </div>

            <label htmlFor="country" className="form-label">Country :</label>
            <input
              type="text"
              className="form-control bg-white mb-1"
              id="country"
              name="country"
              placeholder="Enter Country"
              value={formik.values.country}
              onChange={formik.handleChange}
              onBlur={formik.handleBlur}
            />
            {formik.errors.country && formik.touched.country && (
              <p style={{ color: "red", fontSize: "12px", marginBottom: "10px"  }}>
                {formik.errors.country}
              </p>
            )}
            <div className="form-check mb-3 ms-3">
              <input
                type="checkbox"
                className="form-check-input"
                id="is_default"
                name="is_default"
                checked={formik.values.is_default === 1} //  checked if value is 1
                onChange={(e) => {
                  const checked = e.target.checked ? 1 : 0;
                  formik.setFieldValue("is_default", checked);
                }}
              />
              <label htmlFor="is_default" className="form-check-label px-2">
                Set as default
              </label>

              {formik.touched.is_default && formik.errors.is_default && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.is_default}
                </p>
              )}
            </div>


          </div>
          <div className='d-flex justify-content-end'>
            <button type='submit' className='btn btn-success' onClick={() => setIsEditing(true)}>Update</button>
          </div>
        </form>
      </Dialog>


    </>
  )
}

export default BillingAddress