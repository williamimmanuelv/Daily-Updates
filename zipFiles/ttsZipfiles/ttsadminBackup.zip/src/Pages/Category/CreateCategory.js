import React, { useEffect, useState } from 'react'
import './category.css'
import tshirt from "../../Assets/t-shirt.png"
import { BiCloudUpload } from "react-icons/bi";
import { Editor } from "primereact/editor";
import { useFormik } from 'formik';
import * as yup from "yup";
import axios from 'axios';
import { base_url, img_path } from '../../Api/BaseUrl';
import axiosInstance from '../../utils/axiosinstance';
import { useNavigate } from 'react-router-dom';
import Toast from '../../utils/Toast';
import { RadioButton } from 'primereact/radiobutton';

const CreateCategory = () => {

  const navigate = useNavigate()
  const [imagePreview, setImagePreview] = useState(null);
  const [text, setText] = useState('');
  const [serverImage, setServerImage] = useState(null);


  const token = localStorage.getItem("tokenAdmin")

  // const handleImageChange = (e) => {
  //   const file = e.target.files[0];
  //   if (file) {
  //     console.log("file", file)
  //     setImagePreview(URL.createObjectURL(file));
  //   }
  // };
  // const handleImageChange = (e) => {
  //   const file = e.target.files[0];
  //   if (file) {
  //     setImagePreview(URL.createObjectURL(file));
  //     formik.setFieldValue("thumbnail", file); 
  //   } else {
  //     setImagePreview(null);
  //     formik.setFieldValue("thumbnail", null); 
  //   }
  // };
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImagePreview(URL.createObjectURL(file));
      formik.setFieldValue("thumbnail", file);
    } else {
      setImagePreview(null);
      formik.setFieldValue("thumbnail", null);
    }
  };

  const [language, setLanguage] = useState("en");

  const handleLanguage = (e, lang) => {
    e.preventDefault();
    formik.setFieldValue("language_code", language);
    setLanguage(lang)
  };
  useEffect(() => {
    formik.setFieldValue("language_code", language);

  }, [language])

  const onSubmit = async (values) => {
    try {
      const formData = new FormData();
      formData.append("title", values.title);
      formData.append("status", values.status);
      // formData.append("created_by", values.created_by);
      // formData.append("stock", values.stock);
      // formData.append("tag_id", values.tag_id);
      formData.append("description", values.description);
      formData.append("language_code", values.language_code);

      if (values.thumbnail) {
        formData.append("thumbnail", values.thumbnail);
      }

      const response = await axios.post(`${base_url}/categories`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      });
      Toast({ message: response.data.message, type: "success" });
      console.log("Success:", response.data);

      setImagePreview(null);
      setServerImage(response.data.thumbnail);
      formik.resetForm();
      navigate('/list')

    } catch (error) {
      // if (error.response?.data?.errors) {
      //   console.error(" Validation errors:", error.response.data.errors);
      // } else {
      //   console.error("Something went wrong:", error.message);
      // }
      Toast({ message: error?.response?.data?.message, type: "error" });

    }
  };

  const formik = useFormik(
    {
      initialValues: {
        title: "",
        // created_by: "",
        // stock: "",
        // tag_id: "",
        thumbnail: null,
        description: "",
        status: "",
        language_code: language,
      },
      validationSchema: yup.object().shape({
        title: yup.string().required("Category is required!"),

        status: yup.string().required("status is required!"),

        description: yup.string().required("description is required!"),
        //  created_by: yup.string().required("Created By is required"),
        // stock: yup.string().required("Stock is required!"),
        // tag_id: yup.string().required("Tag ID is required!"),

      }),
      onSubmit,
    }
  )
  return (
    <>

      <div className="d-flex justify-content-start">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/list')}
        >
          ← Back
        </button>
      </div>
      <div className=''>
        <form onSubmit={formik.handleSubmit} autoComplete="off">

          {/* <h4 className='pt-3'>Category Create</h4> */}

          <div className='row'>

            <div className='col-12 col-md-12' >

              <div className='box_shadow p-4 rounded mt-4 bg-white' >
                <ul className="nav nav-tabs mb-3 ">
                  <li className="nav-item">
                    <button
                      type="button"
                      className='nav-link active text-primary'
                      // className={`nav-link ${language === "en" ? "active" : "black"}`}
                      // onClick={(e) => handleLanguage(e, "en")}
                    >
                      English
                    </button>
                  </li>
                  {/* <li className="nav-item">
                    <button
                      type="button"
                      className={`nav-link ${language === "de" ? "active" : "black"}`}
                      onClick={(e) => handleLanguage(e, "de")}
                    >
                      German
                    </button>
                  </li> */}
                </ul>
                <div className='d-flex'>
                  <h5>General Information</h5>


                  {/* <div className="dropdown ms-4">
                      <button type="button" className="btn btn-outline-primary dropdown-toggle" data-bs-toggle="dropdown">
                    Select Language
                      </button>
                      <ul className="dropdown-menu">
                        <li><a className="dropdown-item" href="#">English </a></li>
                        <li><a className="dropdown-item" href="#">German </a></li>
                        <li><a className="dropdown-item" href="#"></a></li>
                      </ul>
                    </div> */}

                  {/* <div className="dropdown ms-4">
                      <button
                        className="btn btn-outline-primary dropdown-toggle"
                        data-bs-toggle="dropdown"
                        type="button"
                      >
                        {formik.values.language_code === "en"
                          ? "English"
                          : formik.values.language_code === "de"
                            ? "German"
                            : "Select a language"}
                      </button>

                      <ul className="dropdown-menu">
                        <li>
                          <button
                            type="button"
                            className="dropdown-item"
                            onClick={() => formik.setFieldValue("language_code", "en")}
                          >
                            English
                          </button>
                        </li>

                        <li>
                          <button
                            type="button"
                            className="dropdown-item"
                            onClick={() => formik.setFieldValue("language_code", "de")}
                          >
                            German
                          </button>
                        </li>
                      </ul>
                      {formik.errors.language_code && formik.touched.language_code && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.language_code}
                        </p>
                      )}
                    </div> */}

                </div>
                <hr />

                <div className='row g-4'>

                  <div className='col-12 col-md-6 mt-2'>
                    <div className='mb-3'>
                      <label htmlFor="categoryTitle" className='form-label text-muted '>Category Title</label>
                      <input
                        type='text'
                        className='form-control opacity-75'
                        name='title'
                        id="title"
                        placeholder='Enter Title'
                        value={formik.values.title}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.title && formik.touched.title && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.title}
                        </p>
                      )}

                    </div>

                    {/* <div className='mb-3'>
                          <label htmlFor="stockSelect" className='form-label text-muted'>Stock</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            name='stock'
                            id="stock"
                            placeholder='Enter Stock'
                            value={formik.values.stock}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.stock && formik.touched.stock && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.stock}
                            </p>
                          )}
                        </div> */}

                    <div className="mb-3 ">
                      <label className="form-label text-muted">Status</label>
                      <div className="d-flex  gap-2">
                        <div className="form-check">

                          <RadioButton inputId="ingredient1" name="status" value="active" id="status-active"
                            checked={formik.values.status === "active"}
                            onChange={formik.handleChange}
                          />
                          <label className="form-check-label ms-2" htmlFor="status-active">
                            Active
                          </label>
                        </div>
                        <div className="form-check">

                          <RadioButton inputId="ingredient2" name="status" value="inactive" id="status-inactive"
                            checked={formik.values.status === "inactive"}
                            onChange={formik.handleChange}
                          />
                          <label className="form-check-label ms-2" htmlFor="status-inactive">
                            Inactive
                          </label>
                        </div>

                      </div>
                      {formik.errors.status && formik.touched.status && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.status}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className='col-12 col-md-6 mt-5'>
                    {/* <div className='mb-3'>
                      <label htmlFor="created_by" className='form-label text-muted'>Created By</label>
                      <select className="form-select opacity-75" id="created_by" name="created_by"
                        value={formik.values.created_by}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      >
                        <option>Select Creator</option>
                        <option>admin</option>
                        <option>user</option>


                      </select>
                      {formik.errors.created_by && formik.touched.created_by && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.created_by}
                        </p>
                      )}
                    </div> */}

                    {/* <div className='mb-3'>
                      <label htmlFor="tag_id" className='form-label text-muted'>Tag ID</label>
                      <input
                        type='text'
                        className='form-control opacity-75'
                        name='tag_id'
                        id="tag_id"
                        placeholder='Enter Tag ID'
                        value={formik.values.tag_id}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.tag_id && formik.touched.tag_id && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.tag_id}
                        </p>
                      )}
                    </div> */}

                  </div>
                  <div className='col-12'>
                    <div className='mb-3'>
                      {/* <label htmlFor="description" className='form-label text-muted'>Description</label>
                                <textarea
                                    className="form-control "
                                    id="description"
                                    rows="5"
                                    placeholder="Type description"
                                ></textarea> */}
                      {/* <div className="">
                            <Editor value={text} onTextChange={(e) => setText(e.htmlValue)} style={{ height: '320px' }} 
                              value={formik.values.description}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}/>
                          </div> */}
                      <div className="">
                        <Editor
                          id="description"
                          name="description"
                          value={formik.values.description}
                          onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                          onBlur={formik.handleBlur}
                          style={{ height: "320px" }}
                        />
                        {formik.errors.description && formik.touched.description && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>

          <div className='row pt-3'>
            <div className="col-12 col-md-12 ">
              <div className='box_shadow  bg-white pb-4'>

                <h5 className="mb-3  ms-4 pt-3">Add Thumbnail Photo</h5>
                <hr className='' />

                <div
                  className="border border-dotted  mx-auto text-center "
                  style={{ maxWidth: "800px", minHeight: "200px", display: "flex", alignItems: "center", justifyContent: "center" }}
                >
                  <input
                    type="file"
                    id="thumbnail-upload"
                    className="d-none"
                    accept="image/png, image/jpeg, image/gif"
                    onChange={handleImageChange}
                  />

                  {/* {imagePreview ? (
                    <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                      <img
                        // src={imagePreview}
                        src={`${img_path}/categories/${response.data.thumbnail}`} */}
                  {imagePreview || serverImage ? (
                    <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                      <img
                        src={
                          imagePreview
                            ? imagePreview // local preview before submit
                            : `${img_path}/categories/${serverImage}` // server image after upload
                        }
                        alt="Preview"
                        className="img-fluid rounded"
                        style={{
                          maxHeight: "200px",
                          maxWidth: "100%",
                          objectFit: "contain",
                          border: "1px solid #ccc",
                          padding: "5px",
                        }}
                      />
                    </label>
                  ) : (
                    // Else show the upload icon + text
                    <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                      <BiCloudUpload size={50} className="color_icon mb-3" />
                      <h4>
                        Drop your images here, or{" "}
                        <span className="color_icon">click to browse</span>
                      </h4>
                      <p className="small text-muted">
                        1600 x 1200 (4:3) recommended. PNG, JPG and GIF files are allowed
                      </p>
                    </label>
                  )}
                </div>
              </div>

            </div>
          </div>
          <div className='col-12 d-flex justify-content-end gap-3 mt-3'>
            <button className='btn btn-danger bg_color' onClick={() => formik.resetForm()}>Cancel</button>

            <button type='submit' className='btn btn-outline-success'>Create</button>
          </div>
        </form>
      </div>
    </>
  )
}

export default CreateCategory