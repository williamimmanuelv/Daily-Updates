import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import { IoSearchOutline } from "react-icons/io5";
import customStyle from '../../utils/Customstyle';
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';


const Customers = () => {
  //  const [products, setProducts] = useState([]);
 const [customeruser, setCustomeruser] = useState([])
  console.log("customeruser", customeruser)
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [viewcustomerconfirmmodal, setViewcustomerconfirmmodal] = useState(false)

  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const fetchcustomer = async () => {
    try {
      const response = await axiosInstance.get(`/allusers`,);
      setCustomeruser(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchcustomer()
  }, [])
  
  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
         width: "120px",
    },
    {
      name: "customer ID",
      selector: (row) => row.customer_id,
      wrap: true,
      sortable: true,
       width: "220px",
    },
    {
      name: "Name",
      selector: (row) => row.name,
       cell: (row) => (
    <span className=" product-name-ellipsis  ">
      {row.name}
    </span>
  ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Email",
      selector: (row) => row.email,
       cell: (row) => (
    <span className=" product-name-ellipsis  ">
      {row.email}
    </span>
  ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Phoneno",
      selector: (row) => row.phone,
      wrap: true,
      sortable: true,
      
    },
    // {
    //   name: "Actions",
    //   cell: (row) => (
      
    //     <div className="d-flex gap-3 me-5">
    //       <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
    //         <GrFormView size={20} color="white" onClick={() => setViewcustomerconfirmmodal(true)} />
    //       </div>
    //      </div>
    //       ),
    //   wrap: true,
    // },

  ];

  const productss = [{
    Product: "1111",
    SKU: "15/12/2025 ",
    Stock: "$636",
    Unit: "user",
    Email: "FS16276",
    Phoneno: "5566",
    Actions: ""
  }]
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'date', 'category_name', 'subcat_name', 'file', 'tracking_status', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(customeruser, filterText, searchColumns);
  return (
    <>
 <div className='mt-3 box_shadow'>
        <div className='d-flex justify-content-between py-3 px-3'>
          <div>
            <h5>All Customer List</h5>
          </div>
          <div className='text-end position-relative'>
            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
              size={18} />
            <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
          </div>

        </div>
        <DataTable
          columns={columns}

          data={filterdata}
          customStyles={customStyle}
          pagination
          // selectableRows
          onRowClicked={handleRowClick}
          fixedHeader
          persistTableHead={true}
        />
      </div>


      <Dialog header="Confirm View Modal" visible={viewcustomerconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!viewcustomerconfirmmodal) return; setViewcustomerconfirmmodal(false); }}>

        <div className='row'>
          <div className='col'>
            <p>SNo :</p>

            <p>Order ID :</p>
            <p>Name :</p>

          </div>
          <div className='col'>
            <p>Email :</p>

            <p>Phoneno:</p>

          </div>

        </div>

      </Dialog>

    </>
  )
}

export default Customers