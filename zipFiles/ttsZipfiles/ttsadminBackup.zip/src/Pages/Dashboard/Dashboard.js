import React, { useEffect, useState } from 'react'
import './dashbord.css'
import { FaCartPlus } from "react-icons/fa6";
import { FaDollarSign } from "react-icons/fa6";
import { RiTShirtFill } from "react-icons/ri";
import { ProgressBar } from 'primereact/progressbar';
import Vegetables from "../../Assets/Frame 21.png"
import Grocery from "../../Assets/Frame 17.png"
import Garments from "../../Assets/Frame 19.png"
import { Chart } from 'primereact/chart';
import { TiThLargeOutline } from "react-icons/ti";

import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import axiosInstance from '../../utils/axiosinstance';

// import { ProductService } from './service/ProductService';
const Dashboard = () => {

  const [products, setProducts] = useState([
    { orderId: 'F3256', customerName: 'Dev', paymentType: 'GPay', amount: 8569 },
    { orderId: 'F3257', customerName: 'Ravi', paymentType: 'Cash', amount: 4250 },
    { orderId: 'F3258', customerName: 'Priya', paymentType: 'Card', amount: 6200 },
    { orderId: 'F3259', customerName: 'Anil', paymentType: 'GPay', amount: 9100 }
  ]);

  //    useEffect(() => {
  //     ProductService.getProductsMini().then(data => setProducts(data));
  // }, []);

  const [chartData, setChartData] = useState({});
  const [chartOptions, setChartOptions] = useState({});
  const [fetchproducts, setFetchproducts] = useState([])
  const [language, setLanguage] = useState([])

  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products`, {
        params: {
          lang: language,
        },
      });
      setFetchproducts(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchproduct()
  }, [language])

  useEffect(() => {
    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = documentStyle.getPropertyValue('--text-color');
    const textColorSecondary = documentStyle.getPropertyValue('--text-color-secondary');
    const surfaceBorder = documentStyle.getPropertyValue('--surface-border');
    const data = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [
        {
          label: 'My First dataset',
          backgroundColor: documentStyle.getPropertyValue('--blue-500'),
          borderColor: documentStyle.getPropertyValue('--blue-500'),
          data: [65, 59, 80, 81, 56, 55, 40]
        },
        {
          label: 'My Second dataset',
          backgroundColor: documentStyle.getPropertyValue('--pink-500'),
          borderColor: documentStyle.getPropertyValue('--pink-500'),
          data: [28, 48, 40, 19, 86, 27, 90]
        }
      ]
    };
    const options = {
      maintainAspectRatio: false,
      aspectRatio: 0.8,
      plugins: {
        legend: {
          labels: {
            fontColor: textColor
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: textColorSecondary,
            font: {
              weight: 500
            }
          },
          grid: {
            display: false,
            drawBorder: false
          }
        },
        y: {
          ticks: {
            color: textColorSecondary
          },
          grid: {
            color: surfaceBorder,
            drawBorder: false
          }
        }
      }
    };

    setChartData(data);
    setChartOptions(options);
  }, []);


  const [ordermanagecount, setOrdermanagecount] = useState([])


  const fetchManageCount = async () => {
    try {
      const response = await axiosInstance.get(`/orders/counts`,);
      setOrdermanagecount(response?.data);
      console.log("response_count", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchManageCount()
  }, [])

  return (
    <>
      {/* <h4>Dashboard</h4> */}
      <div className="row g-4 py-3">
        {/* Card 1 */}
        <div className="col-12 col-md-3">
          <div className="shadow d-flex align-items-center justify-content-center p-3 h-100">
            <div className="text-center me-3">
              <FaCartPlus size={28} color="blue" />
              <h5 className="text-success mt-2">110%</h5>
            </div>
            <div>
              <p className="fw-semibold mb-0">Total Order</p>

              {/* <h4>{ordermanagecount?.total_orders}</h4> */}

              <h4 className="fw-bold mb-1">1,234</h4>
              <small className="text-muted">This Month</small>
            </div>
          </div>
        </div>

        {/* Card 2 */}
        <div className="col-12 col-md-3">
          <div className="shadow d-flex align-items-center justify-content-center p-3 h-100">
            <div className="text-center me-3">
              <RiTShirtFill size={28} color="" />
              <h5 className="text-success mt-2">30%</h5>
            </div>
            <div>
              <h4 className="fw-bold mb-1">{fetchproducts.length}</h4>
              <p className="fw-semibold mb-0">Total Product</p>
              <small className="text-muted">Last Month</small>
            </div>
          </div>
        </div>

        {/* Card 3 */}
        <div className="col-12 col-md-3">
          <div className="shadow d-flex align-items-center justify-content-center p-3 h-100">
            <div className="text-center me-3">
              <TiThLargeOutline size={25} color="" />
              <h5 className="text-danger mt-2">-0.0%</h5>
            </div>
            <div>
              <h4 className="fw-bold mb-1">50</h4>
              {/* <p className="fw-semibold mb-0">Total Sales</p> */}
              <small className="text-muted">From Last Month</small>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-3">
          <div className="shadow d-flex align-items-center justify-content-center p-3 h-100">
            <div className="text-center me-3">
              <FaDollarSign size={28} color="blue" />
              <h5 className="text-success mt-2">-185%</h5>
            </div>
            <div>
              <h4 className="fw-bold mb-1">500,000</h4>
              <p className="fw-semibold mb-0">Total Sales</p>
              <small className="text-muted">From Last Month</small>
            </div>
          </div>
        </div>

      </div>
      <div className='row py-5 '>
        <div className='col-12 col-md-6 py-3'>
          <h5 className='text-center'>Order Summary</h5>

          <div className="pt-4">
            <h6 className='pb-1'>Todal Order Today</h6>
            <ProgressBar value={100} className='progressWidth'></ProgressBar>
            <h6 className='pt-4'>Confirm Order</h6>
            <ProgressBar value={80} className='progressWidth mt-3'></ProgressBar>
            <h6 className='pt-4'>Processed Order</h6>
            <ProgressBar value={60} className='progressWidth mt-3'></ProgressBar>
            <h6 className='pt-4'>Shipped Order</h6>
            <ProgressBar value={40} className='progressWidth mt-3'></ProgressBar>
            <h6 className='pt-4'>Pending Order</h6>
            <ProgressBar value={20} className='progressWidth mt-3'></ProgressBar>

          </div>
        </div>
        <div className="col-12 col-md-6 ps-md-5 py-3">
          <h5 className="text-center mb-4">Low Stock Alert</h5>

          {/* Vegetable Card */}
          <div className="d-flex align-items-center justify-content-between p-3 border rounded ">
            <div className="d-flex align-items-center">
              <img
                src={Vegetables}
                alt="Vegetables"
                className="img-fluid me-3"
                style={{ height: "80px", objectFit: "contain" }}
              />
              <h6 className="mb-0">Vegetables</h6>
            </div>
            <span className="fw-semibold text-muted fs-5">10 Stock</span>
          </div>

          {/* Grocery Card */}
          <div className="d-flex align-items-center justify-content-between p-3 border rounded  mt-3">
            <div className="d-flex align-items-center">
              <img
                src={Grocery}
                alt="Grocery"
                className="img-fluid me-3"
                style={{ height: "80px", objectFit: "contain" }}
              />
              <h6 className="mb-0">Grocery</h6>
            </div>
            <span className="fw-semibold text-muted fs-5">50 Stock</span>
          </div>

          {/* Garments Card */}
          <div className="d-flex align-items-center justify-content-between p-3 border rounded  mt-3">
            <div className="d-flex align-items-center">
              <img
                src={Garments}
                alt="Garments"
                className="img-fluid me-3"
                style={{ height: "80px", objectFit: "contain" }}
              />
              <h6 className="mb-0">Garments</h6>
            </div>
            <span className="fw-semibold text-muted fs-5">5 Stock</span>
          </div>
        </div>


      </div>

      {/* <div className='row'>
  <div className="col-12 col-md-6">
  <h5 className='text-center'>Top Products</h5>
<div className='d-flex justify-content-between pt-3'>
  <h6 className="mb-3 pt-3">Product</h6>
  <h6 className="mb-3 pt-3">Todal</h6>

</div>


  <div className="d-flex align-items-center mb-2">
    <ProgressBar value={100} className="flex-grow-1 me-2" />
    <span className="fw-semibold ps-4">584</span>
  </div>

  
  <div className="d-flex align-items-center mb-2">
    <ProgressBar value={80} className="flex-grow-1 me-2 mt-2" />
    <span className="fw-semibold ps-4">484</span>
  </div>

 
  <div className="d-flex align-items-center mb-2">
    <ProgressBar value={60} className="flex-grow-1 me-2 mt-2" />
    <span className="fw-semibold ps-4">342</span>
  </div>


  <div className="d-flex align-items-center mb-2">
    <ProgressBar value={40} className="flex-grow-1 me-2 mt-2" />
    <span className="fw-semibold ps-4">284</span>
  </div>


  <div className="d-flex align-items-center">
    <ProgressBar value={20} className="flex-grow-1 me-2 mt-2" />
    <span className="fw-semibold ps-4">184</span>
  </div>
</div>


  <div className='col-12 col-md-6 '>
    <h5 className='text-center'>Online Payment</h5>

     <div className="pt-3 ps-3">
            <DataTable value={products} tableStyle={{ minWidth: '50rem' }}>
                <Column field="orderId" header="OrderID" sortable style={{ width: '25%' }}></Column>
                <Column field="customerName" header="Customer Name" sortable style={{ width: '25%' }}></Column>
                <Column field="paymentType" header="Payment Type" sortable style={{ width: '25%' }}></Column>
                <Column field="amount" header="Amount" sortable style={{ width: '25%' }}></Column>
            </DataTable>
        </div>
  </div>
 </div>

 <div className=''>


 </div>

 <div>
 <div className="mt-5 pt-5">
    <h3> Sale Graph</h3>
            <Chart type="bar" data={chartData} options={chartOptions} />
        </div>
 </div> */}
    </>
  )
}

export default Dashboard