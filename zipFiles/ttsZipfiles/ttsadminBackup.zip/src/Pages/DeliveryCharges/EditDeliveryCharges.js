import { useFormik } from 'formik'
import React, { useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import Toast from '../../utils/Toast'
import axiosInstance from '../../utils/axiosinstance'
import { RadioButton } from 'primereact/radiobutton';
import * as yup from 'yup'

const EditDeliveryCharges = () => {
      const navigate = useNavigate()
     const { state } = useLocation();  
  const getData = state;  
  console.log("getData",getData)  


  useEffect(()=>{
     formik.setFieldValue('charges_by', getData?.charges_by)
     formik.setFieldValue('min_amount', getData?.min_amount)
     formik.setFieldValue('max_amount', getData?.max_amount)
     formik.setFieldValue('charge', getData?.charge)
   
     formik.setFieldValue('id', getData?.id)
  },[])

    const onSubmit = async (values) => {
    
        try {
            const response = await axiosInstance.post(`/delivercharges/${values.id}?_method=PUT`, values, {

                headers: {
                    "Content-Type": "application-json"
                },
            });
            console.log("response", response)
            Toast({ message: "Successfully Updated", type: "success" });
            formik.resetForm()
            navigate('/ListDeliveryCharges')
        }
        catch (error) {
            console.log("error", error)
            Toast({ message: "Error to taken project", type: "error" });
        }
         }
     const formik = useFormik(
        {
            initialValues: {
                charges_by: "",
                min_amount: "",
                max_amount: "",
                charge: "",
              },
            validationSchema: yup.object().shape({
                 charges_by: yup.string().required("charges_by is required!"),
                min_amount: yup.string().required("min_amount is required!"),
                max_amount: yup.string().required("max_amount is required!"),
                charge: yup.string().required("charge  is required"),
            }),
            onSubmit,
        }
    )
  return (
    <>
       <div className="d-flex justify-content-start">
    <button
        type="button"
        className="btn btn-secondary"
        onClick={() => navigate('/ListDeliveryCharges')}
    >
        ← Back
    </button>
    </div>

     <div className='row'>

                <div className='col-12 col-md-12' >
                    <form onSubmit={formik.handleSubmit} autoComplete="off">
                        <div className='box_shadow p-4 rounded mt-4 bg-white' >
                            <h5>Edit Delivery Charges</h5>
                            <hr />

                            <div className='row g-4'>

                                <div className='col-12 col-md-6 mt-5'>
                                  {/* <div className="mb-3 ">
                                        <label className="form-label text-muted">Via</label>
                                        <div className="d-flex flex-column gap-2">
                                            <div className="form-check">
                                               
                                                 <RadioButton inputId="ingredient1"  name="charges_by"     value="Amount"   id="charges_by" 
                                                checked={formik.values.charges_by === "Amount"}
                                           onChange={formik.handleChange}
                                          />
                                                <label className="form-check-label ms-2" htmlFor="charges_by">
                                                    Amount
                                                </label>
                                            </div>
                                            <div className="form-check">
                                               
                                                  <RadioButton inputId="ingredient2"  name="charges_by"      value="District"   id="charges_by" 
                                       checked={formik.values.charges_by === "District"}
                                           onChange={formik.handleChange}
                                          />
                                                <label className="form-check-label ms-2" htmlFor="charges_by">
                                                    District
                                                </label>
                                            </div>
                                        </div>
                                    </div> */}

                                    {/* Conditional Rendering */}
                                    {/* {formik.values.charges_by === "Amount" && (
                                        <div className="mb-3">
                                            <label htmlFor="condition" className="form-label text-muted">
                                                Condition
                                            </label>
                                            <select
                                                className="form-select opacity-75"
                                                id="condition"
                                                name="condition"
                                                value={formik.values.condition}
                                                onChange={formik.handleChange}
                                                onBlur={formik.handleBlur}
                                            >
                                                <option value="">Select Condition</option>
                                                <option value="Below">Below</option>
                                                <option value="Above">Above</option>
                                            </select>
                                            {formik.errors.condition && formik.touched.condition && (
                                                <p style={{ color: "red", fontSize: "12px" }}>
                                                    {formik.errors.condition}
                                                </p>
                                            )}
                                        </div>
                                    )}

                                    {formik.values.charges_by === "District" && (
                                        <div className="mb-3">
                                            <label htmlFor="condition" className="form-label text-muted">
                                                Place
                                            </label>
                                            <select
                                                className="form-select opacity-75"
                                                id="condition"
                                                name="condition"
                                                value={formik.values.condition}
                                                onChange={formik.handleChange}
                                                onBlur={formik.handleBlur}
                                            >
                                                <option value="">Select Place</option>
                                                <option value="Thanjavur">Thanjavur</option>
                                                <option value="Kumbakonam">Kumbakonam</option>
                                            </select>
                                            {formik.errors.condition && formik.touched.condition && (
                                                <p style={{ color: "red", fontSize: "12px" }}>
                                                    {formik.errors.condition}
                                                </p>
                                            )}
                                        </div>
                                    )} */}
                                            <div className='mb-3'>
                                        <label htmlFor="max_amount" className='form-label text-muted'>MaxAmount</label>
                                        <input
                                            type='text'
                                            className='form-control opacity-75 w-75'
                                            name='max_amount'
                                            id="max_amount"
                                            placeholder='Enter MaxAmount'
                                            value={formik.values.max_amount}
                                            onChange={formik.handleChange}
                                            onBlur={formik.handleBlur}
                                        />
                                        {formik.errors.max_amount && formik.touched.max_amount && (
                                            <p style={{ color: "red", fontSize: "12px" }}>
                                                {formik.errors.max_amount}
                                            </p>
                                        )}
                                    </div>
                                          </div>
                                   <div className='col-12 col-md-6 mt-5'>
                                   
                                     <div className='mb-3'>
                                        <label htmlFor="min_amount" className='form-label text-muted'>MinAmount</label>
                                        <input
                                            type='text'
                                            className='form-control opacity-75 w-75'
                                            name='min_amount'
                                            id="min_amount"
                                            placeholder='Enter MinAmount'
                                            value={formik.values.min_amount}
                                            onChange={formik.handleChange}
                                            onBlur={formik.handleBlur}
                                        />
                                        {formik.errors.min_amount && formik.touched.min_amount && (
                                            <p style={{ color: "red", fontSize: "12px" }}>
                                                {formik.errors.min_amount}
                                            </p>
                                        )}
                                    </div>
                                       <div className='mb-3'>
                                        <label htmlFor="charge" className='form-label text-muted'>Delivery Amount</label>
                                        <input
                                            type='text'
                                            className='form-control opacity-75 w-75'
                                            name='charge'
                                            id="charge"
                                            placeholder='Enter Delivery  Amount'
                                            value={formik.values.charge}
                                            onChange={formik.handleChange}
                                            onBlur={formik.handleBlur}
                                        />
                                        {formik.errors.charge && formik.touched.charge && (
                                            <p style={{ color: "red", fontSize: "12px" }}>
                                                {formik.errors.charge}
                                            </p>
                                        )}
                                    </div>

                                </div>
                                <div className='col-12 d-flex justify-content-end gap-3'>
                                    <button className='btn btn-danger bg_color' onClick={() => formik.resetForm()}>Cancel</button>

                                    <button type='submit' className='btn btn-outline-success'>Update</button>
                                </div>
                            </div>
                        </div>
                          </form>
                </div>

            </div>
    </>
  )
}

export default EditDeliveryCharges