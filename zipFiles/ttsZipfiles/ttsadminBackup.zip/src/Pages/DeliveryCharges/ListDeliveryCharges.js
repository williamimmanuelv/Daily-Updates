import React, { useEffect, useState } from 'react'

import { Dialog } from 'primereact/dialog';
import DataTable from 'react-data-table-component';
import Toast from '../../utils/Toast';
import axiosInstance from '../../utils/axiosinstance';
import { Link, useNavigate } from 'react-router-dom';
import { IoSearchOutline } from "react-icons/io5";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";

import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';

import { FiPlus } from "react-icons/fi";

const ListDeliveryCharges = () => {

    const navigate=useNavigate()

      const [fetchDelivery, setFetchDelivery] = useState([])
      console.log(" fetchDeliverydddddddd",fetchDelivery)
      const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false);
   
      const [selectedRowId, setSelectedRowId] = useState(null);
      const [viewCategory, setViewCategory] = useState(null);
  
     const fetchDeliverys = async () => {
    try {
      const response = await axiosInstance.get(`/delivercharges`,);
      setFetchDelivery(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchDeliverys()
  }, [])


      const columns = [
        {
          name: "S.no",
          cell: (row, index) => index + 1,
          wrap: true,
          sortable: true,
        },
        {
          name: "Via",
          selector: (row) => row.charges_by,
          wrap: true,
          sortable: true,
        },
        
        {
          name: "Amount",
          selector: (row) => row.charge,
          wrap: true,
          sortable: true,
        },
        // {
        //   name: "Status",
        //   selector: (row) => row.stock,
        //   wrap: true,
        //   sortable: true,
        // },
         {
          name: "Max Amount",
          selector: (row) => row.max_amount,
          wrap: true,
          sortable: true,
        },
        {
          name: "Min Amount",
          selector: (row) => row.min_amount,
          wrap: true,
          sortable: true,
          width: "170px",
        },
        {
          name: "Actions",
          cell: (row) => (
            // <button className="btn btn-danger btn-sm">Delete</button>
            <div className="d-flex gap-3">
              <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => editcate(row)}>
                <LuPencilLine size={16} color="red" />
              </div>
    
              <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}onClick={() => {
                  setSelectedRowId(row.id);
                  setDeleteconfirmmodal(true); }} >
                <AiOutlineDelete size={18} color="red" />
              </div>
            </div>
    
          ),
          wrap: true,
        },
      ];


      const editcate=(row)=>{
          navigate('/EditDeliveryCharges', { state: row }); 

      }

        const handleRowClick = (row) => {

  };


      const handleConfirmClose = () => {
    setDeleteconfirmmodal(false);
  };


  const handleConfirmDelete = async () => {
  
    try {
      await axiosInstance.delete(`/delivercharges/${selectedRowId}`);
           Toast({ message: "Successfully Deleted", type: "success" });

    fetchDeliverys()
    
    } catch (error) {
      console.error("Delete error:", error);
    } finally {
      setDeleteconfirmmodal(false);
    }
  };

   const [filterText, setFilterText] = useState("");
                const searchColumns = [ 'charges_by','min_amount','max_amount','charge','status' ];
                const handleFilter = (event) => {
                  setFilterText(event.target.value);
                };
                const filterdata = SearchData(fetchDelivery, filterText, searchColumns);
  return (
   <>
     <div className='container'>
          
                    
                     <div className='mt-3 box_shadow  bg-white rounded-2'>
                          <div className='d-flex justify-content-between'>
                            <div className='pt-3 px-3'>
                            <h5>All Delivery Charges List</h5>
                           </div>
                             <div className='d-flex  pt-2 pe-2'>
                             <div className='text-end position-relative px-2 pt-1'>
                            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                              size={18} />
                            <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
                          </div>
                            <Link to="/CreateDeliveryCharges" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
                            <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus  className='pb-1'/></button>
                          </div></Link>
                          </div>
                        </div>
          
               <div className='pt-2'>
          <DataTable
            columns={columns}
            data={filterdata}
           
            customStyles={customStyle}
            pagination
            // // selectableRows
            onRowClicked={handleRowClick}
            fixedHeader
            persistTableHead={true}
          />
        </div>
        </div>

      </div>

        <Dialog header="Confirm Delete" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>
      
              <div className=" form-group">
                <p>Do you want to delete this record?</p>
              </div>
              <div className="d-flex p-3 justify-content-end mt-3">
                <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp;
      
                <button
                  className="btn btn-success"
                  type="button"
                  onClick={() => handleConfirmDelete(selectedRowId)}
                >
                  Yes
                </button>
              </div>
      
            </Dialog>
   </>
  )
}

export default ListDeliveryCharges