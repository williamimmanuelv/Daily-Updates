import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dropdown } from 'primereact/dropdown';
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
import { useFormik } from 'formik';
import * as yup from "yup"
import Toast from '../../utils/Toast';
import customStyle from '../../utils/Customstyle';

const Stock = () => {
  //  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [viewstockconfirmmodal, setViewstockconfirmmodal] = useState(false)
  const [editconfirmmodal, setEditconfirmmodal] = useState(false)
  const [fetchproducts, setFetchproducts] = useState([]);
  const [viewrowId, setViewrowId] = useState(null)

  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products`,
        {
          params: {
            lang: "all",
          },
        }
      );
      setFetchproducts(response?.data?.data)
      // setFetchproducts(response?.data?.data?.filter((item) => item.translations === "en"));
      console.log("response.dataS", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchproduct()
  }, [])

  const columns = [
    // {
    //   name: "Product",
    //   selector: (row) => row?.translations?.en?.product_name,
    //   wrap: true,
    //   sortable: true,
    // },
    {

      name: "Product Name",
      selector: (row) => row.product_name,
      sortable: true,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row?.translations?.en ? row?.translations?.en?.product_name : row?.translations?.de?.product_name}
        </span>
      ),
    },
    // {
    //   name: "SKU",
    //   selector: (row) => row.pro_sku,
    //    wrap: true,
    //   sortable: true,
    // },
    {
      name: "Stock",
      selector: (row) => row.stock,
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "Unit",
    //   selector: (row) => row.Unit,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Low Stock Alert",
    //   selector: (row) => row.low_stk_alert,
    //   wrap: true,
    //   sortable: true,

    // },
    // {
    //   name: "Last Update",
    //   selector: (row) => row.updated_at,
    //   wrap: true,
    //   sortable: true,
    // },

    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-3 me-5">
          <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setViewrowId(row); setViewstockconfirmmodal(true); }}>
            <GrFormView size={20} color="white" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { handleEdit(row); setEditconfirmmodal(true); }} >
            <LuPencilLine size={16} color="red" />
          </div>

          {/* <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
                  <AiOutlineDelete size={18} color="red" />
                </div> */}
        </div>

      ),
      wrap: true,
    },
  ];

  const handleEdit = (row) => {
    console.log("rowsss", row)

    formik.setValues({
      stock: row.stock,
      id: row.id,
    });
    console.log("row.stock", row.stock)

    setEditconfirmmodal(true)
  };

  const onSubmit = async (values) => {
    try {
      const response = await axiosInstance
        .post(`/products/update-stock/${values.id}`, values, {
          headers: {
            "Content-Type": "multipart/form-data",
            Accept: "application/json",

          },
        });
      Toast({ message: "Successfully Update", type: "success" });
      formik.resetForm();
      console.log("responsessss", response)
      fetchproduct()

      setEditconfirmmodal(false)

    } catch (error) {
      console.log("error", error)
    }
  }

  const formik = useFormik(
    {
      initialValues: {

        stock: "",
      },

      // validationSchema: yup.object().shape({
      //   stock: yup.string().required("stock By is required"),
      // }),
      onSubmit,
    }
  )



  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['product_name', 'pro_sku', 'stock', 'Unit', 'low_stk_alert', 'updated_at', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchproducts, filterText, searchColumns);

  return (
    <>
      <div className='mt-3 box_shadow'>
        <div className='d-flex justify-content-between py-3 px-3'>
          <div>
            <h5>All Stock List</h5>
          </div>
          <div className='text-end position-relative'>
            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
              size={18} />
            <input text="search" className='form-control opacity-75' id='' name='' onChange={handleFilter} placeholder='Search Filter.........' />
          </div>

        </div>


        <DataTable
          columns={columns}

          data={filterdata}

          customStyles={customStyle}
          pagination
          // selectableRows
          onRowClicked={handleRowClick}
          fixedHeader
          persistTableHead={true}
        />
      </div>

      <Dialog header="Confirm Edit Modal" visible={editconfirmmodal} position="top" style={{ width: '50vw' }} onHide={() => { if (!editconfirmmodal) return; setEditconfirmmodal(false); }}>
        <form onSubmit={formik.handleSubmit} autoComplete="off">

          <div className='row'>

            <div className='col-12 col-md-6'>
              {/* <div className='mb-3'>
                                        <label htmlFor="createdBy" className='form-label text-muted'>Tag No</label>
                                        <input
                                            type='text'
                                            className='form-control opacity-75'
                                            id="createdBy"
                                            placeholder='Enter Tag No'
                                        />
                                    </div> */}
              <div className='mb-3'>
                <label htmlFor="stock" className='form-label text-muted'>Stock</label>
                <input
                  type='text'
                  className='form-control opacity-75'
                  id="stock"
                  name='stock'
                  placeholder='Enter Stock'
                  value={formik.values.stock}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.stock && formik.touched.stock && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.stock}
                  </p>
                )}
              </div>
              {/* <div className='mb-3'>
                                        <label htmlFor="createdBy" className='form-label text-muted'>Product SKU</label>
                                        <input
                                            type='text'
                                            className='form-control opacity-75'
                                            id="createdBy"
                                            placeholder='Enter Product SKU'
                                        />
                                    </div> */}
            </div>

            {/* <div className='col-12 col-md-6'>
                                    <div className='mb-3'>
                                        <label htmlFor="createdBy" className='form-label text-muted'>Tag</label>
                                        <input
                                            type='text'
                                            className='form-control opacity-75'
                                            id="createdBy"
                                            placeholder='Enter Tag'
                                        />
                                    </div>
                                    <div className='mb-3'>
                                        <label htmlFor="createdBy" className='form-label text-muted'>Low stock alert threshold</label>
                                        <input
                                            type='text'
                                            className='form-control opacity-75'
                                            id="createdBy"
                                            placeholder='Enter Low stock'
                                        />
                                    </div>
                                    <div className='mb-3'>
                                        <label htmlFor="createdBy" className='form-label text-muted'>Related Products</label>
                                        <input
                                            type='text'
                                            className='form-control opacity-75'
                                            id="createdBy"
                                            placeholder='Enter Related Products'
                                        />
                                    </div>
                                </div> */}
            <div className='text-end'>

              <Button variant="outlined" color="error"> Cancel </Button>&nbsp;

              <Button type='submit' variant="contained" color="success">Update </Button>
            </div>

          </div>
        </form>
      </Dialog>

      <Dialog header="Confirm View" visible={viewstockconfirmmodal} position="top" style={{ width: '60vw' }} onHide={() => { if (!viewstockconfirmmodal) return; setViewstockconfirmmodal(false); }}>
        {viewrowId && (
          <div className='row'>
            <div className='col'>
              <p><strong>Product :</strong>   {viewrowId?.translations?.en?.product_name}</p>
              <p><strong>SKU :</strong> {viewrowId?.pro_sku}</p>
              <p><strong>Stock :</strong> {viewrowId.stock}</p>
            </div>
            <div className='col'>
              {/* <p><strong>Unit:</strong></p> */}
              <p><strong>Low Stock Alert :</strong> {viewrowId?.low_stk_alert}</p>
              {/* <p><strong>Last Update :</strong> {viewrowId?.updated_at}</p> */}
            </div>

          </div>
        )}

      </Dialog>
    </>
  )
}

export default Stock