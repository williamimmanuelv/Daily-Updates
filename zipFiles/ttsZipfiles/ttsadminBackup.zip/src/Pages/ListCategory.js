import React, { useEffect, useState } from 'react'
import imge1 from "../../Assets/Frame 21.png"
import imge2 from "../../Assets/Frame 17.png"
import image3 from "../../Assets/Frame 18.png"
import image4 from "../../Assets/Frame 19.png"
import image5 from "../../Assets/Frame 20.png"
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { IoSearchOutline } from "react-icons/io5";
import { FiPlus } from "react-icons/fi";

// import { DataTable } from 'primereact/datatable';
// import { Column } from 'primereact/column';
// import { InputSwitch } from 'primereact/inputswitch';
// import { ProductService } from './service/ProductService';

import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import axiosInstance from '../../utils/axiosinstance'
import { img_path } from '../../Api/BaseUrl'
import { SearchData } from '../../utils/Search'
import Toast from '../../utils/Toast'
import customStyle from '../../utils/Customstyle'


const ListCategory = () => {


  const navigate = useNavigate();
  const [fetchcategory, setFetchcategory] = useState([])
  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false);
  const [viewconfirmmodal, setViewconfirmmodal] = useState(false);
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [viewCategory, setViewCategory] = useState(null);
  
  const [editcategoryrowId, setEditcategoryrowId] = useState(null);


  const fetch = async () => {
    try {
      const response = await axiosInstance.get(`/categories`,);
      setFetchcategory(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetch()
  }, [])



  // const [selectedCountry, setSelectedCountry] = useState(null);
  // const countries = [
  //   { name: 'Vegetables', code: 'AU' },
  //   { name: 'Grocery', code: 'BR' },
  //   { name: 'Vessel', code: 'CN' },
  //   { name: 'Garments', code: 'EG' },
  //   { name: 'Rose Gold', code: 'FR' },
  //   { name: 'Germany', code: 'DE' },
  //   { name: 'India', code: 'IN' },
  //   { name: 'Japan', code: 'JP' },
  //   { name: 'Spain', code: 'ES' },
  //   { name: 'United States', code: 'US' }
  // ];

  // const selectedCountryTemplate = (option, props) => {
  //   if (option) {
  //     return (
  //       <div className="flex align-items-center">
  //         <img alt={option.name} src="https://primefaces.org/cdn/primereact/images/flag/flag_placeholder.png" className={`mr-2 flag flag-${option.code.toLowerCase()}`} style={{ width: '18px' }} />
  //         <div>{option.name}</div>
  //       </div>
  //     );
  //   }

  //   return <span>{props.placeholder}</span>;
  // };

  // const countryOptionTemplate = (option) => {
  //   return (
  //     <div className="flex align-items-center">
  //       <img alt={option.name} src="https://primefaces.org/cdn/primereact/images/flag/flag_placeholder.png" className={`mr-2 flag flag-${option.code.toLowerCase()}`} style={{ width: '18px' }} />
  //       <div>{option.name}</div>
  //     </div>
  //   );
  // };


  //    const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [selectedRows, setSelectedRows] = useState([]);

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

const editcate = (row) => {
  navigate('/edit', { state: row });  
};
  const columns = [
    {
      name: "S.no",
       cell: (row, index) => (
    <div className="px-3 py-2"> 
      {index + 1}
    </div>
  ),
      wrap: true,
      sortable: true,
      width: "120px",
      className:""
     },
    {
      name: "Categories",
      selector: (row) => row.title,
      wrap: true,
      sortable: true,
    },
    {
      name: "Image",
      cell: (row) => (
        row.thumbnail ? (
          <img
            src={`${img_path}/categories/${row.thumbnail}`}
            alt={row.title}
            style={{ width: "100px", height: "80px", objectFit: "cover", borderRadius: "6px",marginTop:"20px" }}
          />
        ) : (
          <span className="text-muted">No image</span>
        )
      ),
      wrap: true,
      sortable: false,
    },

    {
      name: "Createby",
      selector: (row) => row.created_by,
      wrap: true,
      sortable: true,
      width: "170px",
    },
    {
      name: "ID",
      selector: (row) => row.tag_id
      ,
      wrap: true,
      sortable: true,
    },
    {
      name: "Stock",
      selector: (row) => row.stock,
      wrap: true,
      sortable: true,
    },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-3">
          <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}onClick={() =>{
           setViewCategory(row);     
           setViewconfirmmodal(true);  
             }} >
            <GrFormView size={20} color="white" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => editcate(row)}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}onClick={() => {
              setSelectedRowId(row.id);
              setDeleteconfirmmodal(true); }} >
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  // const products = [{
  //   SNo: "1",
  //   CreatedDate: "15/12/2025 ",
  //   Price: "$636",
  //   Createby: "user",
  //   ID: "FS16276	",
  //   Stock: "5566",
  //   Actions: ""
  // }]
  const handleRowClick = (row) => {

  };


  // useEffect(() => {
  //     ProductService.getProductsMini().then((data) => setProducts(data));
  // }, []);



  const handleConfirmClose = () => {
    setDeleteconfirmmodal(false);
  };


  const handleConfirmDelete = async () => {
  
    try {
      await axiosInstance.delete(`/categories/${selectedRowId}`);
           Toast({ message: "Successfully Deleted", type: "success" });

    fetch()
    } catch (error) {
      console.error("Delete error:", error);
    } finally {
      setDeleteconfirmmodal(false);
    }
  };

   const [filterText, setFilterText] = useState("");
                const searchColumns = [ 'created_by','stock','title','subcat_name','tag_id','status' ];
                const handleFilter = (event) => {
                  setFilterText(event.target.value);
                };
                const filterdata = SearchData(fetchcategory, filterText, searchColumns);

  return (
    <>
      <div className='container  '>
        {/* <h4>Category List</h4> */}


          {/* <div className="">
            <Dropdown value={selectedCountry} onChange={(e) => setSelectedCountry(e.value)} options={countries} optionLabel="name" placeholder="Select a Category"
              filter valueTemplate={selectedCountryTemplate} itemTemplate={countryOptionTemplate} className="w-full md:w-14rem "
            />
          </div> */}
       
       



      {/* <div className='container'>
        <div className='row px-lg-5 gap-4'>
            <div className='col-12 col-md-2 ms-5'>
                <div className='box_shadow p-3  rounded-5 text-center'>
                    <img src={imge1} className='img-fluid  pb-3 px-3' style={{width:"120px",height:"100px"}} />
                    <span>Vegetables</span>
                </div>

            </div>
            <div className='col-12 col-md-2'>
                 <div className='box_shadow p-3  rounded-5 text-center'>
                    <img src={imge2} className='img-fluid pb-3 px-3'style={{width:"120px",height:"100px"}} />
                    <span>Grocery</span>
                </div>

            </div>
            <div className='col-12 col-md-2'>
                 <div className='box_shadow p-3  rounded-5 text-center'>
                    <img src={image3} className='img-fluid pb-3 px-3'  style={{width:"120px",height:"100px"}}/>
                    <span>Vessel</span>
                </div>

            </div>
            <div className='col-12 col-md-2'>
                <div className='box_shadow p-3 rounded-5 text-center'>
                    <img src={image4} className='img-fluid  pb-3 px-3'style={{width:"120px",height:"100px"}} />
                    <sapn>Garments</sapn>
                </div>
            </div>
            <div className='col-12 col-md-2'>
                <div className='box_shadow p-3 rounded-5 text-center'>
                    <img src={image5} className='img-fluid  pb-3 px-3' style={{width:"120px",height:"100px"}}/>
                    <span>Rose Gold</span>
                </div>
            </div>

        </div>


    </div> */}

      {/* <div className='container'> 
         <div className="box_shadow mt-5 p-5">
           
            <DataTable value={products} selectionMode={rowClick ? null : 'checkbox'} selection={selectedProducts} onSelectionChange={(e) => setSelectedProducts(e.value)} dataKey="id" tableStyle={{ minWidth: '0rem' }}>
                <Column selectionMode="multiple" headerStyle={{ width: '3rem' }}></Column>
                <Column field="SNo" header="S.No"></Column>
                <Column field="Categories" header="Categories"></Column>

                <Column field="CreatedDate" header="Created Date"></Column>
                <Column field="Price" header="Price"></Column>
                <Column field="Createby" header="Create by"></Column>
                <Column field="ID" header="ID"></Column>
                <Column field="Stock" header="Stock"></Column>
                <Column field="Actions" header="Actions"></Column>
                </DataTable>
        </div>

    </div> */}
      <div className='mt-3 box_shadow  bg-white rounded-2'>
        <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3'>
            <h5>All Category List</h5>
           </div>
             <div className='d-flex  pt-2 pe-2'>
             <div className='text-end position-relative px-2 pt-1'>
            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
              size={18} />
            <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
          </div>
            <Link to="/create" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
            <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus  className='pb-1'/></button>
          </div></Link>
          </div>
        </div>
       

        <div className='pt-2'>
           <DataTable
            columns={columns}
            data={filterdata}
          //  selectableRows
              customStyles={customStyle}
            pagination
            onRowClicked={handleRowClick}
            fixedHeader
            persistTableHead={true}
          />
        </div>

      </div>
      </div>

      <Dialog header="Confirm Deleted" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp;

          <button
            className="btn btn-success"
            type="button"
            onClick={() => handleConfirmDelete(selectedRowId)}
          >
            Yes
          </button>
        </div>

      </Dialog>

      <Dialog header="Confirm View" visible={viewconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!viewconfirmmodal) return; setViewconfirmmodal(false); }}>
       {viewCategory && (
        <div className='row'>
          <div className='col'>
            <p>Categories :{viewCategory.title}</p>
            <p>Stock :{viewCategory.stock}</p>
         
          </div>
          <div className='col'>
            <p>Create by :{viewCategory.created_by}</p>
            <p>ID :{viewCategory.tag_id}</p>
           
          </div>

        </div>
      )}

      </Dialog>


    </>
  )
  }

export default ListCategory