import React, { useEffect, useState } from 'react'
import { Dropdown } from 'primereact/dropdown';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import './marketing.css'
import { useFormik } from 'formik';
import * as yup from "yup"
import Toast from '../../utils/Toast';
import { useLocation, useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosinstance';
import { RadioButton } from 'primereact/radiobutton';

const AutogenCpnEdit = () => {

  const navigate = useNavigate()

  const { state } = useLocation();
  const autogencoupon = state;
  console.log("autogencoupon", autogencoupon)

  useEffect(() => {
    formik.setFieldValue('min_amount', autogencoupon?.min_amount)
    formik.setFieldValue('max_amount', autogencoupon?.max_amount)
    formik.setFieldValue('min_order_value', autogencoupon?.min_order_value)
    formik.setFieldValue('validity', autogencoupon?.validity)
    formik.setFieldValue('discount_amount', autogencoupon?.discount_amount)
    formik.setFieldValue('description', autogencoupon?.description)
    formik.setFieldValue('status', autogencoupon?.status)
    formik.setFieldValue('language_code', autogencoupon?.language)

    formik.setFieldValue('id', autogencoupon?.id)
  }, [])

  const [language, setLanguage] = useState("en");

  useEffect(() => {
    if (autogencoupon?.language) {
      setLanguage(autogencoupon.language)
      formik.setFieldValue("language_code", autogencoupon.language)
    }
  }, [autogencoupon])

  const handleLanguage = (e, lang) => {
    e.preventDefault();
    formik.setFieldValue("language_code", lang);
    setLanguage(lang)
  };

  const onSubmit = async (values) => {
    try {
      const response = await axiosInstance.post(`/autocoupon/${values.id}?_method=PUT`, values, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log("response", response)
      Toast({ message: response.data.message, type: "success" });

      formik.resetForm()
      navigate('/autogeneratecoupon')

    } catch (error) {
      Toast({ message: "An unexpected error occurred.", type: "error" });
    }
  }

  // start

  const couponData = state;

  console.log("couponDataAAAA_coupon", couponData)
  const [lang_data, setLangdata] = useState()

  const [fetchCoupon, setFetchAttribute] = useState("en");

  const fetchAttributes = async () => {
    try {
      const response = await axiosInstance.get(`/autocoupon/${couponData?.id}`, {
        params: {
          lang: language,
        },
      });
      setLangdata(response.data);
      setFetchAttribute(response.data);

      console.log("response.data_auto", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchAttributes()
    console.log("lang_data", lang_data);

  }, [language])

  useEffect(() => {
    if (couponData?.language) {
      setLanguage(couponData?.language)
      formik.setFieldValue("language_code", couponData?.language)
    }
  }, [couponData])

  useEffect(() => {
    if (!fetchCoupon || !fetchCoupon.id) return;
    formik.setValues({
      max_amount: fetchCoupon?.max_amount || "",
      min_amount: fetchCoupon?.min_amount || "",
      discount_amount: fetchCoupon?.discount_amount || "",
      min_order_value: fetchCoupon?.min_order_value || "",
      validity: fetchCoupon?.validity || "",
      status: fetchCoupon?.status || "",
      language_code: fetchCoupon?.translation?.language_code ? fetchCoupon?.translation?.language_code : language,
      id: fetchCoupon?.id || "",

      description: fetchCoupon?.translation?.description,

    });


    console.log("fetchAttribute_lang", fetchCoupon?.data);

  }, [fetchCoupon]);


  // end



  const formik = useFormik(
    {
      initialValues: {
        min_amount: "",
        max_amount: "",
        discount_amount: "",
        min_order_value: "",
        validity: "",
        description: "",
        status: "",
        language_code: ""
      },
      validationSchema: yup.object().shape({
        min_amount: yup.string().required("min_amount is required!"),
        max_amount: yup.string().required("max_amount By is required"),
        discount_amount: yup.string().required("discount_amount By is required"),
        min_order_value: yup.string().required("min_order_value By is required"),
        validity: yup.string().required("validity By is required"),
        description: yup.string().required("description By is required"),
        status: yup.string().required("status is required!"),
        // language_code: yup.string().required("language_code is required!"),
      }),
      onSubmit,
    }
  )

  return (
    <>
      <div className="d-flex justify-content-start mb-3">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/autogeneratecoupon')}
        >
          ← Back
        </button>
      </div>

      <div className='box_shadow  bg-white p-4'>
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <ul className="nav nav-tabs mb-3 ms-3">
            <li className="nav-item">
              <button
                type="button"
                className={`nav-link ${language === "en" ? "active text-primary" : "text-black"}`}
                onClick={(e) => handleLanguage(e, "en")}
              >
                English
              </button>
            </li>
            <li className="nav-item">
              <button
                type="button"
                className={`nav-link ${language === "de" ? "active text-primary" : "text-black"}`}
                onClick={(e) => handleLanguage(e, "de")}
              >
                German
              </button>
            </li>
          </ul>
          {language == "en" && (
            <div className='row py-4'>
              <div className='col-12 col-md-6 col-lg-6'>

                <div className="d-flex align-items-center pb-3">
                  {/* <div className="dropdown">
                  <button
                    className="btn btn-outline-primary dropdown-toggle"
                    data-bs-toggle="dropdown"
                    type="button"
                  >
                    {formik.values.language_code === "en"
                      ? "English"
                      : formik.values.language_code === "de"
                        ? "German"
                        : "Select a language"}
                  </button>

                  <ul className="dropdown-menu">
                    <li>
                      <button
                        type="button"
                        className="dropdown-item"
                        onClick={() => formik.setFieldValue("language_code", "en")}
                      >
                        English
                      </button>
                    </li>

                    <li>
                      <button
                        type="button"
                        className="dropdown-item"
                        onClick={() => formik.setFieldValue("language_code", "de")}
                      >
                        German
                      </button>
                    </li>
                  </ul>
                  {formik.errors.language_code && formik.touched.language_code && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.language_code}
                    </p>
                  )}
                </div> */}
                </div>

                <div className='mb-3'>
                  <label htmlFor="min_amount " className='form-label text-muted'>MinAmount  </label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="min_amount"
                    name='min_amount'
                    placeholder='Enter MinAmount'
                    value={formik.values.min_amount}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.min_amount && formik.touched.min_amount && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.min_amount}
                    </p>
                  )}
                </div>
                <div className='mb-3 pt-3' >
                  <label htmlFor="max_amount " className='form-label text-muted'>MaxAmount </label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="max_amount"
                    name='max_amount'
                    placeholder='Enter MaxAmount'
                    value={formik.values.max_amount}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.max_amount && formik.touched.max_amount && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.max_amount}
                    </p>
                  )}
                </div>

                <div className='mb-3 pt-3' >
                  <label htmlFor="discount_amount " className='form-label text-muted'>DiscountAmount </label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="discount_amount"
                    name='discount_amount'
                    placeholder='Enter DiscountAmount'
                    value={formik.values.discount_amount}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.discount_amount && formik.touched.discount_amount && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.discount_amount}
                    </p>
                  )}
                </div>
              </div>
              <div className='col-12 col-md-6 col-lg-6 mt-3'>
                <div className='mb-3 ' >
                  <label htmlFor="min_order_value " className='form-label text-muted'>Min Order Value </label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="min_order_value"
                    name='min_order_value'
                    placeholder='Enter Min Order Value'
                    value={formik.values.min_order_value}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.min_order_value && formik.touched.min_order_value && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.min_order_value}
                    </p>
                  )}
                </div>

                <div className='mb-3 pt-3' >
                  <label htmlFor="validity " className='form-label text-muted'>Validity</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="validity"
                    name='validity'
                    placeholder='Enter Validity'
                    value={formik.values.validity}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.validity && formik.touched.validity && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.validity}
                    </p>
                  )}
                </div>

                <div className="mb-3">
                  <label htmlFor="description" className="form-label">
                    Description
                  </label>
                  <textarea
                    type="text"
                    name="description"
                    className="form-control"
                    placeholder="Enter description"
                    value={formik.values.description}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.description && formik.touched.description && (
                    <small className="text-danger">{formik.errors.description}</small>
                  )}
                </div>

                <div className="mb-3 pt-3 ">
                  <label className="form-label text-muted">Status</label>
                  <div className="d-flex flex-column gap-2">
                    <div className="form-check">

                      <RadioButton inputId="ingredient1" name="status" id="active" value="active" defaultChecked
                        checked={formik.values.status === "active"}
                        onChange={formik.handleChange}
                      />
                      <label className="form-check-label ms-2" htmlFor="active">Active</label>
                    </div>
                    <div className="form-check">

                      <RadioButton inputId="ingredient2" name="status" value="inactive" id="inactive"
                        checked={formik.values.status === "inactive"}
                        onChange={formik.handleChange}
                      />
                      <label className="form-check-label ms-2" htmlFor="inactive">Inactive</label>
                    </div>

                  </div>
                  {formik.errors.status && formik.touched.status && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.status}
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
          {language == "de" && (
            <div className="mb-3">
              <label htmlFor="description" className="form-label">
                Description
              </label>
              <textarea
                type="text"
                name="description"
                className="form-control"
                placeholder="Enter description"
                value={formik.values.description}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.description && formik.touched.description && (
                <small className="text-danger">{formik.errors.description}</small>
              )}
            </div>
          )}

          <div className='text-end'>
            <Button type="submit" variant="contained" color="success" >Update</Button>
          </div>
        </form>
      </div>

    </>
  )
}

export default AutogenCpnEdit