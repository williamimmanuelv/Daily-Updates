import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import Toast from '../../utils/Toast';
import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';
import { FiPlus } from "react-icons/fi";

// 
import './marketing.css'

const Coupon = () => {

  const navigate = useNavigate()
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [deleteCoupon, setDeleteCoupon] = useState(null)
  const [editCoupon, setEditCoupon] = useState(null)

  const [selectedRows, setSelectedRows] = useState([]);
  const [fetchCoupon, setFetchCoupon] = useState([])
  console.log("fetchCouponnnn", fetchCoupon)

  const fetchCoupons = async () => {
    try {
      const response = await axiosInstance.get(`/coupon`,);
      setFetchCoupon(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchCoupons()
  }, [])

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
    },
    {
      name: "Code",
      selector: (row) => row.coupon_code,

      // cell: (row) => (
      //   <div>
      //     <button className="btn btn-primary">{row.project_id}</button>
      //   </div>
      // ),
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "Discount product",
    //   selector: (row) => row.product_id_name,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Start Date",
      selector: (row) => row.start_date,
      wrap: true,
      width: "150px",
      sortable: true,
    },
    {
      name: "End Date",
      selector: (row) => row.end_date,
      wrap: true,
      sortable: true,
      width: "150px",
    },
    {
      name: "Coupon Limit ",
      selector: (row) => row.coupon_limit,
      wrap: true,
      sortable: true,
      width: "175px",
    },
    //  {
    //   name: "customerId ",
    //   selector: (row) => row.customer_id,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Validation Days",
      selector: (row) => row.validity_days,
      wrap: true,
      width: "175px",
      sortable: true,
    },
    {
      name: "Coupon Status",
      selector: (row) => row.coupon_status,
      wrap: true,
      width: "175px",
      sortable: true,
    },

    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => editCoupons(row)}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setDeleteCoupon(row.id); setDeleteconfirmmodal(true); }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  const editCoupons = (row) => {
    navigate('/couponEdit', { state: row })
  }

  const handleConfirmClsDltCpn = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmOpnDltCoupon = async () => {
    try {
      await axiosInstance.delete(`/coupon/${deleteCoupon}`)
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchCoupons()

    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });

    }
    setDeleteconfirmmodal(false)

  }
  const handleRowClick = (row) => {

  };
  const [filterText, setFilterText] = useState("");
  const searchColumns = ['coupon_code', 'discount_product', 'Createby', 'ProductName', 'coupon_limit', 'coupon_status', 'start_date', 'end_date', 'validity_days', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchCoupon, filterText, searchColumns);

  return (

    <>
      <div className='container'>


        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3'>
              <h5>All Coupon List</h5>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <Link to="/couponCreate" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div></Link>
            </div>
          </div>

          <div className='pt-2'>

            <DataTable
              columns={columns}

              data={filterdata}
              customStyles={customStyle}
              pagination
              // selectableRows
              className='couponDataTable'
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />
          </div>
        </div>
      </div>


      <Dialog header="Confirm Delete Modal" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmClsDltCpn()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmOpnDltCoupon(deleteCoupon)}>Yes </Button>
        </div>

      </Dialog>


    </>
  )
}

export default Coupon