import React, { useEffect, useState } from 'react'
import { Dropdown } from 'primereact/dropdown';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import './marketing.css'
import { useLocation, useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosinstance';
import { useFormik } from 'formik';
import Toast from '../../utils/Toast';
import * as yup from "yup"
import { TagPicker } from 'rsuite';
import { RadioButton } from 'primereact/radiobutton';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';

const CouponEdit = () => {
    const navigate = useNavigate()


    const [fetchproducts, setFetchproducts] = useState([]);
  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products`,);
      setFetchproducts(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchproduct()
  }, [])

   const { state } = useLocation();
        const CouponData = state;
        console.log("CouponDataaaaaaaaaaaa", CouponData)
    
        useEffect(() => {
            formik.setFieldValue('coupon_code', CouponData?.coupon_code)
            formik.setFieldValue('coupon_limit', CouponData?.coupon_limit)
            formik.setFieldValue('discount_amount', CouponData?.discount_amount)
            formik.setFieldValue('coupon_types', CouponData?.coupon_types)
            formik.setFieldValue('discount_product', CouponData?.discount_product)
            formik.setFieldValue('coupon_status', CouponData?.coupon_status)
            formik.setFieldValue('start_date', CouponData?.start_date)
            formik.setFieldValue('end_date', CouponData?.end_date)

           formik.setFieldValue('id', CouponData?.id)
        }, [])
     const onSubmit = async (values) => {
        try {
            const response = await axiosInstance.post(`/coupon/${values.id}?_method=PUT`, values, {
                headers: {
                    "Content-Type": "application/json",
                },
            });
            console.log("response", response)
            Toast({ message: "Successfully Updated", type: "success" });


            formik.resetForm()
            navigate('/couponmarketing')

        } catch (error) {
            Toast({ message: "An unexpected error occurred.", type: "error" });

            // console.log("Suberror", error)
        }
    }
       const formik = useFormik(
        {
            initialValues: {
                coupon_code: "",
                coupon_limit: "",
                discount_amount: "",
                coupon_types: "",
                discount_product:[],
                coupon_status:"",
                 start_date: "",
               end_date: "",
                customer_id: [],

            },
            validationSchema: yup.object().shape({
                coupon_code: yup.string().required("coupon_code is required!"),
                // customer_id: yup.string().required("customer_id is required!"),  
                coupon_limit: yup.string().required("coupon_limit By is required"),
                discount_amount: yup.string().required("discount_amount is required!"),
                coupon_types: yup.string().required("coupon_types is required!"),
                // discount_product: yup.string().required("discount_product is required!"),
                coupon_status: yup.string().required("coupon_status is required!"),
                start_date: yup.string().required("start_date is required!"),
                end_date: yup.string().required("end_date is required!"),
                }),
            onSubmit,
        }
    )

      const data = fetchproducts?.map((item) => ({
    label: item.product_name,
    value: item.id,
  }));

  return (
   <>
      <div className="d-flex justify-content-start mb-3">
    <button
        type="button"
        className="btn btn-secondary"
        onClick={() => navigate('/couponmarketing')}
    >
        ← Back
    </button>
    </div>

    <div className='box_shadow p-4'>
      <form onSubmit={formik.handleSubmit} autoComplete="off">
      <div className='row py-4'>
        <div className='col'>
               <div className="mb-3 ">
                <label className="form-label text-muted">Coupon Types</label>
                <div className="d-flex flex-column gap-2">
                  <div className="form-check">
                    {/* <input
                      className="form-check-input"
                      type="radio"
                      name="coupon_types"
                      id="free-shipping"
                      value="Free Shipping"
                      checked={formik.values.coupon_types === "Free Shipping"}
                      onChange={formik.handleChange}
                    /> */}
                                         <RadioButton inputId="ingredient1"  name="coupon_types"  value="Free Shipping"  id="free-shipping" defaultChecked
                                            checked={formik.values.coupon_types === "Free Shipping"}
                                           onChange={formik.handleChange}
                                          />
                    <label className="form-check-label ms-2" htmlFor="free-shipping">
                      New
                    </label>
                  </div>

                  <div className="form-check">
                    {/* <input
                      className="form-check-input"
                      type="radio"
                      name="coupon_types"
                      id="percentage"
                      value="Percentage"
                      checked={formik.values.coupon_types === "Percentage"}
                      onChange={formik.handleChange}
                    /> */}
                     <RadioButton inputId="ingredient2"  name="coupon_types"  value="Percentage"   id="percentage" 
                                          checked={formik.values.coupon_types === "Percentage"}
                                           onChange={formik.handleChange}
                                          />
                    <label className="form-check-label ms-2" htmlFor="percentage">
                      Existing
                    </label>
                  </div>

                  <div className="form-check">
                    {/* <input
                      className="form-check-input"
                      type="radio"
                      name="coupon_types"
                      id="fixed-amount"
                      value="Fixed Amount"
                      checked={formik.values.coupon_types === "Fixed Amount"}
                      onChange={formik.handleChange}
                    /> */}
                     <RadioButton inputId="ingredient3"  name="coupon_types" value="Fixed Amount"    id="fixed-amount"
                                          checked={formik.values.coupon_types === "Fixed Amount"}
                                           onChange={formik.handleChange}
                                          />
                    <label className="form-check-label ms-2" htmlFor="fixed-amount">
                      All
                    </label>
                  </div>
                </div>
              </div>

             {/* {formik.values.coupon_types === "Percentage" && (
                <div className="mb-3 col-md-4">
                  <label className="form-label" htmlFor="inputState">
                    Select Customer
         
                  </label>
                  <TagPicker
                    data={data}
                    style={{ width: 280 }}
                    menuStyle={{ width: 200 }}

                    value={formik.values.customer_id || []}
                    onChange={(value) => formik.setFieldValue("customer_id", value || [])}
                    onBlur={() => formik.setFieldTouched("customer_id", true)}
                    name="customer_id"

                  />

                  {formik.touched.customer_id && formik.errors.customer_id ? (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.customer_id}
                    </p>
                  ) : null}
                </div>
              )} */}
         <div className="mb-3 pt-3 ps-1">
            <label className="form-label text-muted">Coupon Status</label>
            <div className="d-flex flex-column gap-2">
              <div className="form-check">
                 <RadioButton inputId="ingredient1"  name="coupon_status" value="active"  id="active" 
                                    checked={formik.values.coupon_status === "active"}
                                     onChange={formik.handleChange}
                                   />
                <label className="form-check-label ms-2" htmlFor="active">Active</label>
              </div>
              <div className="form-check">
               <RadioButton inputId="ingredient2"  name="coupon_status" value="inactive"  id="inactive" 
                     checked={formik.values.coupon_status === "inactive"}
                      onChange={formik.handleChange}
                    />
                <label className="form-check-label ms-2" htmlFor="inactive">Inactive</label>
              </div>
             
            </div>
          </div>

      

      

        </div>
        <div className='col'>
          <div className='mb-3'>
            <label htmlFor="coupon_code" className='form-label text-muted'>Coupon Code </label>
            <input
              type='text'
              className='form-control opacity-75'
              id="coupon_code"
              name='coupon_code'
              placeholder='Enter Coupon Code'
                value={formik.values.coupon_code}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
            />
            {formik.errors.coupon_code && formik.touched.coupon_code && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.coupon_code}
                        </p>
                      )} 
          </div>

          
             <div className='mb-3 pt-3' >
            <label htmlFor="coupon_limit" className='form-label text-muted'>Coupon Limit </label>
            <input
              type='text'
              className='form-control opacity-75'
              id="coupon_limit"
              name='coupon_limit'
              placeholder='Enter Coupon Limit'
               value={formik.values.coupon_limit}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
            />
            {formik.errors.coupon_limit && formik.touched.coupon_limit && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.coupon_limit}
                        </p>
                      )} 
          </div>

             <div className='mb-3 pt-4'>
            <label htmlFor="discount_amount" className='form-label text-muted'>Discount Amount </label>
            <input
              type='text'
              className='form-control opacity-75'
              id="discount_amount"
              name='discount_amount'
              placeholder='Enter Discount Amount'
               value={formik.values.discount_amount}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
            />
            {formik.errors.discount_amount && formik.touched.discount_amount && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.discount_amount}
                        </p>
                      )} 
          </div>
           {/* <div className="mb-3 ">
                  <label className="form-label" htmlFor="discount_product">
                   Discount product
                  </label>
                  <TagPicker
                    data={data}
                    style={{ width: 280 }}
                    menuStyle={{ width: 200 }}

                    value={formik.values.discount_product || []}
                    onChange={(value) => formik.setFieldValue("discount_product", value || [])}
                    onBlur={() => formik.setFieldTouched("discount_product", true)}
                    name="discount_product"

                  />

                  {formik.touched.discount_product && formik.errors.discount_product ? (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.discount_product}
                    </p>
                  ) : null}
                </div> */}
           
        </div>

           <div className='col'>
          {/* <div className='mb-3'>
            <label htmlFor="discount_product" className='form-label text-muted'>Discount product</label>
             <select className="form-select opacity-75" id="discount_product" name="discount_product"
              value={formik.values.discount_product}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                     
                      >
                        <option>Select product</option>
                         <option>Vegetables</option>
                        <option>Grocery</option> 
                        </select>
                        {formik.errors.discount_product && formik.touched.discount_product && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.discount_product}
                        </p>
                      )} 
             
           
          </div> */}
          <div className='mb-3'>
                <label htmlFor="start_date" className='form-label text-muted'>Start date</label>
                {/* <input
                  type="datetime-local"
                  class="form-control"
                  id="start_date"
                  name="start_date"
                  value={formik.values.start_date}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                /> */}
                <DatePicker
                        id="start_date"
                        name="start_date"
                        className='w-75 form-control'
                        format="DD-MM-YYYY"
                       value={formik.values.start_date ? dayjs(formik.values.start_date,"YYYY-MM-DD") : ""}
                        onChange={(date) => {
                          formik.setFieldValue(
                            "start_date",
                            date ? date.format("YYYY-MM-DD") : ""
                          );
                        }}
                        onBlur={() => formik.setFieldTouched("start_date", true)}
                        style={{ width: "100%" }}
                      />
                {formik.errors.start_date && formik.touched.start_date && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.start_date}
                  </p>
                )}
              </div>
                 <div className='mb-3 pt-3' >
                <label htmlFor="end_date" className='form-label text-muted'>End Date </label>
                {/* <input
                  type="datetime-local"
                  class="form-control"
                  id="end_date"
                  name="end_date"
                  value={formik.values.end_date}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                /> */}
                <DatePicker
                        id="end_date"
                        name="end_date"
                        className='w-75 form-control'
                        format="DD-MM-YYYY"
                       value={formik.values.end_date ? dayjs(formik.values.end_date,"YYYY-MM-DD") : ""}
                        onChange={(date) => {
                          formik.setFieldValue(
                            "end_date",
                            date ? date.format("YYYY-MM-DD") : ""
                          );
                        }}
                        onBlur={() => formik.setFieldTouched("end_date", true)}
                        style={{ width: "100%" }}
                      />
                {formik.errors.end_date && formik.touched.end_date && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.end_date}
                  </p>
                )}
              </div>

        
          </div>
          <div className='text-end'>
           <Button  type="submit" variant="contained" color="success" >Save</Button>

          </div>

      </div>
      </form>
    </div>

   
   </>
  )
}

export default CouponEdit