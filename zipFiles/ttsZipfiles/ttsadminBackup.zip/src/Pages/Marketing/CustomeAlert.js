import React, { useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";


const CustomeAlert = () => {

       const   navigate= useNavigate()
          const [selectedProducts, setSelectedProducts] = useState(null);
          const [rowClick, setRowClick] = useState(true);

          const[deleteconfirmmodal,setDeleteconfirmmodal]=useState(false)
  
       const [selectedRows, setSelectedRows] = useState([]);
        const handleSelectedRowsChange = (state) => {
        setSelectedRows(state.selectedRows);
        };
    
           const columns = [
            {
              name: "S.no",
              selector: (row) => row.SNo,
              wrap: true,
              sortable: true,
            },
            {
              name: "Image",
              selector: (row) => row.ProductName,
    
              // cell: (row) => (
              //   <div>
              //     <button className="btn btn-primary">{row.project_id}</button>
              //   </div>
              // ),
              wrap: true,
              sortable: true,
            },
            {
              name: "Link",
              selector: (row) => row.Category,
              wrap: true,
              sortable: true,
            },
              {
              name: "Text",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
            },
            {
              name: "Status",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
            },
           
           
            // {
            //   name: "Created At",
            //   selector: (row) => row.stock,
            //   wrap: true,
            //   sortable: true,
            // },
            // {
            //   name: "Updated At",
            //   selector: (row) => row.stock,
            //   wrap: true,
            //   sortable: true,
            // },
            {
              name: "Actions",
              cell: (row) => (
                // <button className="btn btn-danger btn-sm">Delete</button>
              <div className="d-flex gap-1 me-5">
            {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}
          
            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <LuPencilLine size={16} color="red" onClick={()=>navigate('/dynamicpopupedit')} />
            </div>
          
            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <AiOutlineDelete size={18} color="red"onClick={()=>setDeleteconfirmmodal(true)} />
            </div>
          </div>
          
              ),
              wrap: true,
            },
          ];
      
             const products =[{
              SNo:"1",
            ProductName:"New100 ",
            Category:"https://codecanyon.net/item/active-ecommerce-cms/23471405?s_rank=25",
              Createby:"27-09-2025",
              ID:"27-09-2026	",
              Stock:"10",
              Actions:""
            }]
    
              const handleConfirmClose =()=>{
        setDeleteconfirmmodal(false)
      }
      const handleconfirmopen =()=>{
       
        setDeleteconfirmmodal(false)
     
      }
             const handleRowClick = (row) => {
                         
                        };
                  
                         const [filterText, setFilterText] = useState("");
                          const searchColumns = [ 'project_id','date','category_name','subcat_name','file','tracking_status','status' ];
                          const handleFilter = (event) => {
                            setFilterText(event.target.value);
                          };
  return (
  <>
  <div>
                    {/* <h4>Custome Alert List</h4> */}
                </div>
                  <div className='mb-3 text-end'>
                        <button className='btn btn-danger bg_color p-0 px-2 py-1' onClick={()=>navigate('/dynamicpopupcreate')}> + Add Custome Alert </button>
                    </div>
                <div className='mt-5 box_shadow'>
                <div className='d-flex justify-content-between py-3 px-3'>
                      <div>
                        <h5> All Custome Alert List</h5>
                    </div>
                 
                      <div className='text-end position-relative'>
                                        <IoSearchOutline    className="position-absolute top-50 end-0  translate-middle-y me-3 "
                                       size={18}/>
                                      <input text="search" className='form-control opacity-75' id='' name='' placeholder='Search Filter.........' />
                                    </div>
                    
                </div>


                <DataTable
                    columns={columns}
                    //   data={filterdata}
                    data={products}
                    selectableRows
                    //  customStyles={customStyle}
                    pagination
                 // selectableRows
                    onRowClicked={handleRowClick}
                    fixedHeader
                    persistTableHead={true}
                />
            </div>

              <Dialog header="Confirm Delete Modal" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>
            
                    <div className=" form-group">
                      <p>Do you want to delete this record?</p>
                    </div>
                    <div className="d-flex p-3 justify-content-end mt-3">
                      {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
                       <Stack direction="row" spacing={2}>
                          <Button variant="outlined" color="error"> No  </Button>&nbsp;
                          </Stack>
            
                      {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
                       <Button variant="contained" color="success">Yes </Button>
                    </div>
            
                  </Dialog>


  </>
  )
}

export default CustomeAlert