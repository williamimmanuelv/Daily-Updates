import React from 'react'

const CustomeAlertCreate = () => {
  return (
    <>
    </>
  )
}

export default CustomeAlertCreate