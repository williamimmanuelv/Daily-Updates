import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import { img_path } from '../../Api/BaseUrl';
import { InputSwitch } from 'primereact/inputswitch';
import Toast from '../../utils/Toast';
import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';


const DynamicPopup = () => {
     const   navigate= useNavigate()
          const [selectedProducts, setSelectedProducts] = useState(null);
          const [rowClick, setRowClick] = useState(true);
            const [fetchDynamics, setFetchDynamics] = useState([])
            console.log("fetchDynamicssssss",fetchDynamics)
            const[deleteDynamic,setDeleteDeleteDynamic]=useState(null)
          


          const[deleteconfirmmodal,setDeleteconfirmmodal]=useState(false)
              const [checkedRows, setCheckedRows] = useState({});

   const fetchDynamic = async () => {
    try {
      const response = await axiosInstance.get(`/dynamicpopup`,);
      setFetchDynamics(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchDynamic()
  }, [])

  
  const handleToggle = async (row) => {

    const newValue = !checkedRows[row.id];

    setCheckedRows((prev) => ({
      ...prev,
      [row.id]: newValue,
    }));

    const payload = {
      status: newValue ? "active" : "inactive",
    };

    console.log("payload", payload);

    try {
      const response = await axiosInstance.put(
        `/dynamicpopup/${row.id}?_method=PUT`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      fetchDynamic()
      console.log("Status updated:", response.data);
    } catch (error) {
      console.error("Upload error:", error);
    }
  };

  
       const [selectedRows, setSelectedRows] = useState([]);
        const handleSelectedRowsChange = (state) => {
        setSelectedRows(state.selectedRows);
        };
    
           const columns = [
            {
              name: "S.no",
              cell: (row,index) => index+1,
              wrap: true,
              sortable: true,
              width:"120px"
            },
            {
              name: "Image",
              selector: (row) => row.thumbnail,
    
             cell: (row) => (
                     row.thumbnail ? (
                       <img
                         src={`${img_path}/dynamicpopup/${row.thumbnail}`}
                         alt={row.title}
                         style={{ width: "30px", height: "30px", objectFit: "cover", borderRadius: "6px" }}
                       />
                     ) : (
                       <span className="text-muted">No image</span>
                     )
                   ),
              wrap: true,
              sortable: true,
            },
            {
              name: "Link",
              selector: (row) => row.product_page_link,
              wrap: true,
              sortable: true,
            },
            {
              name: "Status",
                cell: (row) => (
                  <div className=" flex justify-content-center">
                    <InputSwitch
                      checked={row.status === "active"}
                      onChange={() => handleToggle(row)}
                    />
                  </div>
                ),
                
              wrap: true,
              sortable: true,
            },
           
           
            // {
            //   name: "Created At",
            //   selector: (row) => row.stock,
            //   wrap: true,
            //   sortable: true,
            // },
            // {
            //   name: "Updated At",
            //   selector: (row) => row.stock,
            //   wrap: true,
            //   sortable: true,
            // },
            {
              name: "Actions",
              cell: (row) => (
                // <button className="btn btn-danger btn-sm">Delete</button>
              <div className="d-flex gap-1 me-5">
            {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}
          
            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}onClick={()=>editDynamic(row)}>
              <LuPencilLine size={16} color="red"  />
            </div>
          
            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}onClick={()=>{setDeleteDeleteDynamic(row.id);setDeleteconfirmmodal(true);}}>
              <AiOutlineDelete size={18} color="red" />
            </div>
          </div>
          
              ),
              wrap: true,
            },
          ];
      
      const editDynamic=(row)=>{
        navigate('/dynamicpopupedit',{state:row})
      }     
      const handleConfirmCloseDltDynamic =()=>{
        setDeleteconfirmmodal(false)
      }
      const handleconfirmopenDltDynamic =async()=>{
        try {
      await axiosInstance.delete(`/dynamicpopup/${deleteDynamic}`)
           Toast({ message: "Successfully Deleted", type: "success" });

       fetchDynamic()
    } catch (error) {
   Toast({ message: "Error to taken project", type: "error" });

    }
  setDeleteconfirmmodal(false)
     
      }

      
             const handleRowClick = (row) => {
                         
                        };
                  
                         const [filterText, setFilterText] = useState("");
                          const searchColumns = [ 'project_id','product_page_link','category_name','status' ];
                          const handleFilter = (event) => {
                            setFilterText(event.target.value);
                          };
                      const filterdata = SearchData(fetchDynamics, filterText, searchColumns);
                          
  return (
  <>
   <div className='container'>
        
                  
                   <div className='mt-3 box_shadow  bg-white rounded-2'>
                        <div className='d-flex justify-content-between'>
                          <div className='pt-3 px-3'>
                          <h5>All DynamicPopup List</h5>
                         </div>
                           <div className='d-flex  pt-2 pe-2'>
                           <div className='text-end position-relative px-2 pt-1'>
                          <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                            size={18} />
                          <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
                        </div>
                           <div className='mb-1 pt-1 text-end'onClick={()=>navigate('/dynamicpopupcreate')}>
                        <button className='btn btn-danger bg_color p-0 px-2 py-1' >Add +</button>
                    </div>
                        </div>
                      </div>
        
             <div className='pt-2'>
  
                 <DataTable
                    columns={columns}
                  
                    data={filterdata}
                 
                   customStyles={customStyle}
                    pagination
                 // selectableRows
                    onRowClicked={handleRowClick}
                    fixedHeader
                    persistTableHead={true}
                /> 
            </div>
            </div>
            </div>

              <Dialog header="Confirm Delete" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>
            
                    <div className=" form-group">
                      <p>Do you want to delete this record?</p>
                    </div>
                    <div className="d-flex p-3 justify-content-end mt-3">
                      {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
                       <Stack direction="row" spacing={2}>
                          <Button variant="outlined" color="error" onClick={()=>handleConfirmCloseDltDynamic()}> No  </Button>&nbsp;
                          </Stack>
            
                      {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
                       <Button variant="contained" color="success" onClick={()=>handleconfirmopenDltDynamic(deleteDynamic)}>Yes </Button>
                    </div>
            
                  </Dialog>


  </>
  )
}

export default DynamicPopup