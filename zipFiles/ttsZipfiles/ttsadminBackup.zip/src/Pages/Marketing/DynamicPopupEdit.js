import React, { useEffect, useState } from 'react'
import { Dropdown } from 'primereact/dropdown';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import './marketing.css'
import { BiCloudUpload } from "react-icons/bi";
import * as yup from "yup"
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { base_url, img_path } from '../../Api/BaseUrl';
import Toast from '../../utils/Toast';
import { useFormik } from 'formik';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';

const DynamicPopupEdit = () => {
 const navigate = useNavigate()
  const token = localStorage.getItem("tokenAdmin")

  const [serverImage, setServerImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);

  const { state } = useLocation();
  const dynamicData = state;
  console.log("dynamicDatacccccc", dynamicData)
  useEffect(() => {
    formik.setFieldValue("discount_product", dynamicData?.discount_product);
    formik.setFieldValue("product_page_link", dynamicData?.product_page_link)
    formik.setFieldValue("start_date", dynamicData?.start_date)
    formik.setFieldValue("end_date", dynamicData?.end_date)
    formik.setFieldValue("id", dynamicData?.id)
  }, [])
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImagePreview(URL.createObjectURL(file));
      formik.setFieldValue("thumbnail", file);
    } else {
      setImagePreview(null);
      formik.setFieldValue("thumbnail", null);
    }
  };
  const onSubmit = async (values) => {

    try {
      const formData = new FormData();
      formData.append("discount_product", values.discount_product);
      formData.append("product_page_link", values.product_page_link);
      formData.append("start_date", values.start_date);
      formData.append("end_date", values.end_date);


      if (values.thumbnail) {
        formData.append("thumbnail", values.thumbnail);
      }

      const response = await axios.post(`${base_url}/dynamicpopup/${values.id}?_method=PUT`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      }); Toast({ message: "Successfully Updated", type: "success" });
      console.log("Success:", response.data);

      setImagePreview(null);
      setServerImage(response.data.thumbnail);
      formik.resetForm();
      navigate('/dynamicpopup')

    } catch (error) {
      Toast({ message: "An unexpected error occurred.", type: "error" });

    }

  }

  const formik = useFormik(
    {
      initialValues: {
        discount_product: "",
        thumbnail: null,
        product_page_link: "",
        start_date: "",
        end_date: "",
        },
      validationSchema: yup.object().shape({
        discount_product: yup.string().required("discount_product is required!"),

        product_page_link: yup.string().required("product_page_link is required!"),
        start_date: yup.string().required("start_date is required!"),
        end_date: yup.string().required("end_date is required!"),

      }),
      onSubmit,
    }
  )
  return (
    <>
      <div className="d-flex justify-content-start mb-3">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/dynamicpopup')}
        >
          ← Back
        </button>
      </div>
      <div className='py-2'>
        {/* <h4>DynamicPopup Creation</h4> */}
      </div>
      <form onSubmit={formik.handleSubmit} autoComplete="off">
        <div className='box_shadow p-4'>

          <div className='row py-4'>

            <div className='col-12 col-md-6'>
              <div className='mb-3'>
                <label htmlFor="start_date" className='form-label text-muted'>Start date</label>
                {/* <input
                  type="datetime-local"
                  class="form-control"
                  id="start_date"
                  name="start_date"
                  value={formik.values.start_date}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                /> */}
                <DatePicker
                        id="start_date"
                        name="start_date"
                        className='w-75 form-control'
                        format="DD-MM-YYYY"
                       value={formik.values.start_date ? dayjs(formik.values.start_date,"YYYY-MM-DD") : ""}
                        onChange={(date) => {
                          formik.setFieldValue(
                            "start_date",
                            date ? date.format("YYYY-MM-DD") : ""
                          );
                        }}
                        onBlur={() => formik.setFieldTouched("start_date", true)}
                        style={{ width: "100%" }}
                      />
                {formik.errors.start_date && formik.touched.start_date && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.start_date}
                  </p>
                )}
              </div>
             <div className='mb-3 pt-3' >
                <label htmlFor="end_date" className='form-label text-muted'>End Date </label>
                {/* <input
                  type="datetime-local"
                  class="form-control"
                  id="end_date"
                  name="end_date"
                  value={formik.values.end_date}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                /> */}
                <DatePicker
                        id="end_date"
                        name="end_date"
                        className='w-75 form-control'
                        format="DD-MM-YYYY"
                       value={formik.values.end_date ? dayjs(formik.values.end_date,"YYYY-MM-DD") : ""}
                        onChange={(date) => {
                          formik.setFieldValue(
                            "end_date",
                            date ? date.format("YYYY-MM-DD") : ""
                          );
                        }}
                        onBlur={() => formik.setFieldTouched("end_date", true)}
                        style={{ width: "100%" }}
                      />
                {formik.errors.end_date && formik.touched.end_date && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.end_date}
                  </p>
                )}
              </div>

            </div>

            <div className='col-12 col-md-6'>
              {/* <div className='mb-3'>
                <label htmlFor="discount_product" className='form-label text-muted'>Discount product</label>
                <select className="form-select opacity-75" id="discount_product" name="discount_product"
                  value={formik.values.discount_product}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}>
                  <option>Select Creator</option>
                  <option value="Dress">Dress</option>
                  <option value="vegetable">vegetable</option>
                  <option value="Seller">Seller</option>
                </select>
                {formik.errors.discount_product && formik.touched.discount_product && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.discount_product}
                  </p>
                )}
             </div> */}
              <div className='mb-3'>
                <label htmlFor="product_page_link" className='form-label text-muted'>Product page link</label>
                <input
                  type="text"
                  class="form-control w-75"
                  id="product_page_link"
                  name="product_page_link"
                  value={formik.values.product_page_link}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.product_page_link && formik.touched.product_page_link && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.product_page_link}
                  </p>
                )}

              </div>
               </div>
            </div>
        </div>
         <div className='row mt-3 '>
          <div className="col-12 col-md-12 ">
            <div className='box_shadow pb-3 bg-white'>

              <h5 className="mb-3  ms-4 pt-3">Add Thumbnail Photo</h5>
              <hr className='' />

              <div
                className="border border-dotted  mx-auto text-center mb-3"
                style={{ maxWidth: "800px", minHeight: "200px", display: "flex", alignItems: "center", justifyContent: "center" }}
              >
                {/* Hidden input */}
                <input
                  type="file"
                  id="thumbnail-upload"
                  className="d-none"
                  accept="image/png, image/jpeg, image/gif"
                  onChange={handleImageChange}
                />

                {/* {imagePreview ? (
                                                        <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                                                          <img
                                                            // src={imagePreview}
                                                            src={`${img_path}/categories/${response.data.thumbnail}`} */}
                {imagePreview || serverImage ? (
                  <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                    <img
                      src={
                        imagePreview
                          ? imagePreview // local preview before submit
                          : `${img_path}/dynamicpopup/${serverImage}` // server image after upload
                      }
                      alt="Preview"
                      className="img-fluid rounded"
                      style={{
                        maxHeight: "200px",
                        maxWidth: "100%",
                        objectFit: "contain",
                        border: "1px solid #ccc",
                        padding: "5px",
                      }}
                    />
                  </label>
                ) : (
                  // Else show the upload icon + text
                  <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                    <BiCloudUpload size={50} className="color_icon mb-3" />
                    <h4>
                      Drop your images here, or{" "}
                      <span className="color_icon">click to browse</span>
                    </h4>
                    <p className="small text-muted">
                      1600 x 1200 (4:3) recommended. PNG, JPG and GIF files are allowed
                    </p>
                  </label>
                )}
              </div>
            </div>
          </div>
        </div>

         <div className='text-end'>
              <Button type='submit' variant="contained" color="success">Update</Button>

            </div>
      </form>
    </>
  )
}

export default DynamicPopupEdit