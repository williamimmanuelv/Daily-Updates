import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import { img_path } from '../../Api/BaseUrl';
import { InputSwitch } from 'primereact/inputswitch';
import Toast from '../../utils/Toast';
import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';
import { FiPlus } from "react-icons/fi";

// 
import './marketing.css'


const FlashDeals = () => {
  const navigate = useNavigate()
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [fetchflashDeals, setFetchflashDeals] = useState([]);
  const [checkedRows, setCheckedRows] = useState({});
  console.log("fetchflashDealssssssss", fetchflashDeals)

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [deleteFlash, setDeleteFlash] = useState(null)

  const [selectedRows, setSelectedRows] = useState([]);

  const handleToggle = async (row) => {

    const newValue = !checkedRows[row.id];

    setCheckedRows((prev) => ({
      ...prev,
      [row.id]: newValue,
    }));

    const payload = {
      status: newValue ? "active" : "inactive",
    };

    console.log("payload", payload);

    try {
      const response = await axiosInstance.put(
        `/flashdeals/${row.id}?_method=PUT`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      fetchFlash()
      console.log("Status updated:", response.data);
    } catch (error) {
      console.error("Upload error:", error);
    }
  };
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const fetchFlash = async () => {
    try {
      const response = await axiosInstance.get(`/flashdeals`,);
      setFetchflashDeals(response.data.data);
      console.log("response_data_jsnsj", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchFlash()
  }, [])

  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
      width:"110px"
    },
    // {
    //   name: "Banner",
    //   selector: (row) => row.thumbnail,
    //   cell: (row) => (
    //     row.thumbnail ? (
    //       <img
    //         src={`${img_path}/flashdeals/${row.thumbnail}`}
    //         alt={row.title}
    //         style={{ width: "100px", height: "80px", objectFit: "cover", borderRadius: "6px" }}
    //       />
    //     ) : (
    //       <span className="text-muted">No image</span>
    //     )
    //   ),
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Start Date",
      selector: (row) => row.start_date,
      wrap: true,
      sortable: true,
    },
    {
      name: "End Date",
      selector: (row) => row.end_date,
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "title",
    //   selector: (row) => row.title,
    //   wrap: true,
    //   sortable: true,
    // },

    // {
    //   name: "category",
    //   selector: (row) => row.category_name,
    //   wrap: true,
    //   sortable: true,
    // },
    { 
      name: "product",
      selector: (row) => row.product_name,
      wrap: true,
      sortable: true,
    },
    {
      name: "Validation Days",
      selector: (row) => row.validity_days,
      wrap: true,
      sortable: true,
      width: "170px",
    },
    {
      name: "Status ",
      cell: (row) => (
        <div className=" flex justify-content-center">
          <InputSwitch
            checked={row.status === "active"}
            onChange={() => handleToggle(row)}
          />
        </div>
      ),
      wrap: true,
      sortable: true,
    },

    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => editflash(row)} >
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setDeleteFlash(row.id); setDeleteconfirmmodal(true); }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  //  const products =[{
  //   SNo:"1",
  // ProductName:"New100 ",
  // Category:"$Dress",
  //   Createby:"27-09-2025",
  //   ID:"27-09-2026	",
  //   Stock:"10",
  //   Actions:""
  // }]


  const editflash = (row) => {
    console.log("response.data_row",row)
    navigate('/flashdealsedit', { state: row })
  }

  const handleConfirmCloseDltFlash = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopenDltFlash = async () => {

    try {
      await axiosInstance.delete(`/flashdeals/${deleteFlash}`)
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchFlash()
    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });
      }
       setDeleteconfirmmodal(false)
       }
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['start_date', 'end_date', 'validity_days', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchflashDeals, filterText, searchColumns);

  return (
    <>
      <div className='container'>


        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3'>
              <h5>All FlashDeals List</h5>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <Link to="/flashdealscreate" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div></Link>
            </div>
          </div>

          <div className='pt-2'>

            <DataTable
              columns={columns}

              data={filterdata}

              customStyles={customStyle}
              pagination
              // selectableRows
              className='flashDealsDataTable'
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />
          </div>
        </div>
      </div>

      <Dialog header="Confirm Deleted" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmCloseDltFlash()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmopenDltFlash(deleteFlash)}>Yes </Button>
        </div>

      </Dialog>


    </>
  )
}

export default FlashDeals