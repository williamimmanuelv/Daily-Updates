import React, { useEffect, useState } from 'react'
import { Dropdown } from 'primereact/dropdown';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import './marketing.css'
import Toast from '../../utils/Toast';
import { useFormik } from 'formik';
import { base_url, img_path } from '../../Api/BaseUrl';
import { useLocation, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { BiCloudUpload } from "react-icons/bi";
import * as yup from "yup"
import axiosInstance from '../../utils/axiosinstance';
import { RadioButton } from 'primereact/radiobutton';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';

const FlashDealsEdit = () => {
  const navigate = useNavigate()
  const [imagePreview, setImagePreview] = useState(null);
  const token = localStorage.getItem("tokenAdmin")

  const [serverImage, setServerImage] = useState(null);
  const [fetchproducts, setFetchproducts] = useState([])
  const [fetchcategory, setFetchcategory] = useState([])
  console.log("fetchcategoryyyyyy", fetchcategory)

  const [language, setLanguage] = useState("all");
  const fetch = async () => {
    try {
      const response = await axiosInstance.get(`/categories`, {
        params: {
          lang: language,
        },
      });
      setFetchcategory(response.data.data);
      console.log("response.data", response.data);
      console.log("responsedataC", response.data)

    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetch()
  }, [])

  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products`, {
        params: {
          lang: language,
        },
      });
      setFetchproducts(response.data.data);
      console.log("response_data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchproduct()
  }, [])

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImagePreview(URL.createObjectURL(file));
      formik.setFieldValue("thumbnail", file);
    } else {
      setImagePreview(null);
      formik.setFieldValue("thumbnail", null);
    }
  };
  const { state } = useLocation();
  const flashData = state;
  console.log("flashDatafffff", flashData)

  useEffect(() => {
    formik.setFieldValue("flash_deals_price", flashData?.flash_deals_price);

    // console.log("selected_category", flashData?.selected_category)

    // console.log("selected_product", flashData?.selected_product)

    formik.setFieldValue("start_date", flashData?.start_date)
    formik.setFieldValue("end_date", flashData?.end_date)
    formik.setFieldValue("status", flashData?.status)
    formik.setFieldValue("thumbnail", flashData?.thumbnail)

    formik.setFieldValue("id", flashData?.id)
    const cat = fetchcategory?.find((item) => item.title === flashData.category_name)
    console.log("sjsb", cat)
    formik.setFieldValue("selected_category", cat?.id);
    const pro = fetchproducts?.find((item) => item?.translations?.en?.product_name === flashData.product_name)
    console.log("dd", pro)

    formik.setFieldValue("selected_product", pro?.id);
  }, [fetchcategory, fetchproducts])

  const onSubmit = async (values) => {
    try {
      const formData = new FormData();
      formData.append("flash_deals_price", values.flash_deals_price);
      formData.append("selected_category", values.selected_category);
      formData.append("selected_product", values.selected_product);
      formData.append("start_date", values.start_date);
      formData.append("status", values.status);
      formData.append("end_date", values.end_date);
      if (values.thumbnail) {
        formData.append("thumbnail", values.thumbnail);
      }
      const response = await axios.post(`${base_url}/flashdeals/${values.id}?_method=PUT`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      }); Toast({ message: "Successfully Updated", type: "success" });
      console.log("Success:", response.data);

      setImagePreview(null);
      setServerImage(response.data.thumbnail);
      formik.resetForm();
      navigate('/flashdeals')
    }
    catch (error) {
      const serverMessage = error.response?.data?.message;
      Toast({
        message: serverMessage || "An unexpected error occurred.",
        type: "error",
      });
    }
  }
  const formik = useFormik(
    {
      initialValues: {
        flash_deals_price: "",
        selected_category: "",
        selected_product: "",
        start_date: "",
        end_date: "",
        status: "",
        thumbnail: null,
      },
      validationSchema: yup.object().shape({
        flash_deals_price: yup.string().required("flash_deals_price is required!"),
        selected_category: yup.string().required("selected_category By is required"),
        selected_product: yup.string().required("selected_product is required!"),
        start_date: yup.string().required("start_date is required!"),
        end_date: yup.string().required("end_date is required!"),
        status: yup.string().required("status is required!"),
      }),
      onSubmit,
    }
  )
  return (
    <>
      <div className="d-flex justify-content-start mb-3">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/flashdeals')}
        >
          ← Back
        </button>
      </div>
      <div className='py-4'>
        {/* <h4>Coupons Creation</h4> */}
      </div>
      <form onSubmit={formik.handleSubmit} autoComplete="off">
        <div className='box_shadow p-4'>
          <div className='row py-4'>
            <div className='col'>
              <div className="mb-3 pt-3 ps-5">
                <label className="form-label text-muted">Deal  Status</label>
                <div className="d-flex flex-column gap-2">
                  <div className="form-check">
                    {/* <input className="form-check-input" type="radio" name="status" id="status" defaultChecked
                          value="active"
                          checked={formik.values.status === "active"}
                          onChange={formik.handleChange} /> */}
                    <RadioButton inputId="ingredient1" name="status" value="active" id="status"
                      checked={formik.values.status === "active"}
                      onChange={formik.handleChange}
                    />
                    <label className="form-check-label ms-2" htmlFor="status">Active</label>
                  </div>
                  <div className="form-check">
                    {/* <input className="form-check-input" type="radio" name="status" id="status"
                          value="Inactive"
                          checked={formik.values.status === "Inactive"}
                          onChange={formik.handleChange} /> */}
                    <RadioButton inputId="ingredient2" name="status" value="Inactive" id="status"
                      checked={formik.values.status === "Inactive"}
                      onChange={formik.handleChange}
                    />
                    <label className="form-check-label ms-2" htmlFor="inactive">Inactive</label>
                  </div>
                  {/* <div className="form-check">
                        <input className="form-check-input" type="radio" name="status" id="status"
                          value="Future"
                          checked={formik.values.status === "Future"}
                          onChange={formik.handleChange} />
                        <label className="form-check-label ms-2" htmlFor="future">Future Plan</label>
                      </div>
                      {formik.errors.status && formik.touched.status && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.status}
                        </p>
                      )} */}
                </div>
              </div>
            </div>

            <div className='col'>
              <div className='mb-3'>
                <label htmlFor="start_date" className='form-label text-muted'>Start date</label>
                {/* <input
                      type="datetime-local"
                      class="form-control"
                      id="start_date"
                      name="start_date"
                      value={formik.values.start_date}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    /> */}
                <DatePicker
                  id="start_date"
                  name="start_date"
                  className='w-75 form-control'
                  format="DD-MM-YYYY"
                  value={formik.values.start_date ? dayjs(formik.values.start_date, "YYYY-MM-DD") : ""}
                  onChange={(date) => {
                    formik.setFieldValue(
                      "start_date",
                      date ? date.format("YYYY-MM-DD") : ""
                    );
                  }}
                  onBlur={() => formik.setFieldTouched("start_date", true)}
                  style={{ width: "100%" }}
                />
                {formik.errors.start_date && formik.touched.start_date && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.start_date}
                  </p>
                )}
              </div>
              <div className='mb-3 pt-3' >
                <label htmlFor="end_date" className='form-label text-muted'>End Date </label>
                {/* <input
                      type="datetime-local"
                      class="form-control"
                      id="end_date"
                      name="end_date"
                      value={formik.values.end_date}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    /> */}
                <DatePicker
                  id="end_date"
                  name="end_date"
                  className='w-75 form-control'
                  format="DD-MM-YYYY"
                  value={formik.values.end_date ? dayjs(formik.values.end_date, "YYYY-MM-DD") : ""}
                  onChange={(date) => {
                    formik.setFieldValue(
                      "end_date",
                      date ? date.format("YYYY-MM-DD") : ""
                    );
                  }}
                  onBlur={() => formik.setFieldTouched("end_date", true)}
                  style={{ width: "100%" }}
                />
                {formik.errors.end_date && formik.touched.end_date && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.end_date}
                  </p>
                )}
              </div>
              <label htmlFor="flash_deals_price" className='form-label text-muted'>Flash Deals Price</label>
              <input
                type='text'
                className='form-control opacity-75'
                id="flash_deals_price"
                name='flash_deals_price'
                placeholder='Enter Flash Deals Price'
                value={formik.values.flash_deals_price}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
              />
              {formik.errors.flash_deals_price && formik.touched.flash_deals_price && (
                <p style={{ color: "red", fontSize: "12px" }}>
                  {formik.errors.flash_deals_price}
                </p>
              )}
            </div>
            <div className='col'>
              <div className='mb-3'>
                <label htmlFor="selected_category" className='form-label text-muted'>Select category</label>
                <select className="form-select opacity-75" id="selected_category" name="selected_category"
                  value={formik.values.selected_category}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}>
                  <option value="">Select Creator</option>
                  {fetchcategory?.length > 0 ? (
                    fetchcategory?.map((item,index) => (
                      <option key={index} value={item.id} >{item.title} </option>
                    ))
                  ) : (<option value="">No data</option>)}
                </select>
                {formik.errors.selected_category && formik.touched.selected_category && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.selected_category}
                  </p>
                )}
              </div>
              <div className='mb-3'>
                <label htmlFor="selected_product" className='form-label text-muted'>Selet product</label>
                <select className="form-select opacity-75" id="selected_product" name="selected_product"
                  value={formik.values.selected_product}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                >
                  <option>Select Creator</option>
                  {fetchproducts
                    ?.filter((item) => item.pro_category == formik.values.selected_category)
                    ?.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item?.translations?.en?.product_name}
                      </option>
                    ))}
                  {/* <option>Select Creator</option>
                  {fetchproducts
                    ?.filter((item) => item.pro_category === formik.values.selected_category)
                    ?.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.product_name}
                      </option>
                    ))} */}
                </select>
                {formik.errors.selected_product && formik.touched.selected_product && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.selected_product}
                  </p>
                )}

              </div>
            </div>
          </div>
        </div>

        {/* <div className='row py-4 mb-3'>
    
            <div className="col-12 col-md-12 ">
                <div className='box_shadow  bg-white'>
    
                  <h5 className=" mb-3  ms-4 pt-3">Add Thumbnail Photo</h5>
                  <hr className='' />
    
                  <div
                    className="border border-dotted  mx-auto text-center "
                    style={{ maxWidth: "800px", minHeight: "200px", display: "flex", alignItems: "center", justifyContent: "center" }}
                  >
                    <input
                      type="file"
                      id="thumbnail-upload"
                      className="d-none"
                      accept="image/png, image/jpeg, image/gif"
                      onChange={handleImageChange}
                    />
                     {imagePreview || serverImage ? (
                      <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                        <img
                          src={
                            imagePreview
                              ? imagePreview 
                              : `${img_path}/flashdeals/${serverImage}`
                          }
                          alt="Preview"
                          className="img-fluid rounded"
                          style={{
                            maxHeight: "200px",
                            maxWidth: "100%",
                            objectFit: "contain",
                            border: "1px solid #ccc",
                            padding: "5px",
                          }}
                        />
                      </label>
                    ) : (
                   
                      <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                        <BiCloudUpload size={50} className="color_icon mb-3" />
                        <h4>
                          Drop your images here, or{" "}
                          <span className="color_icon">click to browse</span>
                        </h4>
                        <p className="small text-muted">
                          1600 x 1200 (4:3) recommended. PNG, JPG and GIF files are allowed
                        </p>
                      </label>
                    )}
                  </div>
                </div>
    
              </div>
            </div> */}
        <div className='text-end'>
          <Button type='submit' variant="contained" color="success">Update </Button>
        </div>

      </form>
    </>
  )
}

export default FlashDealsEdit