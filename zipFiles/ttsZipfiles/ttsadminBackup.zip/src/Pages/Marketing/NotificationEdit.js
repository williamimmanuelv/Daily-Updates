import React, { useEffect, useState } from 'react'
import { Editor } from "primereact/editor";
import * as yup from "yup"
import { useFormik } from 'formik';
import axiosInstance from '../../utils/axiosinstance';
import Toast from '../../utils/Toast';
import { useLocation, useNavigate } from 'react-router-dom';
import Button from '@mui/material/Button';
import { img_path } from '../../Api/BaseUrl';

const NotificationEdit = () => {
  const [text, setText] = useState('');
  const [previewImage, setPreviewImage] = useState(null);
  const navigate = useNavigate()
  const { state } = useLocation()
  const notificationData = state;
  console.log("notificationData", notificationData)


  useEffect(() => {
    formik.setFieldValue("title", notificationData?.title);
    formik.setFieldValue("notification_type", notificationData?.notification_type)
    formik.setFieldValue("description", notificationData?.description)
    // formik.setFieldValue("image",notificationData?.image)
    formik.setFieldValue("image", notificationData.image || "");
    setPreviewImage(`${img_path}/notifications/${notificationData.image}`);
    formik.setFieldValue("old_image", notificationData.image || "");
    formik.setFieldValue("id", notificationData.id || "");

  }, [])

  const onSubmit = async (values) => {
    try {
      const formData = new FormData();
      formData.append("title", values.title);
      formData.append("notification_type", values.notification_type);
      formData.append("description", values.description);

      if (values.image) {
        formData.append("image", values.image);
      }

      const response = await axiosInstance.post(`/notification/${values.id}?_method=PUT`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      console.log("response", response);
      Toast({ message: "Successfully Updated", type: "success" });

      formik.resetForm();
      navigate("/notification");
      setPreviewImage(null)
    } catch (error) {
      Toast({ message: "An unexpected error occurred.", type: "error" });
      console.error("Upload error:", error);
    }
  };


  const formik = useFormik(
    {
      initialValues: {
        image: "",
        title: "",
        notification_type: "",
        description: "",

      },
      validationSchema: yup.object().shape({
        // image: yup.string().required("image is required!"),
        title: yup.string().required("title By is required"),
        notification_type: yup.string().required("notification_type is required!"),
        description: yup.string().required("description is required!"),
      }),
      onSubmit,
    }
  )

  return (
    <>
      <div className="d-flex justify-content-start mb-3">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/notification')}
        >
          ← Back
        </button>
      </div>
      <div className='box_shadow p-4'>
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className='row py-4'>

            <div className='col'>
              <div className='mb-3'>
                <label htmlFor="title" className='form-label text-muted'>Title</label>
                <input
                  type='text'
                  className='form-control opacity-75'
                  id="title"
                  name='title'
                  placeholder='Enter the Title'
                  value={formik.values.title}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.title && formik.touched.title && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.title}
                  </p>
                )}
              </div>

              {/* <div className="mb-3">
                <label htmlFor="image" className="form-label text-muted">Image Upload</label>
                <input
                  type="file"
                  className="form-control opacity-75"
                  id="image"
                  name="image"
                  accept="image/*"

                  onChange={(event) => {
                    formik.setFieldValue("image", event.currentTarget.files[0]);
                  }}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.image && formik.touched.image && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.image}
                  </p>
                )}
              </div> */}
              {previewImage && (
                <div className="mb-2">
                  <img
                    src={previewImage}
                    alt="preview"
                    style={{
                      width: "120px",
                      height: "90px",
                      objectFit: "cover",
                      borderRadius: "6px",
                    }}
                  />
                </div>
              )}

              <input
                type="file"
                className="form-control w-50"
                id="image"
                name="image"
                accept="image/*"
                onChange={(event) => {
                  const file = event.currentTarget.files[0];
                  formik.setFieldValue("image", file);
                  if (file) {
                    setPreviewImage(URL.createObjectURL(file));
                  }
                }}
              />
            </div>

            <div className='col'>
              <div className='mb-3'>
                <label htmlFor="notification_type" className='form-label text-muted'>Notification Type</label>
                <select className="form-select opacity-75" id="notification_type" name="notification_type" placeholder="select notification type"
                  value={formik.values.notification_type}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}>
                  <option>Select Creator</option>
                  <option>Admin</option>
                  <option>Other</option>
                  <option>Seller</option>
                </select>
                {formik.errors.notification_type && formik.touched.notification_type && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.notification_type}
                  </p>
                )}

              </div>
            </div>
            <div className='col-12'>
              <div className='mb-3'>
                {/* <label htmlFor="description" className='form-label text-muted'>Description</label>
                                                  <textarea
                                                      className="form-control "
                                                      id="description"
                                                      rows="5"
                                                      placeholder="Type description"
                                                  ></textarea> */}
                <div className="">

                  <Editor
                    value={formik.values.description}
                    onTextChange={(e) => {
                      if (e.source !== "user") return;
                      formik.setFieldValue("description", e.htmlValue);
                    }}
                    style={{ height: "320px" }}
                  />


                  {/* <Editor
                    id="description"
                    name="description"
                    value={formik.values.description}
                    onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                    onBlur={formik.handleBlur}
                    style={{ height: "320px" }}
                  /> */}
                  {formik.errors.description && formik.touched.description && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.description}
                    </p>
                  )}
                </div>
              </div>
            </div>


            <div className='text-end'>
              <Button type='submit' variant="contained" color="success">Update </Button>

            </div>

          </div>
        </form>
      </div>
    </>
  )
}

export default NotificationEdit