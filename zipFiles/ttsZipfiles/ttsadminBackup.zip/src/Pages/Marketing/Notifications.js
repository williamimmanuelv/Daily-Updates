import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import { img_path } from '../../Api/BaseUrl';
import { InputSwitch } from "primereact/inputswitch";
import Toast from '../../utils/Toast';
import { SearchData } from '../../utils/Search';
import { FiPlus } from "react-icons/fi";
import customStyle from '../../utils/Customstyle';

// 
import './marketing.css'



const Notifications = () => {
  const navigate = useNavigate()
  const [checkedRows, setCheckedRows] = useState({});
  const [deleteNotification, setDeleteNotification] = useState(null)

  const handleToggle = async (row) => {

    const newValue = !checkedRows[row.id];

    setCheckedRows((prev) => ({
      ...prev,
      [row.id]: newValue,
    }));

    const payload = {
      status: newValue ? "active" : "inactive",
    };

    console.log("payload", payload);

    try {
      const response = await axiosInstance.put(
        `/notification/${row.id}?_method=PUT`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      fetchNotification()
      console.log("Status updated:", response.data);
    } catch (error) {
      console.error("Upload error:", error);
    }
  };

  console.log("2ch", checkedRows)


  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);


  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [fetchNotifications, setFetchNotification] = useState([])
  console.log("fetchNotificationsssddd", fetchNotifications)

  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const fetchNotification = async () => {
    try {
      const response = await axiosInstance.get(`/notification`,);
      setFetchNotification(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchNotification()
  }, [])

  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
    },
    {
      name: "Image",
      // selector: (row) => row.ProductName,

      cell: (row) => (
        row.image ? (
          <img
            src={`${img_path}/notifications/${row.image}`}
            alt={row.title}
            style={{ width: "30px", height: "30px", objectFit: "cover", borderRadius: "6px" }}
          />
        ) : (
          <span className="text-muted">No image</span>
        )
      ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Title",
      selector: (row) => row.title,
      wrap: true,
      sortable: true,
    },
    {
      name: "Notification Type",
      selector: (row) => row.notification_type,
      wrap: true,
      sortable: true,
    },

    // {
    //   name: "Status",
    //   cell: (row) => (
    //     <div className="card flex justify-content-center">
    //       <InputSwitch
    //         checked={checkedRows[row.id] || false}
    //         onChange={() => handleToggle(row)}
    //       />
    //     </div>
    //   ),
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Status",
      cell: (row) => (
        <div className=" flex justify-content-center">
          <InputSwitch
            checked={row.status === "active"}
            onChange={() => handleToggle(row)}
          />
        </div>
      ),
      wrap: true,
      sortable: true,
    },




    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => editnote(row)} >
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setDeleteNotification(row.id); setDeleteconfirmmodal(true); }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  //  const products =[{
  //   SNo:"1",
  // ProductName:"New100 ",
  // Category:"https://codecanyon.net/item/active-ecommerce-cms/23471405?s_rank=25",
  //   Createby:"27-09-2025",
  //   ID:"27-09-2026	",
  //   Stock:"10",
  //   Actions:""
  // }]

  const editnote = (row) => {
    navigate('/NotificationEdit', { state: row })
  }

  const handleConfirmClosenotify = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopennotify = async () => {
    try {
      await axiosInstance.delete(`/notification/${deleteNotification}`)
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchNotification()
    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });

      // console.log("error", error)
    }
    setDeleteconfirmmodal(false)

  }
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['title', 'notification_type', 'category_name', 'subcat_name', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchNotifications, filterText, searchColumns);

  return (
    <>
      <div className='container'>


        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3'>
              <h5>All Notifications List</h5>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <Link to="/notificationcreation" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div></Link>
            </div>
          </div>

          <div className='pt-2'>
            <DataTable
              columns={columns}

              data={filterdata}

              customStyles={customStyle}
              pagination
              // selectableRows
              className='notificationsDataTable'
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />
          </div>
        </div>
      </div>

      <Dialog header="Confirm Delete Modal" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmClosenotify()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmopennotify(deleteNotification)}>Yes </Button>
        </div>

      </Dialog>


    </>
  )
}

export default Notifications