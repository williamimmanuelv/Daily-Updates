import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import { Editor } from "primereact/editor";
import { useFormik } from 'formik';
import * as yup from "yup"
import Toast from '../../utils/Toast';
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';

const NotesInformation = () => {
    const [text, setText] = useState('');

    const navigate = useNavigate()

    const [selectedProducts, setSelectedProducts] = useState(null);
    const [rowClick, setRowClick] = useState(true);

    const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
    const [editmodalpolice, setEditmodalpolice] = useState(false)
    const [createmodalpolice, setCreatemodalpolice] = useState(false)

    const [deleteRow, setDeleteRow] = useState(null)

    const [selectedRows, setSelectedRows] = useState([]);
    const [fetchNote, setFetchNote] = useState([])
    console.log("fetchNoteeeeeeeeee", fetchNote)

    const handleSelectedRowsChange = (state) => {
        setSelectedRows(state.selectedRows);
    };

    const fetchNotes = async () => {
        try {
            const response = await axiosInstance.get(`/notes`,);
            setFetchNote(response.data);
            console.log("response.data", response.data)
        } catch (error) {
            console.error("Error fetching data", error);
        }

    };
    useEffect(() => {
        fetchNotes()
    }, [])

    const columns = [
        {
            name: "S.no",
            cell: (row, index) => index + 1,
            wrap: true,
            sortable: true,
            width:"140px"
        },
        {
            name: "Notes",
            // selector: (row) => row.description,
            cell: (row) => (
                <div>
                    {(row.description || "").replace(/<[^>]+>/g, '')}
                </div>
            ),
            wrap: true,
            sortable: true,
        },
        // cell: (row) => (
        //   <div>
        //     <button className="btn btn-primary">{row.project_id}</button>
        //   </div>
        // ),
             {
            name: "Date",
            selector: (row) => row.date,
            wrap: true,
            sortable: true,
        },
        // {
        //   name: "Updated At",
        //   selector: (row) => row.stock,
        //   wrap: true,
        //   sortable: true,
        // },
        {
            name: "Actions",
            cell: (row) => (
                // <button className="btn btn-danger btn-sm">Delete</button>
                <div className="d-flex gap-1 me-5">
                    {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}

                    <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => handleEdit(row)}>
                        <LuPencilLine size={16} color="red" />
                    </div>

                    <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setDeleteRow(row.id); setDeleteconfirmmodal(true); }}>
                        <AiOutlineDelete size={18} color="red" />
                    </div>
                </div>

            ),
            wrap: true,
        },
    ];


    const handleConfirmCloseDltNote = () => {
        setDeleteconfirmmodal(false)
    }
    const handleconfirmopenDltNote = async () => {
        try {
            await axiosInstance.delete(`/notes/${deleteRow}`)
            Toast({ message: "Successfully Deleted", type: "success" });

            fetchNotes()
        } catch (error) {
            Toast({ message: "Error to taken project", type: "error" });

            // console.log("error", error)
        }
        setDeleteconfirmmodal(false)

    }
    const handleRowClick = (row) => {

    };


    const handleEdit = (row) => {
        formik1.setValues({
            date: row.date,
            description: row.description,

            id: row.id,
        });
        setEditmodalpolice(true);
    };


    const onSubmitEditnote = async (values) => {

        try {
            const response = await axiosInstance.post(`/notes/${values.id}?_method=PUT`, values, {
                headers: {
                    "Content-Type": "application/json",
                },
            });
            console.log("response", response)
            Toast({ message: "Successfully Updated", type: "success" });


            formik1.resetForm()
            fetchNotes()
            setEditmodalpolice(false)

        } catch (error) {
            Toast({ message: "Error to taken project", type: "error" });

            // console.log("Suberror", error)
        }

    }
           const formik1 = useFormik(
        {
            initialValues: {
                date: "",

                description: "",
            },
            validationSchema: yup.object().shape({
                date: yup.string().required("date is required!"),

                description: yup.string().required("description is required!"),
            }),
            onSubmit: onSubmitEditnote,
        }
    )
         const onSubmit = async (values) => {
        try {
            const response = await axiosInstance.post(`/notes`, values, {
                headers: {
                    "Content-Type": "application/json",
                },
            });
            console.log("response", response)
            Toast({ message: "Successfully Created", type: "success" });
            formik.resetForm()
            setCreatemodalpolice(false)
            // navigate('/listAttribute')

            fetchNotes()

        } catch (error) {
            Toast({ message: "An unexpected error occurred.", type: "error" });

            // console.log("Suberror", error)
        }
    }
           const formik = useFormik(
        {
            initialValues: {
                date: "",

                description: "",
            },
            validationSchema: yup.object().shape({
                date: yup.string().required("date is required!"),

                description: yup.string().required("description is required!"),
            }),
            onSubmit,
        }
    )

    const [filterText, setFilterText] = useState("");
    const searchColumns = ['description', 'date', 'status'];
    const handleFilter = (event) => {
        setFilterText(event.target.value);
    };
    const filterdata = SearchData(fetchNote, filterText, searchColumns);
    return (
        <>
            <div className='container'>
             <div className='mt-3 box_shadow  bg-white rounded-2'>
                    <div className='d-flex justify-content-between'>
                        <div className='pt-3 px-3'>
                            <h5>All Notes Information List</h5>
                        </div>
                        <div className='d-flex  pt-2 pe-2'>
                            <div className='text-end position-relative px-2 pt-1'>
                                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                                    size={18} />
                                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
                            </div>
                            <div className='mb-2 pt-1 text-end' onClick={() => setCreatemodalpolice(true)}>
                                <button className='btn btn-danger bg_color p-0 px-2 py-1' > + Add </button>
                            </div>
                        </div>
                    </div>

                    <div className='pt-2'>

                        <DataTable
                            columns={columns}

                            data={filterdata}
                            customStyles={customStyle}
                            pagination
                            // selectableRows
                            onRowClicked={handleRowClick}
                            fixedHeader
                            persistTableHead={true}
                        />
                    </div>
                </div>
            </div>

            <Dialog header="Confirm Edit" visible={editmodalpolice} position="top" style={{ width: '50vw' }} onHide={() => { if (!editmodalpolice) return; setEditmodalpolice(false); }}>

                {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
                <form onSubmit={formik1.handleSubmit} autoComplete="off">
                    <div className='row py-4'>

                        <div className='col-12 col-md-12'>
                            <div className='mb-3'>
                                <label htmlFor="date" className="form-label text-muted">Date</label>
                                <input
                                    type='date'
                                    className="form-control w-25"
                                    id="date"
                                    name='date'
                                    rows="4"
                                    placeholder="Type date"
                                    value={formik1.values.date}
                                    onChange={formik1.handleChange}
                                    onBlur={formik1.handleBlur}
                                />
                                {formik1.errors.date && formik1.touched.date && (
                                    <p style={{ color: "red", fontSize: "12px" }}>
                                        {formik1.errors.date}
                                    </p>
                                )}
                            </div>
                            <div className='mb-3 '>
                                   <Editor
                                    id="description"
                                    name="description"
                                    value={formik1.values.description}
                                    onTextChange={(e) => formik1.setFieldValue("description", e.htmlValue)}
                                    onBlur={formik1.handleBlur}
                                    style={{ height: "320px" }}
                                />
                                {formik1.errors.description && formik1.touched.description && (
                                    <p style={{ color: "red", fontSize: "12px" }}>
                                        {formik1.errors.description}
                                    </p>
                                )}

                            </div>

                        </div>
                        <div className='text-end'>
                            <Button variant="outlined" color="error" onClick={() => formik1.resetForm()}> Cancel</Button>

                            <Button type='submit' variant="contained" className='mx-2' color="success">Update   </Button>&nbsp;
                        </div>

                    </div>
                </form>
            </Dialog>

            <Dialog header="Confirm Create" visible={createmodalpolice} position="top" style={{ width: '50vw' }} onHide={() => { if (!createmodalpolice) return; setCreatemodalpolice(false); }}>

                {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
                <form onSubmit={formik.handleSubmit} autoComplete="off">
                    <div className='row py-4'>

                        <div className='col-12 col-md-12'>
                            <div className='mb-3'>
                                <label htmlFor="date" className="form-label text-muted">Date</label>
                                <input
                                    type='date'
                                    className="form-control w-25"
                                    id="date"
                                    name='date'
                                    rows="4"
                                    placeholder="Type date"
                                    value={formik.values.date}
                                    onChange={formik.handleChange}
                                    onBlur={formik.handleBlur}
                                />
                                {formik.errors.date && formik.touched.date && (
                                    <p style={{ color: "red", fontSize: "12px" }}>
                                        {formik.errors.date}
                                    </p>
                                )}
                            </div>
                            <div className='mb-3 '>
                                 <Editor
                                    id="description"
                                    name="description"
                                    value={formik.values.description}
                                    onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                                    onBlur={formik.handleBlur}
                                    style={{ height: "320px" }}
                                />
                                {formik.errors.description && formik.touched.description && (
                                    <p style={{ color: "red", fontSize: "12px" }}>
                                        {formik.errors.description}
                                    </p>
                                )}

                            </div>

                        </div>
                        <div className='text-end'>
                            <Button variant="outlined" color="error" onClick={() => formik.resetForm()}> Cancel</Button>

                            <Button type='submit' variant="contained" className='mx-2' color="success">Save   </Button>&nbsp;
                        </div>

                    </div>
                </form>
            </Dialog>

            <Dialog header="Confirm Deleted " visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

                <div className=" form-group">
                    <p>Do you want to delete this record?</p>
                </div>
                <div className="d-flex p-3 justify-content-end mt-3">
                    {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
                    <Stack direction="row" spacing={2}>
                        <Button variant="outlined" color="error" onClick={() => handleConfirmCloseDltNote()}> No  </Button>&nbsp;
                    </Stack>

                    {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
                    <Button variant="contained" color="success" onClick={() => handleconfirmopenDltNote(deleteRow)}>Yes </Button>
                </div>

            </Dialog>

        </>
    )
}

export default NotesInformation