import React, { useEffect, useRef, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { IoSearchOutline } from "react-icons/io5";
import customStyle from '../../utils/Customstyle';
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
import { useReactToPrint } from "react-to-print";
import { DatePicker } from 'antd';
import dayjs from 'dayjs';

const Bucketlist = () => {
  const printRef = useRef();

  //  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const [sourceDate, setSourceDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [ordermanageBucket, setOrdermanageBucket] = useState([])
  console.log("ordermanageBucketssss", ordermanageBucket)

  const handlePrint = useReactToPrint({
    contentRef: printRef,
    documentTitle: "Order Summary Report",
    removeAfterPrint: true,
  });


  const [isChange, setIsChange] = useState(false)
  const handleCancelFilter = async () => {
    setSourceDate(null)
    setEndDate(null)
    setIsChange(true)
  }

  useEffect(() => {
    if (isChange) {

      fetchBucketlist()
      setIsChange(false)

    }
  }, [sourceDate, endDate, isChange])

  const fetchBucketlist = async () => {
    try {
      const response = await axiosInstance.get(`/orders/stock-shortage`, {
        params: {
          start_date: sourceDate,
          end_date: endDate,
        }
      });
      setOrdermanageBucket(response?.data?.data);
      console.log("response_count", response.data?.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchBucketlist()
  }, [])



  // const handleFilterdate = () => {
  // if (!sourceDate) {
  //   setOrdermanageBucket(ordermanageBucket); // no filter
  //   return;
  // }

  // const filtered = ordermanageBucket.filter(item => 
  //   item.created_at.startsWith(sourceDate)
  // );

  // setOrdermanageBucket(filtered);
  // };


  const columns = [
    {
      name: "Product",
      selector: (row) => row.product_name,
      wrap: true,
      sortable: true,
      // width: "270px",
    },

    {
      name: "ordered Qty",
      selector: (row) => row.ordered_qty,
      wrap: true,
      sortable: true,
      // width: "270px",
    },
    {
      name: "Available Stock",
      selector: (row) => row.available_qty,
      wrap: true,
      sortable: true,
      // width: "270px",
    },
    {
      name: "Shortage",
      selector: (row) => row.shortage,
      wrap: true,
      sortable: true,
      // width: "270px",
    },


  ];

  const products = [{
    SNo: "1",
    CreatedDate: "15/12/2025 ",
    Price: "$636",
    Createby: "user",
    ID: "FS16276	",
    Stock: "5566",
    Actions: ""
  }]
  const handleRowClick = (row) => {
  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'date', 'available_qty', 'ordered_qty', 'product_name', 'shortage', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(ordermanageBucket, filterText, searchColumns);
  return (
    <>
      <div className='container'>
        {/* <h5>Bucket list</h5> */}
        <div className='row'>

          {/* <div className='col-12 col-md-2 pt-4'>
            <div className='shadow p-1 rounded-4 text-muted text-center'>
              <h6 className='pt-1'>Bucket  Orders</h6>
              <h5>1250</h5>
            </div>
          </div> */}
          <div className='col-12 col-md-2'>
            <label className="form-label fs-5 fw-semibold">Start Date</label>
            {/* <input
              type="date"
              className="form-control"
              name="start_date"
              id='start_date'
              value={sourceDate}
              onChange={(e) => setSourceDate(e.target.value)}
            /> */}
            <DatePicker
              format="DD-MM-YYYY"
              value={sourceDate ? dayjs(sourceDate, "YYYY-MM-DD") : null}
              onChange={(date) => {
                setSourceDate(date ? date.format("YYYY-MM-DD") : null);
              }}
              style={{ width: "100%" }}
            />
          </div>
          <div className='col-12 col-md-2'>
            <label className="form-label fs-5 fw-semibold">End Date </label>
            {/* <input
              type="date"
              className="form-control"
              name="end_date"
              id='end_date'
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            /> */}
            <DatePicker
              format="DD-MM-YYYY"
              value={endDate ? dayjs(endDate, "YYYY-MM-DD") : null}
              onChange={(date) => {
                setEndDate(date ? date.format("YYYY-MM-DD") : null);
              }}
              style={{ width: "100%" }}
            />
          </div>

          {/* <div className='col-12 col-md-2 mt-4'>
            <button type='button' className='btn btn-secondary mt-4 ' onClick={fetchBucketlist}>Filter</button>
          </div> */}

          <div className="col-12 col-md-4 d-flex align-items-end">
            <button type='button' className='btn btn-outline-secondary mx-3' onClick={handleCancelFilter}
              style={{ height: "fit-content", padding: "3px 22px" }}
            >Clear</button>

            <button
              type="button"
              className="btn btn-outline-secondary mx-3"
              onClick={fetchBucketlist}
              style={{ height: "fit-content", padding: "3px 22px" }}
            >
              Filter
            </button>
          </div>

          <div className='col-12 col-md-4 text-end'>
            <button className='btn btn-primary'
            style={{marginTop: "30px"}}
            onClick={handlePrint}>Print</button>
          </div>
        </div>
      </div>

      <div className='mt-3'>
        <div className='container'>
          <div className='mt-3 box_shadow'>
            <div className='d-flex justify-content-between py-3 px-3'>
              <div className='d-flex'>
                <h5>All Bucket Order List</h5>
                {/* <button type="button" class="btn btn-outline-secondary  small py-0 mx-2 count_box">{ordermanageBucket.length}</button> */}
              </div>
              <div className='text-end position-relative'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' name='' onChange={handleFilter} placeholder='Search Filter.........' />
              </div>
            </div>
            <div ref={printRef} id="print-area">
              <DataTable
                columns={columns}

                data={filterdata}
                customStyles={customStyle}
                pagination
                // selectableRows
                onRowClicked={handleRowClick}
                fixedHeader
                persistTableHead={true}
              />
            </div>
          </div>
        </div>
      </div>

    </>
  )
}

export default Bucketlist