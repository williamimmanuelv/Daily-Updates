import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { IoSearchOutline } from "react-icons/io5";
import { Dialog } from 'primereact/dialog';
import customStyle from '../../utils/Customstyle';
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
// 
import { InputText } from 'primereact/inputtext';
import { DatePicker, Dropdown, Space } from 'antd';
import dayjs from 'dayjs';
import { Dropdown as PrimeDropdown } from 'primereact/dropdown';

import "./cancel.css"


const CancelledOrder = () => {
  //  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [manageconfirmmodal, setManageconfirmmodal] = useState(false)


  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const [manageViewconfirmmodal, setManageViewconfirmmodal] = useState(false)
  const [viewuser, setViewuser] = useState(null);
  const [viewDelivery, setViewDelivery] = useState(null);
  const [deliveryViewconfirmmodal, setDeliveryViewconfirmmodal] = useState(false)

  const [ordermanagecancel, setOrdermanagecancel] = useState([])

  // 

  const [orderId, setOrderId] = useState("");
  const [paymentId, setPaymentId] = useState("");
  const [status, setStatus] = useState("");
  const [date, setDate] = useState(null);
  const [todate, setTodate] = useState(null);

  const fetchorderCancelled = async () => {
    try {
      // const encoded = encodeURIComponent(status); 
      const response = await axiosInstance.get(`/orders/pickup/cancelled`);

      setOrdermanagecancel(response.data.orders);
      console.log("Status Data:", response.data.orders);

    } catch (error) {
      console.error("Error fetching status:", error);
    }
  };

  useEffect(() => {
    fetchorderCancelled()
  }, [])

  const columns = [
    {
      name: "Order ID",
      selector: (row) => row.order_no,
      wrap: true,
      sortable: true,
    },
    {
      name: "Pickup Date",
      selector: (row) => row.pickup_date,
      wrap: true,
      sortable: true,
    },
    {
      name: "transaction Id",
      selector: (row) => row.transaction_id,
      wrap: true,
      sortable: true,
    },

    {
      name: "Total",
      selector: (row) => row.total_amount,
      wrap: true,
      sortable: true,
    },
    {
      name: "Payment Status",
      selector: (row) => row.payment_status,
      wrap: true,
      sortable: true,
    },
    {
      name: "Tax Amount",
      selector: (row) => row.tax_amount,
      wrap: true,
      sortable: true,
    },
    {
      name: "Delivery Type",
      selector: (row) => row.delivery_type,
      wrap: true,
      sortable: true,
    },
    {
      name: "Payment Type",
      selector: (row) => row.payment_type,
      wrap: true,
      sortable: true,
    },

    {
      name: "Delivery Details",
      cell: (row) => (
        <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => {
          setViewDelivery(row);
          setDeliveryViewconfirmmodal(true);
        }} >
          <GrFormView size={20} color="white" />
        </div>
      ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Status",
      cell: (row) => (
        <div
          style={{
            backgroundColor: "black",
            padding: "6px",
            borderRadius: "6px",
            cursor: "pointer"
          }}
          onClick={() => {
            setViewuser(row);
            setManageViewconfirmmodal(true);

          }}
        >
          <GrFormView size={20} color="white" />
        </div>
      ),
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "Status",
    //   cell: (row) => (
    //     <Dropdown menu={{ items: getStatusItems(row) }}>
    //       <a className="dropdown-btn" onClick={(e) => e.preventDefault()}>
    //         <Space>
    //           Status
    //           <DownOutlined />
    //         </Space>
    //       </a>
    //     </Dropdown>
    //   ),
    //   wrap: true,
    // },
    // {
    //   name: "Actions",
    //   cell: (row) => (
    //     // <button className="btn btn-danger btn-sm">Delete</button>
    //     <div className="d-flex gap-3 me-5">
    //       <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
    //         <GrFormView size={20} color="white" />
    //       </div>

    //       {/* <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
    //                   <LuPencilLine size={16} color="red" />
    //                 </div>

    //                 <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
    //                   <AiOutlineDelete size={18} color="red" />
    //                 </div> */}
    //     </div>

    //   ),
    //   wrap: true,
    // },
  ];

  const products = [{
    SNo: "1",
    CreatedDate: "15/12/2025 ",
    Price: "$636",
    Createby: "user",
    ID: "FS16276	",
    Stock: "5566",
    Actions: ""
  }]
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'date', 'payment_type', 'tax_amount', 'payment_status', 'total_amount', 'total_amount', 'transaction_id', 'pickup_date', 'order_no'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const [filteredTableForCancel, setFilteredTableForCancel] = useState(null);
  const [isChange, setIsChange] = useState(false);


  const [forRedErrors, setForRedErrors] = useState(false);


  const handleCancelFilter = async () => {
    setOrderId("");
    setPaymentId("");
    setStatus("");
    setDate(null);
    setTodate(null);
    setIsChange(true);
    setForRedErrors(!forRedErrors);

  }
  useEffect(() => {
    if (isChange) {

      handleFilterAll()
      setIsChange(false)

    }
  }, [orderId, paymentId, isChange, status, date, todate])

  const handleFilterAll = async () => {
    let filtered = ordermanagecancel;
    console.log("ordertrackingFilter", ordermanagecancel);

    // const nn = ordertrackingFilter.filter(item => item.order_no=== "TTS_ORD_ONP1767618413");
    // console.log("nnnnnn",nn);



    // Filter by Order ID
    if (orderId.trim() !== "") {
      filtered = ordermanagecancel.filter(order =>
        order.order_no.toLowerCase().includes(orderId.toLowerCase())
      );
      console.log("filtereddd", filtered);
    }

    // Filter by Payment ID
    if (paymentId.trim() !== "") {
      filtered = filtered.filter(order =>
        order.payment_ref?.toLowerCase().includes(paymentId.toLowerCase())
      );
      console.log("filtereddd", filtered);
    }

    // Filter Date Range (created_at)
    if (date && todate) {
      const from = new Date(date);
      const to = new Date(todate);

      filtered = filtered.filter(order => {
        const created = new Date(order.created_at);
        return created >= from && created <= to;
      });
      console.log("filtereddd", filtered);
    }


    // Filter Status
    if (status !== "") {
      filtered = filtered.filter(order =>
        order.status.toLowerCase() === status.toLowerCase()
      );
      console.log("filtereddd", filtered);
    }

    // await setFilteredOrders(filtered);
    await setFilteredTableForCancel(filtered);
    console.log("filtered", filtered);


    if (filteredTableForCancel === null) {
      setForRedErrors(true)
      // console.log("length__", filteredTableForCancel.length);

    }
    setShowFilterOrderId(false);
    setShowFilterPaymentId(false);

  };

  console.log("filteredTableForCancel", filteredTableForCancel);

  const finalData = React.useMemo(() => {
    const dataSource =
      filteredTableForCancel && filteredTableForCancel.length > 0
        ? filteredTableForCancel
        : ordermanagecancel;
    return dataSource

    // return dataSource.filter(
    //   order => order.status?.toLowerCase() === "order placed"
    // );
  }, [filteredTableForCancel, ordermanagecancel]);


  const filterdata = SearchData(finalData, filterText, searchColumns);



  const filteredOrderId = ordermanagecancel.filter((order) =>
    order.order_no.toLowerCase().includes(orderId.toLowerCase())
  );

  const filteredPaymentId = ordermanagecancel.filter((order) =>
    order.payment_ref.toLowerCase().includes(paymentId.toLowerCase())
  );

  console.log("filtered_K", filteredOrderId);

  const [showFilterOrderId, setShowFilterOrderId] = useState(false);
  const [showFilterPaymentId, setShowFilterPaymentId] = useState(false);

  useEffect(() => {

    if (orderId.length === 0) {
      setShowFilterOrderId(false)
    }
    else if (orderId.length > 0) {
      setShowFilterOrderId(true)

    }

    if (paymentId.length === 0) {
      setShowFilterPaymentId(false)
    }
    else if (paymentId.length > 0) {
      setShowFilterPaymentId(true)

    }

  }, [orderId, paymentId])


  return (
    <>
      <div className='container  px-lg-0'>
        {/* <h5>Cancelled Order</h5> */}

        <div>
          <div className='row py-3 px-lg- g-2 d-flex align-items-end'>
            <div className='col-12 col-md-2 position-relative'>
              <label htmlFor='' className='mb-2'>Order ID</label>

              <InputText
                className={`form-control opacity-75 ${forRedErrors && orderId.length === 0 ? "border-danger" : ""}`}
                placeholder="Order ID..."
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
              />

              {showFilterOrderId && filteredOrderId.length > 0 && (
                <div className="overlay position-absolute rounded bg-white align-items-center"
                  style={{ zIndex: "10" }}
                >
                  {filteredOrderId.map((p) => (
                    <>
                      <p className='p-2' style={{ fontSize: "12px" }} onClick={() => setOrderId(p.order_no)}>{p.order_no}</p>
                      <hr className='mt-1 mb-1' />
                    </>

                  ))}
                </div>
              )}

            </div>
            {/* <div className='col-12 col-md-2 position-relative'>
              <label htmlFor='' className='mb-2'>Payment ID</label>
              <InputText
                className={`form-control opacity-75 ${forRedErrors && orderId.length === 0 ? "border-danger" : ""}`}
                placeholder="Payment ID..."
                value={paymentId}
                onChange={(e) => setPaymentId(e.target.value)}
              />

              {showFilterOrderId && filteredOrderId.length > 0 && (
                <div className="overlay position-absolute rounded bg-white align-items-center"
                  style={{ zIndex: "10" }}
                >
                  {filteredOrderId.map((p) => (
                    <>
                      <p className='p-2' style={{ fontSize: "12px" }} onClick={() => setOrderId(p.order_no)}>{p.order_no}</p>
                      <hr className='mt-1 mb-1' />
                    </>

                  ))}
                </div>
              )}

            </div> */}
            <div className='col-12 col-md-2'>
              <div className="flex-auto ">
                <label htmlFor="buttondisplay" className="font-bold block mb-2">
                  From Date
                </label>


                <DatePicker
                  format="DD-MM-YYYY"
                  value={date ? dayjs(date, "YYYY-MM-DD") : null}
                  onChange={(date) => {
                    setDate(date ? date.format("YYYY-MM-DD") : null);
                  }}
                  style={{ width: "100%" }}
                  className={`form-control opacity-75 mt-0 ${forRedErrors && date === null ? "border-danger" : ""}`}

                />

              </div>
            </div>
            <div className='col-12 col-md-2 '>
              <div className="flex-auto">
                <label htmlFor="buttondisplay" className="font-bold block mb-2">
                  To Date
                </label>
                <DatePicker
                  format="DD-MM-YYYY"
                  value={todate ? dayjs(todate, "YYYY-MM-DD") : null}
                  onChange={(date) => {
                    setTodate(date ? date.format("YYYY-MM-DD") : null);
                  }}
                  className={`form-control opacity-75 mt-0 ${forRedErrors && todate === null ? "border-danger" : ""}`}

                  style={{ width: "100%" }}
                />
              </div>
            </div>
            <div className='col-12 col-md-2'>
              <label className='mb-2'>Status</label>

              <PrimeDropdown
                value={status}
                onChange={(e) => setStatus(e.value)}
                options={[
                  { label: "Pending", value: "Pending" },
                  { label: "Order Placed", value: "Order Placed" },
                  { label: "Processing", value: "Processing" },
                  { label: "Packed", value: "Packed" },
                  { label: "Ready for Pickup", value: "Ready for Pickup" },
                  { label: "Shipped", value: "Shipped" },
                  { label: "Picked Up", value: "Picked Up" },
                  { label: "Delivered", value: "Delivered" },
                  { label: "Cancelled", value: "Cancelled" },
                  { label: "All", value: "all" }

                ]}
                optionLabel="label"
                placeholder="Select Status"
                className={`selectStatus ${forRedErrors && status === "" ? "border-danger" : ""}`}
              />

            </div>
            {/* <div className='col-12 col-md-2 mt-4 ps-5'>
              <button type='button' className='btn btn-outline-secondary mt-5 ms-3 ' onClick={handleFilterAll}>Filter</button>
            </div> */}

            <div className='d-flex gap-2 col-md-2'>
              <button type='button' className='btn btn-outline-secondary mx-2' onClick={handleCancelFilter}
                style={{ height: "fit-content", padding: "4px 22px" }}
                disabled={orderId === "" && paymentId === "" && todate === null && date === null ? true : false}
              >Clear</button>
              <button
                type="button"
                className="btn btn-outline-secondary mx-2"
                onClick={handleFilterAll}
                style={{ height: "fit-content", padding: "4px 22px" }}
              >
                Filter
              </button>
            </div>
          </div>
        </div>

        <div className='mt-3 box_shadow'>
          <div className='d-flex justify-content-end py-3 px-3'>

            {/* <div className='d-flex'>
              <h5 className='pe-2 pt-2'>All Cancelled Order </h5>
              <button type="button" className="btn btn-outline-secondary mt-2 small py-0 mx-2 count_box">{ordermanagecancel?.length ?? 0}</button>
            </div> */}

            <div className='text-end position-relative'>
              <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                size={18} />
              <input text="search" className='form-control opacity-75' id='' name='' onChange={handleFilter} placeholder='Search Filter.........' />
            </div>

          </div>


          <DataTable
            columns={columns}

            data={filterdata}
            customStyles={customStyle}
            pagination
            // selectableRows
            className='cancelledDataTable'
            onRowClicked={handleRowClick}
            fixedHeader
            persistTableHead={true}
          />
        </div>
      </div>
      <Dialog header="Confirm  modal" visible={manageconfirmmodal} position="top-2" style={{ width: '30vw' }} onHide={() => { if (!manageconfirmmodal) return; setManageconfirmmodal(false); }}>

        <div className="form-group">
          <p>Are you sure the cancelled order to move</p>
        </div>
        <div className="d-flex justify-content-end mt-3">
          <button className="btn btn-danger" type="submit" >No </button>&nbsp;

          <button className="btn btn-success" type="submit" >Yes </button>
        </div>

      </Dialog>
      <Dialog header="Delivery Details" visible={deliveryViewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!deliveryViewconfirmmodal) return; setDeliveryViewconfirmmodal(false); }}>
        {viewDelivery && (
          <div className='row'>
            <div className='col pt-1'>
              {/* <p><strong>Delivery Address Id: </strong>   {viewDelivery.delivery_address_id}</p> */}
              <p><strong>Delivery Charges  : </strong>   {viewDelivery.delivery_charge}</p>
              <p><strong>Delivery Type  :</strong> {viewDelivery.delivery_type}</p>
              <p><strong>Discount Applied : </strong>{viewDelivery.discount_applied}</p>
            </div>
          </div>
        )}
      </Dialog>

      <Dialog header="User Details" visible={manageViewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!manageViewconfirmmodal) return; setManageViewconfirmmodal(false); }}>
        {viewuser && (
          <div className='row'>
            <div className='col pt-1'>
              <p>  <strong>User Name  : </strong>   {viewuser.user_name}</p>
              <p>   <strong>User Mobile  :</strong> {viewuser.user_mobile}</p>
              <p>   <strong>User Email : </strong>{viewuser.user_email}</p>


            </div>


          </div>
        )}

      </Dialog>
    </>
  )
}

export default CancelledOrder