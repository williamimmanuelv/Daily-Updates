import React, { useEffect, useState, useRef } from "react";
import DataTable from "react-data-table-component";
import { IoSearchOutline } from "react-icons/io5";
import customStyle from "../../utils/Customstyle";
import axiosInstance from "../../utils/axiosinstance";
import { SearchData } from "../../utils/Search";
import { useReactToPrint } from "react-to-print";
import "./orders.css";
import { DatePicker } from 'antd';
import dayjs from 'dayjs';

 const ChecklistorOrdersummery = () => {
  const printRef = useRef();

 const handlePrint = useReactToPrint({
  contentRef: printRef,               
  documentTitle: "Order Summary Report",
  removeAfterPrint: true,
  });
 const [orderSummery, setOrderSummery] = useState([]); 
  const [sourceDate, setSourceDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [filterText, setFilterText] = useState("");

  const [isChange, setIsChange] = useState(false)

  const [forRedErrors, setForRedErrors] = useState(false);
  
  const handleCancelFilter = async () => {
    setSourceDate(null)
    setEndDate(null)
    setIsChange(true)
    setForRedErrors(!forRedErrors);
  }

    useEffect(() => {
      if (isChange) {
        fetchBucketlist()
        setIsChange(false)
  
      }
    }, [sourceDate, endDate, isChange])

    const [filterActive, setFilterActive] = useState(false);

  const fetchBucketlist = async () => {

    try {
      const response = await axiosInstance.get(`/orders/order-summary`, {
        params: {
          start_date: sourceDate,
          end_date: endDate,
        },
      });

      setOrderSummery(response?.data?.summary || []);
      console.log("response?.data?.summary ",response?.data?.summary || []);

    if (filterActive === true  ) {
      setForRedErrors(true);
    }

    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchBucketlist();
  }, []);

  const columns = [
    {
      name: "Product Name",
      selector: (row) => row.product_name,
      wrap: true,
      sortable: true,
    },
    {
      name: "Total Quantity",
      selector: (row) => row.total_quantity,
      wrap: true,
      sortable: true,
    },
    {
      name: "Total Orders",
      selector: (row) => row.total_orders,
      wrap: true,
      sortable: true,
    },
    {
      name: "Stock",
      selector: (row) => row.stock,
      wrap: true,
      sortable: true,
    },
  ];
    
   const searchColumns = [
    "product_name",
    "total_quantity",
    "total_orders",
    "stock",
  ];

  const filterdata = SearchData(orderSummery, filterText, searchColumns);

  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-12 col-md-2">
            <label className="form-label fs-5 fw-semibold">Start Date</label>
            {/* <input
              type="date"
              className="form-control"
              value={sourceDate}
              onChange={(e) => setSourceDate(e.target.value)}
            /> */}
               <DatePicker
      format="DD-MM-YYYY"
      value={sourceDate ? dayjs(sourceDate, "YYYY-MM-DD") : null}
      onChange={(date) => {
        setSourceDate(date ? date.format("YYYY-MM-DD") : null);
      }}
      style={{ width: "100%" }}
      className={`${forRedErrors && sourceDate === "" ? "border-danger" : ""}`}

    />
          </div>

          <div className="col-12 col-md-2">
            <label className="form-label fs-5 fw-semibold">End Date</label>
              {/* <input
                type="date"
                className="form-control"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              /> */}
           <DatePicker
      format="DD-MM-YYYY"
      value={endDate ? dayjs(endDate, "YYYY-MM-DD") : null}
      onChange={(date) => {
        setEndDate(date ? date.format("YYYY-MM-DD") : null);
      }}
      style={{ width: "100%" }}
                      className={`mt-0 ${forRedErrors && endDate === "" ? "border-danger" : ""}`}

    />
          </div>

          <div className="col-12 col-md-4 d-flex align-items-end">
            <button type='button' className='btn btn-outline-secondary mx-3' onClick={handleCancelFilter}
              style={{ height: "fit-content", padding:"3px 22px" }}
               disabled={sourceDate === "" && endDate === "" ? true : false}

              >Clear</button>

            <button
              type="button"
              className="btn btn-outline-secondary mx-3"
              onClick={fetchBucketlist}

              style={{ height: "fit-content", padding:"3px 22px" }}
            >
              Filter
            </button>
          </div>

          <div className="col-12 col-md-4 text-end">
            <button className="btn btn-primary" onClick={handlePrint}
            style={{marginTop: "30px"}}
            >
              Print
            </button>
          </div>
        </div>
      </div>

      <div className="mt-3">
        <div className="container">
          <div className="mt-3 box_shadow">
            <div className="d-flex justify-content-between py-3 px-3">
              <div className="d-flex">
              <h5>Order Summary List</h5>
                {/* <button type="button" class="btn btn-outline-secondary  small py-0 mx-2 count_box">{orderSummery.length}</button> */}
              </div>
              <div className="text-end position-relative">
                <IoSearchOutline
                  className="position-absolute top-50 end-0 translate-middle-y me-3"
                  size={18}
                />
                <input
                  className="form-control opacity-75"
                  onChange={(e) => setFilterText(e.target.value)}
                  placeholder="Search Filter..."
                />
              </div>
            </div>

            {/* PRINT AREA */}
            <div ref={printRef} id="print-area">
              <DataTable
                columns={columns}
                data={filterdata}
                customStyles={customStyle}
                pagination
                persistTableHead
              />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ChecklistorOrdersummery;



// import React, { useEffect, useState } from 'react'
// import DataTable from 'react-data-table-component';
// import { Link } from 'react-router-dom'
// import { GrFormView } from "react-icons/gr";
// import { IoSearchOutline } from "react-icons/io5";
// import customStyle from '../../utils/Customstyle';
// import axiosInstance from '../../utils/axiosinstance';
// import { SearchData } from '../../utils/Search';
// import { useReactToPrint } from "react-to-print";
// import { useRef } from "react";
// import './orders.css'


// const ChecklistorOrdersummery = () => {
//   const printRef = useRef();

//   // const printRef = useRef(null);
//   //  const [products, setProducts] = useState([]);
//   const [selectedProducts, setSelectedProducts] = useState(null);
//   const [rowClick, setRowClick] = useState(true);
//   const [sourceDate, setSourceDate] = useState("");
//   const [endDate, setEndDate] = useState("");

//   const [selectedRows, setSelectedRows] = useState([]);
//   const handleSelectedRowsChange = (state) => {
//     setSelectedRows(state.selectedRows);
//   };


// const handlePrint = useReactToPrint({
//   content: () => printRef.current,
//   documentTitle: "Order Summary Report",
//   removeAfterPrint: true,
// });

//   const [orderSummery, setOrderSummery] = useState([]);

//   const fetchBucketlist = async () => {
//     try {
//       const response = await axiosInstance.get(`/orders/order-summary`, {
//         params: {
//           start_date: sourceDate,
//           end_date: endDate,
//         }
//       });

//       setOrderSummery(response?.data?.summary);
//     } catch (error) {
//       console.error("Error fetching data", error);
//     }
//   };

//   useEffect(() => {
//     fetchBucketlist(); // initial fetch
//   }, []);


//   const columns = [
//     {
//       name: "ProductName",
//       selector: (row) => row.product_name,
//       wrap: true,
//       sortable: true,
//     },

//     {
//       name: "Total Quantity Ordered",
//       selector: (row) => row.total_quantity,
//       wrap: true,
//       sortable: true,
//     },
//     {
//       name: "Total Orders",
//       selector: (row) => row.total_orders,
//       wrap: true,
//       sortable: true,
//     },
//     {
//       name: "Stock",
//       selector: (row) => row.stock,
//       wrap: true,
//       sortable: true,
//     },


//   ];

//   const products = [{
//     SNo: "1",
//     CreatedDate: "15/12/2025 ",
//     Price: "$636",
//     Createby: "user",
//     ID: "FS16276	",
//     Stock: "5566",
//     Actions: ""
//   }]

//   const handleRowClick = (row) => {

//   };

//   const [filterText, setFilterText] = useState("");
//   const searchColumns = ['product_name', 'total_quantity', 'total_orders', 'stock'];
//   const handleFilter = (event) => {
//     setFilterText(event.target.value);
//   };
//   const filterdata = SearchData(orderSummery, filterText, searchColumns);
//   return (
//     <>
//       <div className='container'>
//         {/* <h5>Checklist Ordersummery </h5> */}
//         <div className='row'>

//           {/* <div className='col-12 col-md-3 pt-4'>
//             <div className='shadow p-1 rounded-4 text-muted text-center'>
//               <h6 className='pt-1'>Today Orders</h6>
//               <h5>1250</h5>
//             </div>
//           </div> */}
//           <div className='col-12 col-md-2 mt-3'>
//             <label className="form-label fs-5 fw-semibold">start Date </label>
//             <input
//               type="date"
//               className="form-control"
//               name="start_date"
//               id='start_date'
//               value={sourceDate}
//               onChange={(e) => setSourceDate(e.target.value)}
//             />
//           </div>
//           <div className='col-12 col-md-2 mt-3'>
//             <label className="form-label fs-5 fw-semibold">End Date </label>
//             <input
//               type="date"
//               className="form-control"
//               name="end_date"
//               id='end_date'
//               value={endDate}
//               onChange={(e) => setEndDate(e.target.value)}
//             />
//           </div>
//           <div className='col-12 col-md-2 mt-4'>
//             <button type='button' className='btn btn-secondary mt-4 ' onClick={fetchBucketlist}>Filter</button>
//           </div>

//           <div className='col-12 col-md-5 pt-5 text-end'>
//             <button className='btn btn-outline-primary' onClick={handlePrint}>Print</button>
//           </div>

//         </div>
//       </div>

//       <div className='mt-5'>
//         <div className='container'>
//           <div className='mt-5 box_shadow'>
//             <div className='d-flex justify-content-between py-3 px-3'>
//               <div>
//                 <h5> Ordersummery List</h5>
//               </div>
//               <div className='text-end position-relative'>
//                 <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
//                   size={18} />
//                 <input text="search" className='form-control opacity-75' id='' name='' onChange={handleFilter} placeholder='Search Filter.........' />
//               </div>

//             </div>
//          {/* <div ref={printRef}>
//             <DataTable
//               columns={columns}

//               data={filterdata}
//               customStyles={customStyle}
//               pagination
          
//               onRowClicked={handleRowClick}
//               fixedHeader
//               persistTableHead={true}
//             />
//             </div> */}
//  <div ref={printRef}>
//   <DataTable
//     columns={columns}
//     data={filterdata}
//     customStyles={customStyle}
//     pagination
//     persistTableHead
//   />
// </div>
//           </div>
//         </div>
//       </div>

//     </>
//   )
// }

// export default ChecklistorOrdersummery