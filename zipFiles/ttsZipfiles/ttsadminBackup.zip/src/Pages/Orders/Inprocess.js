import React, { useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { Dialog } from 'primereact/dialog';
import { IoSearchOutline } from "react-icons/io5";
import customStyle from '../../utils/Customstyle';

const Inprocess = () => {
      //  const [products, setProducts] = useState([]);
              const [selectedProducts, setSelectedProducts] = useState(null);
              const [rowClick, setRowClick] = useState(true);
              const[manageconfirmmodal,setManageconfirmmodal]=useState(false)
              
      
           const [selectedRows, setSelectedRows] = useState([]);
            const handleSelectedRowsChange = (state) => {
            setSelectedRows(state.selectedRows);
            };
      
           const columns = [
            {
              name: "Order ID",
              selector: (row) => row.ID,
              wrap: true,
              sortable: true,
            },
            {
              name: "Date",
              selector: (row) => row.CreatedDate,
            
              wrap: true,
              sortable: true,
            },
            {
              name: "Payment Id",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
            },
            {
              name: "Customer",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
            },
            {
              name: "Total",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
             
            },
            {
              name: "Payment Status",
              selector: (row) => row.Price,
              wrap: true,
              sortable: true,
            },
            {
              name: "Payment mode",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
            },
                    {
              name: "Order Type",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
            },        {
              name: "Items",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
            },        {
              name: "Delivery Address",
              selector: (row) => row.Createby,
              wrap: true,
              sortable: true,
            },        {
              name: "Order status",
              // selector: (row) => row.stock,
                cell: (row) => (
            <div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
    status
  </button>
  <ul class="dropdown-menu">
    <li><a class="dropdown-item" href="#" onClick={()=>setManageconfirmmodal(true)}>confirmOrder</a></li>
  

  </ul>
</div>
          ),
              wrap: true,
              sortable: true,
            },
            {
              name: "Actions",
              cell: (row) => (
                // <button className="btn btn-danger btn-sm">Delete</button>
              <div className="d-flex gap-3 me-5">
            <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div>
          
            {/* <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <LuPencilLine size={16} color="red" />
            </div>
          
            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <AiOutlineDelete size={18} color="red" />
            </div> */}
          </div>
          
              ),
              wrap: true,
            },
          ];
      
             const products =[{
              SNo:"1",
             CreatedDate:"15/12/2025 ",
              Price:"$636",
              Createby:"user",
              ID:"FS16276	",
              Stock:"5566",
              Actions:""
            }]
             const handleRowClick = (row) => {
                         
                        };
                  
                         const [filterText, setFilterText] = useState("");
                          const searchColumns = [ 'project_id','date','category_name','subcat_name','file','tracking_status','status' ];
                          const handleFilter = (event) => {
                            setFilterText(event.target.value);
                          };
  return (
  <>

  <div className='container'>
    {/* <h4>In Process Order</h4> */}

    <div className='shadow p-4 rounded-4 text-muted text-center w-25 mt-3'>
        <h6 className=''>Inprocess</h6>
        <h4 className='me-4'>550</h4>
      </div>


      <div className='mt-5 box_shadow'>
                <div className='d-flex justify-content-between py-3 px-3'>
                      <div>
                        <h5>All In Process Order List</h5>
                    </div>
                   
                     <div className='text-end position-relative'>
                                        <IoSearchOutline    className="position-absolute top-50 end-0  translate-middle-y me-3 "
                                       size={18}/>
                                      <input text="search" className='form-control opacity-75' id='' name='' placeholder='Search Filter.........' />
                                    </div>
                </div>


                <DataTable
                    columns={columns}
                   
                    data={products}
                   
                  customStyles={customStyle}
                    pagination
                 // selectableRows
                    onRowClicked={handleRowClick}
                    fixedHeader
                    persistTableHead={true}
                />
            </div>
  </div>
   <Dialog header="Confirm  modal" visible={manageconfirmmodal} position="top-2" style={{ width: '30vw' }} onHide={() => { if (!manageconfirmmodal) return; setManageconfirmmodal(false); }}>

        <div className="form-group">
          <p>Are you sure the Inprocess order to move</p>
        </div>
        <div className="d-flex justify-content-end mt-3">
          <button className="btn btn-danger" type="submit" >No </button>&nbsp;

          <button className="btn btn-success" type="submit" >Yes </button>
        </div>

      </Dialog>

  </>
  )
}

export default Inprocess