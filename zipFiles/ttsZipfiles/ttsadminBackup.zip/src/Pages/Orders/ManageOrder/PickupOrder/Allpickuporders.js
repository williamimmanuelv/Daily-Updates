import React, { useRef, useState, useEffect } from 'react'
import './pickuporders.css'
import OrderPlaced from './OrderPlaced';
import ProcessingPickup from './ProcessingPickup';
import Packed from './Packed';
import ReadyforPickup from './ReadyforPickup';
import PickedUp from './PickedUp';
import axiosInstance from '../../../../utils/axiosinstance';
// 
import { InputText } from 'primereact/inputtext';
import { DatePicker, Dropdown, Space } from 'antd';
import dayjs from 'dayjs';
import { Dropdown as PrimeDropdown } from 'primereact/dropdown';
import { SearchData } from '../../../../utils/Search';
// 
import { useDispatch, useSelector } from 'react-redux';
import { SetPickupCount } from '../../../../Redux/Reducers/PickupCounts';


const Allpickuporders = () => {

  // const pickupCounts = useSelector((state) => state.pickupCount);
  // const dispatch = useDispatch();
  // console.log("pickupCounts", pickupCounts);


  const [active, setActive] = useState("OrderPlaced");
  const tabRefs = useRef([]);

  const handleClick = (key, index) => {
    setActive(key);

    tabRefs?.current[index]?.scrollIntoView({
      behavior: "smooth",
      inline: "center",
      block: "nearest",
    });
  };

  const tabs = [
    { key: "OrderPlaced", label: "OrderPlaced", countKey: "order_placed" },
    { key: "Processing", label: "Processing", countKey: "processing" },
    { key: "Packed", label: "Packed", countKey: "packed" },
    { key: "Ready for Pickup", label: "Ready for Pickup", countKey: "ready_for_pickup" },
    { key: "Picked Up", label: "Picked Up", countKey: "picked_up" },
  ];


  // const tabs = [

  //   { key: "OrderPlaced", label: "OrderPlaced" },
  //   {
  //     key: "Processing",
  //     label: "Processing",
  //   },
  //   { key: "Packed", label: "Packed" },
  //   { key: "Ready for Pickup", label: "Ready for Pickup" },
  //   { key: "Picked Up", label: "Picked Up" },
  // ];
  // 
  const [ordermanagecount, setOrdermanagecount] = useState([]);
  const [ordertrackingFilter, setOrdertrackingFilter] = useState([]);
  const [filteredOrders, setFilteredOrders] = useState([]);
  const [filterText, setFilterText] = useState("");

  const searchColumns = ['project_id', 'order_no', 'created_at', 'delivery_charge', 'delivery_type', 'discount_applied', 'invoice_no', 'user_email', 'user_mobile', 'user_name', 'status', 'payment_type', 'delivery_type', 'tax_amount', 'payment_status', 'total_amount', 'transaction_id', 'pickup_time', 'pickup_date', 'order_no'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);

  };
  const filterdata = SearchData(ordertrackingFilter, filterText, searchColumns);
  const ordersToShow = filteredOrders.length > 0 ? filteredOrders : ordertrackingFilter;


  const fetchManageCount = async () => {
    try {
      const response = await axiosInstance.get(`/orders/counts`,);
      console.log("response?.data", response?.data?.pickup_status_counts);

      setOrdermanagecount(response?.data);
      // dispatch(SetPickupCount(response?.data));
      // console.log("pickupCounts", pickupCounts);

      console.log("response_count", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchManageCount()
  }, [])

  // 

  const fetchManageCountFilter = async () => {
    try {
      const response = await axiosInstance.get(`/orders`,);
      console.log("response?.data", response?.data);
      setOrdertrackingFilter(response?.data?.orders)
      console.log("response_count_ad", response?.data?.orders)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchManageCountFilter()
  }, [])
  console.log("ordersToShow", ordersToShow);


  const [orderId, setOrderId] = useState("");
  const [paymentId, setPaymentId] = useState("");
  const [status, setStatus] = useState("");
  const [date, setDate] = useState(null);
  const [todate, setTodate] = useState(null);

  // 
  const [filteredTableForPick, setFilteredTableForPick] = useState(null);
  const handleFilterAll = async () => {
    let filtered = ordertrackingFilter;
    console.log("ordertrackingFilter", ordertrackingFilter);

    // const nn = ordertrackingFilter.filter(item => item.order_no=== "TTS_ORD_ONP1767618413");
    // console.log("nnnnnn",nn);



    // Filter by Order ID
    if (orderId.trim() !== "") {
      filtered = ordertrackingFilter.filter(order =>
        order.order_no.toLowerCase().includes(orderId.toLowerCase())
      );
      console.log("filtereddd", filtered);

    }

    // Filter by Payment ID
    if (paymentId.trim() !== "") {
      filtered = filtered.filter(order =>
        order.payment_ref?.toLowerCase().includes(paymentId.toLowerCase())
      );
      console.log("filtereddd", filtered);
    }

    // Filter Date Range (created_at)
    if (date && todate) {
      const from = new Date(date);
      const to = new Date(todate);

      filtered = filtered.filter(order => {
        const created = new Date(order.created_at);
        return created >= from && created <= to;
      });
      console.log("filtereddd", filtered);
    }


    // Filter Status
    if (status !== "") {
      filtered = filtered.filter(order =>
        order.status.toLowerCase() === status.toLowerCase()
      );
      console.log("filtereddd", filtered);
    }

    await setFilteredOrders(filtered);
    await setFilteredTableForPick(filtered);
    console.log("filtered", filtered);

  };

  return (
    <>
      <div className="order_tab_main_container mb-3">
        <div className="order-tab-container order-tab-container-ress">
          {tabs.map((tab, index) => (
            <div
              key={tab.key}
              ref={(el) => (tabRefs.current[index] = el)}
              onClick={() => handleClick(tab.key, index)}
              className={`order_tab_p ${active === tab.key ? "active" : ""}`}
            >
              <button className="order-tab-btn">
                {tab.label}
              </button>

              {/* {active === tab.key && ( */}
              <span className='badge bg-danger rounded-circle'                >
                {/* {pickupCounts} */}
                {ordermanagecount?.pickup_status_counts?.[tab.countKey]}
              </span>
              {/* )} */}

            </div>
          ))}


        </div>
      </div>

      {/* for filter */}

      {/* <div>
        <div className='row py-3 px-lg-5 g-5'>
          <div className='col-12 col-md-2'>
            <label htmlFor='' className='mb-2'>Order ID</label>

            <InputText
              className="form-control opacity-75"
              placeholder="Order ID..."
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
            />

          </div>
          <div className='col-12 col-md-2'>
            <label htmlFor='' className='mb-2'>Payment ID</label>
            <InputText
              className="form-control opacity-75"
              placeholder="Payment ID..."
              value={paymentId}
              onChange={(e) => setPaymentId(e.target.value)}
            />
          </div>
          <div className='col-12 col-md-2'>
            <div className="flex-auto ">
              <label htmlFor="buttondisplay" className="font-bold block mb-2">
                From Date
              </label>


              <DatePicker
                format="DD-MM-YYYY"
                value={date ? dayjs(date, "YYYY-MM-DD") : null}
                onChange={(date) => {
                  setDate(date ? date.format("YYYY-MM-DD") : null);
                }}
                style={{ width: "100%" }}
              />

            </div>
          </div>
          <div className='col-12 col-md-2 '>
            <div className="flex-auto">
              <label htmlFor="buttondisplay" className="font-bold block mb-2">
                To Date
              </label>
              <DatePicker
                format="DD-MM-YYYY"
                value={todate ? dayjs(todate, "YYYY-MM-DD") : null}
                onChange={(date) => {
                  setTodate(date ? date.format("YYYY-MM-DD") : null);
                }}
                style={{ width: "100%" }}
              />
            </div>
          </div>
          <div className='col-12 col-md-2'>
            <label className='mb-2'>Status</label>

            <PrimeDropdown
              value={status}
              onChange={(e) => setStatus(e.value)}
              options={[
                { label: "Pending", value: "Pending" },
                { label: "Order Placed", value: "Order Placed" },
                { label: "Processing", value: "Processing" },
                { label: "Packed", value: "Packed" },
                { label: "Ready for Pickup", value: "Ready for Pickup" },
                { label: "Shipped", value: "Shipped" },
                { label: "Picked Up", value: "Picked Up" },
                { label: "Delivered", value: "Delivered" },
                { label: "Cancelled", value: "Cancelled" },
                { label: "All", value: "all" }

              ]}
              optionLabel="label"
              placeholder="Select Status"
              className="h-50 w-100"
            />

          </div>
          <div className='col-12 col-md-2 mt-4 ps-5'>
            <button type='button' className='btn btn-outline-secondary mt-5 ms-3 ' onClick={handleFilterAll}>Filter</button>
          </div>
        </div>
      </div> */}

      {active == "OrderPlaced" && (
        <OrderPlaced />
      )
      }
      {active == "Processing" && (
        <ProcessingPickup />
      )
      }
      {active == "Packed" && (
        <Packed />
      )
      }
      {active == "Ready for Pickup" && (
        <ReadyforPickup />
      )
      }
      {active == "Picked Up" && (
        <PickedUp />
      )
      }

    </>
  )
}

export default Allpickuporders