import React, { useEffect, useRef, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { Dialog } from 'primereact/dialog';
import { IoSearchOutline } from "react-icons/io5";
import customStyle from '../../../../utils/Customstyle';
import { Dropdown, Space, Tag } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import axiosInstance from '../../../../utils/axiosinstance';
import { SearchData } from '../../../../utils/Search';
import Button from '@mui/material/Button';
import { img_path } from '../../../../Api/BaseUrl';
import Packed from "./Packed"
import './pickuporders.css'
// 
import { InputText } from 'primereact/inputtext';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';
import { Dropdown as PrimeDropdown } from 'primereact/dropdown';
// 
import { useDispatch, useSelector } from 'react-redux';
import { SetPickupCount } from '../../../../Redux/Reducers/PickupCounts';



const OrderPlaced = () => {
  // console.log("filteredTableForPic", filteredTableForPick);
  const pickupCounts = useSelector((state) => state.pickupCount);
  const dispatch = useDispatch();
  // console.log("pickupCounts", pickupCounts);



  //  const [products, setProducts] = useState([]);
  const navigate = useNavigate()
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [manageconfirmmodal, setManageconfirmmodal] = useState(false)
  const [ordermanageStatus, setOrdermanageStatus] = useState([])
  console.log("ordermanageStatussssssssssssssssssssss", ordermanageStatus)


  const [filteredApiPickOrderPlaced, setFilteredApiPickOrderPlaced] = useState([]);

  const [manageViewconfirmmodal, setManageViewconfirmmodal] = useState(false)
  const [viewuser, setViewuser] = useState(null);
  const [viewDelivery, setViewDelivery] = useState(null);
  const [deliveryViewconfirmmodal, setDeliveryViewconfirmmodal] = useState(false)
  const [ordermanagecount, setOrdermanagecount] = useState([])
  const [orderItem, setOrderItem] = useState(false)
  const [ordermanageOrderitem, setOrdermanageOrderitem] = useState([])
  console.log("ordermanageOrderitem", ordermanageOrderitem)

  const [OrderDeliveryAddress, setOrderDeliveryAddress] = useState([])
  console.log("OrderDeliveryAddress", OrderDeliveryAddress)

  const token = localStorage.getItem("tokenAdmin")

  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  // 

  const [orderId, setOrderId] = useState("");
  const [paymentId, setPaymentId] = useState("");
  const [status, setStatus] = useState("");
  const [date, setDate] = useState(null);
  const [todate, setTodate] = useState(null);


  const fetchManageStatusPic = async () => {
    try {
      // const encoded = encodeURIComponent(status); 
      const response = await axiosInstance.get(`/orders/pickup/Order Placed`);

      setOrdermanageStatus(response.data.orders);
      setFilteredApiPickOrderPlaced(response.data.orders);
      dispatch(SetPickupCount(response.data.orders.length))
      console.log("pijjckupCounts", pickupCounts)

      console.log("response.data.orders", response.data.orders);


      console.log("Status Data:", response.data.orders);

    } catch (error) {
      console.error("Error fetching status:", error);
    }
  };

  useEffect(() => {
    fetchManageStatusPic()
  }, [])

  const fetchManageCount = async () => {
    try {
      const response = await axiosInstance.get(`/orders/counts`,);
      setOrdermanagecount(response?.data);

      console.log("response_counttt", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchManageCount()
  }, [])

  const handleStatus = async (order_id, status) => {
    try {
      const payload = {
        order_id: order_id,
        status: status,
      };

      const response = await axiosInstance.post(
        "/orders/update-status",
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );

      console.log("Updated:", response.data);
      fetchManageStatusPic()
      // navigate('/processingpickup')
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  const fetchManageViewOrder = async (id) => {
    try {
      const response = await axiosInstance.get(`/orders/view/${id}`,);
      setOrdermanageOrderitem(response.data.items);
      console.log("Orderitem", response.data.items)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const columns = [
    {
      name: "Order ID",
      selector: (row) => row.order_no,
      wrap: true,
      sortable: true,
    },
    {
      name: "Pickup Date",
      selector: (row) => row.pickup_date,

      wrap: true,
      sortable: true,
    },
    {
      name: "Transaction Id",
      selector: (row) => row.transaction_id,
      wrap: true,
      sortable: true,
    },

    {
      name: "Total",
      selector: (row) => row.total_amount,
      wrap: true,
      sortable: true,

    },
    {
      name: "Payment Status",
      selector: (row) => row.payment_status,
      wrap: true,
      sortable: true,
    },
    {
      name: "Tax Amount",
      selector: (row) => row.tax_amount,
      wrap: true,
      sortable: true,
    },
    {
      name: "Discount Applied",
      selector: (row) => row.discount_applied,
      wrap: true,
      sortable: true,
    },
    {
      name: "Delivery Type",
      selector: (row) => row.delivery_type,
      wrap: true,
      sortable: true,
    },
    {
      name: "Payment Type",
      selector: (row) => row.payment_type,
      wrap: true,
      sortable: true,
    },

    // {
    //   name: "Delivery Address",
    //   cell: (row) => (
    //     <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => {
    //       setViewDelivery(row);
    //       setDeliveryViewconfirmmodal(true);
    //     }} >
    //       <GrFormView size={20} color="white" />
    //     </div>
    //   ),
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "User Status",
      cell: (row) => (
        <div
          style={{
            backgroundColor: "black",
            padding: "6px",
            borderRadius: "6px",
            cursor: "pointer"
          }}
          onClick={() => {
            setViewuser(row);
            setManageViewconfirmmodal(true);

          }}
        >
          <GrFormView size={20} color="white" />
        </div>
      ),
      wrap: true,
      sortable: true,
    },

    //   {
    //    name: "Order status",
    //    cell: (row) => (
    //      <Dropdown menu={{ items }} trigger={["click"]}>
    //        <a
    //          onClick={(e) => e.preventDefault()}
    //          className="cursor-pointer"
    //          style={{ color: "black", textDecoration: "none" }}
    //        >
    //          <Space>
    //            Status
    //            <DownOutlined />
    //          </Space>
    //        </a>
    //      </Dropdown>
    //    ),
    //    wrap: true,
    //    sortable: true,
    //  },

    {
      name: "Order status",
      width: "180px",
      cell: (row) => (
        //  const firstWord = row.status?.split(" ")[0];  

        <Dropdown menu={{ items: getStatusItems(row) }}>
          <a
            className=""
            onClick={(e) => e.preventDefault()}
            style={{ color: "black", textDecoration: "none" }}
          >
            <Space>
              {row.status}

              <DownOutlined />
            </Space>
          </a>
        </Dropdown>

      ),
      wrap: true,
    },

    {
      name: "Actions",
      cell: (row) => (
        <div className="d-flex gap-3 me-5" onClick={() => {
          fetchManageViewOrder(row.id)
          setOrderItem(true)
        }}>
          <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
            <GrFormView size={20} color="white" />
          </div>
        </div>
      ),
      wrap: true,
    },
  ];

  const products = [{
    SNo: "1",
    CreatedDate: "15/12/2025 ",
    Price: "$636",
    Createby: "user",
    ID: "FS16276	",
    Stock: "5566",
    Actions: ""
  }]

  // const items = [
  //   {
  //     label: "Processing",
  //     key: "1",
  //   },
  //   {
  //     label: "Cancel",
  //     key: "2",
  //   }
  // ];
  //    const items = [
  //   {
  //     key: "1",
  //     label: (
  //       <span onClick={() => fetchManageStatusPic("Order Placed")}>
  //        Processing
  //       </span>
  //     ),
  //   },
  //   {
  //     key: "2",
  //     label: (
  //       <span onClick={() => fetchManageStatusPic("cancelled")}>
  //       cancelled
  //       </span>
  //     ),
  //   },

  // ];
  // const getStatusItems = (row) => [
  //   {
  //     key: "1",
  //     label: (
  //       <span onClick={() => handleStatus(row.id, "Processing")}>
  //         Processing
  //       </span>
  //     ),
  //   },
  //   {
  //     key: "2",
  //     label: (
  //       <span onClick={() => handleStatus(row.id, "Cancelled")}>
  //         Cancelled
  //       </span>
  //     ),
  //   },
  // ];


  const getStatusItems = (row) => [

    {
      key: "2",
      label: (
        <span onClick={() => handleStatus(row.id, "Processing")}>
          Processing
        </span>
      ),
    },
    {
      key: "3",
      label: (
        <span onClick={() => handleStatus(row.id, "Packed")}>
          Packed
        </span>
      ),
    },
    {
      key: "4",
      label: (
        <span onClick={() => handleStatus(row.id, "Ready for Pickup")}>
          Ready for Pickup
        </span>
      ),
    },
    {
      key: "5",
      label: (
        <span onClick={() => handleStatus(row.id, "Picked Up")}>
          Picked Up
        </span>
      ),
    },
    // {
    //   key: "6",
    //   label: (
    //     <span onClick={() => handleStatus(row.id, "Pending")}>
    //       Pending
    //     </span>
    //   ),
    // },
    {
      key: "7",
      label: (
        <span onClick={() => handleStatus(row.id, "Cancelled")}>
          Cancel
        </span>
      ),
    },

  ];

  const handleRowClick = (row) => {
  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'date', 'order_no', 'pickup_date', 'transaction_id', 'total_amount', 'payment_status', 'tax_amount', 'payment_type'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };

  // 


  const [filteredPickOrderPlaced, setFilteredPickOrderPlaced] = useState([]);
  const [forRedErrors, setForRedErrors] = useState(false);

  const [isChange, setIsChange] = useState(false)
  const handleCancelFilter = async () => {
    setOrderId("");
    setPaymentId("");
    setStatus("");
    setDate(null);
    setTodate(null);
    setIsChange(true);
    setForRedErrors(!forRedErrors);
  }
  useEffect(() => {
    if (isChange) {

      handleFilterAll()
      setIsChange(false)

    }
  }, [orderId, paymentId, isChange, status, date, todate])


  const handleFilterAll = async () => {

    let filtered = filteredApiPickOrderPlaced;
    console.log("ordertrackingFilter", filteredApiPickOrderPlaced);

    // const nn = ordertrackingFilter.filter(item => item.order_no=== "TTS_ORD_ONP1767618413");
    // console.log("nnnnnn",nn);



    // Filter by Order ID
    if (orderId.trim() !== "") {
      filtered = filtered.filter(order =>
        order.order_no.toLowerCase().includes(orderId.toLowerCase())
      );
      console.log("filtereddd", filtered);
    }

    // Filter by Payment ID
    if (paymentId.trim() !== "") {
      filtered = filtered.filter(order =>
        order.payment_ref?.toLowerCase().includes(paymentId.toLowerCase())
      );
      console.log("filtereddd", filtered);
    }

    // Filter Date Range (created_at)
    if (date && todate) {
      const from = new Date(date);
      const to = new Date(todate);

      filtered = filtered.filter(order => {
        const created = new Date(order.created_at);
        return created >= from && created <= to;
      });
      console.log("filteredddssss", filtered);
      // setFilteredPickOrderPlaced(filtered);
    }


    // // Filter Status
    // if (status !== "") {
    //   filtered = filtered.filter(order =>
    //     order.status.toLowerCase() === status.toLowerCase()
    //   );
    //   console.log("filtereddd", filtered);
    // }

    // await setFilteredOrders(filtered);


    if (filtered.length === 0) {
      setFilteredPickOrderPlaced([0])
      console.log("length0", filtered.length);
    }

    else {
      await setFilteredPickOrderPlaced(filtered);
    }
    console.log("filtered", filtered);


    if (filteredPickOrderPlaced.length === 0) {
      setForRedErrors(true)
      console.log("length__", filteredPickOrderPlaced.length);

    }
    setShowFilterOrderId(false);
    setShowFilterPaymentId(false);

  };

  const finalData = React.useMemo(() => {
    const dataSource =
      filteredPickOrderPlaced && filteredPickOrderPlaced.length > 0
        ? filteredPickOrderPlaced
        : filteredApiPickOrderPlaced;
    return dataSource

    // return dataSource.filter(
    //   order => order.status?.toLowerCase() === "order placed"
    // );
  }, [filteredPickOrderPlaced, filteredApiPickOrderPlaced]);


  const filterdata = SearchData(finalData, filterText, searchColumns);

  const filteredOrderId = filteredApiPickOrderPlaced.filter((order) =>
    order.order_no.toLowerCase().includes(orderId.toLowerCase())
  );

  const filteredPaymentId = filteredApiPickOrderPlaced.filter((order) =>
    order.payment_ref.toLowerCase().includes(paymentId.toLowerCase())
  );

  console.log("filtered_K", filteredOrderId);

  const [showFilterOrderId, setShowFilterOrderId] = useState(false);
  const [showFilterPaymentId, setShowFilterPaymentId] = useState(false);

  useEffect(() => {

    if (orderId.length === 0) {
      setShowFilterOrderId(false)
    }
    else if (orderId.length > 0) {
      setShowFilterOrderId(true)

    }

  }, [orderId])

  useEffect(() => {

    if (paymentId.length === 0) {
      setShowFilterPaymentId(false)
    }
    else if (paymentId.length > 0) {
      setShowFilterPaymentId(true)

    }
  }, [paymentId])

  // if (filteredPickOrderPlaced && filteredPickOrderPlaced.length > 0) {

  // }

  return (
    <>

      <div className='container px-lg-0'>


        <div>
          <div className='row py-3 px-lg-5 g-2'>
            <div className='col-12 col-md-2  position-relative '>
              <label htmlFor='' className='mb-2'>Order ID</label>

              <InputText
                className={`form-control opacity-75 ${forRedErrors && orderId.length === 0 ? "border-danger" : ""}`}
                placeholder="Order ID..."
                value={orderId}
                onChange={(e) => setOrderId(e.target.value)}
              />

              {showFilterOrderId && filteredOrderId.length > 0 && (
                <div className="overlay position-absolute rounded bg-white align-items-center"
                  style={{ zIndex: "10" }}
                >
                  {filteredOrderId.map((p) => (
                    <>
                      <p className='p-2' style={{ fontSize: "12px" }} onClick={() => setOrderId(p.order_no)}>{p.order_no}</p>
                      <hr className='mt-1 mb-1' />
                    </>

                  ))}
                </div>
              )}

            </div>
            {/* <div className='col-12 col-md-2 position-relative'>
              <label htmlFor='' className='mb-2'>Payment ID</label>
              <InputText
                className={`form-control opacity-75 ${forRedErrors && paymentId.length === 0 ? "border-danger" : ""}`}
                placeholder="Payment ID..."
                value={paymentId}
                onChange={(e) => setPaymentId(e.target.value)}
              />

              {showFilterPaymentId && filteredPaymentId.length > 0 && (
                <div className="overlay position-absolute rounded bg-white align-items-center"
                  style={{ zIndex: "10" }}
                >
                  {filteredPaymentId.map((p) => (
                    <>
                      <p className='p-2' style={{ fontSize: "12px" }} onClick={() => setPaymentId(p.payment_ref)}>{p.payment_ref}</p>
                      <hr className='mt-1 mb-1' />
                    </>

                  ))}
                </div>
              )}

            </div> */}
            <div className='col-12 col-md-2'>
              <div className="flex-auto ">
                <label htmlFor="buttondisplay" className="font-bold block mb-2">
                  From Date
                </label>


                <DatePicker
                  format="DD-MM-YYYY"
                  value={date ? dayjs(date, "YYYY-MM-DD") : null}
                  onChange={(date) => {
                    setDate(date ? date.format("YYYY-MM-DD") : null);
                  }}
                  className={`form-control opacity-75 mt-0 ${forRedErrors && date === null ? "border-danger" : ""}`}
                  style={{ width: "100%", marginTop: "6px" }}
                />

              </div>
            </div>
            <div className='col-12 col-md-2 '>
              <div className="flex-auto">
                <label htmlFor="buttondisplay" className="font-bold block mb-2">
                  To Date
                </label>
                <DatePicker
                  format="DD-MM-YYYY"
                  value={todate ? dayjs(todate, "YYYY-MM-DD") : null}
                  onChange={(date) => {
                    setTodate(date ? date.format("YYYY-MM-DD") : null);
                  }}
                  className={`form-control opacity-75 mt-0 ${forRedErrors && todate === null ? "border-danger" : ""}`}
                  style={{ width: "100%", marginTop: "6px" }}
                />
              </div>
            </div>
            {/* <div className='col-12 col-md-2'>
              <label className='mb-2'>Status</label>

              <PrimeDropdown
                value={status}
                onChange={(e) => setStatus(e.value)}
                options={[
                  { label: "Pending", value: "Pending" },
                  { label: "Order Placed", value: "Order Placed" },
                  { label: "Processing", value: "Processing" },
                  { label: "Packed", value: "Packed" },
                  { label: "Ready for Pickup", value: "Ready for Pickup" },
                  { label: "Shipped", value: "Shipped" },
                  { label: "Picked Up", value: "Picked Up" },
                  { label: "Delivered", value: "Delivered" },
                  { label: "Cancelled", value: "Cancelled" },
                  { label: "All", value: "all" }

                ]}
                optionLabel="label"
                placeholder="Select Status"
                className="h-50 w-100"
              />

            </div> */}
            {/* <div className='col-12 col-md-4 align-content-center'>
              <button type='button' className='btn btn-outline-secondary d-block mx-auto' onClick={handleFilterAll}>Filter</button>
            </div> */}

            <div className="col-12 col-md-4 d-flex align-items-end">
              <button type='button' className='btn btn-outline-secondary mx-2' onClick={handleCancelFilter}
                style={{ height: "fit-content", padding: "4px 22px" }}
                disabled={orderId === "" && paymentId === "" && todate === null && date === null ? true : false}
              >Clear</button>

              <button
                type="button"
                className="btn btn-outline-secondary mx-2"
                onClick={handleFilterAll}
                style={{ height: "fit-content", padding: "4px 22px" }}
              >
                Filter
              </button>
            </div>


          </div>
        </div>

        {/* <h4>In Process Order</h4> */}
        {/* {ordermanageStatus &&(
        <div className='shadow p-4 rounded-4 text-muted text-center w-25 mt-3'>
          <h6 className=''>OrderPlaced</h6>
          <h4 className='me-4'>{ordermanageStatus?.length}</h4>
        </div>
        )} */}
        <div className="d-flex justify-content-start">
          {/* <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate('/processingpickup')}
            >
              ← Back
            </button> */}
        </div>
        <div className='mt-3 box_shadow'>
          <div className='d-flex justify-content-between py-3 px-3'>
            <div className='d-flex'>
              <h5 className='pe-2 pt-2'>All OrderPlacedPickup </h5>
              {/* <button type="button" class="btn btn-outline-secondary mt-2 small py-0 mx-2 count_box">{ordermanagecount?.pickup_status_counts?.order_placed}</button> */}
            </div>

            <div className='text-end position-relative d-flex '>
              <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                size={18} />
              <input text="search" className='form-control opacity-75' id='' name='' onChange={handleFilter} placeholder='Search Filter.........' />
            </div>
          </div>


          <DataTable
            columns={columns}

            data={filterText ? filterdata : finalData}

            customStyles={customStyle}
            pagination
            // selectableRows
            className='pickup pickupOrderPlaced'
            onRowClicked={handleRowClick}
            fixedHeader
            persistTableHead={true}
          />
        </div>

      </div >

      <Dialog header="Confirm  modal" visible={manageconfirmmodal} position="top-2" style={{ width: '30vw' }} onHide={() => { if (!manageconfirmmodal) return; setManageconfirmmodal(false); }}>

        <div className="form-group">
          <p>Are you sure the Inprocess order to move</p>
        </div>
        <div className="d-flex justify-content-end mt-1">
          <button className="btn btn-danger" type="submit" >No </button>&nbsp;

          <button className="btn btn-success" type="submit" >Yes </button>
        </div>

      </Dialog>
      {/* <Dialog header="Confirm Delivery View" visible={deliveryViewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!deliveryViewconfirmmodal) return; setDeliveryViewconfirmmodal(false); }}>
        {viewDelivery && (
          <div className='row'>
            <div className='col pt-3'>
              <p><strong>delivery_address_id: </strong>   {viewDelivery.delivery_address_id}</p>
              <p><strong>delivery_charge  : </strong>   {viewDelivery.delivery_charge}</p>
              <p><strong>delivery_type  :</strong> {viewDelivery.delivery_type}</p>
              <p><strong>discount_applied : </strong>{viewDelivery.discount_applied}</p>
            </div>
          </div>
        )}
      </Dialog> */}

      <Dialog header="User Details" visible={manageViewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!manageViewconfirmmodal) return; setManageViewconfirmmodal(false); }}>
        {viewuser && (
          <div className='row'>
            <div className='col pt-1'>
              <p><strong>User Name  : </strong>   {viewuser.user_name}</p>
              <p>   <strong>User Mobile  :</strong> {viewuser.user_mobile}</p>
              <p>   <strong>User Email : </strong>{viewuser.user_email}</p>
            </div>
          </div>
        )}

      </Dialog>
      <Dialog
        header="Ordered Item Details"
        visible={orderItem}
        position="top"
        style={{ width: '80vw' }}
        onHide={() => setOrderItem(false)}
      >
        {ordermanageOrderitem.length > 0 && ordermanageOrderitem.map((item) => (
          <div key={item.id} className="row align-items-center p-3 border-bottom">

            <div className="col-md-3 pt-2">
              <div className="border p-2">
                <img
                  src={`${img_path}/products/${item.image}`}
                  alt={item.product_name}
                  className="img-fluid rounded"
                  style={{ width: "120px", height: "120px", objectFit: "contain" }}
                />
              </div>
            </div>

            <div className="col-md-6 cardfamily">
              <h5>{item.product_name}</h5>

              <p className="fw-semibold mb-1">
                Size: <span className="py-2 px-2">{item.weight}{item.attribute_type}</span>
              </p>

              <div className="pt-1">
                <span className="fw-semibold fs-5 me-2">{item.price}€</span>
                <span className="text-muted opacity-75 fs-5 fw-semibold">
                  <s>{item.mrp}€</s>
                </span>
                {/* <span className="text-success ms-2 fw-semibold">42% off</span> */}
              </div>
            </div>

            <div className="col-md-3 px-xl-5">
              <div className=" rounded-5 d-flex align-items-center justify-content-between px-3 py-1 mb-2">
                <span className="fs-5">{item.qty}</span>
              </div>
            </div>

          </div>
        ))}
      </Dialog>
    </>
  )
}

export default OrderPlaced