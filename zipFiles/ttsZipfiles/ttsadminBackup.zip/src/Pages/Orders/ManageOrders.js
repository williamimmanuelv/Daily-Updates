import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
// import customStyle from '../../utils/Customstyle';
import { IoSearchOutline } from "react-icons/io5";
import { Dialog } from 'primereact/dialog';
import customStyle from '../../utils/Customstyle';
import { Dropdown, Space } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import './orders.css'
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
import { img_path } from '../../Api/BaseUrl';

const ManageOrders = () => {
  //  const [products, setProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [manageconfirmmodal, setManageconfirmmodal] = useState(false)
  const [paymentType, setPaymentType] = useState(false)
  const [manageViewconfirmmodal, setManageViewconfirmmodal] = useState(false)
  const [viewuser, setViewuser] = useState(null);
  // const [viewDelivery, setViewDelivery] = useState(null);
  const [deliveryViewconfirmmodal, setDeliveryViewconfirmmodal] = useState(false)
  const [orderItem, setOrderItem] = useState(false)
  const [ordermanageOrderitem, setOrdermanageOrderitem] = useState([])
  console.log("ordermanageOrderitem", ordermanageOrderitem)

  const navigate = useNavigate()

  const token = localStorage.getItem("tokenAdmin")

  // const [selectedRows, setSelectedRows] = useState([]);
  const [ordermanage, setOrdermanage] = useState([]);
  console.log("ordermanagerr", ordermanage)
  const [ordermanageStatus, setOrdermanageStatus] = useState([])
  console.log("ordermanageStatusssssss", ordermanageStatus)
  const [ordermanagecount, setOrdermanagecount] = useState([])
  console.log("ordermanagecountddd", ordermanagecount)
  const [OrderDeliveryAddress, setOrderDeliveryAddress] = useState([])

  const handleSelectedRowsChange = (state) => {
    // setSelectedRows(state.selectedRows);
  };

  const fetchManageCount = async () => {
    try {
      const response = await axiosInstance.get(`/orders/counts`,);
      setOrdermanagecount(response?.data);
      console.log("response_count", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchManageCount()
  }, [])

  const fetchdeliveryAddress = async (id) => {
    try {
      const response = await axiosInstance.get(`/orders/address/${id}`,);
      setOrderDeliveryAddress(response.data.address);
      console.log("Orderadd", response.data.address)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const fetchManageViewOrder = async (id) => {
    try {
      const response = await axiosInstance.get(`/orders/view/${id}`,);
      setOrdermanageOrderitem(response.data.items);
      console.log("Orderitem", response.data.items)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  const fetchManage = async () => {
    try {
      const response = await axiosInstance.get(`/orders/pending`,);
      setOrdermanage(response.data.orders);
      console.log("response.data", response.data.orders.orders)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchManage()
  }, [])

  const handleStatus = async (order_id, status) => {
    try {
      const payload = {
        order_id: order_id,
        status: status,
      };

      const response = await axiosInstance.post(
        "/orders/update-status",
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      console.log("Updated:", response.data);
      // navigate('/orderplaced')
      fetchManage()
    } catch (error) {
      console.error("Error updating status:", error);
    }
  };

  //   const items = [
  //   {
  //     key: "1",
  //     label: (
  //       <span onClick={() => fetchManageStatusPic("Order Placed")}>
  //         Order Placed
  //       </span>
  //     ),
  //   },
  //   {
  //     key: "2",
  //     label: (
  //       <span onClick={() => fetchManageStatusPic("cancelled")}>
  //       cancelled
  //       </span>
  //     ),
  //   },

  // ];
  // const getStatusItems = (row) => [
  //   {
  //     key: "1",
  //     label: (
  //       <span onClick={() => handleStatus(row.id, "Order Placed")}>
  //         Order Placed
  //       </span>
  //     ),
  //   },
  //   {
  //     key: "2",
  //     label: (
  //       <span onClick={() => handleStatus(row.id, "Cancel")}>
  //         Cancel
  //       </span>
  //     ),
  //   },
  // ];
  const getStatusItems = (row) => [
    {
      key: "1",
      label: (
        <span onClick={() => handleStatus(row.id, "Order Placed")}>
        Order Placed
        </span>
      ),
    },

    // {
    //   key: "2",
    //   label: (
    //     <span onClick={() => handleStatus(row.id, "Processing")}>
    //       Processing
    //     </span>
    //   ),
    // },
    // {
    //   key: "3",
    //   label: (
    //     <span onClick={() => handleStatus(row.id, "Packed")}>
    //       Packed
    //     </span>
    //   ),
    // },
    //   {
    //   key: "4",
    //   label: (
    //     <span onClick={() => handleStatus(row.id, "Ready for Pickup")}>
    //       Ready for Pickup
    //     </span>
    //   ),
    // },
    //  {
    //   key: "5",
    //   label: (
    //     <span onClick={() => handleStatus(row.id, "Picked Up")}>
    //       Picked Up
    //     </span>
    //   ),
    // },

    // {
    //   key: "6",
    //   label: (
    //     <span onClick={() => handleStatus(row.id, "Shipped")}>
    //       Shipped
    //     </span>
    //   ),
    // },
    //    {
    //   key: "7",
    //   label: (
    //     <span onClick={() => handleStatus(row.id, "Delivered")}>
    //       Delivered
    //     </span>
    //   ),
    // },
    // {
    //   key: "6",
    //   label: (
    //     <span onClick={() => handleStatus(row.id, "Pending")}>
    //       Pending
    //     </span>
    //   ),
    // },
    {
      key: "8",
      label: (
        <span onClick={() => handleStatus(row.id, "Cancelled")}>
          Cancel
        </span>
      ),
    },

  ];

  const columns = [
    {
      name: "Order ID",
      selector: (row) => row.order_no,
      wrap: true,
      sortable: true,
    },
    {
      name: "Pickup Date",
      selector: (row) => row.pickup_date,

      wrap: true,
      sortable: true,
    },
    {
      name: "Transaction Id",
      selector: (row) => row.transaction_id,
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "Customer",
    //   selector: (row) => row.Stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Total",
      selector: (row) => row.total_amount,
      wrap: true,
      sortable: true,

    },
    {
      name: "Payment Status",
      selector: (row) => row.payment_status,
      wrap: true,
      sortable: true,
    },
    {
      name: "Tax Amount",
      selector: (row) => row.tax_amount,
      wrap: true,
      sortable: true,
    },
    {
      name: "Discount",
      selector: (row) => row.discount_applied,
      wrap: true,
      sortable: true,
    },
    {
      name: "Delivery Type",
      selector: (row) => row.delivery_type,
      wrap: true,
      sortable: true,
    },
    {
      name: "Payment Type",
      selector: (row) => row.payment_type,
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "Payment Type",
    //   cell: (row) => (
    //     <div class="">
    //       <button class="btn btn-secondary" type="button" onClick={() => setPaymentType(true)} >
    //         status
    //       </button>

    //     </div>
    //   ),
    //   selector: (row) => row.Createby,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Order Type",
    //   selector: (row) => row.Price,
    //   wrap: true,
    //   sortable: true,
    // }, {
    //   name: "User",
    //   selector: (row) => row.Createby,
    //   wrap: true,
    //   sortable: true,
    // },

    {
      name: "Delivery Address",
      cell: (row) => (
        row.delivery_type === "delivery" ? (
          <div
            style={{
              backgroundColor: "black",
              padding: "6px",
              borderRadius: "6px",
              cursor: "pointer"
            }}
            onClick={() => {
              setDeliveryViewconfirmmodal(true);
              fetchdeliveryAddress(row.delivery_address_id);
            }}
          >
            <GrFormView size={20} color="white" />
          </div>
        ) : (
          <span className="text-muted">—</span>  // If not delivery
        )
      ),
      wrap: true,
      sortable: true,
      },
       {
      name: "User",
      cell: (row) => (
        <div
          style={{
            backgroundColor: "black",
            padding: "6px",
            borderRadius: "6px",
            cursor: "pointer"
          }}
          onClick={() => {
            setViewuser(row);
            setManageViewconfirmmodal(true);
          }}
        >
          <GrFormView size={20} color="white" />
        </div>
      ),
      wrap: true,
      sortable: true,
    },

    // {
    //   name: "Order status",

    //   cell: (row) => (

    //     <div class="dropdown" onClick={()=>fetchManageStatusPic(row.id)}>
    //       <button class="btn btn-secondary dropdown-toggle " type="button" data-bs-toggle="dropdown" aria-expanded="false">
    //         status
    //       </button>
    //       <ul class="dropdown-menu custom-dropdown-z">
    //         <li><a class="dropdown-item" href="#" onClick={() => setManageconfirmmodal(true)}>OrderPlaced</a></li>
    //         <li><a class="dropdown-item" href="#">Cancel</a></li>

    //       </ul>
    //     </div>

    //   ),
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Status",
      cell: (row) => (
        <Dropdown menu={{ items: getStatusItems(row) }}>
          <a className="dropdown-btn" onClick={(e) => e.preventDefault()}>
            <Space>
              {row.status}
              <DownOutlined />
            </Space>
          </a>
        </Dropdown>
      ),
      wrap: true,
    },

    {
      name: "Order Item",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-3 me-5" onClick={() => {
          fetchManageViewOrder(row.id)
          setOrderItem(true)
        }}>
          <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>

            <GrFormView size={20} color="white" />
          </div>


        </div>

      ),
      wrap: true,
    },
  ];

  // const products = [{
  //   SNo: "1",
  //   CreatedDate: "15/12/2025 ",
  //   Price: "$636",
  //   Createby: "user",
  //   ID: "FS16276	",
  //   Stock: "5566",
  //   Actions: ""
  // }]

  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'date', 'order_no', 'pickup_date', 'transaction_id', 'total_amount', 'payment_status', 'tax_amount', 'delivery_type', 'payment_type'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(ordermanage, filterText, searchColumns);


  return (
    <>

      <div className='container  px-lg-0'>
        {/* <h4 className='py-3'>Manage Order</h4> */}

        {/* First Row */}
        <div className="d-flex justify-content-start pb-3">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={() => navigate('/orderplaced')}
          >
            ← Back
          </button>
        </div>


        <div className='row order_family g-3'>
          <div className='col-6 col-md-3'>
            <div className='shadow p-4 rounded-4 text-muted text-center h-100'>
              <h6>Total Orders</h6>
              <h4>{ordermanagecount?.total_orders}</h4>
            </div>
          </div>

          <div className='col-6 col-md-3'>
            <div className='shadow p-4 rounded-4 text-muted text-center h-100'>
              <h6>Pending Order</h6>
              <h4>{ordermanagecount?.overall_status_counts?.pending}</h4>

            </div>
          </div>

          <div className='col-6 col-md-3'>
            <div className='shadow p-4 rounded-4 text-muted text-center h-100'>
              <h6>Cancelled Order</h6>
              <h4>{ordermanagecount?.overall_status_counts?.cancelled}</h4>
            </div>
          </div>

          <div className='col-6 col-md-3'>
            <div className='shadow p-4 rounded-4 text-muted text-center h-100'>
              <h6 className=''>Inprocess</h6>

              <h4>{ordermanagecount?.overall_status_counts?.processing}</h4>

            </div>
          </div>

          {/* <div className='col-6 col-md-2'>
      <div className='shadow p-3 rounded-4 text-muted text-center'>
        <h6>Check list</h6>
        <h4>150</h4>
      </div>
    </div> */}
        </div>


        {/* Second Row */}
        <div className='row pt-3 order_family g-3'>
          <div className='col-6 col-md-3'>
            <div className='shadow p-4 rounded-4 text-center h-100'>
              <h6 className='text-muted'>Order Shipped</h6>
              {/* <h5 className='me-5'>350</h5> */}
              <h4>{ordermanagecount?.overall_status_counts?.shipped}</h4>

            </div>
          </div>

          <div className='col-6 col-md-3'>
            <div className='shadow p-4 rounded-4 text-center h-100'>
              <h6 className='text-muted'> total Order Delivered</h6>
              <h5>{ordermanagecount?.total_delivery}</h5>
            </div>
          </div>

          <div className='col-6 col-md-3'>
            <div className='shadow p-4 rounded-4 text-center h-100'>
              <h6 className='text-muted'>Order delivered</h6>
              <h4>{ordermanagecount?.overall_status_counts?.delivered}</h4>

            </div>
          </div>

          <div className='col-6 col-md-3'>
            <div className='shadow p-4 rounded-4 text-center h-100'>
              <h6 className='text-muted'>Total Pickup Orders</h6>
              <h5>{ordermanagecount?.total_pickup}</h5>
            </div>
          </div>

          {/* <div className='col-6 col-md-2'>
      <div className='shadow p-3 rounded-4 text-center'>
        <h6 className='text-muted'>Bucket List</h6>
        <h5>1150</h5>
      </div>
    </div> */}
        </div>

      </div>

      <div className='container'>

        <div className='mt-5 box_shadow'>
          <div className='d-flex justify-content-between py-3 px-3'>
            <div>
              <h5>All Pending List</h5>
            </div>

            <div className='text-end position-relative'>
              <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                size={18} />
              <input text="search" className='form-control opacity-75' id='' name='' onChange={handleFilter} placeholder='Search Filter.........' />
            </div>
          </div>


          <DataTable
            columns={columns}

            data={filterdata}

            customStyles={customStyle}
            pagination
            // selectableRows
            className='manageOrderDataTable'
            onRowClicked={handleRowClick}
            fixedHeader
            persistTableHead={true}
          />
        </div>
      </div>
      {/* 
      <Dialog header="Confirm  modal" visible={manageconfirmmodal} position="top-2" style={{ width: '30vw' }} onHide={() => { if (!manageconfirmmodal) return; setManageconfirmmodal(false); }}>

        <div className="form-group">
          <p>Are you sure the confirme order to move</p>
        </div>
        <div className="d-flex justify-content-end mt-3">
          <button className="btn btn-danger" type="submit" >No </button>&nbsp;

          <button className="btn btn-success" type="submit" >Yes </button>
        </div>

      </Dialog> */}
      {/* 
      <Dialog
        header="Received Amount"
        visible={paymentType}
        position="top-2"
        style={{ width: '30vw' }}
        onHide={() => { if (!paymentType) return; setPaymentType(false); }}
      >
        <form>
          <div >
            <div className="mb-3">
              <label className="form-label fw-semibold">Amount</label>
              <input type="text" name="amount" className="form-control" placeholder="Enter amount" />
            </div>
            <div className="mb-3">
              <label className="form-label fw-semibold d-block">Payment Type</label>
              <div className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="radio"
                  name="paymentType"
                  id="radioOnline"
                  value="online"
                />
                <label className="form-check-label" htmlFor="radioOnline">
                  Online
                </label>
              </div>
              <div className="form-check form-check-inline">
                <input
                  className="form-check-input"
                  type="radio"
                  name="paymentType"
                  id="radioCOD"
                  value="cod"
                  defaultChecked
                />
                <label className="form-check-label" htmlFor="radioCOD">
                  Cash On Delivery
                </label>
              </div>
            </div>


            <div className="mb-3">
              <label className="form-label fw-semibold">Reference</label>
              <input
                type="text"
                name="reference"
                className="form-control"
                placeholder="Enter reference"
              />
            </div>
          </div>
          <div className="d-flex justify-content-end mt-4">
            <button className="btn btn-danger me-2" type="button" onClick={() => setPaymentType(false)}>
              Cancel
            </button>
            <button className="btn btn-success" type="submit">
              Submit
            </button>
          </div>
        </form>
      </Dialog> */}

      {/* <Dialog header="Confirm Delivery View" visible={deliveryViewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!deliveryViewconfirmmodal) return; setDeliveryViewconfirmmodal(false); }}>
        {viewDelivery && (
          <div className='row'>
            <div className='col pt-3'>
              <p><strong>delivery_address: </strong>   {viewDelivery.delivery_address_id}</p>
              <p><strong>delivery_charge  : </strong>   {viewDelivery.delivery_charge}</p>
              <p><strong>delivery_type  :</strong> {viewDelivery.delivery_type}</p>
              <p><strong>discount_applied : </strong>{viewDelivery.discount_applied}</p>
            </div>
          </div>
        )}
      </Dialog> */}

      <Dialog header="User Details" visible={manageViewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!manageViewconfirmmodal) return; setManageViewconfirmmodal(false); }}>
        {viewuser && (
          <div className='row'>
            <div className='col pt-1'>
              <p><strong>User Name  : </strong>   {viewuser.user_name}</p>
              <p>   <strong>User Mobile  :</strong> {viewuser.user_mobile}</p>
              <p>   <strong>User Email : </strong>{viewuser.user_email}</p>
            </div>
          </div>
        )}

      </Dialog>


      <Dialog
        header="Ordered Item Details"
        visible={orderItem}
        position="top"
        style={{ width: '80vw' }}
        onHide={() => setOrderItem(false)}
      >
        {ordermanageOrderitem.length > 0 && ordermanageOrderitem.map((item) => (
          <div key={item.id} className="row align-items-center p-3 border-bottom">

            <div className="col-md-3 pt-2">
              <div className="border p-2">
                <img
                  src={`${img_path}/products/${item.image}`}
                  alt={item.product_name}
                  className="img-fluid rounded"
                  style={{ width: "120px", height: "120px", objectFit: "contain" }}
                />
              </div>
            </div>

            <div className="col-md-6 cardfamily">
              <h5>{item.product_name}</h5>

              <p className="fw-semibold mb-1">
                Size: <span className="py-2 px-2">{item.weight}{item.attribute_type}</span>
              </p>

              <div className="pt-1">
                <span className="fw-semibold fs-5 me-2">{item.price}€</span>
                <span className="text-muted opacity-75 fs-5 fw-semibold">
                  <s>{item.mrp}€</s>
                </span>
                {/* <span className="text-success ms-2 fw-semibold">42% off</span> */}
              </div>
            </div>

            <div className="col-md-3 px-xl-5">
              <div className=" rounded-5 d-flex align-items-center justify-content-between px-3 py-1 mb-2">
                <span className="fs-5">{item.qty}</span>
              </div>
            </div>

          </div>
        ))}
      </Dialog>

      <Dialog
        header="Delivery Address Details"
        visible={deliveryViewconfirmmodal}
        position="top"
        style={{ width: '80vw' }}
        onHide={() => setDeliveryViewconfirmmodal(false)}
      >
        {OrderDeliveryAddress.length > 0 && OrderDeliveryAddress.map((item) => (
          <>
            <div className="d-flex justify-content-between align-items-center">

              <div>
                <span className="fw-semibold">
                  {item.first_name} {item.surname}
                </span>

                {item.address_label && (
                  <span className="bg-primary text-white ms-3 p-1 px-2 rounded-3 small">
                    {item.address_label}
                  </span>
                )}
              </div>

            </div>

            <p className="mt-2 mb-3 small text-muted">
              {item.building_block_no}, {item.street_area}, <br />
              {item.landmark && `${item.landmark}, `}
              {item.city}, {item.zip_code}, {item.country}
              <br />
              Phone: {item.phone}
            </p>
          </>
        ))}
      </Dialog>



    </>
  )
}

export default ManageOrders