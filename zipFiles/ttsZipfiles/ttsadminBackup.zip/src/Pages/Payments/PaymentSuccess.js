import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { MdOutlineFileDownload } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5";
import customStyle from '../../utils/Customstyle';
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
// 
import './payment.css'

    const PaymentSuccess = () => {
    const navigate = useNavigate()
    const [selectedProducts, setSelectedProducts] = useState(null);
    const [rowClick, setRowClick] = useState(true);

    const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
    const [viewconfirmmodal, setViewconfirmmodal] = useState(false)

    const [selectedRows, setSelectedRows] = useState([]);
    const handleSelectedRowsChange = (state) => {
        setSelectedRows(state.selectedRows);
    };

    const [fetchpaymentSuccess, setFetchpaymentSuccess] = useState([])

    const fetchpayment = async () => {
        try {
            const response = await axiosInstance.get(`/get-payment-report`, {
                params: {
                    status: "paid",
                },
            });
            setFetchpaymentSuccess(response.data.data);
            console.log("response.data", response.data)
        } catch (error) {
            console.error("Error fetching data", error);
        }
    };

    useEffect(() => {
        fetchpayment()
    }, [])

    const columns = [
        {
            name: "S.no",
            selector: (row) => row.SNo,
            wrap: true,
            sortable: true,
        },
        {
            name: "Coupon Id",
            selector: (row) => row.coupon_id,
            wrap: true,
            sortable: true,
        },

        {
            name: "Coupon Type",
            selector: (row) => row.coupon_type,
            wrap: true,
            sortable: true,
            // width: "170px",
        },
        {
            name: "Delivery Charge ",
            selector: (row) => row.delivery_charge,
            wrap: true,
            sortable: true,
        },
        {
            name: "Discount Appliec",
            selector: (row) => row.discount_applied,
            wrap: true,
            sortable: true,
            // width: "200px"
        },
        {
            name: "Order Id",
            selector: (row) => row.order_id,
            wrap: true,
            sortable: true,
        },

        {
            name: "Order No",
            selector: (row) => row.order_no,
            wrap: true,
            sortable: true,
        },
        {
            name: "Order Status",
            selector: (row) => row.order_status,
            wrap: true,
            sortable: true,
        },
        {
            name: "Payment Ref",
            selector: (row) => row.payment_ref,
            wrap: true,
            sortable: true,
        },
        {
            name: "Payment Status",
            selector: (row) => row.payment_status,
            wrap: true,
            sortable: true,
        },
        {
            name: "Tax Amount",
            selector: (row) => row.tax_amount,
            wrap: true,
            sortable: true,
        },
        {
            name: "Total Amount",
            selector: (row) => row.total_amount,
            wrap: true,
            sortable: true,
        },
        {
            name: "Transaction Id",
            selector: (row) => row.transaction_id,
            wrap: true,
            sortable: true,
        },
        {
            name: "User Email",
            selector: (row) => row.user_email,
            wrap: true,
            sortable: true,
        },
        {
            name: "User Name",
            selector: (row) => row.user_name,
            wrap: true,
            sortable: true,
        },
        {
            name: "User Phone",
            selector: (row) => row.user_phone,
            wrap: true,
            sortable: true,
        },
        // {
        //     name: "Actions",
        //     cell: (row) => (
                
        //         <div className="d-flex gap-1 me-5">
        //           <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
        //                 <AiOutlineDelete size={18} color="red" onClick={() => setDeleteconfirmmodal(true)} />
        //             </div>
        //         </div>

        //     ),
        //     wrap: true,
        // },
    ];

    const products = [{
        SNo: "1",
        ProductName: "New100 ",
        Category: "$Dress",
        Createby: "27-09-2025",
        ID: "27-09-2026	",
        Stock: "10",
        Actions: ""
    }]

    const handleConfirmClose = () => {
        setDeleteconfirmmodal(false)
    }
    const handleconfirmopen = () => {

        setDeleteconfirmmodal(false)

    }
    const handleRowClick = (row) => {
    };

    const [filterText, setFilterText] = useState("");
    const searchColumns = ['coupon_id', 'coupon_type', 'delivery_charge', 'discount_applied', 'order_id', 'order_no', 'order_status','payment_ref','payment_status','tax_amount','total_amount','transaction_id','user_email','user_name','user_phone'];
    const handleFilter = (event) => {
        setFilterText(event.target.value);
    };
    const filterdata = SearchData(fetchpaymentSuccess, filterText, searchColumns);
    return (
        <>
            <div>
                {/* <h4>Payment Success Report</h4> */}
            </div>

            <div className='mt-5 box_shadow'>
                <div className='d-flex justify-content-between py-3 px-3'>
                    <div>
                        <h5> All Payment Success Report  List</h5>
                    </div>
                    <div className='text-end position-relative'>
                        <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                            size={18} />
                        <input text="search" className='form-control opacity-75' id='' name='' onChange={handleFilter} placeholder='Search Filter.........' />
                    </div>

                </div>
                  <DataTable
                    columns={columns}

                    data={filterdata}
                    customStyles={customStyle}
                    pagination
                    // selectableRows
                    className='paymentSuccessDataTable'
                    onRowClicked={handleRowClick}
                    fixedHeader
                    persistTableHead={true}
                />
            </div>

            <Dialog header="Confirm Delete Modal" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

                <div className=" form-group">
                    <p>Do you want to delete this record?</p>
                </div>
                <div className="d-flex p-3 justify-content-end mt-3">

                    <Stack direction="row" spacing={2}>
                        <Button variant="outlined" color="error"> No  </Button>&nbsp;
                    </Stack>


                    <Button variant="contained" color="success">Yes </Button>
                </div>

            </Dialog>
        </>
    )
}

export default PaymentSuccess