import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import * as yup from "yup"
import axiosInstance from '../../utils/axiosinstance';
import Toast from '../../utils/Toast';
import { useFormik } from 'formik';
import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';

const Police = () => {

  const navigate = useNavigate()

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [editmodalpolice, setEditmodalpolice] = useState(false)
  const [createmodalpolice, setCreatemodalpolice] = useState(false)
  const [deleteRow, setDeleteRow] = useState(null)

  const [selectedRows, setSelectedRows] = useState([]);
  const[fetchNote,setFetchNote]=useState([])
  console.log("fetchNoteeccccccccc",fetchNote)

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

   const fetchterms = async () => {
        try {
            const response = await axiosInstance.get(`/termsandcondition`,);
            setFetchNote(response.data);
            console.log("response.data", response.data)
        } catch (error) {
            console.error("Error fetching data", error);
        }
           };
    useEffect(() => {
        fetchterms()
    }, [])

  const columns = [
    {
      name: "S.no",
      cell: (row,index) => index + 1,
      wrap: true,
      sortable: true,
      width:"120px",
    },
    {
      name: "Terms",
      selector: (row) => row.terms,

      // cell: (row) => (
      //   <div>
      //     <button className="btn btn-primary">{row.project_id}</button>
      //   </div>
      // ),
     cell: (row) => (
    <span className=" product-name-ellipsis  ">
      {row.terms}
    </span>
     ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Date",
      selector: (row) => row.date,
      wrap: true,
      sortable: true,
    },
    {
      name: "Status ",
      selector: (row) => row.status,
       cell: (row) => (
    <span className=" product-name-ellipsis  ">
      {row.status}
    </span>
  ),
      wrap: true,
      sortable: true,
    },


    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}onClick={() => handleEdit(row)}>
            <LuPencilLine size={16} color="red"  />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}onClick={() =>{setDeleteRow(row.id); setDeleteconfirmmodal(true);}}>
            <AiOutlineDelete size={18} color="red"  />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];
 const handleConfirmCloseDltTerms = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopenDltterms = async() => {
     try {
            await axiosInstance.delete(`/termsandcondition/${deleteRow}`)
            Toast({ message: "Successfully Deleted", type: "success" });

            fetchterms()
        } catch (error) {
            Toast({ message: "Error to taken project", type: "error" });

            // console.log("error", error)
        }

    setDeleteconfirmmodal(false)
     }

   const handleEdit = (row) => {
  formik1.setValues({
    terms: row.terms,

    date: row.date,
    status: row.status,
  
    id: row.id,
  });
  setEditmodalpolice(true);
};

  const onSubmitEditTerms = async (values) => {
    try {
      const response = await axiosInstance.post(`/termsandcondition/${values.id}?_method=PUT`, values, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log("response", response)
      Toast({ message: "Successfully Updated", type: "success" });


      formik1.resetForm()
      setEditmodalpolice(false)
    

      fetchterms()

    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });

      // console.log("Suberror", error)
    }
  }
const formik1 = useFormik(
    {
      initialValues: {
        terms: "",
        date: "",
        status: "",
      },
      validationSchema: yup.object().shape({
        terms: yup.string().required("terms is required!"),
        date: yup.string().required("date is required!"),

        status: yup.string().required("status is required!"),
      }),
      onSubmit:onSubmitEditTerms,
    }
  )
 const onSubmit = async (values) => {
    try {
      const response = await axiosInstance.post(`/termsandcondition`, values, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log("response", response)
      Toast({ message: "Successfully Created", type: "success" });


      formik.resetForm()
      setCreatemodalpolice(false)
    

      fetchterms()

    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });

      // console.log("Suberror", error)
    }
  }


  const formik = useFormik(
    {
      initialValues: {
        terms: "",
        date: "",
        status: "",
      },
      validationSchema: yup.object().shape({
        terms: yup.string().required("terms is required!"),
        date: yup.string().required("date is required!"),

        status: yup.string().required("status is required!"),
      }),
      onSubmit,
    }
  )
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['terms', 'date', 'status', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
    const filterdata = SearchData(fetchNote, filterText, searchColumns);
  return (
    <>
    <div className='container'>
          <div className='mt-3 box_shadow  bg-white rounded-2'>
                          <div className='d-flex justify-content-between'>
                            <div className='pt-3 px-3'>
                            <h5>All Police List</h5>
                           </div>
                             <div className='d-flex  pt-2 pe-2'>
                             <div className='text-end position-relative px-2 pt-1'>
                            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                              size={18} />
                            <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
                          </div>
                             <div className='mb-3 pt-1 text-end'onClick={() => setCreatemodalpolice(true)}>
                         <button className='btn btn-danger bg_color p-0 px-2 py-1' > + Add</button>
                        </div>
                          </div>
                        </div>
          
               <div className='pt-2'>
    


        <DataTable
          columns={columns}
          
          data={filterdata}
         
          customStyles={customStyle}
          pagination
          // selectableRows
          onRowClicked={handleRowClick}
          fixedHeader
          persistTableHead={true}
        />
      </div>
      </div>
      </div>

      <Dialog header="Confirm Edit " visible={editmodalpolice} position="top" style={{ width: '50vw' }} onHide={() => { if (!editmodalpolice) return; setEditmodalpolice(false); }}>

        {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
         <form onSubmit={formik1.handleSubmit} autoComplete="off">
          <div className='row py-4'>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <label htmlFor="terms" className='form-label text-muted'>Terms</label>
                <input
                  type="text"
                  class="form-control"
                  id="terms"
                  name="terms"
                  placeholder='Enter Terms'
                  value={formik1.values.terms}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.terms && formik1.touched.terms && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.terms}
                  </p>
                )}
              </div>


              <div className='mb-3 ' >
                <label htmlFor="date" className='form-label text-muted'> Date </label>
                <input
                  type="date"
                  class="form-control"
                  id="date"
                  name="date"
                  placeholder='Enter date'
                  value={formik1.values.date}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.date && formik1.touched.date && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.date}
                  </p>
                )}
              </div>


            </div>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3' >
                <label htmlFor="status" className='form-label text-muted'>  Enter Status</label>
                <input
                  type="text"
                  class="form-control opacite-75"
                  id="status"
                  name="status"
                  placeholder='Enter text'
                  value={formik1.values.status}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.status && formik1.touched.status && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.status}
                  </p>
                )}
              </div>

            </div>
            <div className='text-end'>
              <Button variant="outlined" color="error" onClick={()=>setEditmodalpolice(false)}> Cancel</Button>

              <Button type='submit' variant="contained" className='mx-2' color="success">Update </Button>&nbsp;
            </div>

          </div>
        </form>
      </Dialog>

      <Dialog header="Confirm Created" visible={createmodalpolice} position="top" style={{ width: '50vw' }} onHide={() => { if (!createmodalpolice) return; setCreatemodalpolice(false); }}>

        {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className='row py-4'>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <label htmlFor="terms" className='form-label text-muted'>Terms</label>
                <input
                  type="text"
                  class="form-control"
                  id="terms"
                  name="terms"
                  placeholder='Enter Terms'
                  value={formik.values.terms}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.terms && formik.touched.terms && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.terms}
                  </p>
                )}
              </div>


              <div className='mb-3 ' >
                <label htmlFor="date" className='form-label text-muted'> Date </label>
                <input
                  type="date"
                  class="form-control"
                  id="date"
                  name="date"
                  placeholder='Enter date'
                  value={formik.values.date}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.date && formik.touched.date && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.date}
                  </p>
                )}
              </div>


            </div>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3' >
                <label htmlFor="status" className='form-label text-muted'>  Enter Status</label>
                <input
                  type="text"
                  class="form-control opacite-75"
                  id="status"
                  name="status"
                  placeholder='Enter text'
                  value={formik.values.status}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.status && formik.touched.status && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.status}
                  </p>
                )}
              </div>

            </div>
            <div className='text-end'>
              <Button variant="outlined" color="error" onClick={()=>setCreatemodalpolice(false)}> Cancel</Button>

              <Button type='submit' variant="contained" className='mx-2' color="success">Save </Button>&nbsp;
            </div>

          </div>
        </form>
      </Dialog>

      <Dialog header="Confirm Delete " visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={()=>handleConfirmCloseDltTerms()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={()=>handleconfirmopenDltterms(deleteRow)}>Yes </Button>
        </div>

      </Dialog>

    </>
  )
}

export default Police