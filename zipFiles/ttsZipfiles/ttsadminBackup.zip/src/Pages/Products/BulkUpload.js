import React, { useEffect, useMemo, useRef, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import { IoMdCloudDownload } from "react-icons/io";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import axiosInstance from '../../utils/axiosinstance';
import { useFormik } from 'formik';
import * as yup from "yup"
import Toast from '../../utils/Toast';
import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';
// 
import ExcelJS from "exceljs";
import EditDialog from './EditBulkUpload';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import BulkUploadErrorPdf from './BulkUploadErrorPdf';

// import jsPDF from "jspdf";
// import html2canvas from "html2canvas";

import './bulkupload.css'

const BulkUpload = () => {





  const navigate = useNavigate()
  const [fetchproducts, setFetchproducts] = useState([])

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [selectedRowId, setSelectedRowId] = useState(null)

  const [selectedRows, setSelectedRows] = useState([]);

  const [excelData, setExcelData] = useState(null);


  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products`, {
        params: {
          lang: "all",
        },
      });
      setFetchproducts(response.data.data);
      console.log("response.data_fetchdata", response.data.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchproduct()
  }, [])

  // 
  const [visible, setVisible] = useState(false);
  const [editetData, setEditedData] = useState(null)
  const [selectedRow, setSelectedRow] = useState(null);

  const [rowIndex, setRowindex] = useState();


  const contentRef = useRef();
  const [dataForPdf, setDataForPdf] = useState()

  console.log("editetDataj", editetData);

  console.log("excelData final", excelData)



  const onEditClick = (row, index) => {
    setRowindex(index)
    setSelectedRow(row);
    console.log("rrrr", row);

    setVisible(true);
  };

  // const [name_mismatch, setName_mismatch] = useState(false)
  // console.log("name_mismatch", name_mismatch);

  const name_mismatch = useMemo(() => {
    if (!excelData || !fetchproducts) return false;

    return excelData.some(row =>
      fetchproducts.some(item =>
        item?.translations?.en?.product_name === row.product_name ||
        item?.translations?.de?.product_name === row.product_name
      )
    );
  }, [excelData, fetchproducts]);



  const conditionalRowStyles = [
    {
      when: (row) =>
        fetchproducts?.some(
          (item) =>
            // item.product_lable_id === row.product_lable_id ||
            item?.translations?.en?.product_name === row.product_name ||
            item?.translations?.de?.product_name === row.product_name
        ),
      style: {
        backgroundColor: "#ffe6e6",
        color: "red",
      },
    },
  ];

  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
      width: "100px",
    },
    {
      name: "Product Name",
      selector: (row) => row.product_name,
      wrap: true,
      sortable: true,
      width: "150px",
    },
    // {
    //   name: "Category",
    //   selector: (row) => row.pro_category,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Brand",
      selector: (row) => row.brand,
      wrap: true,
      sortable: true,
    },
    {
      name: "weight",
      selector: (row) => row.weight,
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "Product Code",
    //   selector: (row) => row.product_lable_id,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "SKU",
      selector: (row) => row.pro_sku,
      wrap: true,
      sortable: true,
    },
    {
      name: "Price ($)",
      selector: (row) => row.price,
      wrap: true,
      sortable: true,
    },
    {
      name: "Stock Qty",
      selector: (row) => row.stock,
      wrap: true,
      sortable: true,
      width: "125px",
    },
    {
      name: "Low Stock Alert",
      selector: (row) => row.low_stk_alert,
      wrap: true,
      sortable: true,
      width: "180px",
    },
    {
      name: "Status",
      selector: (row) => row.status,
      wrap: true,
      sortable: true,
    },
    {
      name: "Actions",
      cell: (row, index) => {
        const canDelete = fetchproducts?.some(
          (item) =>
            // item.product_lable_id === row.product_lable_id ||
            item?.translations?.en?.product_name === row.product_name ||
            item?.translations?.de?.product_name === row.product_name
        )
        // setName_mismatch(canDelete);

        return (
          <div className="d-flex gap-1 me-5">
            {/* {canDelete && */}
            <>
              <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
                <LuPencilLine size={16} color="red"
                  onClick={() => onEditClick(row, index)}
                // onClick={() => editbulkupload(row)}
                />
              </div>
            </>
            {/* } */}
            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <AiOutlineDelete size={18} color="red" onClick={() => {
                setSelectedRowId(index);
                // handleconfirmopenDltpdt(index);
                setDeleteconfirmmodal(true);
              }} />
            </div>
          </div>

        )

      },
      wrap: true,
    },
  ];

  const fileInputRef = useRef();

  const handleChangeFileChange = (event) => {
    const selectedFile = event.target.files[0];
    setFile(selectedFile);
    handleExcelData(selectedFile);
    event.target.value = null;
  }

  const handleConfirmCloseDltPdt = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopenDltpdt = async (data) => {
    console.log("index", data);

    console.log("selectedRowId", data);

    try {

      const deleted = excelData.filter((item, index) => index !== data)
      setExcelData(deleted);
      localStorage.setItem("bulkuploadExcelData", JSON.stringify(deleted));
      console.log("deleted", deleted);
      Toast({ message: "Successfully Deleted", type: "success" });

    } catch (error) {
      console.error("Delete error:", error);
    } finally {
      setDeleteconfirmmodal(false);
    }
  }

  // const exportToExcel = async () => {
  //   if (!fetchproducts?.length) return;

  //   const firstRow = fetchproducts[0];

  //   console.log("firstRow",firstRow);


  //   const workbook = new ExcelJS.Workbook();
  //   const worksheet = workbook.addWorksheet("filterdata");

  //   worksheet.columns = Object.keys(firstRow).map((key) => ({

  //     header: key,
  //     key: key,
  //     width: 25,
  //   }));


  //   const buffer = await workbook.xlsx.writeBuffer();

  //   saveAs(
  //     new Blob([buffer], {
  //       type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  //     }),
  //     "filterdata.xlsx"
  //   );
  // };
  const flattenProduct = (product) => {
    const { translations, ...rest } = product;

    const enTranslations = translations?.en || {};

    const flattenedEn = Object.fromEntries(
      Object.keys(enTranslations).map((key) => [key, ""])
    );

    return {
      ...rest,
      ...flattenedEn,
    };
  };

  const exportToExcel = async () => {
    if (!fetchproducts?.length) return;

    const flattenedData = flattenProduct(fetchproducts[0]);
    const { id, category_name, subcategory_name, ...newData } = flattenedData;

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("filterdata");

    worksheet.columns = [
      { header: "language", key: "language", width: 20 },
      ...Object.keys(newData).map((key) => ({
        header: key,
        key,
        width: 25,
      })),
    ];


    const buffer = await workbook.xlsx.writeBuffer();

    saveAs(
      new Blob([buffer], {
        type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      }),
      "product header.xlsx"
    );
  };


  // const exportToExcel = async () => {
  //   if (!fetchproducts?.length) return;

  //   const flattenedData = flattenProduct(fetchproducts[0]);
  //   const { id, ...newData } = flattenedData;

  //   const workbook = new ExcelJS.Workbook();
  //   const worksheet = workbook.addWorksheet("filterdata");

  //   const columns = [
  //     { header: "Language", key: "language", width: 20 },
  //     ...Object.keys(newData).map((key) => ({
  //       header: key,
  //       key: key,
  //       width: 25,
  //     })),
  //   ];

  //   worksheet.columns = columns;

  //   worksheet.addRow({
  //     language: flattenedData.language || "N/A",
  //     ...newData,
  //   });

  //   const buffer = await workbook.xlsx.writeBuffer();

  //   saveAs(
  //     new Blob([buffer], {
  //       type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  //     }),
  //     "filterdata.xlsx"
  //   );
  // };


  // const exportToExcel = async () => {
  //   if (!fetchproducts?.length) return;

  //   const flattenedData = flattenProduct(fetchproducts[0]);

  //   const workbook = new ExcelJS.Workbook();
  //   const worksheet = workbook.addWorksheet("filterdata");
  //   const { id, ...newData } = flattenedData

  //   worksheet.columns = Object.keys(newData).map((key) => ({
  //     header: key,
  //     key: key,
  //     width: 25,
  //   }));


  //   const buffer = await workbook.xlsx.writeBuffer();

  //   saveAs(
  //     new Blob([buffer], {
  //       type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  //     }),
  //     "filterdata.xlsx"
  //   );
  // };


  // const exportToExcel = async () => {
  //   if (!fetchproducts?.length) return;

  //   const flattenedData = fetchproducts.map(flattenProduct);

  //   const workbook = new ExcelJS.Workbook();
  //   const worksheet = workbook.addWorksheet("filterdata");

  //   // Headers from flattened keys
  //   worksheet.columns = Object.keys(flattenedData[0]).map((key) => ({
  //     header: key,
  //     key: key,
  //     width: 25,
  //   }));

  //   // Add rows
  //   flattenedData.forEach((row) => {
  //     worksheet.addRow(row);
  //   });

  //   const buffer = await workbook.xlsx.writeBuffer();

  //   saveAs(
  //     new Blob([buffer], {
  //       type: "application/vnd.openxmlformats-officedsheetml.sheet",
  //     }),
  //     "filterdata.xlsx"
  //   );
  // };


  const [file, setFile] = useState(null);


  // for excel validation




  // set the validated data 






  const EXPECTED_IMAGES_PER_ROW = 2;
  const IMAGE_COLUMNS = ["image", "thumbnail"];

  const [excelValError, setExcelValError] = useState();
  console.log("excelValError", excelValError);
  const [errorMessage, setErrorMessage] = useState();
  const [errorMessageModal, setErrorMessageModal] = useState(false);




  const handleExcelData = (file) => {
    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const buffer = e.target.result;

        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(buffer);

        const worksheet = workbook.worksheets[0];
        if (!worksheet) {
          throw new Error("Worksheet not found");
        }

        const headerRow = worksheet.getRow(1);
        const headers = [];

        headerRow.eachCell({ includeEmpty: true }, (cell, col) => {
          headers[col] = String(cell.value || "").trim();
        });

        const rows = [];

        worksheet.eachRow((row, rowNumber) => {
          if (rowNumber === 1) return;

          const rowData = {};

          headers.forEach((header, col) => {
            if (!header) return;
            rowData[header] = row.getCell(col).value ?? "";
          });

          rows.push(rowData);
        });

        if (rows.length === 0) {
          throw new Error("No data rows found");
        }

        const images = worksheet.getImages();

        const expectedImageCount =
          rows.length * EXPECTED_IMAGES_PER_ROW;

        if (images.length !== expectedImageCount) {
          throw new Error(
            `Image count mismatch. Expected ${expectedImageCount}, found ${images.length}`
          );
        }

        let imgIndex = 0;

        rows.forEach((row, rowIndex) => {
          IMAGE_COLUMNS.forEach((colName) => {
            const imgRef = images[imgIndex];
            if (!imgRef) {
              throw new Error(
                `Missing image for row ${rowIndex + 2}`
              );
            }

            const image = workbook.getImage(imgRef.imageId);
            if (!image?.buffer) {
              throw new Error(
                `Invalid image buffer at row ${rowIndex + 2}`
              );
            }

            const blob = new Blob([image.buffer], {
              type: `image/${image.extension}`,
            });

            row[colName] = new File(
              [blob],
              `row-${rowIndex + 2}-${colName}.${image.extension}`,
              { type: blob.type }
            );

            imgIndex++;
          });
        });

        console.log("FINAL IMPORT DATA:", rows);



        // ..........


        const productExcelSchema = yup.object({
          product_name: yup.string().required(),
          brand: yup.string().required(),
          pro_category: yup.number().required(),
          pro_sub_category: yup.number().required(),
          attribute: yup.string().required(),
          attribute_type: yup.string().required(),
          color: yup.string().nullable(),

          tag_no: yup.string().required(),
          tag: yup.string().required(),
          stock: yup.number().required().min(0),
          low_stk_alert: yup.number()
            .required()
            .min(0)
            .test(
              "low-stock-less-than-stock",
              "Low stock alert must be less than stock",
              function (value) {
                return value < this.parent.stock;
              }
            ),

          pro_sku: yup.string().required(),
          related_pro: yup.string().required(),
          mrp: yup.number().required().min(0),
          price: yup.number().required().min(0),

          discount_type: yup.string().required(),
          discount: yup.string().required(),

          min_purchase_qty: yup.number().required().min(1),
          max_purchase_qty: yup.number()
            .required()
            .min(yup.ref("min_purchase_qty")),

          tax: yup.number().required().min(0),
          expired: yup.date().required(),

          status: yup.string().required(),
          meta_title: yup.string().required(),
          meta_description: yup.string().required(),

          description: yup.string().required(),
          additional_info: yup.string().required(),

          seller: yup.string().required(),
          material_type: yup.string().required(),
          product_lable_id: yup.string().required(),
          weight: yup.string().required(),
          language: yup.string().required(),


          thumbnail: yup.mixed().required(),
          image: yup.mixed().required(),

        });

        // {
        //   formik.errors.discount && formik.touched.discount && (
        //     <p style={{ color: "red", fontSize: "12px" }}>
        //       {formik.errors.discount}
        //     </p>
        //   )
        // }

        //......

        const validatedRows = [];
        const errors = [];


        for (let i = 0; i < rows.length; i++) {
          try {
            const cleanRow = await productExcelSchema.validate(rows[i], {
              abortEarly: false,
              stripUnknown: true,
            });

            validatedRows.push(cleanRow);
          } catch (err) {
            console.log("err_", err);

            errors.push({
              row: i + 2,
              errors: err.inner.map(e => ({
                field: e.path,
                message: e.message,
              })),
            });
          }
        }
        console.log("errors_", errors);


        if (errors.length > 0) {
          setErrorMessageModal(true)
          console.error("Excel validation failed:", errors);
          setErrorMessage({
            type: "EXCEL_VALIDATION_FAILED",
            message: "Excel validation failed",
            rows: errors?.map((rowError) => ({
              row: rowError.row,
              errors: rowError.errors.map((e, index) => ({
                index: index + 1,
                field: e.field,
                message: e.message
              }))
            }))
          });



          // setErrorMessage(
          //   "Excel validation failed.\n\n" +
          //   errors
          //     .map(
          //       (rowError, i) =>
          //         `Row ${rowError.row}:\n` +
          //         rowError.errors
          //           .map(
          //             (e, j) => `  ${j + 1}. ${e.field}: ${e.message}`
          //           )
          //           .join("\n")
          //     )
          //     .join("\n\n")
          // )

          // setErrorMessage(errorMessage);
          console.log("errorMessage", errorMessage);


          setExcelValError(errors)
          return;
          // }
          // catch(err){
          //   console.error(err);
          // }
          // finally{
          //   // setErrorMessageModal(false);
          // }
        }

        setExcelData(validatedRows);


        localStorage.setItem("bulkuploadExcelData", JSON.stringify(validatedRows));
        console.log("validatedRows", validatedRows);
        // const local = localStorage.setItem('excelData', JSON.stringify(validatedRows) || {});
        // console.log("local",local);

        // localStorage.setItem("excelData", [validatedRows]);
        console.log("validatedRows", validatedRows);

        // setExcelData(rows);

      } catch (err) {
        console.error("Excel import failed:", err.message);
        alert(err.message);
      }
      finally {

      }
    };

    reader.readAsArrayBuffer(file);
  };


  console.log("errorMessage_hhh", errorMessage);



  const [filterText, setFilterText] = useState("");
  const searchColumns = ['product_name', 'pro_category', 'brand', 'pro_sku', 'price', 'stock', 'low_stk_alert', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };

  console.log(editetData);
  if (editetData !== null) {

  }


  const filterdata = SearchData(excelData, filterText, searchColumns);

  console.log("hhhh", filterdata);





  // const onSubmit = async (values) => {
  //   try {
  //     const formData = new FormData();

  //     if (values.file) {
  //       formData.append("file", values.file);
  //     }

  //     Object.keys(values).forEach((key) => {
  //       if (key !== "file") {
  //         formData.append(key, values[key]);
  //       }
  //     });

  //     const response = await axiosInstance.post(
  //       `/products/bulk-upload`,
  //       formData,
  //       {
  //         headers: {
  //           "Content-Type": "multipart/form-data",
  //         },
  //       }
  //     );

  //     console.log("response", response);
  //     Toast({ message: "Successfully Created", type: "success" });

  //     formik.resetForm();
  //     fetchproduct()


  //   } catch (error) {
  //     console.error("Upload error:", error.response?.data || error);
  //     Toast({ message: "Error uploading file", type: "error" });
  //   }
  // };

  // const formik = useFormik(
  //   {
  //     initialValues: {
  //       file: "",
  //     },
  //     // validationSchema: yup.object().shape({
  //     //     file: yup.string().required("file is required!"),
  //     //   }),
  //     onSubmit,
  //   }
  // )

  const token = localStorage.getItem("tokenAdmin");


  const uploadToApi = async (data) => {
    console.log("dataapi", data);


    excelData.forEach((row, i) => {
      console.log(i, row.image instanceof File, row.thumbnail instanceof File);
    });

    if (!Array.isArray(data) || data.length === 0) {
      console.error("Invalid or empty data");
      return;
    }

    const formData = new FormData();

    data.forEach((row, rowIndex) => {
      Object.entries(row).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          formData.append(`products[${rowIndex}][${key}]`, value);
        }
      });
    });
    for (let pair of formData.entries()) {
      console.log(pair[0], pair[1], pair[1] instanceof File);
    }

    try {
      const response = await axiosInstance.post(
        "/products/bulk-upload",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      // fileInputRef = null;
      setExcelData(null);
      Toast({ message: "Successfully Created", type: "success" });

      localStorage.removeItem("bulkuploadExcelData")


      console.log("Upload success:", response.data);
    } catch (err) {
      console.error("Upload failed:", err);
      // throw err;
    }
  };

  console.log("errorMessage", errorMessage);

  console.log("excelData_edited", excelData);


  // Bulk Upload Error Download - _pdf_



  const downloadPdf = () => {
    const input = contentRef.current;

    html2canvas(input, { scale: 3 }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");

      const pdf = new jsPDF("p", "mm", "a4");

      const pageWidth = 210;
      const pageHeight = 297;

      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      // PAGE 1
      pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      // MULTIPLE PAGES
      while (heightLeft > 0) {
        pdf.addPage();
        position = -(imgHeight - heightLeft);
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }


      pdf.save("BulkValidationFailed.pdf");

    });
  };

  const [pdfDownBtn, setPdfDownBtn] = useState(false);

  useEffect(() => {
    if (dataForPdf && pdfDownBtn) {
      setTimeout(() => {
        downloadPdf();
        setVisible(false);
      }, 500);
    }
  }, [dataForPdf]);

  const inData = async (mess) => {
    try {
      console.log("errorMessage_pdf__indaaaa", mess);
      setDataForPdf(mess)
      console.log("errorMessage_pdf__", errorMessage);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  }

  useEffect(() => {
    inData(errorMessage);
    console.log("errorMessage_pdf", errorMessage);
    console.log("dataForPdf_pdf", dataForPdf);
  }, [errorMessage])

  useEffect(() => {
    const bulkuploadExcelData = JSON.parse(localStorage.getItem("bulkuploadExcelData"));
    setExcelData(bulkuploadExcelData);
    console.log("bulkuploadExcelData", bulkuploadExcelData);
  }, [])



  return (
    <>
      <div className="d-flex align-items-center gap-2">
        <button className="btn btn-primary d-flex align-items-center" onClick={exportToExcel}>
          <IoMdCloudDownload className="me-1" />
          Excel Format
        </button>

        <form
          // onSubmit={formik.handleSubmit}
          autoComplete="off" className="d-flex align-items-center gap-2">
          {/* 
          <input
            type="file"
            name="file"
            accept=".xlsx, .csv"
            className="form-control"
            onChange={(event) => {
              const selectedFile = event.target.files[0];
              setFile(selectedFile);
              handleExcelData(selectedFile);
              // handleExcelData(event.currentTarget.files[0]);
              // console.log("datasfromexcel", event.currentTarget.files[0]);
            }}
          /> */}


          <input
            ref={fileInputRef}
            type="file"
            name="file"
            accept=".xlsx,.csv"
            className="form-control"
            onChange={handleChangeFileChange}
          />
        </form>
      </div>

      <div className='mt-5 box_shadow'>
        <div className='d-flex justify-content-between py-3  px-3'>
          <div>
            <h5> Product Bulk Upload</h5>
          </div>
          <div className='d-flex gap-3'>
            <div className='text-end position-relative'>
              <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                size={18} />
              <input text="search" className='form-control opacity-75' id='' name='' onChange={handleFilter} placeholder='Search Filter.........' />
            </div>
            {/* <button
              className={`btn btn-outline-success ${name_mismatch ? "disabled" : ""}`}
              disabled={name_mismatch || excelData === null ? true : false}
              onClick={() => { uploadToApi(excelData) }}>Upload</button> */}
          </div>
        </div>
        <DataTable
          columns={columns}
          data={filterdata ? filterdata : []}
          customStyles={customStyle}
          pagination
          conditionalRowStyles={conditionalRowStyles}
          // selectableRows
          // onRowClicked={handleRowClick}
          fixedHeader
          persistTableHead={true}
          style={{ height: "10px" }}
          className='bulkUploadDataTable'
        />

        <div className='d-flex justify-content-end'>
          <button
            className={`btn btn-outline-success m-3 ${name_mismatch ? "disabled" : ""}`}
            disabled={name_mismatch || excelData === null ? true : false}
            onClick={() => { uploadToApi(excelData); console.log("excelData_log", excelData) }}>
            Submit
          </button>
        </div>


      </div>
      <Dialog header="Confirm Delete" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmCloseDltPdt()}> No  </Button>&nbsp;
          </Stack>
          <Button variant="contained" color="success" onClick={() => handleconfirmopenDltpdt(selectedRowId)}>Yes </Button>
        </div>

      </Dialog>
      {errorMessage &&

        <Dialog header="The uploaded Excel is failed in Validation"
          visible={errorMessageModal}
          position="top"
          style={{ width: '60vw' }} onHide={() => {
            if (!errorMessageModal)
              return; setErrorMessageModal(false);
          }}>
          {/* 
          {errorMessage?.rows?.map((rowItem, rowIndex) => (
            <div key={rowIndex}>
              <h4>Row: {rowItem.row -1}</h4>

              {rowItem.errors.map((err, errIndex) => (
                <p key={errIndex}>
                  <strong>{err.field}</strong>: {err.message}
                </p>
              ))}
            </div>
          ))} */}

          {errorMessage?.rows.map((rowItem, rowIndex) => (
            <>
              <div key={rowIndex}>
                <h4> Row: {rowItem.row - 1} </h4>

                {rowItem?.errors.map((rowField, rowFieldIndex) => (
                  <p key={rowFieldIndex}>
                    <strong> {rowField.field} </strong>: {rowField.message}
                  </p>
                ))}
              </div>
              <hr className='text-prime' style={{ color: "red", backgroundColor: "black" }} />



            </>

          ))}


          {/* <div className=" form-group">
            <p>Do you want to delete this record?</p>
          </div>
          <div className="d-flex p-3 justify-content-end mt-3">
            <Stack direction="row" spacing={2}>                <p>{value.rows}</p>
                <p>{value.rows}</p>

              <Button variant="outlined" color="error" onClick={() => handleConfirmCloseDltPdt()}> No  </Button>&nbsp;
            </Stack>
            <Button variant="contained" color="success" onClick={() => handleconfirmopenDltpdt(selectedRowId)}>Yes </Button>
          </div> */}

          <Button onClick={downloadPdf} > Down </Button>

        </Dialog>
      }





      <EditDialog
        visible={visible}
        data={selectedRow}
        onHide={() => setVisible(false)}
        setExcelData={setExcelData}
        excelData={excelData}
        rowIndex={rowIndex}
        setVisible={setVisible}
      // style={{zIndex:"100"}}

      // onSave={(updatedData) => {
      //   console.log("updatedData", updatedData);
      //   setEditedData(updatedData)
      //   setVisible(false);
      // }}

      // onSave={(updatedData) => {
      //   updatedData || console.log("updatedDatatt", updatedData)
      //   setVisible(false);
      // }}
      />

      <div
        style={{ position: "absolute", left: "-9999px", top: 0 }}
      >

        <BulkUploadErrorPdf ref={contentRef}
          data={dataForPdf}
        />
      </div>


    </>
  )
}

export default BulkUpload