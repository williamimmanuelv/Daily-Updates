import React, { forwardRef } from "react";


const BulkUploadErrorPdf = forwardRef((props, ref) => {

  const { data } = props;
  console.log("errorpdf", data);

  const itemsPerPage = 1;

  const pages = [];
  for (let i = 0; i < data?.rows?.length; i += itemsPerPage) {
    pages.push(data?.rows?.slice(i, i + itemsPerPage));
  }
  return (
    <>

      <div ref={ref} style={{ padding: "40px", background: "#fff", width: "800px" }}>
        {pages.map((items, pageIndex) => (
          <div key={pageIndex} style={{ pageBreakAfter: "always" }}>

            {pageIndex === 0 && (
              <div>
                {data?.rows.map((rowData, rowIndex) =>
                  <div key={rowIndex}>
                    <h4> Row: {rowData.row - 1} </h4>
                    {rowData?.errors.map((errorData, errorIndex) => (
                      <>
                        <strong key={errorIndex}> Field: {errorData.field} </strong> <p> {errorData.message}</p>
                      </>

                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </>
  )
});

export default BulkUploadErrorPdf;







