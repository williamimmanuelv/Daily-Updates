import React, { useEffect, useState } from 'react'
import tshirt from "../../Assets/t-shirt.png"
import { BiCloudUpload } from "react-icons/bi";
import { ColorPicker } from 'primereact/colorpicker';
import { Checkbox } from "primereact/checkbox";
import { Editor } from "primereact/editor";
import { useFormik } from 'formik';
import * as yup from "yup"
import axios from 'axios';
import { base_url, img_path } from '../../Api/BaseUrl';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosinstance';
import Toast from '../../utils/Toast';
import { FileUpload } from 'primereact/fileupload';
import { RadioButton } from 'primereact/radiobutton';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';

const CreateProduct = () => {
  const navigate = useNavigate()
  const [fetchcategory, setFetchcategory] = useState([])
  console.log("fetchcategorysssss", fetchcategory)

  const [fetchsubcategory, setFetchsubcategory] = useState([])
  console.log("fetchsubcategoryyyyyy", fetchsubcategory)

  const [fetchAttribute, setFetchAttribute] = useState([])
  console.log("fetchAttributeeee", fetchAttribute)

  const [checked, setChecked] = useState(false);

  const [imagePreview, setImagePreview] = useState(null);
  const [serverImage, setServerImage] = useState(null);

  const token = localStorage.getItem("tokenAdmin")

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImagePreview(URL.createObjectURL(file));
      formik.setFieldValue("image", file);
    } else {
      setImagePreview(null);
      formik.setFieldValue("image", null);
    }
  };
  console.log("imagepreview", imagePreview)

  const [imagePreviewThumb, setImagePreviewThumb] = useState([]);


  // const handleImageChangethumb = (e) => {
  //   const newFiles = Array.from(e.target.files);

  //   if (newFiles.length === 0) return;

  //   const allFiles = [...(formik.values.thumbnail || []), ...newFiles];

  //   const newPreviews = newFiles.map(file => URL.createObjectURL(file));
  //   const allPreviews = [...imagePreviewThumb, ...newPreviews];

  //   setImagePreviewThumb(allPreviews);
  //   formik.setFieldValue("thumbnail", allFiles);

  //   e.target.value = null;
  // };

  const handleImageChangethumb = (e) => {
    const files = Array.from(e.target.files);

    if (files.length === 0) {
      setImagePreviewThumb([]);
      formik.setFieldValue("thumbnail", []);
      return;
    }

    const previewUrls = files.map(file => URL.createObjectURL(file));

    setImagePreviewThumb(previewUrls);
    formik.setFieldValue("thumbnail", files);
  };

  console.log("imagePreviewThumb", imagePreviewThumb)

  //  const handleLanguage = (e, lang) => {
  //   e.preventDefault();
  //   setLanguage(lang)
  //   formik.setFieldValue("language_code", lang);

  // };
  const [formDataByLang, setFormDataByLang] = useState({
    en: {},
    de: {}
  });
  const handleLanguage = (e, lang) => {
    // e.preventDefault();
    // setLanguage(lang);
    // formik.setFieldValue("language_code", lang);
    // formik.setFieldTouched("language_code", true);

    e.preventDefault();

    setFormDataByLang(prev => ({
      ...prev,
      [language]: formik.values   // save current language data
    }));

    setLanguage(lang);

    formik.setValues(formDataByLang[lang] || {
      ...formik.initialValues,
      language_code: lang
    });
  };

  // const fetch = async () => {
  //   try {
  //     const response = await axiosInstance.get(`/categories`,);
  //     setFetchcategory(response.data);
  //     console.log("response.data", response.data)
  //   } catch (error) {
  //     console.error("Error fetching data", error);
  //   }

  // };
  // useEffect(() => {
  //   fetch()
  // }, [])
  const [language, setLanguage] = useState("en");
  const fetch = async () => {
    try {
      const response = await axiosInstance.get(`/categories`, {
        params: {
          lang: language,
        },
      });
      setFetchcategory(response.data.data);
      console.log("response.data", response.data.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetch()
  }, [language])


  const fetchsubcate = async () => {
    try {
      const response = await axiosInstance.get(`/subcategories`, {
        params: {
          lang: language,
        },
      });
      setFetchsubcategory(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchsubcate()
  }, [language])

  const fetchAttributes = async () => {
    try {
      const response = await axiosInstance.get(`/attributes`, {
        params: {
          lang: language,
        },
      });
      setFetchAttribute(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchAttributes()
  }, [])
  const onSubmit = async (values) => {
    console.log("values", values)
    try {
      const formData = new FormData();

      formData.append("product_name", values.product_name);
      formData.append("brand", values.brand);
      formData.append("pro_category", values.pro_category);
      formData.append("pro_sub_category", values.pro_sub_category);
      formData.append("attribute", values.attribute);
      formData.append("attribute_type", values.attribute_type);
      formData.append("color", values.color);
      formData.append("tag_no", values.tag_no);
      formData.append("tag", values.tag);
      formData.append("stock", values.stock);
      formData.append("low_stk_alert", values.low_stk_alert);
      formData.append("pro_sku", values.pro_sku);
      formData.append("related_pro", values.related_pro);
      formData.append("mrp", values.mrp);
      formData.append("price", values.price);
      formData.append("discount_type", values.discount_type);
      formData.append("min_purchase_qty", values.min_purchase_qty);
      formData.append("max_purchase_qty", values.max_purchase_qty);
      formData.append("tax", values.tax);
      formData.append("expired", values.expired);
      formData.append("status", values.status);
      formData.append("meta_title", values.meta_title);
      formData.append("meta_description", values.meta_description);
      formData.append("description", values.description);
      formData.append("discount", values.discount);
      formData.append("additional_info", values.additional_info);
      formData.append("addtional_gender", values.addtional_gender);
      formData.append("weight", values.weight);
      formData.append("product_lable_id", values.product_lable_id);
      formData.append("seller", values.seller);
      formData.append("material_type", values.material_type);
      formData.append("language_code", values.language_code);

      if (values.image) {
        formData.append("image", values.image);
      }

      Object.keys(values).forEach((key) => {
        if (key !== "thumbnail") {
          formData.append(key, values[key]);
          console.log("values", formData);

        }
      });

      if (values.thumbnail && values.thumbnail.length > 0) {
        values.thumbnail.forEach((file, index) => {
          formData.append("thumbnail[]", file);
          console.log("thumbnail[]", file);

        });
      }

      const kk = Object.entries(formData)
      console.log("formDatssa", kk);
      console.log("formData", formData);

      const response = await axios.post(`${base_url}/products`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Accept: "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      Toast({ message: response.data.message, type: "success" });

      console.log("Success:", response.data);
      setImagePreview(null);
      setServerImage(response.data.thumbnails);
      formik.resetForm();
      navigate('/listproduct');
    } catch (error) {
      if (error.response?.data?.errors) {
        console.error("Validation errors:", error.response.data.errors);
      } else {
        console.error("Something went wrong:", error.message);
      }
      Toast({ message: error.response?.data?.message, type: "error" });
    }
  };
  const formik = useFormik(
    {
      initialValues: {
        product_name: "",
        brand: "",
        pro_category: "",
        pro_sub_category: "",
        attribute: "",
        attribute_type: "",
        color: "",
        tag_no: "",
        tag: "",
        stock: "",
        low_stk_alert: "",
        pro_sku: "",
        related_pro: "",
        mrp: "",
        price: "",
        discount_type: "",
        discount: "",
        min_purchase_qty: "",
        max_purchase_qty: "",
        tax: "",
        expired: "",
        status: "",
        meta_title: "",
        meta_description: "",
        thumbnail: [],
        image: null,
        description: "",
        additional_info: "",
        addtional_gender: "",
        weight: "",
        product_lable_id: "",
        seller: "",
        material_type: "",
        language_code: "en"
      },

      validationSchema: yup.object().shape({
        product_name: yup.string().required("product name is required!"),
        brand: yup.string().required("brand is required"),
        pro_category: yup.string().required("category is required!"),
        pro_sub_category: yup.string().required("sub category is required!"),
        attribute: yup.string().required("attribute is required"),
        attribute_type: yup.string().required("attribute type By is required"),
        weight: yup.string().required("weight By is required"),

        tag_no: yup.string().required("tag_no By is required"),
        tag: yup.string().required("tag By is required"),

        pro_sku: yup.string().required("sku By is required"),
        related_pro: yup.string().required("related products is required"),

        mrp: yup.string().required("mrp is required"),
        price: yup.string().required("price is required"),
        discount_type: yup.string().required("discount type is required"),
        discount: yup.string().required("discount is required"),

        min_purchase_qty: yup.string().required("min purchase qty is required"),
        max_purchase_qty: yup.string().required("max purchase qty is required"),
        tax: yup.string().required("tax is required"),
        expired: yup.string().required("expired is required"),
        status: yup.string().required("status is required"),
        meta_title: yup.string().required("meta title is required"),
        meta_description: yup.string().required("meta description is required"),
        description: yup.string().required("description is required"),
        additional_info: yup.string().required("additional info is required"),

        seller: yup.string().required("seller is required"),
        material_type: yup.string().required(" material type is required"),
        product_lable_id: yup.string().required(" product lable id is required"),
        stock: yup.number()
          .typeError("Stock must be a number")
          .required("Stock is required")
          .min(0, "Stock cannot be negative"),

        low_stk_alert: yup.number()
          .typeError("Low stock alert must be a number")
          .required("Low stock alert is required")
          .min(0, "Low stock alert cannot be negative")
          .test(
            "low-stock-less-than-stock",
            "Low stock alert must be less than stock",
            function (value) {
              const { stock } = this.parent;
              if (value === undefined || stock === undefined) return true;
              return Number(value) < Number(stock);
            }
          ),
      }),

      onSubmit,
    }
  )
  console.log("sjjsj", formik.values.thumbnail)


  // expired

  const disabledDate = (current) => {
    return current && current < dayjs().startOf('day');
  };

  return (
    <>
      <div className="d-flex justify-content-start">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/listproduct')}
        >
          ← Back
        </button>
      </div>

      <div className=' py-4'>
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className='box_shadow p-4 rounded bg-white'>

            <ul className="nav nav-tabs mb-3">
              <li className="nav-item">
                <button
                  type="button"
                  className="nav-link active text-primary"
                // className={`nav-link ${language === "en" ? "active" : "black"}`}
                // onClick={(e) => handleLanguage(e, "en")}
                >
                  English
                </button>
              </li>
              {/* <li className="nav-item">
                <button
                  type="button"
                  className={`nav-link ${language === "de" ? "active" : "black"}`}
                  onClick={(e) => handleLanguage(e, "de")}
                >
                  German
                </button>
              </li> */}
            </ul>
            <div className='row'>
              <div className='col-12 col-md-12'>
                <div className='d-flex'>
                  <h5>Product Information</h5>

                  {/* <div className="dropdown ms-4">
                      <button
                        className="btn btn-outline-primary dropdown-toggle"
                        data-bs-toggle="dropdown"
                        type="button"
                      >
                        {formik.values.language_code === "en"
                          ? "English"
                          : formik.values.language_code === "de"
                            ? "German"
                            : "Select a language"}
                      </button>

                      <ul className="dropdown-menu">
                        <li>
                          <button
                            type="button"
                            className="dropdown-item"
                            onClick={() => {
                              formik.setFieldValue("language_code", "en")
                              setLanguage("en")
                            }}
                          >
                            English
                          </button>
                        </li>

                        <li>
                          <button
                            type="button"
                            className="dropdown-item"
                            onClick={() => {
                              formik.setFieldValue("language_code", "de")
                              setLanguage("de")
                            }}
                          >
                            German
                          </button>
                        </li>
                      </ul>
                      {formik.errors.language_code && formik.touched.language_code && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.language_code}
                        </p>
                      )}
                    </div> */}
                </div>
              </div>
              <div className='row g-4'>
                <div className='col-12 col-md-6'>
                  <div className='mb-3'>
                    <label htmlFor="product_lable_id" className='form-label text-muted'>Product ID</label>
                    <input
                      type='text'
                      className='form-control opacity-75'
                      name='product_lable_id'
                      id="product_lable_id"
                      placeholder='Enter Product ID'
                      value={formik.values.product_lable_id}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.product_lable_id && formik.touched.product_lable_id && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.product_lable_id}
                      </p>
                    )}
                  </div>

                  <div className='mb-3'>
                    <label htmlFor="product_name" className='form-label text-muted'>Product Name</label>
                    <input
                      type='text'
                      className='form-control opacity-75'
                      name='product_name'
                      id="product_name"
                      placeholder='Enter Product Name'
                      value={formik.values.product_name}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.product_name && formik.touched.product_name && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.product_name}
                      </p>
                    )}
                  </div>

                  {/* <div className='mb-3'>
                      <label htmlFor="pro_category" className='form-label text-muted'>Product Categories </label>
                      <select

                        className="form-select "
                        id="pro_category"
                        name="pro_category"
                        value={formik.values.pro_category}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}

                      >
                        <option value=''>select product category</option>
                         {fetchcategory?.length > 0 ? (
                                                    fetchcategory?.map((item) => (
                                                        <option key={item.id} value={item.pro_category} >{item.title} </option>
                                                    ))

                                                ) : (<option value="">No data</option>)}

                      </select>
                      {formik.errors.pro_category && formik.touched.pro_category && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.pro_category}
                        </p>
                      )}
                    </div> */}

                  <label htmlFor="pro_category" className='form-label text-muted'>Product Categories</label>
                  <select
                    className="form-select"
                    id="pro_category"
                    name="pro_category"
                    // placeholder="Select product category"
                    value={formik.values.pro_category}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  >
                    <option >Select product category</option>
                    {fetchcategory?.length > 0 ? (
                      fetchcategory.map((item) => (
                        <option key={item.id} value={item.id}>
                          {item.title}
                        </option>
                      ))
                    ) : (
                      <option value="" disabled>No data</option>
                    )}
                  </select>

                  {formik.errors.pro_category && formik.touched.pro_category && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.pro_category}
                    </p>
                  )}
                  {/* 
                    {formik.values.pro_category === "Garments" && (
                      <div className="mb-3 pt-4">
                        <label htmlFor="addtional_gender" className="form-label text-muted">
                          Additional Gender
                        </label>
                        <select
                          className="form-select"
                          id="addtional_gender"
                          name="addtional_gender"
                          value={formik.values.addtional_gender}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        >
                          <option value="">Select gender</option>
                          <option value="Men">Men</option>
                          <option value="Women">Women</option>
                          <option value="Kids">Kids</option>
                        </select>

                        {formik.errors.addtional_gender && formik.touched.addtional_gender && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.addtional_gender}
                          </p>
                        )}
                      </div>
                    )} */}

                  <div className='mb-3 mt-3'>
                    <label htmlFor="pro_sub_category" className='form-label text-muted'>Product Sub Categories </label>
                    <select className="form-select opacity-75" id="pro_sub_category" name="pro_sub_category"
                      value={formik.values.pro_sub_category}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}>
                      <option>Select Sub Categories</option>
                      {fetchsubcategory?.filter(
                        (sub) => sub.category_id == formik.values.pro_category
                      ).length > 0 ? (
                        fetchsubcategory
                          .filter((sub) => sub.category_id == formik.values.pro_category)
                          .map((item) => (
                            <option key={item.id} value={item.id}>
                              {item.title}
                            </option>
                          ))
                      ) : (
                        <option value="" disabled>No data</option>
                      )}

                      {/* {fetchsubcategory?.length > 0 ? (
                          fetchsubcategory?.map((item) => (
                            <option key={item.id} value={item.id} >{item.title} </option>
                          ))

                        ) : (<option value="">No data</option>)} */}

                    </select>
                    {formik.errors.pro_sub_category && formik.touched.pro_sub_category && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.pro_sub_category}
                      </p>
                    )}
                  </div>
                </div>
                <div className='col-12 col-md-6'>
                  <div className='mb-3'>
                    <label htmlFor="brand" className='form-label text-muted'>Brand</label>
                    <input
                      type='text'
                      className='form-control opacity-75'
                      name='brand'
                      id="brand"
                      placeholder='Enter Brand'
                      value={formik.values.brand}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.brand && formik.touched.brand && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.brand}
                      </p>
                    )}
                  </div>

                  <div className='mb-3'>
                    <label htmlFor="attribute" className='form-label text-muted'>Select Attribute</label>
                    <select
                      className="form-select"
                      id="attribute"
                      name="attribute"
                      value={formik.values.attribute}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    >
                      <option>select product Attribute</option>
                      {/* <option value=''>select product Attribute</option> */}
                      {fetchAttribute?.length > 0 ? (
                        fetchAttribute.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.attribute_title}
                          </option>
                        ))
                      ) : (
                        <option value="" disabled>No data</option>
                      )}
                    </select>
                    {formik.errors.attribute && formik.touched.attribute && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.attribute}
                      </p>
                    )}
                  </div>
                  <div className='mb-3'>
                    <label htmlFor="attribute_type" className='form-label text-muted'>Attribute Type</label>
                    <input
                      type='text'
                      name='attribute_type'
                      className='form-control opacity-75'
                      id="attribute_type"
                      placeholder='Enter Attribute Type'
                      value={formik.values.attribute_type}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.attribute_type && formik.touched.attribute_type && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.attribute_type}
                      </p>
                    )}
                  </div>
                  <div className='mb-3'>
                    <label htmlFor="weight" className='form-label text-muted'>Weight/value</label>
                    <input
                      type='text'
                      name='weight'
                      className='form-control opacity-75'
                      id="weight"
                      placeholder='Enter Weight'
                      value={formik.values.weight}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.weight && formik.touched.weight && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.weight}
                      </p>
                    )}
                  </div>
                </div>

                <input
                  type="file"
                  name="thumbnail"
                  multiple
                  accept="image/*"
                  onChange={handleImageChangethumb}
                // onChange={(e) => {
                //   const files = Array.from(e.currentTarget.files);
                //   formik.setFieldValue("thumbnail", files);
                // }}
                />
                <div className='d-flex gap-2'>
                  {imagePreviewThumb.map((item) => (

                    <img
                      src={item
                        // : `${img_path}/product/${serverImage}`
                      }
                      alt="Preview"
                      className="img-fluid rounded"
                      style={{

                        maxHeight: "100px",
                        maxWidth: "100px",
                        objectFit: "contain",
                        border: "1px solid #ccc",
                        padding: "5px",
                      }}
                    />
                  ))
                  }
                </div>
                <div className=''>
                  <div className=" flex justify-content-center">
                    {/* <ColorPicker value={color} onChange={(e) => setColor(e.value)} /> */}
                    <div className="flex justify-content-center">
                      <input
                        type="color"
                        id="color"
                        name="color"
                        className="form-control form-control-color"
                        value={formik.values.color}
                        onChange={(e) => formik.setFieldValue("color", e.target.value)}
                      />
                    </div>

                  </div>
                </div>
                <div className='col-12'>
                  <div className='mb-3'>

                    <div className="">
                      <label htmlFor="description" className='form-label text-muted'>Description</label>

                      <Editor
                        id="description"
                        name="description"
                        value={formik.values.description}
                        onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                        onBlur={formik.handleBlur}
                        style={{ height: "320px" }}
                      />
                      {formik.errors.description && formik.touched.description && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.description}
                        </p>
                      )}

                    </div>
                  </div>
                </div>

                <div className='col-12'>
                  <div className='mb-3'>

                    <div className="">
                      <label htmlFor="additional_info" className='form-label text-muted'>Additional Information</label>

                      <Editor
                        id="additional_info"
                        name="additional_info"
                        value={formik.values.additional_info}
                        onTextChange={(e) => formik.setFieldValue("additional_info", e.htmlValue)}
                        onBlur={formik.handleBlur}
                        style={{ height: "320px" }}
                      />
                      {formik.errors.additional_info && formik.touched.additional_info && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.additional_info}
                        </p>
                      )}

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className='box_shadow p-4 rounded mt-4 bg-white'>
            <h5> ProductStock</h5>
            <hr />
            <div className='row'>
              <div className='col-12 col-md-6'>
                <div className='mb-3'>
                  <label htmlFor="tag_no" className='form-label text-muted'>Tag No</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="createdBy"
                    name='tag_no'
                    placeholder='Enter Tag No'
                    value={formik.values.tag_no}
                    // onChange={formik.handleChange}
                    onChange={(e) => {
                      const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                      formik.setFieldValue("tag_no", onlyNumbers);
                    }}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.tag_no && formik.touched.tag_no && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.tag_no}
                    </p>
                  )}
                </div>
                <div className='mb-3'>
                  <label htmlFor="stock" className='form-label text-muted'>Stock</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="stock"
                    name='stock'
                    placeholder='Enter Stock'
                    value={formik.values.stock}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.stock && formik.touched.stock && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.stock}
                    </p>
                  )}
                </div>
                <div className='mb-3'>
                  <label htmlFor="pro_sku" className='form-label text-muted'>Product SKU</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="createdBy"
                    name='pro_sku'
                    placeholder='Enter Product SKU'
                    value={formik.values.pro_sku}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.pro_sku && formik.touched.pro_sku && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.pro_sku}
                    </p>
                  )}
                </div>

                <div className='mb-3'>
                  <label htmlFor="material_type" className='form-label text-muted'>MaterialType</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="material_type"
                    name='material_type'
                    placeholder='Enter material_type'
                    value={formik.values.material_type}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.material_type && formik.touched.material_type && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.material_type}
                    </p>
                  )}
                </div>
              </div>

              <div className='col-12 col-md-6'>
                <div className='mb-3'>
                  <label htmlFor="tag" className='form-label text-muted'>Tag</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="tag"
                    name='tag'
                    placeholder='Enter Tag'
                    value={formik.values.tag}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.tag && formik.touched.tag && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.tag}
                    </p>
                  )}
                </div>
                <div className='mb-3'>
                  <label htmlFor="low_stk_alert" className='form-label text-muted'>Low stock alert Limit</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="low_stk_alert"
                    name='low_stk_alert'
                    placeholder='Enter Low stock'
                    value={formik.values.low_stk_alert}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.low_stk_alert && formik.touched.low_stk_alert && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.low_stk_alert}
                    </p>
                  )}
                </div>
                <div className='mb-3'>
                  <label htmlFor="related_pro" className='form-label text-muted'>Related Products</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="related_pro"
                    name='related_pro'
                    placeholder='Enter Related Products'
                    value={formik.values.related_pro}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.related_pro && formik.touched.related_pro && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.related_pro}
                    </p>
                  )}
                </div>

                <div className='mb-3'>
                  <label htmlFor="seller" className='form-label text-muted'>Seller</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="seller"
                    name='seller'
                    placeholder='Enter seller'
                    value={formik.values.seller}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.seller && formik.touched.seller && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.seller}
                    </p>
                  )}
                </div>
              </div>
            </div>

          </div>

          <div className='box_shadow p-4 rounded mt-4 bg-white'>
            <h5> Pricing Details</h5>
            <hr />
            <div className='row'>
              <div className='col-12 col-md-3'>

                <div className='d-flex'>

                  <div className='mb-3  me-2'>
                    <label htmlFor="mrp" className='form-label text-muted '>MRP</label>
                    <input
                      type='text'
                      className='form-control opacity-75'
                      id="mrp"
                      name='mrp'
                      placeholder='Enter MRP'
                      value={formik.values.mrp}
                      // onChange={formik.handleChange}
                      onChange={(e) => {
                        const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                        formik.setFieldValue("mrp", onlyNumbers);
                      }}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.mrp && formik.touched.mrp && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.mrp}
                      </p>
                    )}
                  </div>
                  <div className='mb-3'>
                    <label htmlFor="price" className='form-label text-muted'>Price ($)</label>
                    <input
                      type='text'
                      className='form-control opacity-75'
                      id="price"
                      name='price'
                      placeholder='Enter Price'
                      value={formik.values.price}
                      // onChange={formik.handleChange}
                      onChange={(e) => {
                        const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                        formik.setFieldValue("price", onlyNumbers);
                      }}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.price && formik.touched.price && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.price}
                      </p>
                    )}
                  </div>
                </div>

                <div className='mb-3 pt-4'>
                  <label htmlFor="tax" className='form-label text-muted'>Tax (%)</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="tax"
                    name='tax'
                    placeholder='Enter Tax'
                    value={formik.values.tax}
                    // onChange={formik.handleChange}
                    onChange={(e) => {
                      const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                      formik.setFieldValue("tax", onlyNumbers);
                    }}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.tax && formik.touched.tax && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.tax}
                    </p>
                  )}
                </div>
              </div>
              <div className='col-12 col-md-3'>
                <div className='mb-3'>
                  <label htmlFor="discount_type" className='form-label text-muted'>Discount by</label>
                  <select className="form-select opacity-75" id="discount_type" name="discount_type"
                    value={formik.values.discount_type}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}>
                    <option value="">Select Creator</option>
                    <option value="Admin">Admin</option>
                    <option value="Other">Other</option>
                    <option value="Seller">Seller</option>
                  </select>
                  {formik.errors.discount_type && formik.touched.discount_type && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.discount_type}
                    </p>
                  )}
                </div>
                <div className='mb-3 pt-4'>
                  <label htmlFor="max_purchase_qty" className='form-label text-muted'>Maximum Purchase Qty</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="max_purchase_qty"
                    name='max_purchase_qty'
                    placeholder='Enter Maximum Purchase Qty'
                    value={formik.values.max_purchase_qty}
                    // onChange={formik.handleChange}
                    onChange={(e) => {
                      const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                      formik.setFieldValue("max_purchase_qty", onlyNumbers);
                    }}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.max_purchase_qty && formik.touched.max_purchase_qty && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.max_purchase_qty}
                    </p>
                  )}
                </div>
              </div>
              <div className='col-12 col-md-3'>
                <div className='mb-3'>
                  <label htmlFor="discount" className='form-label text-muted'>Discount </label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="discount"
                    name='discount'
                    placeholder='Enter Discount'
                    value={formik.values.discount}
                    // onChange={formik.handleChange}
                    onChange={(e) => {
                      const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                      formik.setFieldValue("discount", onlyNumbers);
                    }}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.discount && formik.touched.discount && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.discount}
                    </p>
                  )}
                </div>

                <div className="mb-3 pt-4 ps-4">
                  <label className="form-label text-muted">Status</label>
                  <div className="d-flex flex-column gap-2">
                    <div className="form-check">
                      {/* <input
                            className="form-check-input"
                            type="radio"
                            name="status"
                            id="status-active"
                            value="active"
                            checked={formik.values.status === "active"}
                            onChange={formik.handleChange}
                          /> */}
                      <RadioButton inputId="ingredient1" name="status" id="status-active" value="active" defaultChecked
                        checked={formik.values.status === "active"}
                        onChange={(e) => formik.setFieldValue("status", e.value)}
                      />
                      <label className="form-check-label ms-2" htmlFor="status-active">
                        Active
                      </label>
                    </div>
                    <div className="form-check">
                      {/* <input
                            className="form-check-input"
                            type="radio"
                            name="status"
                            id="status-inactive"
                            value="inactive"
                            checked={formik.values.status === "inactive"}
                            onChange={formik.handleChange}
                          /> */}
                      <RadioButton inputId="ingredient2" name="status" id="status-inactive" value="inactive"
                        checked={formik.values.status === "inactive"}
                        // onChange={formik.handleChange}
                        onChange={(e) => formik.setFieldValue("status", e.value)}
                      />
                      <label className="form-check-label ms-2" htmlFor="status-inactive">
                        Inactive
                      </label>
                    </div>

                  </div>
                  {formik.errors.status && formik.touched.status && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.status}
                    </p>
                  )}
                </div>


              </div>

              <div className='col-12 col-md-3'>

                <div className='mb-3'>
                  <label htmlFor="min_purchase_qty" className='form-label text-muted'>Minimum Purchase Qty</label>
                  <input
                    type='text'
                    className='form-control opacity-75'
                    id="min_purchase_qty"
                    name='min_purchase_qty'
                    placeholder='Enter Minimum Purchase Qty'
                    value={formik.values.min_purchase_qty}
                    // onChange={formik.handleChange}
                    onChange={(e) => {
                      const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                      formik.setFieldValue("min_purchase_qty", onlyNumbers);
                    }}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.min_purchase_qty && formik.touched.min_purchase_qty && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.min_purchase_qty}
                    </p>
                  )}
                </div>
                <div className='mb-3 pt-4'>
                  <label htmlFor="expired" className='form-label text-muted'>Expired</label><br />
                  {/* <input
                        type='text'
                        className='form-control opacity-75'
                        id="createdBy"
                        name='expired'
                        placeholder='Enter Expired'
                        value={formik.values.expired}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />  
                    */}
                  {/* <input
                        type='date'
                        className="form-control"
                        id="expired"
                        name='expired'
                        rows="4"
                      
                        value={formik.values.expired}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      /> */}
                  {/* <input
                    type="date"
                    className="form-control"
                    id="expired"
                    name="expired"  
                    value={formik.values.expired}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    onClick={(e) => e.target.showPicker && e.target.showPicker()}
                    onFocus={(e) => e.target.showPicker && e.target.showPicker()}
                  /> */}




                  <DatePicker
                    id="expired"
                    name="expired"
                    format="DD-MM-YYYY"
                    disabledDate={disabledDate}
                    // value={formik.values.expired ? dayjs(formik.values.expired) : null}
                    value={formik.values.expired ? dayjs(formik.values.expired, "YYYY-MM-DD") : ""}
                    onChange={(date) => {
                      formik.setFieldValue(
                        "expired",
                        date ? date.format("YYYY-MM-DD") : ""
                      );
                    }}
                    onBlur={() => formik.setFieldTouched("expired", true)}
                    style={{ width: "100%" }}
                  />

                  {formik.errors.expired && formik.touched.expired && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.expired}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className='box_shadow p-4 rounded mt-4 bg-white'>
            <h5> Meta Data</h5>
            <hr />
            <div className='row'>
              <div className='col-12 col-md-12'>
                <div className='mb-3'>
                  <label htmlFor="meta_title" className='form-label text-muted ps-1'>Meta Title</label>
                  <input
                    type='text'
                    className='form-control opacity-75 w-25'
                    id="meta_title"
                    name='meta_title'
                    placeholder='Enter Meta Data'
                    value={formik.values.meta_title}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                  {formik.errors.meta_title && formik.touched.meta_title && (
                    <p style={{ color: "red", fontSize: "12px" }}>
                      {formik.errors.meta_title}
                    </p>
                  )}
                </div>

                <div className='mb-3'>
                  {/* <label htmlFor="description" className='form-label text-muted'>Description</label>
                                        <textarea
                                            className="form-control "
                                            id="description"
                                            rows="5"
                                            placeholder="Type description"
                                        ></textarea> */}
                  <div className="">
                    <label htmlFor="meta_title" className='form-label text-muted ps-1'>Meta Description</label>

                    <Editor
                      id="meta_description"
                      name="meta_description"
                      value={formik.values.meta_description}
                      onTextChange={(e) => formik.setFieldValue("meta_description", e.htmlValue)}
                      onBlur={formik.handleBlur}
                      style={{ height: "200px" }}
                    />
                    {formik.errors.meta_description && formik.touched.meta_description && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.meta_description}
                      </p>
                    )}

                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className='row py-4'>
            <div className="col-12 col-md-12 ">

              {/* <div className="">
            <FileUpload name="demo[]" url={'/api/upload'} multiple accept="image/*" maxFileSize={1000000} />
        </div> */}

              <div className='box_shadow  bg-white pb-5'>
                <h5 className="mb-3 ms-4 pt-3">Add product image</h5>
                <hr className='' />

                <div
                  className="border border-dotted  mx-auto text-center "
                  style={{ maxWidth: "800px", minHeight: "200px", display: "flex", alignItems: "center", justifyContent: "center" }}
                >
                  <input
                    type="file"
                    id="thumbnail-upload"
                    className="d-none"
                    accept="image/png, image/jpeg, image/gif"
                    onChange={handleImageChange}
                  />
                  {imagePreview || serverImage ? (
                    <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                      <img
                        src={
                          imagePreview
                            ? imagePreview
                            : `${img_path}/product/${serverImage}`
                        }
                        alt="Preview"
                        className="img-fluid rounded"
                        style={{
                          maxHeight: "200px",
                          maxWidth: "100%",
                          objectFit: "contain",
                          border: "1px solid #ccc",
                          padding: "5px",
                        }}
                      />
                    </label>
                  ) : (
                    <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                      <BiCloudUpload size={50} className="color_icon mb-3" />
                      <h4>
                        Drop your images here, or{" "}
                        <span className="color_icon">click to browse</span>
                      </h4>
                      <p className="small text-muted">
                        1600 x 1200 (4:3) recommended. PNG, JPG and GIF files are allowed
                      </p>
                    </label>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className='col-12 d-flex justify-content-end gap-3 '>
            {/* <button className='btn btn-danger bg_color' onClick={() => formik.resetForm()}>Cancel</button> */}

            <button type='submit' className='btn btn-outline-success'>Create</button>
          </div>
        </form>
      </div>
    </>
  )
}

export default CreateProduct