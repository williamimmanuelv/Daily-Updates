import React, { useEffect, useState } from 'react'
import tshirt from "../../Assets/t-shirt.png"
import { BiCloudUpload } from "react-icons/bi";
import { ColorPicker } from 'primereact/colorpicker';
import { Checkbox } from "primereact/checkbox";
import Button from '@mui/material/Button';
import { Editor } from "primereact/editor";
import { useLocation, useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosinstance';
import axios from 'axios';
import { base_url, img_path } from '../../Api/BaseUrl';
import { useFormik } from 'formik';
import Toast from '../../utils/Toast';
import * as yup from "yup"
import { RadioButton } from 'primereact/radiobutton';
import { DatePicker, message } from 'antd';
import dayjs from 'dayjs';
// 
import { Dialog } from "primereact/dialog";
import { useDispatch, useSelector } from 'react-redux';
import { SetEditedbulkData } from '../../Redux/Reducers/EditedbulkDataSlice'
import './bulkupload.css'



export default function EditDialog({ visible, onHide, data, onSave, setExcelData, excelData, rowIndex, setVisible }) {

  const reduxEdited = useSelector((state) => state.editedBulkData);
  console.log("reduxEdited", reduxEdited);

  const dispatch = useDispatch();

  console.log("dataaa", data);

  const editDataFromTable = data;
  console.log("editDataFromTable", editDataFromTable);


  const [fetchAttribute, setFetchAttribute] = useState([])
  console.log("fetchAttributeeee", fetchAttribute)

  const [checked, setChecked] = useState(false);

  const [imagePreview, setImagePreview] = useState(null);
  const [serverImage, setServerImage] = useState(null);
  const [language, setLanguage] = useState("en");

  // const [fetchproducts, setFetchproducts] = useState([])
  // console.log("fetchproductsfetchproducts", fetchproducts)
  const token = localStorage.getItem("tokenAdmin")

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImagePreview(URL.createObjectURL(file));
      formik.setFieldValue("image", file);
    } else {
      setImagePreview(null);
      formik.setFieldValue("image", null);
    }
  };

  const [previewImages, setPreviewImages] = useState([]);
  // }


  useEffect(() => {
    // if (!editDataFromTable || !editDataFromTable.id) return; 
    console.log("editDataFromTablekk", editDataFromTable);


    formik.setValues({
      product_name: editDataFromTable?.product_name || "",
      brand: editDataFromTable?.brand || "",
      pro_category: editDataFromTable?.pro_category || "",
      pro_sub_category: editDataFromTable?.pro_sub_category || "",
      attribute: editDataFromTable?.attribute || "",
      attribute_type: editDataFromTable?.attribute_type || "",
      color: editDataFromTable?.color || "",
      tag_no: editDataFromTable?.tag_no || "",
      tag: editDataFromTable?.tag || "",
      stock: editDataFromTable?.stock || "",
      low_stk_alert: editDataFromTable?.low_stk_alert || "",
      pro_sku: editDataFromTable?.pro_sku || "",
      related_pro: editDataFromTable?.related_pro || "",
      mrp: editDataFromTable?.mrp || "",
      price: editDataFromTable?.price || "",
      discount_type: editDataFromTable?.discount_type || "",
      min_purchase_qty: editDataFromTable?.min_purchase_qty || "",
      max_purchase_qty: editDataFromTable?.max_purchase_qty || "",
      tax: editDataFromTable?.tax || "",
      expired: editDataFromTable?.expired
        ? dayjs(editDataFromTable.expired)
        : null,

      status: editDataFromTable?.status || "",
      meta_title: editDataFromTable?.meta_title || "",
      meta_description: editDataFromTable?.meta_description || "",
      description: editDataFromTable?.description || "",
      discount: editDataFromTable?.discount || "",
      additional_info: editDataFromTable?.additional_info || "",
      thumbnail: editDataFromTable?.thumbnail || "",
      addtional_gender: editDataFromTable?.addtional_gender || "",
      image: editDataFromTable?.image || "",
      weight: editDataFromTable?.weight || "",
      product_lable_id: editDataFromTable?.product_lable_id || "",
      material_type: editDataFromTable?.material_type || "",
      seller: editDataFromTable?.seller || "",
      language_code: editDataFromTable?.language_code || "",
      id: editDataFromTable?.id || "",
    });
  }, [editDataFromTable, data]);




  const onSubmit = async (values) => {
    const afterEditFullData = excelData.map((item, index) =>
      index === rowIndex ? { ...item, ...values } : item
    );
    setExcelData(afterEditFullData);
    console.log("afterEditFullData",afterEditFullData);
    
    // if (!editDataFromTable || !editDataFromTable.id) return; 

    console.log("valude", values);

    try {
      const formData = new FormData();
      console.log("all data",formik.values)
      //  Append all individual fields
      formData.append("product_name", values.product_name);
      formData.append("brand", values.brand);
      formData.append("pro_category", values.pro_category);
      formData.append("pro_sub_category", values.pro_sub_category);
      formData.append("attribute", values.attribute);
      formData.append("attribute_type", values.attribute_type);
      formData.append("color", values.color);
      formData.append("tag_no", values.tag_no);
      formData.append("tag", values.tag);
      formData.append("stock", values.stock);
      formData.append("low_stk_alert", values.low_stk_alert);
      formData.append("pro_sku", values.pro_sku);
      formData.append("related_pro", values.related_pro);
      formData.append("mrp", values.mrp);
      formData.append("price", values.price);
      formData.append("discount_type", values.discount_type);
      formData.append("min_purchase_qty", values.min_purchase_qty);
      formData.append("max_purchase_qty", values.max_purchase_qty);
      formData.append("tax", values.tax);
      formData.append("expired", values.expired);
      formData.append("status", values.status);
      formData.append("meta_title", values.meta_title);
      formData.append("meta_description", values.meta_description);
      formData.append("description", values.description);
      formData.append("discount", values.discount);
      formData.append("additional_info", values.additional_info);
      formData.append("addtional_gender", values.addtional_gender);
      formData.append("weight", values.weight);
      formData.append("product_lable_id", values.product_lable_id);
      formData.append("seller", values.seller);
      formData.append("material_type", values.material_type);
      formData.append("language_code", values.language_code);

      //  Append main image if available
      if (values.image) {
        formData.append("image", afterEditFullData?.image);
      }

      if (values.thumbnail) {
        if (Array.isArray(values.thumbnail)) {
          // Multiple thumbnails
          values.thumbnail.forEach((file) => {
            formData.append("thumbnail[]", file);
          });
        } else {
          // Single file or existing URL
          formData.append("thumbnail[]", values.thumbnail);
        }
      }

      //  On success
      // Toast({ message: response.data.message, type: "success" });
      // console.log("Success:", response.data);

      setImagePreview(null);
      setVisible(false)
      // setServerImage(response.data.thumbnail);
      formik.resetForm();
      // navigate("/listproduct");
      console.log("formik.values", formik.values);
      // setEditedData(formik.values);
      // dispatch(SetEditedbulkData(null));



    } catch (error) {
      //  Handle validation or other errors
      // if (error.response?.data?.errors) {
      //   console.error("Validation errors:", error.response.data.errors);
      // } else {
      //   console.error("Something went wrong:", error.message);
      // }
      Toast({ message: error?.response?.data?.message, type: "error" });
    }
  };

  const formik = useFormik(
    {
      initialValues: {
        product_name: "",
        brand: "",
        pro_category: "",
        pro_sub_category: "",
        attribute: "",
        attribute_type: "",
        color: "",
        tag_no: "",
        tag: "",
        stock: "",
        low_stk_alert: "",
        pro_sku: "",
        related_pro: "",
        mrp: "",
        price: "",
        discount_type: "",
        discount: "",
        min_purchase_qty: "",
        max_purchase_qty: "",
        tax: "",
        expired: "",
        status: "",
        meta_title: "",
        meta_description: "",
        thumbnail: null,
        description: "",
        additional_info: "",
        addtional_gender: "",
        image: null,
        weight: "",
        product_lable_id: "",
        seller: "",
        material_type: "",
        language_code: ""
      },
      validationSchema: yup.object().shape({
        product_name: yup.string().required("product_name is required!"),
        brand: yup.string().required("brand By is required"),
        pro_category: yup.string().required("pro_category is required!"),
        pro_sub_category: yup.string().required("pro_sub_category is required!"),
        attribute: yup.string().required("attribute By is required"),
        attribute_type: yup.string().required("attribute_type By is required"),
        weight: yup.string().required("weight By is required"),

        tag_no: yup.string().required("tag_no By is required"),
        tag: yup.string().required("tag By is required"),
        pro_sku: yup.string().required("pro_sku By is required"),
        related_pro: yup.string().required("related_pro By is required"),
        mrp: yup.string().required("mrp By is required"),
        price: yup.string().required("price By is required"),
        discount_type: yup.string().required("discount_type By is required"),
        discount: yup.string().required("discount By is required"),

        min_purchase_qty: yup.string().required("min_purchase_qty By is required"),
        max_purchase_qty: yup.string().required("max_purchase_qty By is required"),
        tax: yup.string().required("tax By is required"),
        expired: yup.string().required("expired By is required"),
        status: yup.string().required("status By is required"),
        meta_title: yup.string().required("meta_title By is required"),
        meta_description: yup.string().required("meta_description By is required"),
        description: yup.string().required("description By is required"),
        additional_info: yup.string().required("additional_info By is required"),

        seller: yup.string().required(" seller By is required"),
        material_type: yup.string().required(" material_type By is required"),
        product_lable_id: yup.string().required(" product_lable_id By is required"),
        stock: yup.number()
          .typeError("Stock must be a number")
          .required("Stock is required")
          .min(0, "Stock cannot be negative"),
        low_stk_alert: yup.number()
          .typeError("Low stock alert must be a number")
          .required("Low stock alert is required")
          .min(0, "Low stock alert cannot be negative")
          .test(
            "low-stock-less-than-stock",
            "Low stock alert must be less than stock",
            function (value) {
              const { stock } = this.parent;
              if (value === undefined || stock === undefined) return true;
              return Number(value) < Number(stock);
            }
          ),
      }),
      onSubmit,
    }
  )
  const handleLanguage = (e, lang) => {
    e.preventDefault();
    formik.setFieldValue("language_code", lang);
    setLanguage(lang)
  };

  if (!data) return null;


  return (
    <Dialog
      header="Edit Row"
      visible={visible}
      onHide={onHide}
      style={{ width: "50vw" }}
      baseZIndex={100}
    >
      <div className=' py-4'>
        <div className='box_shadow  rounded bg-white'>
          <form onSubmit={formik.handleSubmit} className='p-4'>
            <div className='row '>
              <div className='col-12 col-md-12'>
                <div className='d-flex'>
                  <h5>Product Information</h5>

                </div>

                <div className='row g-4 mt-2'>

                  <div className='col-12 col-md-6'>

                    <div className='mb-3'>
                      <label htmlFor="product_lable_id" className='form-label text-muted'>Product ID</label>
                      <input
                        type='text'
                        className='form-control opacity-75'
                        name='product_lable_id'
                        id="product_lable_id"
                        placeholder='Enter Product ID'
                        value={formik.values.product_lable_id}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.product_lable_id && formik.touched.product_lable_id && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.product_lable_id}
                        </p>
                      )}
                    </div>
                    <div className='mb-3'>
                      <label htmlFor="product_name" className='form-label text-muted '>Product Name</label>
                      <input
                        type='text'
                        className='form-control opacity-75'
                        name='product_name'
                        id="product_name"
                        placeholder='Enter Product Name'
                        value={formik.values.product_name}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.product_name && formik.touched.product_name && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.product_name}
                        </p>
                      )}
                    </div>

                    <div className='mb-3'>
                      <label htmlFor="pro_category" className='form-label text-muted'>Product Categories</label>
                      <input
                        type='text'
                        className='form-control opacity-75'
                        name='pro_category'
                        id="pro_category"
                        placeholder='Enter Product Category'
                        value={formik.values.pro_category}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.pro_category && formik.touched.pro_category && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.pro_category}
                        </p>
                      )}
                    </div>

                    <div className='mb-3'>
                      <label htmlFor="pro_sub_category" className='form-label text-muted'>Product Sub Categories </label>
                      <input
                        type='text'
                        className='form-control opacity-75'
                        name='pro_sub_category'
                        id="pro_sub_category"
                        placeholder='Enter Product Subcategory'
                        value={formik.values.pro_sub_category}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.pro_sub_category && formik.touched.pro_sub_category && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.pro_sub_category}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className='col-12 col-md-6'>
                    <div className='mb-3'>
                      <label htmlFor="brand" className='form-label text-muted'>Brand</label>
                      <input
                        type='text'
                        className='form-control opacity-75'
                        name='brand'
                        id="brand"
                        placeholder='Enter Brand'
                        value={formik.values.brand}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.brand && formik.touched.brand && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.brand}
                        </p>
                      )}
                    </div>
                    <div className='mb-3'>
                      <label htmlFor="attribute" className='form-label text-muted'>Select Attribute</label>
                      <input
                        type='text'
                        name='attribute'
                        className='form-control opacity-75'
                        id="attribute"
                        placeholder='Enter Attribute'
                        value={formik.values.attribute}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.attribute_type && formik.touched.attribute && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.attribute}
                        </p>
                      )}
                    </div>

                    <div className='mb-3'>
                      <label htmlFor="attribute_type" className='form-label text-muted'>Select Attribute Type</label>
                      <input
                        type='text'
                        name='attribute_type'
                        className='form-control opacity-75'
                        id="attribute_type"
                        placeholder='Enter Attribute Type'
                        value={formik.values.attribute_type}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.attribute_type && formik.touched.attribute_type && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.attribute_type}
                        </p>
                      )}
                    </div>

                    <div className='mb-3'>
                      <label htmlFor="weight" className='form-label text-muted'>Weight/value</label>
                      <input
                        type='text'
                        name='weight'
                        className='form-control opacity-75'
                        id="weight"
                        placeholder='Enter Weight'
                        value={formik.values.weight}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.weight && formik.touched.weight && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.weight}
                        </p>
                      )}
                    </div>
                  </div>
                  <div>
                    <input
                      type="file"
                      name="thumbnail"
                      multiple
                      accept="image/*"
                      onChange={(e) => {
                        const newFiles = Array.from(e.currentTarget.files);
                        formik.setFieldValue("thumbnail", [
                          ...formik.values.thumbnail,
                          ...newFiles,
                        ]);

                        // Add preview URLs for new files
                        const newPreviews = newFiles.map((file) => URL.createObjectURL(file));
                        setPreviewImages((prev) => [...prev, ...newPreviews]);
                      }}
                    />
                  </div>
                  <div className=''>
                    <div className=" flex justify-content-center">
                      <div className="flex justify-content-center">
                        <input
                          type="color"
                          id="color"
                          name="color"
                          className="form-control form-control-color"
                          value={formik.values.color}
                          onChange={(e) => formik.setFieldValue("color", e.target.value)}
                        />
                      </div>

                    </div>
                  </div>
                  <div className='col-12'>
                    <div className='mb-3'>
                      <div className="">
                        <Editor
                          id="description"
                          name="description"
                          value={formik.values.description}
                          onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                          onBlur={formik.handleBlur}
                          style={{ height: "320px" }}
                        />
                        {formik.errors.description && formik.touched.description && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className='col-12'>
                    <div className='mb-3'>

                      <div className="">
                        <label htmlFor="additional_info" className='form-label text-muted'>Additional Information</label>

                        <Editor
                          id="additional_info"
                          name="additional_info"
                          value={formik.values.additional_info}
                          onTextChange={(e) => formik.setFieldValue("additional_info", e.htmlValue)}
                          onBlur={formik.handleBlur}
                          style={{ height: "320px" }}
                        />
                        {formik.errors.additional_info && formik.touched.additional_info && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.additional_info}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                <div className='box_shadow p-4 rounded mt-4 bg-white'>
                  <h5> ProductStock</h5>
                  <hr />
                  <div className='row'>
                    <div className='col-12 col-md-6'>
                      <div className='mb-3'>
                        <label htmlFor="tag_no" className='form-label text-muted'>Tag No</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="createdBy"
                          name='tag_no'
                          placeholder='Enter Tag No'
                          value={formik.values.tag_no}
                          onChange={(e) => {
                            const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                            formik.setFieldValue("tag_no", onlyNumbers);
                          }}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.tag_no && formik.touched.tag_no && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.tag_no}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="stock" className='form-label text-muted'>Stock</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="stock"
                          name='stock'
                          placeholder='Enter Stock'
                          value={formik.values.stock}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.stock && formik.touched.stock && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.stock}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="pro_sku" className='form-label text-muted'>Product SKU</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="createdBy"
                          name='pro_sku'
                          placeholder='Enter Product SKU'
                          value={formik.values.pro_sku}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.pro_sku && formik.touched.pro_sku && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.pro_sku}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="material_type" className='form-label text-muted'>MaterialType</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="material_type"
                          name='material_type'
                          placeholder='Enter material_type'
                          value={formik.values.material_type}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.material_type && formik.touched.material_type && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.material_type}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className='col-12 col-md-6'>
                      <div className='mb-3'>
                        <label htmlFor="tag" className='form-label text-muted'>Tag</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="tag"
                          name='tag'
                          placeholder='Enter Tag'
                          value={formik.values.tag}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.tag && formik.touched.tag && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.tag}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="low_stk_alert" className='form-label text-muted'>Low stock alert Limit</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="low_stk_alert"
                          name='low_stk_alert'
                          placeholder='Enter Low stock'
                          value={formik.values.low_stk_alert}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.low_stk_alert && formik.touched.low_stk_alert && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.low_stk_alert}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="related_pro" className='form-label text-muted'>Related Products</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="related_pro"
                          name='related_pro'
                          placeholder='Enter Related Products'
                          value={formik.values.related_pro}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.related_pro && formik.touched.related_pro && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.related_pro}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="seller" className='form-label text-muted'>Seller</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="seller"
                          name='seller'
                          placeholder='Enter seller'
                          value={formik.values.seller}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.seller && formik.touched.seller && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.seller}
                          </p>
                        )}
                      </div>

                    </div>
                  </div>

                </div>

                <div className='box_shadow p-4 rounded mt-4 bg-white'>
                  <h5> Pricing Details</h5>
                  <hr />
                  <div className='row'>
                    <div className='col-12 col-md-3'>

                      <div className='d-flex'>

                        <div className='mb-3  me-2'>
                          <label htmlFor="mrp" className='form-label text-muted '>MRP</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="mrp"
                            name='mrp'
                            placeholder='Enter MRP'
                            value={formik.values.mrp}
                            onChange={(e) => {
                              const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                              formik.setFieldValue("mrp", onlyNumbers);
                            }}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.mrp && formik.touched.mrp && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.mrp}
                            </p>
                          )}
                        </div>
                        <div className='mb-3'>
                          <label htmlFor="price" className='form-label text-muted'>Price ($)</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="price"
                            name='price'
                            placeholder='Enter Price'
                            value={formik.values.price}
                            onChange={(e) => {
                              const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                              formik.setFieldValue("price", onlyNumbers);
                            }}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.price && formik.touched.price && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.price}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className='mb-3 pt-4'>
                        <label htmlFor="tax" className='form-label text-muted'>Tax (%)</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="tax"
                          name='tax'
                          placeholder='Enter Tax'
                          value={formik.values.tax}
                          onChange={(e) => {
                            const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                            formik.setFieldValue("tax", onlyNumbers);
                          }}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.tax && formik.touched.tax && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.tax}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className='col-12 col-md-3'>
                      <div className='mb-3'>
                        <label htmlFor="discount_type" className='form-label text-muted'>Discount by</label>
                        <select className="form-select opacity-75" id="discount_type" name="discount_type"
                          value={formik.values.discount_type}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}>
                          <option value="">Select Creator</option>
                          <option value="Admin">Admin</option>
                          <option value="Other">Other</option>
                          <option value="Seller">Seller</option>
                        </select>
                        {formik.errors.discount_type && formik.touched.discount_type && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.discount_type}
                          </p>
                        )}
                      </div>
                      <div className='mb-3 pt-4'>
                        <label htmlFor="max_purchase_qty" className='form-label text-muted'>Maximum Purchase Qty</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="max_purchase_qty"
                          name='max_purchase_qty'
                          placeholder='Enter Maximum Purchase Qty'
                          value={formik.values.max_purchase_qty}
                          onChange={(e) => {
                            const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                            formik.setFieldValue("max_purchase_qty", onlyNumbers);
                          }}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.max_purchase_qty && formik.touched.max_purchase_qty && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.max_purchase_qty}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className='col-12 col-md-3'>
                      <div className='mb-3'>
                        <label htmlFor="discount" className='form-label text-muted'>Discount </label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="discount"
                          name='discountdiscount'
                          placeholder='Enter Discount'
                          value={formik.values.discount}
                          onChange={(e) => {
                            const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                            formik.setFieldValue("discount", onlyNumbers);
                          }}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.discount && formik.touched.discount && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.discount}
                          </p>
                        )}
                      </div>

                      <div className="mb-3 pt-4 ps-4">
                        <label className="form-label text-muted">Status</label>
                        <div className="d-flex flex-column gap-2">
                          <div className="form-check">
                            <RadioButton inputId="ingredient1" name="status" id="status-active" value="active" defaultChecked
                              checked={formik.values.status === "active"}
                              onChange={formik.handleChange}
                            />
                            <label className="form-check-label ms-2" htmlFor="status-active">
                              Active
                            </label>
                          </div>
                          <div className="form-check">
                            <RadioButton inputId="ingredient2" name="status" id="status-inactive" value="inactive"
                              checked={formik.values.status === "inactive"}
                              onChange={formik.handleChange}
                            />
                            <label className="form-check-label ms-2" htmlFor="status-inactive">
                              Inactive
                            </label>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className='col-12 col-md-3'>

                      <div className='mb-3'>
                        <label htmlFor="min_purchase_qty" className='form-label text-muted'>Minimum Purchase Qty</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="min_purchase_qty"
                          name='min_purchase_qty'
                          placeholder='Enter Minimum Purchase Qty'
                          value={formik.values.min_purchase_qty}
                          onChange={(e) => {
                            const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                            formik.setFieldValue("min_purchase_qty", onlyNumbers);
                          }}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.min_purchase_qty && formik.touched.min_purchase_qty && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.min_purchase_qty}
                          </p>
                        )}
                      </div>
                      <div className='mb-3 pt-4'>
                        <label htmlFor="expired" className='form-label text-muted'>Expired</label>
                        <DatePicker
                          id="expired"
                          name="expired"
                          format="MM-DD-YYYY"
                          value={formik.values.expired ? dayjs(formik.values.expired, "YYYY-MM-DD") : ""}
                          onChange={(date) => {
                            formik.setFieldValue(
                              "expired",
                              date ? date.format("YYYY-MM-DD") : ""
                            );
                          }}
                          onBlur={() => formik.setFieldTouched("expired", true)}
                          style={{ width: "100%" }}
                        />

                        {formik.errors.expired && formik.touched.expired && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.expired}
                          </p>
                        )}
                        {/* {formik.errors.expired && formik.touched.expired && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.expired}
                          </p>
                        )} */}
                      </div>

                    </div>
                  </div>
                </div>
                <div className='box_shadow p-4 rounded mt-4 bg-white'>
                  <h5> Meta Data</h5>
                  <hr />
                  <div className='row'>
                    <div className='col-12 col-md-12'>
                      <div className='mb-3'>
                        <label htmlFor="meta_title" className='form-label text-muted ps-1'>Meta Title</label>
                        <input
                          type='text'
                          className='form-control opacity-75 w-25'
                          id="meta_title"
                          name='meta_title'
                          placeholder='Enter Meta Data'
                          value={formik.values.meta_title}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.meta_title && formik.touched.meta_title && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.meta_title}
                          </p>
                        )}
                      </div>

                      <div className='mb-3'>
                        <Editor
                          id="meta_description"
                          name="meta_description"
                          value={formik.values.meta_description}
                          onTextChange={(e) => formik.setFieldValue("meta_description", e.htmlValue)}
                          onBlur={formik.handleBlur}
                          style={{ height: "200px" }}
                        />
                        {formik.errors.meta_description && formik.touched.meta_description && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.meta_description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* )} */}
            {/* {language == "en" && ( */}
            {/* <div className='row py-4'>
              <div className="col-12 col-md-12 ">

                <div className="box_shadow pb-4 bg-white">
                  <h5 className="mb-3 ms-4 pt-3">Add Product image</h5>
                  <hr />

                  <div
                    className="border border-dotted  mx-auto text-center"
                    style={{ maxWidth: "800px", minHeight: "200px", display: "flex", alignItems: "center", justifyContent: "center" }}
                  >
                    <input
                      type="file"
                      id="thumbnail-upload"
                      className="d-none"
                      accept="image/png, image/jpeg, image/gif"
                      onChange={handleImageChange}
                    />
                    {imagePreview || serverImage ? (
                      <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                        <img
                          src={
                            imagePreview
                              ? imagePreview
                              : `${img_path}/products/${serverImage}`
                          }
                          alt="Preview"
                          className="img-fluid rounded"
                          style={{
                            maxHeight: "200px",
                            maxWidth: "100%",
                            objectFit: "contain",
                            border: "1px solid #ccc",
                            padding: "5px",
                          }}
                        />
                      </label>
                    ) : (

                      <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                        <BiCloudUpload size={50} className="color_icon mb-3" />
                        <h4>
                          Drop your images here, or{" "}
                          <span className="color_icon">click to browse</span>
                        </h4>
                        <p className="small text-muted">
                          1600 x 1200 (4:3) recommended. PNG, JPG and GIF files are allowed
                        </p>
                      </label>
                    )}
                  </div>
                </div>

              </div>
            </div> */}
            <div className='col-12 d-flex justify-content-end gap-3 '>
              {/* <button className='btn btn-danger bg_color'onClick={()=>formik.resetForm()}>Cancel</button> */}
              <button type="submit" className="btn btn-outline-success">
                Update
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* <button
        onClick={() => onSave(editedData) ||
          console.log("editeddata", editedData) ||
          dispatch(SetEditedbulkData(editedData))}>
        Save
      </button> */}
    </Dialog>
  );
}
