import React, { useEffect, useState } from 'react'
import tshirt from "../../Assets/t-shirt.png"
import { BiCloudUpload } from "react-icons/bi";
import { ColorPicker } from 'primereact/colorpicker';
import { Checkbox } from "primereact/checkbox";
import Button from '@mui/material/Button';
import { Editor } from "primereact/editor";
import { useLocation, useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosinstance';
import axios from 'axios';
import { base_url, img_path } from '../../Api/BaseUrl';
import { useFormik } from 'formik';
import Toast from '../../utils/Toast';
import * as yup from "yup"
import { RadioButton } from 'primereact/radiobutton';
import { DatePicker, message } from 'antd';
import dayjs from 'dayjs';

const EditProduct = () => {

  const navigate = useNavigate()

  const [fetchcategory, setFetchcategory] = useState([])
  // console.log("fetchcategorysssss",fetchcategory)

  const [fetchsubcategory, setFetchsubcategory] = useState([])
  // console.log("fetchsubcategoryyyyyy",fetchsubcategory)

  const [fetchAttribute, setFetchAttribute] = useState([])
  console.log("fetchAttributeeee", fetchAttribute)

  const [checked, setChecked] = useState(false);

  const [imagePreview, setImagePreview] = useState(null);
  const [serverImage, setServerImage] = useState(null);
  const [language, setLanguage] = useState("en");

  const [fetchproducts, setFetchproducts] = useState([])
  console.log("fetchproductsfetchproducts", fetchproducts)
  const token = localStorage.getItem("tokenAdmin")

  // const handleImageChange = (e) => {
  //   const file = e.target.files[0];
  //   if (file) {
  //     setImagePreview(URL.createObjectURL(file));
  //     formik.setFieldValue("thumbnail", file);
  //   } else {
  //     setImagePreview(null);
  //     formik.setFieldValue("thumbnail", null);
  //   }
  // // };
  // const MultipleImageUpload = ({  img_path, serverImages }) => {

  // const handleImageChange = (e) => {
  //   const files = Array.from(e.target.files); 

  //   if (files.length > 0) {

  //     const previews = files.map((file) => URL.createObjectURL(file));
  //     setImagePreviews(previews);


  //     formik.setFieldValue("thumbnails", files);
  //   } else {
  //     setImagePreviews([]);
  //     formik.setFieldValue("thumbnails", []);
  //   }
  // };







  const { state } = useLocation();
  const productData = state;
  console.log("productDatasssssEdit", productData)

  const [previewImages, setPreviewImages] = useState([]);
  console.log("previewImages", previewImages);

  let parses = [];
  try {
    parses = JSON.parse(productData.thumbnail || "[]");
    console.log("parses", parses);

  } catch (err) {
    console.error("Error parsing thumbnail JSON:", err);
  }

  const [initialThumbnal, setInitialThumbnal] = useState([]);
  const [imagePreviewThumb, setImagePreviewThumb] = useState([])

  const handleImageChangethumb = (e) => {
    console.log("thumbnail_", thumbnail);

    const files = Array.from(e.target.files);
    console.log("files", files);


    if (files.length === 0) {
      setImagePreviewThumb([]);
      formik.setFieldValue("thumbnail", []);
      return;
    }
    // if (thumbnail.length !== 0) {
    //   setImagePreviewThumb([thumbnail]);
    //   formik.setFieldValue("thumbnail", thumbnail);
    // }

    const previewUrls = files.map(file => URL.createObjectURL(file));

    setImagePreviewThumb(previewUrls);
    console.log("previewUrls", previewUrls);

    formik.setFieldValue("thumbnail", files);
  }

  // useEffect(() => {
  //   formik.setFieldValue('product_name', productData?.product_name)
  //   formik.setFieldValue('brand', productData?.brand)
  //   formik.setFieldValue('pro_category', productData?.pro_category)
  //   formik.setFieldValue('pro_sub_category', productData?.pro_sub_category)
  //   formik.setFieldValue('attribute', productData?.attribute)
  //   console.log(" productData?.attribute_name", productData?.attribute)
  //   formik.setFieldValue('attribute_type', productData?.attribute_type)
  //   console.log(" productData?.attribute_type", productData?.attribute_type)
  //   formik.setFieldValue('color', productData?.color)
  //   formik.setFieldValue('tag_no', productData?.tag_no)
  //   formik.setFieldValue('tag', productData?.tag)
  //   formik.setFieldValue('stock', productData?.stock)
  //   formik.setFieldValue('low_stk_alert', productData?.low_stk_alert)
  //   formik.setFieldValue('pro_sku', productData?.pro_sku)
  //   formik.setFieldValue('related_pro', productData?.related_pro)
  //   formik.setFieldValue('mrp', productData?.mrp)
  //   formik.setFieldValue('price', productData?.price)
  //   formik.setFieldValue('discount_type', productData?.discount_type)
  //   formik.setFieldValue('min_purchase_qty', productData?.min_purchase_qty)
  //   formik.setFieldValue('max_purchase_qty', productData?.max_purchase_qty)
  //   formik.setFieldValue('tax', productData?.tax)
  //   formik.setFieldValue('expired', productData?.expired)
  //   formik.setFieldValue('status', productData?.status)
  //   formik.setFieldValue('meta_title', productData?.meta_title)
  //   formik.setFieldValue('meta_description', productData?.meta_description)
  //   formik.setFieldValue('description', productData?.description)
  //   formik.setFieldValue('discount', productData?.discount)
  //   formik.setFieldValue('additional_info', productData?.additional_info)
  //   formik.setFieldValue('thumbnail', productData?.thumbnail)
  //   formik.setFieldValue('thumbnail', parses);
  //   console.log("productData?.thumbnail", 'thumbnail', parses)
  //   formik.setFieldValue('addtional_gender', productData?.addtional_gender)
  //   formik.setFieldValue('image', productData?.image)
  //   formik.setFieldValue('weight', productData?.weight)
  //   formik.setFieldValue('product_lable_id', productData?.product_lable_id)
  //   formik.setFieldValue('material_type', productData?.material_type)
  //   formik.setFieldValue('seller', productData?.seller)
  //   formik.setFieldValue('language_code', productData?.language)
  //   formik.setFieldValue('id', productData?.id)
  // }, [])

  const [thumbnail, setThumbnail] = useState()

  console.log("productData", productData);


  useEffect(() => {
    if (!fetchproducts || !fetchproducts.id) return;

    formik.setValues({
      product_name: fetchproducts?.translation?.product_name || "",
      brand: fetchproducts?.translation?.brand || "",
      pro_category: fetchproducts?.pro_category || "",
      pro_sub_category: fetchproducts?.pro_sub_category || "",
      attribute: fetchproducts?.translation?.attribute || "",
      attribute_type: fetchproducts?.translation?.attribute_type || "",
      color: fetchproducts?.color || "",
      tag_no: fetchproducts?.tag_no || "",
      tag: fetchproducts?.tag || "",
      stock: fetchproducts?.stock || "",
      low_stk_alert: fetchproducts?.low_stk_alert || "",
      pro_sku: fetchproducts?.pro_sku || "",
      related_pro: fetchproducts?.related_pro || "",
      mrp: fetchproducts?.mrp || "",
      price: fetchproducts?.price || "",
      discount_type: fetchproducts?.discount_type || "",
      min_purchase_qty: fetchproducts?.min_purchase_qty || "",
      max_purchase_qty: fetchproducts?.max_purchase_qty || "",
      tax: fetchproducts?.tax || "",
      expired: fetchproducts?.expired || "",
      status: fetchproducts?.status || "",
      meta_title: fetchproducts?.translation?.meta_title || "",
      meta_description: fetchproducts?.translation?.meta_description || "",
      description: fetchproducts?.translation?.description || "",
      discount: fetchproducts?.discount || "",
      additional_info: fetchproducts?.translation?.additional_info || "",
      thumbnail: parses || [],
      addtional_gender: fetchproducts?.addtional_gender || "",
      image: fetchproducts?.image || "",
      weight: fetchproducts?.weight || "",
      product_lable_id: fetchproducts?.product_lable_id || "",
      material_type: fetchproducts?.material_type || "",
      seller: fetchproducts?.translation?.seller || "",
      language_code: fetchproducts?.translation?.language_code || "",
      id: fetchproducts?.id || "",
    });
    // if (thumbnail.length !== 0) {
    //   setImagePreviewThumb([thumbnail]);
    //   formik.setFieldValue("thumbnail", thumbnail);
    // }
  }, [fetchproducts]);


  // useEffect(() => {
  //   if (!fetchproducts) return;

  //   formik.setValues({
  //     product_name: fetchproducts?.translations?.en?.product_name || "",
  //     category_id: fetchproducts?.category_id || "",
  //     description: fetchproducts?.translation?.description || "",
  //     status: fetchproducts?.status || "",
  //     thumbnail: null,
  //     language_code:
  //       fetchproducts?.translation?.language_code || language,
  //     id: fetchproducts?.id || "",
  //   });
  // }, [fetchproducts]);


  const [imagepre, setImagePre] = useState(null)
  const [imageChange, setImageChange] = useState(null)




  const langForEdit = null;
  useEffect(() => {
    if (productData?.pending_language) {
      setLanguage(productData.pending_language)
      formik.setFieldValue("language_code", productData.pending_language)
    }
    else if (productData?.language) {
      setLanguage(productData.language)
      formik.setFieldValue("language_code", productData.language)
    }
    console.log("oroductLanguage", productData.language);
  }, [productData])

  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products/${productData?.id}`, {
        params: {
          lang: language,
        },
      });
      setFetchproducts(response?.data);
      console.log("response_data", response.data);
      console.log("response_data_product", response.data);

      setImagePre(response?.data?.image)
      setThumbnail(response?.data?.thumbnail)

      console.log("response_data_thumb", response?.data?.thumbnail);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchproduct()
  }, [language])
  console.log("imagepre", imagepre)
  const fetch = async () => {
    try {
      const response = await axiosInstance.get(`/categories`, {
        params: {
          lang: language,
        },
      });
      setFetchcategory(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetch()
  }, [language])

  const fetchsubcate = async () => {
    try {
      const response = await axiosInstance.get(`/subcategories`, {
        params: {
          lang: language,
        },
      });
      setFetchsubcategory(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchsubcate()
  }, [language])

  const fetchAttributes = async () => {
    try {
      const response = await axiosInstance.get(`/attributes`, {
        params: {
          lang: language,
        },
      });
      setFetchAttribute(response.data.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetchAttributes()
  }, [language])



  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // setImagePre(URL.createObjectURL(file))
      setImageChange(URL.createObjectURL(file))
      // setImagePreview(URL.createObjectURL(file));
      formik.setFieldValue("image", file);
    } else {
      setImagePreview(null);
      formik.setFieldValue("image", null);
    }
  };

  const onSubmit = async (values) => {
    try {
      const formData = new FormData();
      //  Append all individual fields
      formData.append("product_name", values.product_name);
      formData.append("brand", values.brand);
      formData.append("pro_category", values.pro_category);
      formData.append("pro_sub_category", values.pro_sub_category);
      formData.append("attribute", values.attribute);
      formData.append("attribute_type", values.attribute_type);
      formData.append("color", values.color);
      formData.append("tag_no", values.tag_no);
      formData.append("tag", values.tag);
      formData.append("stock", values.stock);
      formData.append("low_stk_alert", values.low_stk_alert);
      formData.append("pro_sku", values.pro_sku);
      formData.append("related_pro", values.related_pro);
      formData.append("mrp", values.mrp);
      formData.append("price", values.price);
      formData.append("discount_type", values.discount_type);
      formData.append("min_purchase_qty", values.min_purchase_qty);
      formData.append("max_purchase_qty", values.max_purchase_qty);
      formData.append("tax", values.tax);
      formData.append("expired", values.expired);
      formData.append("status", values.status);
      formData.append("meta_title", values.meta_title);
      formData.append("meta_description", values.meta_description);
      formData.append("description", values.description);
      formData.append("discount", values.discount);
      formData.append("additional_info", values.additional_info);
      formData.append("addtional_gender", values.addtional_gender);
      formData.append("weight", values.weight);
      formData.append("product_lable_id", values.product_lable_id);
      formData.append("seller", values.seller);
      formData.append("material_type", values.material_type);
      formData.append("language_code", values.language_code);

      //  Append main image if available
      if (values.image) {
        formData.append("image", values.image);
      }

      if (values.thumbnail) {
        if (Array.isArray(values.thumbnail)) {
          // Multiple thumbnails
          values.thumbnail.forEach((file) => {
            formData.append("thumbnail[]", file);
          });
        } else {
          // Single file or existing URL
          formData.append("thumbnail[]", values.thumbnail);
        }
      }

      // API request
      const response = await axios.post(
        `${base_url}/products/${values.id}?_method=PUT`,
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
            Accept: "application/json",
            Authorization: `Bearer ${token}`,
          },
          // params: {
          //   lang: "all",
          // },
        }
      );
      //  On success
      Toast({ message: response.data.message, type: "success" });
      console.log("Success:", response.data);

      setImagePreview(null);
      setServerImage(response.data.thumbnail);
      formik.resetForm();
      navigate("/listproduct");
    } catch (error) {
      //  Handle validation or other errors
      if (error.response?.data?.errors) {
        console.error("Validation errors:", error.response.data.errors);
      } else {
        console.error("Something went wrong:", error.message);
      }
      Toast({ message: error?.response?.data?.message, type: "error" });
    }
  };

  const formik = useFormik(
    {
      initialValues: {
        product_name: "",
        brand: "",
        pro_category: "",
        pro_sub_category: "",
        attribute: "",
        attribute_type: "",
        color: "",
        tag_no: "",
        tag: "",
        stock: "",
        low_stk_alert: "",
        pro_sku: "",
        related_pro: "",
        mrp: "",
        price: "",
        discount_type: "",
        discount: "",
        min_purchase_qty: "",
        max_purchase_qty: "",
        tax: "",
        expired: "",
        status: "",
        meta_title: "",
        meta_description: "",
        thumbnail: null,
        description: "",
        additional_info: "",
        addtional_gender: "",
        image: null,
        weight: "",
        product_lable_id: "",
        seller: "",
        material_type: "",
        language_code: ""
      },
      validationSchema: yup.object().shape({
        product_name: yup.string().required("product_name is required!"),
        brand: yup.string().required("brand By is required"),
        pro_category: yup.string().required("pro_category is required!"),
        pro_sub_category: yup.string().required("pro_sub_category is required!"),
        attribute: yup.string().required("attribute By is required"),
        attribute_type: yup.string().required("attribute_type By is required"),
        weight: yup.string().required("weight By is required"),

        tag_no: yup.string().required("tag_no By is required"),
        tag: yup.string().required("tag By is required"),
        pro_sku: yup.string().required("pro_sku By is required"),
        related_pro: yup.string().required("related_pro By is required"),
        mrp: yup.string().required("mrp By is required"),
        price: yup.string().required("price By is required"),
        discount_type: yup.string().required("discount_type By is required"),
        discount: yup.string().required("discount By is required"),

        min_purchase_qty: yup.string().required("min_purchase_qty By is required"),
        max_purchase_qty: yup.string().required("max_purchase_qty By is required"),
        tax: yup.string().required("tax By is required"),
        expired: yup.string().required("expired By is required"),
        status: yup.string().required("status By is required"),
        meta_title: yup.string().required("meta_title By is required"),
        meta_description: yup.string().required("meta_description By is required"),
        description: yup.string().required("description By is required"),
        additional_info: yup.string().required("additional_info By is required"),

        seller: yup.string().required(" seller By is required"),
        material_type: yup.string().required(" material_type By is required"),
        product_lable_id: yup.string().required(" product_lable_id By is required"),
        stock: yup.number()
          .typeError("Stock must be a number")
          .required("Stock is required")
          .min(0, "Stock cannot be negative"),
        low_stk_alert: yup.number()
          .typeError("Low stock alert must be a number")
          .required("Low stock alert is required")
          .min(0, "Low stock alert cannot be negative")
          .test(
            "low-stock-less-than-stock",
            "Low stock alert must be less than stock",
            function (value) {
              const { stock } = this.parent;
              if (value === undefined || stock === undefined) return true;
              return Number(value) < Number(stock);
            }
          ),
      }),
      onSubmit,
    }
  )
  const handleLanguage = (e, lang) => {
    e.preventDefault();
    formik.setFieldValue("language_code", lang);
    setLanguage(lang)
  };

  return (
    <>
      <div className="d-flex justify-content-start">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/listproduct')}
        >
          ← Back
        </button>
      </div>
      <div className=' py-4'>
        <div className='box_shadow  rounded bg-white'>
          {/* <form onSubmit={formik.handleSubmit} autoComplete="off"> */}
          <form onSubmit={formik.handleSubmit} className='p-4'>
            <ul className="nav nav-tabs mb-3">
              <li className="nav-item">
                <button
                  type="button"
                  className={`nav-link ${language === "en" ? "active text-primary" : "text-black"
                    }`}

                  onClick={(e) => handleLanguage(e, "en")}
                >
                  English
                </button>
              </li>

              <li className="nav-item">
                <button
                  type="button"
                  className={`nav-link ${language === "de" ? "active text-primary" : "text-black"
                    }`}
                  onClick={(e) => handleLanguage(e, "de")}
                >
                  German
                </button>
              </li>
            </ul>
            {formik.errors.language_code && formik.touched.language_code && (
              <p style={{ color: "red", fontSize: "12px" }} className="mt-1">
                {formik.errors.language_code}
              </p>
            )}
            {language == "en" && (
              <div className='row '>
                <div className='col-12 col-md-12'>
                  <div className='d-flex'>
                    <h5>Product Information</h5>

                    {/* <div className="ms-4">
                      {/* <ul className="nav nav-tabs">
                        <li className="nav-item">
                          <button
                            type="button"
                            className={`nav-link ${language === "en" ? "active" : ""}`}
                            onClick={(e) => handleLanguage(e, "en")}
                          >
                            English
                          </button>
                        </li>

                        <li className="nav-item">
                          <button
                            type="button"
                            className={`nav-link ${language === "de" ? "active" : ""}`}
                            onClick={(e) => handleLanguage(e, "de")}
                          >
                            German
                          </button>
                        </li>
                      </ul> *

                      {formik.errors.language_code && formik.touched.language_code && (
                        <p style={{ color: "red", fontSize: "12px" }} className="mt-1">
                          {formik.errors.language_code}
                        </p>
                      )}
                    </div> */}


                    {/* <div className="dropdown ms-4">
                    <button
                      className="btn btn-outline-primary dropdown-toggle"
                      data-bs-toggle="dropdown"
                      type="button"
                    >
                      {formik.values.language_code === "en"
                        ? "English"
                        : formik.values.language_code === "de"
                          ? "German"
                          : "Select a language"}
                    </button>

                    <ul className="dropdown-menu">
                      <li>
                        <button
                          type="button"
                          className="dropdown-item"
                          onClick={() => {
                            formik.setFieldValue("language_code", "en")
                            setLanguage("en")
                          }}
                        >
                          English
                        </button>
                      </li>

                      <li>
                        <button
                          type="button"
                          className="dropdown-item"
                          onClick={() => {
                            formik.setFieldValue("language_code", "de")
                            setLanguage("de")
                          }}
                        >
                          German
                        </button>
                      </li>
                    </ul>
                    {formik.errors.language_code && formik.touched.language_code && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.language_code}
                      </p>
                    )}
                  </div> */}

                  </div>
                  {/* <hr /> */}

                  <div className='row g-4 mt-2'>

                    <div className='col-12 col-md-6'>

                      <div className='mb-3'>
                        <label htmlFor="product_lable_id" className='form-label text-muted'>Product ID</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          name='product_lable_id'
                          id="product_lable_id"
                          placeholder='Enter Product ID'
                          value={formik.values.product_lable_id}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.product_lable_id && formik.touched.product_lable_id && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.product_lable_id}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="product_name" className='form-label text-muted '>Product Name</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          name='product_name'
                          id="product_name"
                          placeholder='Enter Product Name'
                          value={formik.values.product_name}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.product_name && formik.touched.product_name && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.product_name}
                          </p>
                        )}
                      </div>

                      <div className='mb-3'>
                        <label htmlFor="pro_category" className='form-label text-muted'>Product Categories</label>
                        <select
                          className="form-select"
                          id="pro_category"
                          name="pro_category"
                          value={formik.values.pro_category}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        >
                          <option value=''>Select product category</option>
                          {fetchcategory?.length > 0 ? (
                            fetchcategory.map((item) => (
                              <option key={item.id} value={item.id}>
                                {item.title}
                              </option>
                            ))
                          ) : (
                            <option value="" disabled>No data</option>
                          )}
                        </select>


                        {/* {formik.values.pro_category === "Garments" && (
                        <div className="mb-3 pt-4 ps-4">
                          <label className="form-label text-muted">Additional Gender</label>
                          <div className="d-flex  gap-2">
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="addtional_gender"
                                id="addtional_gender"
                                value="Men"
                                checked={formik.values.addtional_gender === "Men"}
                                onChange={formik.handleChange}
                              />
                              <label className="form-check-label ms-2" htmlFor="addtional_gender">
                                Men
                              </label>
                            </div>
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="addtional_gender"
                                id="addtional_gender"
                                value="Women"
                                checked={formik.values.addtional_gender === "Women"}
                                onChange={formik.handleChange}
                              />
                              <label className="form-check-label ms-2" htmlFor="addtional_gender">
                                Women
                              </label>
                            </div>
                            <div className="form-check">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="addtional_gender"
                                id="addtional_gender"
                                value="kids"
                                checked={formik.values.addtional_gender === "kids"}
                                onChange={formik.handleChange}
                              />
                              <label className="form-check-label ms-2" htmlFor="addtional_gender">
                                kids
                              </label>
                            </div>
                          </div>
                        </div>
                      )} */}

                      </div>

                      <div className='mb-3'>
                        <label htmlFor="pro_sub_category" className='form-label text-muted'>Product Sub Categories </label>
                        <select className="form-select opacity-75" id="pro_sub_category" name="pro_sub_category"
                          value={formik.values.pro_sub_category}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}>
                          <option>Select Creator</option>
                          {/* {fetchsubcategory
          ?.filter((sub) => sub.pro_category_id == formik.values.pro_category)  
          .map((item) => (
            <option key={item.id} value={item.id}>
              {item.title}
            </option>
          ))} */}
                          {fetchsubcategory?.filter(
                            (sub) => sub.category_id == formik.values.pro_category
                          ).length > 0 ? (
                            fetchsubcategory
                              .filter((sub) => sub.category_id == formik.values.pro_category)
                              .map((item) => (
                                <option key={item.id} value={item.id}>
                                  {item.title}
                                </option>
                              ))
                          ) : (
                            <option value='' disabled>No data</option>
                          )}
                          {/* {fetchsubcategory?.length > 0 ? (
                          fetchsubcategory?.map((item) => (
                            <option key={item.id} value={item.id} >{item.title} </option>
                          ))

                        ) : (<option value="">No data</option>)} */}

                        </select>
                        {formik.errors.pro_sub_category && formik.touched.pro_sub_category && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.pro_sub_category}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className='col-12 col-md-6'>
                      <div className='mb-3'>
                        <label htmlFor="brand" className='form-label text-muted'>Brand</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          name='brand'
                          id="brand"
                          placeholder='Enter Brand'
                          value={formik.values.brand}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.brand && formik.touched.brand && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.brand}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="attribute" className='form-label text-muted'>Select Attribute</label>
                        <select
                          className="form-select "
                          id="attribute"
                          name="attribute"
                          value={formik.values.attribute}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        >
                          <option value=''  >select product Attribute</option>

                          {/* {fetchAttribute?.length > 0 ? (
                          fetchAttribute.map((item) => (
                            <option key={item.id} value={item.id}>
                              {item.attribute_title}
                            </option>
                          ))
                        ) : (
                          <option value="" disabled>No data</option>
                        )} */}
                          {fetchAttribute?.length > 0 ? (
                            fetchAttribute.map((item) => (
                              <option key={item.id} value={item.id}>
                                {item.attribute_title}
                              </option>
                            ))
                          ) : (
                            <option value="" disabled>No data</option>
                          )}

                        </select>
                        {formik.errors.attribute && formik.touched.attribute && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.attribute}
                          </p>
                        )}
                      </div>

                      <div className='mb-3'>
                        <label htmlFor="attribute_type" className='form-label text-muted'>Attribute Type</label>
                        <input
                          type='text'
                          name='attribute_type'
                          className='form-control opacity-75'
                          id="attribute_type"
                          placeholder='Enter Attribute Type'
                          value={formik.values.attribute_type}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.attribute_type && formik.touched.attribute_type && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.attribute_type}
                          </p>
                        )}
                      </div>

                      <div className='mb-3'>
                        <label htmlFor="weight" className='form-label text-muted'>Weight/value</label>
                        <input
                          type='text'
                          name='weight'
                          className='form-control opacity-75'
                          id="weight"
                          placeholder='Enter Weight'
                          value={formik.values.weight}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.weight && formik.touched.weight && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.weight}
                          </p>
                        )}
                      </div>
                    </div>
                    <div>
                      <input
                        type="file"
                        name="thumbnail"
                        multiple
                        accept="image/*"
                        title='Please Enter Your New Image'

                        onChange={handleImageChangethumb}


                      // onChange={(e) => {
                      //   const newFiles = Array.from(e.currentTarget.files);

                      //   // Add new files to existing thumbnails (string paths or File objects)
                      //   formik.setFieldValue("thumbnail", [
                      //     ...formik.values.thumbnail,
                      //     ...newFiles,
                      //   ]);

                      //   // Add preview URLs for new files
                      //   const newPreviews = newFiles.map((file) => URL.createObjectURL(file));
                      //   setPreviewImages((prev) => [...prev, ...newPreviews]);
                      //   console.log("p__", (prev) => [...prev, ...newPreviews]);
                      //   console.log("p__", newPreviews);

                      // }}
                      />

                      {/* <input
                        type="file"
                        name="thumbnail"
                        multiple
                        accept="image/*"
                        title='Please Enter Your New Image'

                        onChange={handleImageChangethumb}
                        className='form-control w-25 m-2'
                        style={{ fontSize: "12px" }}
                      /> */}



                      {parses?.length > 0 && imagePreviewThumb?.length <= 0 &&
                        <>
                          <div className="d-flex gap-2 m-1">
                            <strong> Old Images </strong>
                            {parses?.length > 0 ? (
                              parses.map((item, index) => (
                                <img
                                  key={index}
                                  src={`${img_path}/products/${item}`}
                                  alt="Preview"
                                  className="img-fluid rounded preview-thumb"
                                  style={{
                                    maxHeight: "100px",
                                    maxWidth: "100px",
                                    objectFit: "contain",
                                    border: "1px solid #ccc",
                                    padding: "5px",
                                  }}
                                />
                              ))
                            ) : (
                              // <p> No Image </p>
                              <>
                                {imagePreviewThumb?.length > 0 ? (imagePreviewThumb.map((item) => (
                                  <img
                                    src={item
                                      // : `${img_path}/product/${serverImage}`
                                    }
                                    alt="Preview"
                                    className="img-fluid rounded"
                                    style={{
                                      maxHeight: "100px",
                                      maxWidth: "100px",
                                      objectFit: "contain",
                                      border: "1px solid #ccc",
                                      padding: "5px",
                                    }}
                                  />
                                ))
                                ) : <p> No Image </p>}
                              </>
                            )}
                          </div>
                        </>
                        // : <p> No Image </p>
                      }

                      {imagePreviewThumb?.length > 0 && <>

                        <div className='d-flex gap-2'>
                          <strong> New Images </strong>
                          {imagePreviewThumb?.length > 0 ? (imagePreviewThumb.map((item) => (
                            <img
                              src={item
                                // : `${img_path}/product/${serverImage}`
                              }
                              alt="Preview"
                              className="img-fluid rounded"
                              style={{
                                maxHeight: "100px",
                                maxWidth: "100px",
                                objectFit: "contain",
                                border: "1px solid #ccc",
                                padding: "5px",
                              }}
                            />
                          ))
                          ) : <p> No Image </p>}
                        </div>
                      </>
                      }


                      {/* <div className='d-flex gap-2'>
                        {imagePreviewThumb.map((item) => (
                          <img
                            src={item
                              // : `${img_path}/product/${serverImage}`
                            }
                            alt="Preview"
                            className="img-fluid rounded"
                            style={{
                              maxHeight: "100px",
                              maxWidth: "100px",
                              objectFit: "contain",
                              border: "1px solid #ccc",
                              padding: "5px",
                            }}
                          />
                        ))
                        }
                      </div> */}
                    </div>
                    {/* <input
                    type="file"
                    name="thumbnail"
                    multiple
                    accept="image/*"
                    onChange={(e) => {
                      const files = Array.from(e.currentTarget.files);
                      formik.setFieldValue("thumbnail", files);
                    }}
                  /> */}

                    <div className=''>
                      <div className=" flex justify-content-center">
                        {/* <ColorPicker value={color} onChange={(e) => setColor(e.value)} /> */}
                        <div className="flex justify-content-center">
                          <input
                            type="color"
                            id="color"
                            name="color"
                            className="form-control form-control-color"
                            value={formik.values.color}
                            onChange={(e) => formik.setFieldValue("color", e.target.value)}
                          />
                        </div>

                      </div>
                    </div>
                    <div className='col-12'>
                      <div className='mb-3'>
                        {/* <label htmlFor="description" className='form-label text-muted'>Description</label>
                                            <textarea
                                                className="form-control "
                                                id="description"
                                                rows="5"
                                                placeholder="Type description"
                                            ></textarea> */}
                        {/* <div className="">
                              <Editor value={text} onTextChange={(e) => setText(e.htmlValue)} style={{ height: '320px' }} />
                             </div> */}
                        <div className="">

                          <label htmlFor="description" className='form-label text-muted'>Description</label>


                          <Editor
                            key={language}
                            value={formik.values.description}
                            style={{ height: "320px" }}
                            onTextChange={(e) => {
                              if (e.source !== "user") return;
                              formik.setFieldValue("description", e.htmlValue);
                            }}
                          />

                          {/* <Editor
                            id="description"
                            name="description"
                            value={formik.values.description}
                            onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                            onBlur={formik.handleBlur}
                            style={{ height: "320px" }}
                          /> */}

                          {formik.errors.description && formik.touched.description && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.description}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className='col-12'>
                      <div className='mb-3'>

                        <div className="">
                          <label htmlFor="additional_info" className='form-label text-muted'>Additional Information</label>

                          {/* <Editor
                            id="additional_info"
                            name="additional_info"
                            value={formik.values.additional_info}
                            onTextChange={(e) => formik.setFieldValue("additional_info", e.htmlValue)}
                            onBlur={formik.handleBlur}
                            style={{ height: "320px" }}
                          /> */}

                          <Editor
                            key={language}
                            value={formik.values.additional_info}
                            style={{ height: "320px" }}
                            onTextChange={(e) => {
                              if (e.source !== "user") return;
                              formik.setFieldValue("additional_info", e.htmlValue);
                            }}
                          />
                          {formik.errors.additional_info && formik.touched.additional_info && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.additional_info}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className='box_shadow p-4 rounded mt-4 bg-white'>
                    <h5> ProductStock</h5>
                    <hr />
                    <div className='row'>
                      <div className='col-12 col-md-6'>
                        <div className='mb-3'>
                          <label htmlFor="tag_no" className='form-label text-muted'>Tag No</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="createdBy"
                            name='tag_no'
                            placeholder='Enter Tag No'
                            value={formik.values.tag_no}
                            // onChange={formik.handleChange}
                            onChange={(e) => {
                              const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                              formik.setFieldValue("tag_no", onlyNumbers);
                            }}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.tag_no && formik.touched.tag_no && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.tag_no}
                            </p>
                          )}
                        </div>
                        <div className='mb-3'>
                          <label htmlFor="stock" className='form-label text-muted'>Stock</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="stock"
                            name='stock'
                            placeholder='Enter Stock'
                            value={formik.values.stock}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.stock && formik.touched.stock && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.stock}
                            </p>
                          )}
                        </div>
                        <div className='mb-3'>
                          <label htmlFor="pro_sku" className='form-label text-muted'>Product SKU</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="createdBy"
                            name='pro_sku'
                            placeholder='Enter Product SKU'
                            value={formik.values.pro_sku}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.pro_sku && formik.touched.pro_sku && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.pro_sku}
                            </p>
                          )}
                        </div>
                        <div className='mb-3'>
                          <label htmlFor="material_type" className='form-label text-muted'>MaterialType</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="material_type"
                            name='material_type'
                            placeholder='Enter Material Type'
                            value={formik.values.material_type}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.material_type && formik.touched.material_type && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.material_type}
                            </p>
                          )}
                        </div>
                      </div>

                      <div className='col-12 col-md-6'>
                        <div className='mb-3'>
                          <label htmlFor="tag" className='form-label text-muted'>Tag</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="tag"
                            name='tag'
                            placeholder='Enter Tag'
                            value={formik.values.tag}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.tag && formik.touched.tag && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.tag}
                            </p>
                          )}
                        </div>
                        <div className='mb-3'>
                          <label htmlFor="low_stk_alert" className='form-label text-muted'>Low stock alert Limit</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="low_stk_alert"
                            name='low_stk_alert'
                            placeholder='Enter Low stock'
                            value={formik.values.low_stk_alert}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.low_stk_alert && formik.touched.low_stk_alert && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.low_stk_alert}
                            </p>
                          )}
                        </div>
                        <div className='mb-3'>
                          <label htmlFor="related_pro" className='form-label text-muted'>Related Products</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="related_pro"
                            name='related_pro'
                            placeholder='Enter Related Products'
                            value={formik.values.related_pro}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.related_pro && formik.touched.related_pro && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.related_pro}
                            </p>
                          )}
                        </div>
                        <div className='mb-3'>
                          <label htmlFor="seller" className='form-label text-muted'>Seller</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="seller"
                            name='seller'
                            placeholder='Enter Seller'
                            value={formik.values.seller}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.seller && formik.touched.seller && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.seller}
                            </p>
                          )}
                        </div>

                      </div>
                    </div>

                  </div>

                  <div className='box_shadow p-4 rounded mt-4 bg-white'>
                    <h5> Pricing Details</h5>
                    <hr />
                    <div className='row'>
                      <div className='col-12 col-md-3'>

                        <div className='d-flex'>

                          <div className='mb-3  me-2'>
                            <label htmlFor="mrp" className='form-label text-muted '>MRP</label>
                            <input
                              type='text'
                              className='form-control opacity-75'
                              id="mrp"
                              name='mrp'
                              placeholder='Enter MRP'
                              value={formik.values.mrp}
                              // onChange={formik.handleChange}
                              onChange={(e) => {
                                const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                                formik.setFieldValue("mrp", onlyNumbers);
                              }}
                              onBlur={formik.handleBlur}
                            />
                            {formik.errors.mrp && formik.touched.mrp && (
                              <p style={{ color: "red", fontSize: "12px" }}>
                                {formik.errors.mrp}
                              </p>
                            )}
                          </div>
                          <div className='mb-3'>
                            <label htmlFor="price" className='form-label text-muted'>Price ($)</label>
                            <input
                              type='text'
                              className='form-control opacity-75'
                              id="price"
                              name='price'
                              placeholder='Enter Price'
                              value={formik.values.price}
                              // onChange={formik.handleChange}
                              onChange={(e) => {
                                const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                                formik.setFieldValue("price", onlyNumbers);
                              }}
                              onBlur={formik.handleBlur}
                            />
                            {formik.errors.price && formik.touched.price && (
                              <p style={{ color: "red", fontSize: "12px" }}>
                                {formik.errors.price}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className='mb-3 pt-4'>
                          <label htmlFor="tax" className='form-label text-muted'>Tax (%)</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="tax"
                            name='tax'
                            placeholder='Enter Tax'
                            value={formik.values.tax}
                            // onChange={formik.handleChange}
                            onChange={(e) => {
                              const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                              formik.setFieldValue("tax", onlyNumbers);
                            }}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.tax && formik.touched.tax && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.tax}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className='col-12 col-md-3'>
                        <div className='mb-3'>
                          <label htmlFor="discount_type" className='form-label text-muted'>Discount by</label>
                          <select className="form-select opacity-75" id="discount_type" name="discount_type"
                            value={formik.values.discount_type}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}>
                            <option value="">Select Creator</option>
                            <option value="Admin">Admin</option>
                            <option value="Other">Other</option>
                            <option value="Seller">Seller</option>
                          </select>
                          {formik.errors.discount_type && formik.touched.discount_type && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.discount_type}
                            </p>
                          )}
                        </div>
                        <div className='mb-3 pt-4'>
                          <label htmlFor="max_purchase_qty" className='form-label text-muted'>Maximum Purchase Qty</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="max_purchase_qty"
                            name='max_purchase_qty'
                            placeholder='Enter Maximum Purchase Qty'
                            value={formik.values.max_purchase_qty}
                            // onChange={formik.handleChange}
                            onChange={(e) => {
                              const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                              formik.setFieldValue("max_purchase_qty", onlyNumbers);
                            }}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.max_purchase_qty && formik.touched.max_purchase_qty && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.max_purchase_qty}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className='col-12 col-md-3'>
                        <div className='mb-3'>
                          <label htmlFor="discount" className='form-label text-muted'>Discount </label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="discount"
                            name='discountdiscount'
                            placeholder='Enter Discount'
                            value={formik.values.discount}
                            // onChange={formik.handleChange}
                            onChange={(e) => {
                              const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                              formik.setFieldValue("discount", onlyNumbers);
                            }}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.discount && formik.touched.discount && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.discount}
                            </p>
                          )}
                        </div>

                        <div className="mb-3 pt-4 ps-4">
                          <label className="form-label text-muted">Status</label>
                          <div className="d-flex flex-column gap-2">
                            <div className="form-check">
                              {/* <input
                                className="form-check-input"
                                type="radio"
                                name="status"
                                id="status-active"
                                value="active"
                                checked={formik.values.status === "active"}
                                onChange={formik.handleChange}
                              /> */}
                              <RadioButton inputId="ingredient1" name="status" id="status-active" value="active" defaultChecked
                                checked={formik.values.status === "active"}
                                onChange={formik.handleChange}
                              />
                              <label className="form-check-label ms-2" htmlFor="status-active">
                                Active
                              </label>
                            </div>
                            <div className="form-check">
                              {/* <input
                                className="form-check-input"
                                type="radio"
                                name="status"
                                id="status-inactive"
                                value="inactive"
                                checked={formik.values.status === "inactive"}
                                onChange={formik.handleChange}
                              /> */}
                              <RadioButton inputId="ingredient2" name="status" id="status-inactive" value="inactive"
                                checked={formik.values.status === "inactive"}
                                onChange={formik.handleChange}
                              />
                              <label className="form-check-label ms-2" htmlFor="status-inactive">
                                Inactive
                              </label>
                            </div>
                            {/* <div className="form-check">
                              <input
                                className="form-check-input"
                                type="radio"
                                name="status"
                                id="status-future"
                                value="future"
                                checked={formik.values.status === "future"}
                                onChange={formik.handleChange}
                              />
                              <label className="form-check-label ms-2" htmlFor="status-future">
                                Future Plan
                              </label>
                            </div> */}
                          </div>
                        </div>
                      </div>

                      <div className='col-12 col-md-3'>

                        <div className='mb-3'>
                          <label htmlFor="min_purchase_qty" className='form-label text-muted'>Minimum Purchase Qty</label>
                          <input
                            type='text'
                            className='form-control opacity-75'
                            id="min_purchase_qty"
                            name='min_purchase_qty'
                            placeholder='Enter Minimum Purchase Qty'
                            value={formik.values.min_purchase_qty}
                            // onChange={formik.handleChange}
                            onChange={(e) => {
                              const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                              formik.setFieldValue("min_purchase_qty", onlyNumbers);
                            }}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.min_purchase_qty && formik.touched.min_purchase_qty && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.min_purchase_qty}
                            </p>
                          )}
                        </div>
                        <div className='mb-3 pt-4'>
                          <label htmlFor="expired" className='form-label text-muted'>Expired</label>
                          {/* <input
                          type='date'
                          className="form-control"
                          id="expired"
                          name='expired'
                          rows="4"
                          placeholder="Type date"
                          value={formik.values.expired}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        /> */}
                          <DatePicker
                            id="expired"
                            name="expired"
                            format="MM-DD-YYYY"
                            // value={formik.values.expired ? dayjs(formik.values.expired) : null}
                            value={formik.values.expired ? dayjs(formik.values.expired, "YYYY-MM-DD") : ""}
                            onChange={(date) => {
                              formik.setFieldValue(
                                "expired",
                                date ? date.format("YYYY-MM-DD") : ""
                              );
                            }}
                            onBlur={() => formik.setFieldTouched("expired", true)}
                            style={{ width: "100%" }}
                          />

                          {formik.errors.expired && formik.touched.expired && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.expired}
                            </p>
                          )}
                          {formik.errors.expired && formik.touched.expired && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.expired}
                            </p>
                          )}
                        </div>

                      </div>
                    </div>
                  </div>
                  <div className='box_shadow p-4 rounded mt-4 bg-white'>
                    <h5> Meta Data</h5>
                    <hr />
                    <div className='row'>
                      <div className='col-12 col-md-12'>
                        <div className='mb-3'>
                          <label htmlFor="meta_title" className='form-label text-muted ps-1'>Meta Title</label>
                          <input
                            type='text'
                            className='form-control opacity-75 w-25'
                            id="meta_title"
                            name='meta_title'
                            placeholder='Enter Meta Data'
                            value={formik.values.meta_title}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                          />
                          {formik.errors.meta_title && formik.touched.meta_title && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.meta_title}
                            </p>
                          )}
                        </div>

                        <div className='mb-3'>
                          {/* <label htmlFor="description" className='form-label text-muted'>Description</label>
                                            <textarea
                                                className="form-control "
                                                id="description"
                                                rows="5"
                                                placeholder="Type description"
                                            ></textarea> */}
                          <div className="">

                            <label htmlFor="meta_title" className='form-label text-muted ps-1'>Meta Description</label>



                            <Editor
                              key={language}
                              value={formik.values.meta_description}
                              style={{ height: "320px" }}
                              onTextChange={(e) => {
                                if (e.source !== "user") return;
                                formik.setFieldValue("meta_description", e.htmlValue);
                              }}
                            />


                            {/* <Editor
                              id="meta_description"
                              name="meta_description"
                              value={formik.values.meta_description}
                              onTextChange={(e) => formik.setFieldValue("meta_description", e.htmlValue)}
                              onBlur={formik.handleBlur}
                              style={{ height: "200px" }}
                            /> */}
                            {formik.errors.meta_description && formik.touched.meta_description && (
                              <p style={{ color: "red", fontSize: "12px" }}>
                                {formik.errors.meta_description}
                              </p>
                            )}

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            {language == "en" && (
              <div className='row py-4'>
                <div className="col-12 col-md-12 ">

                  <div className="box_shadow pb-4 bg-white">
                    <h5 className="mb-3 ms-4 pt-3">Add Product image</h5>
                    <hr />

                    {/* <div
                       className="border border-dotted p-5 mx-auto text-center my-5"
                       style={{ maxWidth: "800px", minHeight: "300px", display: "flex", alignItems: "center", justifyContent: "center" }}
                     >
     
                       <input
                         type="file"
                         id="thumbnail-upload"
                         className="d-none"
                         accept="image/png, image/jpeg, image/gif"
                         onChange={handleImageChange}
                       />
     
                       {imagePreview || serverImage ? (
                         <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                           <img
                             src={
                               imagePreview
                                 ? imagePreview
                                 : `${img_path}/product/${serverImage}`
                             }
                             alt="Preview"
                             className="img-fluid rounded"
                             style={{
                               maxHeight: "100%",
                               maxWidth: "100%",
                               objectFit: "contain",
                               border: "1px solid #ccc",
                               padding: "5px",
                             }}
                           />
                         </label>
                       ) : (
     
                         <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                           <BiCloudUpload size={50} className="color_icon mb-3" />
                           <h4>
                             Drop your images here, or{" "}
                             <span className="color_icon">click to browse</span>
                           </h4>
                           <p className="small text-muted">
                             1600 x 1200 (4:3) recommended. PNG, JPG and GIF files are allowed
                           </p>
                         </label>
                       )}
                     </div> */}

                    <div
                      className="border border-dotted  mx-auto text-center"
                      style={{ maxWidth: "800px", minHeight: "200px", display: "flex", alignItems: "center", justifyContent: "center" }}
                    >
                      <input
                        type="file"
                        id="thumbnail-upload"
                        className="d-none"
                        accept="image/png, image/jpeg, image/gif"
                        onChange={handleImageChange}
                      />
                      {imagepre || imageChange ? (
                        <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                          <img
                            src={
                              // imagePreview
                              // ? imagePreview :
                              imageChange ? imageChange : `${img_path}/products/${imagepre}`
                            }
                            alt="Preview"
                            className="img-fluid rounded"
                            style={{
                              maxHeight: "200px",
                              maxWidth: "100%",
                              objectFit: "contain",
                              border: "1px solid #ccc",
                              padding: "5px",
                            }}
                          />
                        </label>
                      ) : (

                        <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                          <BiCloudUpload size={50} className="color_icon mb-3" />
                          <h4>
                            Drop your images here, or{" "}
                            <span className="color_icon">click to browse</span>
                          </h4>
                          <p className="small text-muted">
                            1600 x 1200 (4:3) recommended. PNG, JPG and GIF files are allowed
                          </p>
                        </label>
                      )}
                    </div>
                  </div>

                </div>
              </div>
            )}
            {language == "de" && (

              <div className='row pb-3'>
                <div className='col-12 col-md-12'>

                  {/* <div className='box_shadow p-4 rounded bg-white'> */}
                  <div className='d-flex'>
                    <h5>Product Information</h5>


                    {/* <div className="dropdown ms-4">
                      <button
                        className="btn btn-outline-primary dropdown-toggle"
                        data-bs-toggle="dropdown"
                        type="button"
                      >
                        {language === "en"
                          ? "English"
                          : language === "de"
                            ? "German"
                            : "Select a language"}
                      </button>
                      <ul className="dropdown-menu">
                        <li>
                          <button
                            type="button"
                            className="dropdown-item"
                            onClick={(e) => handleLanguage(e, "en")}
                          >
                            English
                          </button>
                        </li>

                        <li>
                          <button
                            type="button"
                            className="dropdown-item"
                            onClick={(e) => handleLanguage(e, "de")}
                          >
                            German
                          </button>
                        </li>
                      </ul>

                      {formik.errors.language_code && formik.touched.language_code && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.language_code}
                        </p>
                      )}
                    </div> */}
                  </div>
                  <hr />

                  <div className='row g-4'>

                    <div className='col-12 col-md-6'>
                      <div className='mb-3'>
                        <label htmlFor="product_name" className='form-label text-muted '>Product Name</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          name='product_name'
                          id="product_name"
                          placeholder='Enter Product Name'
                          value={formik.values.product_name}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.product_name && formik.touched.product_name && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.product_name}
                          </p>
                        )}
                      </div>

                      <div className='mb-3'>
                        <label htmlFor="brand" className='form-label text-muted'>Brand</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          name='brand'
                          id="brand"
                          placeholder='Enter Brand'
                          value={formik.values.brand}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.brand && formik.touched.brand && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.brand}
                          </p>
                        )}
                      </div>

                      <div className='mb-3'>
                        <label htmlFor="seller" className='form-label text-muted'>Seller</label>
                        <input
                          type='text'
                          className='form-control opacity-75'
                          id="seller"
                          name='seller'
                          placeholder='Enter seller'
                          value={formik.values.seller}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.seller && formik.touched.seller && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.seller}
                          </p>
                        )}
                      </div>
                      <div className="">
                        <label htmlFor="seller" className='form-label text-muted'>Description</label>


                        <Editor
                          key={language}
                          value={formik.values.description}
                          style={{ height: "320px" }}
                          onTextChange={(e) => {
                            if (e.source !== "user") return;
                            formik.setFieldValue("description", e.htmlValue);
                          }}
                        />

                        {/* <Editor
                          id="description"
                          name="description"
                          value={formik.values.description}
                          onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                          onBlur={formik.handleBlur}
                          style={{ height: "320px" }}
                        /> */}


                        {formik.errors.description && formik.touched.description && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.description}
                          </p>
                        )}

                      </div>
                      <div className="mt-3">
                        <label htmlFor="seller" className='form-label text-muted'>Meta Description</label>


                        <Editor
                          key={language}
                          value={formik.values.meta_description}
                          style={{ height: "320px" }}
                          onTextChange={(e) => {
                            if (e.source !== "user") return;
                            formik.setFieldValue("meta_description", e.htmlValue);
                          }}
                        />


                        {/* <Editor
                          id="meta_description"
                          name="meta_description"
                          value={formik.values.meta_description}
                          onTextChange={(e) => formik.setFieldValue("meta_description", e.htmlValue)}
                          onBlur={formik.handleBlur}
                          style={{ height: "200px" }}
                        /> */}

                        {formik.errors.meta_description && formik.touched.meta_description && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.meta_description}
                          </p>
                        )}

                      </div>

                    </div>
                    <div className='col-12 col-md-6'>

                      <div className='mb-3'>
                        <label htmlFor="attribute" className='form-label text-muted'>Select Attribute</label>
                        <select
                          className="form-select "
                          id="attribute"
                          name="attribute"
                          value={formik.values.attribute}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        >
                          <option value=''>select product Attribute</option>

                          {fetchAttribute?.length > 0 ? (
                            fetchAttribute.map((item) => (
                              <option key={item.id} value={item.id}>
                                {item.attribute_title}
                              </option>
                            ))
                          ) : (
                            <option value="" disabled>No data</option>
                          )}

                        </select>
                        {formik.errors.attribute && formik.touched.attribute && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.attribute}
                          </p>
                        )}
                      </div>

                      <div className='mb-3'>
                        <label htmlFor="attribute_type" className='form-label text-muted'>Select Attribute Type</label>
                        <input
                          type='text'
                          name='attribute_type'
                          className='form-control opacity-75'
                          id="attribute_type"
                          placeholder='Enter Attribute Type'
                          value={formik.values.attribute_type}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.attribute_type && formik.touched.attribute_type && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.attribute_type}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <label htmlFor="meta_title" className='form-label text-muted ps-1'>Meta Title</label>
                        <input
                          type='text'
                          className='form-control opacity-75 w-25'
                          id="meta_title"
                          name='meta_title'
                          placeholder='Enter Meta Data'
                          value={formik.values.meta_title}
                          onChange={formik.handleChange}
                          onBlur={formik.handleBlur}
                        />
                        {formik.errors.meta_title && formik.touched.meta_title && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.meta_title}
                          </p>
                        )}
                      </div>
                      <div className='mb-3'>
                        <div className="">
                          <label htmlFor="additional_info" className='form-label text-muted'>Additional Information</label>


                          <Editor
                            key={language}
                            value={formik.values.additional_info}
                            style={{ height: "320px" }}
                            onTextChange={(e) => {
                              if (e.source !== "user") return;
                              formik.setFieldValue("additional_info", e.htmlValue);
                            }}
                          />

                          {/* <Editor
                            id="additional_info"
                            name="additional_info"
                            value={formik.values.additional_info}
                            onTextChange={(e) => formik.setFieldValue("additional_info", e.htmlValue)}
                            onBlur={formik.handleBlur}
                            style={{ height: "320px" }}
                          /> */}

                          {formik.errors.additional_info && formik.touched.additional_info && (
                            <p style={{ color: "red", fontSize: "12px" }}>
                              {formik.errors.additional_info}
                            </p>
                          )}

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* </div> */}

              </div>
            )}
            <div className='col-12 d-flex justify-content-end gap-3 '>
              {/* <button className='btn btn-danger bg_color'onClick={()=>formik.resetForm()}>Cancel</button> */}
              <button type="submit" className='btn btn-outline-success'>Update</button>
            </div>
          </form>
        </div>
      </div>
    </>
  )
}
export default EditProduct



