import React, { useEffect, useMemo, useState } from 'react'
import './product.css'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
import Toast from '../../utils/Toast';
import { img_path } from '../../Api/BaseUrl';
import { FiPlus } from "react-icons/fi";
import customStyle from '../../utils/Customstyle';

const Language_Pending = () => {

  const navigate = useNavigate()
  const [fetchproducts, setFetchproducts] = useState([]);
  console.log("fetchproductsssssssss", fetchproducts)

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [viewconfirmmodal, setViewconfirmmodal] = useState(false);
  const [viewProduct, setViewProduct] = useState(null);

  const [language, setLanguage] = useState("all");

  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products/lang/pending`, {
        params: {
          lang: language,
        },
      });
      setFetchproducts(response.data.data);
      console.log("responsedata_langpending", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchproduct()
  }, [language])

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const gotToProductEdit = (row) => {
    navigate('/editproducts', { state: row })

    console.log("row",row);
    
  }

  // const columns = [
  const columns = useMemo(() => [
    {
      name: "S.no",
      cell: (row, index) => (
        <div className="px-3 py-2">
          {index + 1}
        </div>
      ),
      wrap: true,
      sortable: true,
      width: "110px"
    },
    {
      name: "Product Name",
      selector: (row) => row.product_name,
      sortable: true,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.product_name}
        </span>
      ),
    },
    {
      name: "Existing Language",
      selector: (row) => row.available_language,
      wrap: true,
      sortable: true,
    },
    {
      name: "Pending Language",
      selector: (row) => row.pending_language,
      wrap: true,
      sortable: true,
    },
    {
      name: " Edit Language",
      cell: (row) => (
        <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => gotToProductEdit(row)}>
          <LuPencilLine size={16} color="red" />
        </div>
      )

    }
  ], []);
  // ];

  const editnagicate = (row) => {
    navigate('/editproducts', { state: row })
  }
  const handleConfirmClosedelete = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopendelete = async (item) => {
    try {
      const response = await axiosInstance.delete(`/products/${item.id}`, {
        params: {
          lang: item.language,
        },
      });
      fetchproduct()
      Toast({ message: response.data.message, type: "success" });
    } catch (error) {
      console.error("Delete error:", error);
    } finally {
      setDeleteconfirmmodal(false);
    }

  }
  const handleRowClick = (row) => {
  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['product_name', 'existing_languages', 'pending_languages',];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  // const filterdata = SearchData(fetchproducts, filterText, searchColumns);
  const uniqueData = useMemo(() => {
    const map = new Map();
    fetchproducts.forEach(item => {
      map.set(`${item.id}-${item.language}`, item);
    });
    return Array.from(map.values());
  }, [fetchproducts]);

  const filterdata = useMemo(() => {
    return SearchData(uniqueData, filterText, searchColumns);
  }, [uniqueData, filterText]);


  return (
    <>
      <div className='container'>

        <div className='mt-3 box_shadow  bg-white rounded-1'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3 d-flex'>
              <h5 className='pt-1'> Language Pending </h5>
              {/* <div className="dropdown ms-2">
                <button
                  type="button"
                  className="btn btn-outline-primary dropdown-toggle"
                  data-bs-toggle="dropdown"
                >
                  {language === "all"
                    ? "All"
                    : language === "en"
                      ? "English"
                      : "German"}
                </button>

                <ul className="dropdown-menu">
                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("all")}
                    >
                      All
                    </button>
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("en")}
                    >
                      English
                    </button>
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("de")}
                    >
                      German
                    </button>
                  </li>
                </ul>
              </div> */}
            </div>
            {/* <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <Link to="/CreateProduct" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div></Link>
            </div> */}
          </div>

          <div className='pt-2'>

            {/* <DataTable
              columns={columns}
             data={filterdata}
             customStyles={customStyle}
              pagination
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            /> */}
            <DataTable
              columns={columns}
              data={filterdata}
              customStyles={customStyle}
              keyField={row => `${row.id}-${row.language}`}
              pagination
              fixedHeader
            />
          </div>
        </div>
      </div>

      <Dialog header="Confirm Delete " visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmClosedelete()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmopendelete(selectedRowId)}>Yes </Button>
        </div>

      </Dialog>

      <Dialog header="Confirm product View" visible={viewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!viewconfirmmodal) return; setViewconfirmmodal(false); }}>
        {viewProduct && (
          <div className='row'>
            <div className='col'>
              <p><strong>Product Name  : </strong>   {viewProduct.product_name}</p>
              <p>   <strong>Product Categories  :</strong> {viewProduct.pro_category}</p>
              <p>   <strong>Additional Gender : </strong>{viewProduct.addtional_gender}</p>
              <p>  <strong>Select Attribute :</strong> {viewProduct.attribute}</p>
              <p>  <strong>Brand :</strong> {viewProduct.brand}</p>
              <p>  <strong>Product Sub Categories :</strong> {viewProduct.pro_sub_category}</p>
              <p>  <strong>Select Attribute Type : </strong>{viewProduct.attribute_type}</p>

              <p> <strong>description :</strong>{" "}{viewProduct.description?.replace(/<[^>]+>/g, "")}</p>

              <p>
                <strong>Additional Information :</strong>{" "}
                {viewProduct.additional_info?.replace(/<[^>]+>/g, "")}
              </p>
              <p>  <strong>Tag No :</strong> {viewProduct.tag_no}</p>
              <p>  <strong>Stock :</strong> {viewProduct.stock}</p>
              <p>  <strong>Product SKU :</strong> {viewProduct.pro_sku}</p>
              <p>  <strong>Tag :</strong> {viewProduct.tag}</p>
            </div>
            <div className='col'>
              <p>  <strong>Low stock alert threshold :</strong> {viewProduct.low_stk_alert}</p>
              <p>  <strong>Related Products :</strong> {viewProduct.related_pro}</p>
              <p>  <strong>MRP :</strong> {viewProduct.mrp}</p>
              <p>  <strong>Price :</strong> {viewProduct.price}</p>
              <p>  <strong>Tax :</strong> {viewProduct.tax}</p>
              <p>  <strong>Discount by :</strong> {viewProduct.discount_type}</p>
              <p>  <strong>Maximum Purchase Qty : </strong>{viewProduct.max_purchase_qty}</p>
              <p>   <strong>Discount : </strong>   {viewProduct.discount}</p>
              <p>  <strong>Status : </strong>{viewProduct.status}</p>
              <p>  <strong>Minimum Purchase Qty :</strong> {viewProduct.max_purchase_qty}</p>
              <p>  <strong>Expired :  </strong>  {viewProduct.expired}</p>
              <p>  <strong>Meta Title : </strong>   {viewProduct.meta_title}</p>

            </div>
            <div className="col-12 mt-3">
              <h6>Product Images:</h6>
              <div className="d-flex flex-wrap">
                {(() => {
                  let thumbnails = [];

                  if (viewProduct.thumbnail) {
                    try {
                      thumbnails =
                        typeof viewProduct.thumbnail === "string"
                          ? JSON.parse(viewProduct.thumbnail)
                          : viewProduct.thumbnail;
                    } catch (e) {
                      console.error("Invalid JSON for thumbnail:", viewProduct.thumbnail);
                      thumbnails = [];
                    }
                  }

                  return thumbnails.length > 0 ? (
                    thumbnails.map((img, idx) => (
                      <img
                        key={idx}
                        src={`${img_path}/products/${img}`}
                        alt={viewProduct.product_name}
                        style={{
                          width: "100px",
                          height: "80px",
                          objectFit: "cover",
                          borderRadius: "6px",
                          marginRight: "5px",
                        }}
                      />
                    ))
                  ) : (
                    <span className="text-muted">No image</span>
                  );
                })()}
              </div>
            </div>
          </div>
        )}

      </Dialog>
    </>
  )
}
export default Language_Pending;