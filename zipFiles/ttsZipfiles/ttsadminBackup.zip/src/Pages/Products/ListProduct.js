import React, { useEffect, useMemo, useState } from 'react'
import './product.css'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { FaRegEyeSlash } from "react-icons/fa";
// import { CiNoWaitingSign } from "react-icons/ci";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
import Toast from '../../utils/Toast';
import { img_path } from '../../Api/BaseUrl';
import { FiPlus } from "react-icons/fi";
import customStyle from '../../utils/Customstyle';

const ListProduct = () => {

  const navigate = useNavigate()
  const [fetchproducts, setFetchproducts] = useState([]);
  console.log("fetchproductsssssssss", fetchproducts)

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectedRowId, setSelectedRowId] = useState(null);
  const [viewconfirmmodal, setViewconfirmmodal] = useState(false);
  const [viewProductEng, setviewProductEng] = useState(null);
  const [viewProductGer, setviewProductGer] = useState(null);
  const [viewconfirmmodalGerman, setViewconfirmmodalGerman] = useState(false);

  const [language, setLanguage] = useState("all");

  const fetchproduct = async () => {
    try {
      const response = await axiosInstance.get(`/products`, {
        params: {
          lang: "all",
        },
      });
      setFetchproducts(response.data.data);
      console.log("response_data_all", response.data.data);
      const fil = response?.data?.data.map((value, index) => value.id);
      console.log("filllll", fil);

    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchproduct()
  }, [language])

  const [fetchproductsGerman, setFetchproductsGerman] = useState("");
  const [germanProductName, setGermanProductName] = useState();

  // const fetchproductGerman = async (rowid) => {
  //   console.log("germanid", rowid);

  //   try {
  //     const response = await axiosInstance.get(`/products/${rowid}`, {
  //       params: {
  //         lang: "de",
  //       },
  //     });
  //     console.log("response_data_german", response?.data)
  //     console.log("response_data_german_name", response?.data?.translation?.product_name)
  //     setFetchproductsGerman(response.data);
  //   } catch (error) {
  //     console.error("Error fetching data", error);
  //   }
  // };

  // useEffect(() => {
  //   fetchproductGerman()
  // }, [])

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const [productImgE, setProductImgE] = useState(null)
  const [productImgG, setProductImgG] = useState(null)

  // const columns = [
  const columns = useMemo(() => [
    {
      name: "S.no",
      cell: (row, index) => (
        <div className="px-3 py-2">
          {index + 1}
        </div>
      ),
      wrap: true,
      sortable: true,
      width: "100px"
    },
    {
      name: "Product Name",
      width: "150px",
      selector: (row) => row.product_name,
      sortable: true,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row?.translations?.en ? row?.translations?.en?.product_name : row?.translations?.de?.product_name}
        </span>
      ),
    },

    {
      name: "Image",
      cell: (row) => (
        row.image ? (
          <img
            src={`${img_path}/products/${row.image}`}
            alt={row.title}
            style={{ width: "30px", height: "30px", objectFit: "cover", borderRadius: "6px" }}
          />
        ) : (
          <span className="text-muted">No image</span>
        )
      ),
      wrap: true,
      sortable: false,
    },

    //   {
    // name: "Images",
    // cell: (row) => {
    //   let thumbnails = [];

    //   if (row.thumbnail) {
    //     try {

    //       thumbnails =
    //         typeof row.thumbnail === "string"
    //           ? JSON.parse(row.thumbnail)
    //           : row.thumbnail;
    //     } catch (e) {
    //       console.error("Invalid JSON for thumbnail:", row.thumbnail);
    //       thumbnails = [];
    //     }
    //   }

    //   return thumbnails.length > 0 ? (
    //     thumbnails.map((img, idx) => (
    //       <img
    //         key={idx}
    //         src={`${img_path}/products/${img}`}
    //         alt={row.title}
    //         style={{
    //           width: "100px",
    //           height: "80px",
    //           objectFit: "cover",
    //           borderRadius: "6px",
    //           marginRight: "5px",
    //         }}
    //       />
    //     ))
    //   ) : (
    //     <span className="text-muted">No image</span>
    //   );
    // },
    // wrap: true,
    // sortable: false,
    //  },

    {
      name: "Category",
      selector: (row) => row.category_name,
      wrap: true,
      sortable: true,
      width: "150px",
    },
    // {
    //   name: "Brand",
    //   selector: (row) => row.brand,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "language",
      width: "150px",
      cell: (row) => {

        const en = row?.translations?.en?.product_name
        const de = row?.translations?.de?.product_name

        return (
          <>
            {en ? <p className='px-2'> en </p> : ""}
            {de ? <p className='mt-0 px-2'> de</p> : ""}
          </>

        )
      },
      wrap: true,
      sortable: true,
    },

    {
      name: "SKU",
      selector: (row) => row.pro_sku,
      wrap: true,
      sortable: true,
      // width: "170px",
    },
    {
      name: "Price ($)",
      selector: (row) => row.price,
      wrap: true,
      sortable: true,
    },
    {
      name: "Tax",
      selector: (row) => row.tax,
      wrap: true,
      sortable: true,
    },
    {
      name: "weight",
      selector: (row) => row.weight,
      wrap: true,
      sortable: true,
    },
    {
      name: "Product label Id",
      selector: (row) => row.product_lable_id,
      wrap: true,
      sortable: true,
      width: "180px",
    },
    {
      name: "Product ID",
      selector: (row) => row.product_id,
      wrap: true,
      sortable: true,
      width: "150px",
    },
    {
      name: "Stock Qty",
      selector: (row) => row.stock,
      wrap: true,
      sortable: true,
      width: "150px",
    },
    {
      name: "Material Type",
      selector: (row) => row.material_type,
      wrap: true,
      sortable: true,
      width: "150px",
    },
    // {
    //   name: "seller",
    //   selector: (row) => row.seller,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Low Stock Alert",
      selector: (row) => row.low_stk_alert,
      wrap: true,
      sortable: true,
      width: "180px",
    },
    {
      name: "Status",
      selector: (row) => row.status,
      wrap: true,
      sortable: true,
    },
    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      width: "300px",
      cell: (row) => {

        const actions = () => {


        }
        // <button className="btn btn-danger btn-sm">Delete</button>
        return (

          <div className="d-flex gap-2 grow-1 w-100 justify-content-center"
          // style={{ width: "1000px" }}
          >
            {row?.translations?.en?.product_name ?
              <div className='d-flex' style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => {
                setviewProductEng(row?.translations?.en);
                setProductImgE(row?.image)

                setViewconfirmmodal(true);
                console.log("endE", row);
                console.log("endjjj", row?.language);
                console.log("endIdE", row?.id);

              }} >
                <p className='text-white' style={{
                  fontSize: "12px",
                  lineHeight: "20px",
                  marginTop: "1px"
                }}>EN</p>
                <GrFormView size={22} color="white" />
              </div>
              :
              <div className='d-flex' style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} >
                {/* <CiNoWaitingSign size={20} color="red" /> */}
                <p className='text-white' style={{
                  fontSize: "12px",
                  lineHeight: "20px",
                  marginTop: "1px"
                }}>EN</p>
                <FaRegEyeSlash style={{ padding: "3px" }} size={20} color="red" />
              </div>
            }

            {/* german */}
            {row?.translations?.de?.product_name ?
              <div className='d-flex' style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => {
                setviewProductGer(row?.translations?.de);
                setProductImgG(row?.image)
                // fetchproductGerman(row?.id)
                setViewconfirmmodalGerman(true);
                console.log("endG", row);
                console.log("end", row?.language);
                console.log("endidG", row?.id);
              }} >

                <p className='text-white' style={{
                  fontSize: "12px",
                  lineHeight: "20px",
                  marginTop: "1px"
                }}>DE</p>
                <GrFormView size={22} color="white" />
              </div>
              :

              <div className='d-flex' style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} >
                {/* <CiNoWaitingSign size={20} color="red" /> */}
                <p className='text-white' style={{
                  fontSize: "12px",
                  lineHeight: "20px",
                  marginTop: "1px"
                }}>DE</p>
                <FaRegEyeSlash style={{ padding: "3px" }} size={20} color="red" />
              </div>
              // <div className='d-flex' style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} >
              //   {/* <CiNoWaitingSign size={20} color="red" /> */}
              //   {/* <p className='text-white' style={{
              //     fontSize: "12px",
              //     lineHeight: "20px",
              //     marginTop: "1px"
              //   }}>DE</p> */}
              //   <FaRegEyeSlash style={{padding: "3px"}} size={20} color="red" />
              // </div>
            }

            {/*  */}

            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}

              onClick={() => editnagicate(row) || console.log("endjjj", row)}>
              <LuPencilLine size={16} color="red" />
            </div>

            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setSelectedRowId(row); setDeleteconfirmmodal(true); }}>
              <AiOutlineDelete size={18} color="red" />
            </div>
          </div>
        )
      },
      wrap: true,
    },
  ], [img_path]);
  // ];

  const editnagicate = (row) => {
    navigate('/editproducts', { state: row })
  }
  const handleConfirmClosedelete = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopendelete = async (item) => {
    try {
      const response = await axiosInstance.delete(`/products/${item.id}`, {
        params: {
          lang: item.language,
        },
      });
      fetchproduct()
      Toast({ message: response.data.message, type: "success" });
    } catch (error) {
      console.error("Delete error:", error);
    } finally {
      setDeleteconfirmmodal(false);
    }

  }
  const handleRowClick = (row) => {
  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['product_name', 'pro_category', 'brand', 'pro_sku', 'price', 'stock', 'low_stk_alert', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  // const filterdata = SearchData(fetchproducts, filterText, searchColumns);
  const uniqueData = useMemo(() => {
    const map = new Map();
    fetchproducts.forEach(item => {
      // map.set(`${item.id}-${item.language}`, item);
      map.set(`${item.id}`, item);
    });
    return Array.from(map.values());
  }, [fetchproducts]);

  const filterdata = useMemo(() => {
    return SearchData(uniqueData, filterText, searchColumns);
  }, [uniqueData, filterText]);


  return (
    <>
      <div className='container'>

        <div className='mt-3 box_shadow  bg-white rounded-1'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3 d-flex'>
              <h5 className='pt-1'> Product </h5>
              {/* <div className="dropdown ms-2">
                  <button
                    type="button"
                    className="btn btn-outline-primary dropdown-toggle"
                    data-bs-toggle="dropdown"
                  >
                    {language === "all"
                      ? "All"
                      : language === "en"
                        ? "English"
                        : "German"}
                    select language
                  </button>

                  <ul className="dropdown-menu">
                    <li>
                      <button
                        type="button"
                        className="dropdown-item"
                        onClick={() => setLanguage("all")}
                      >
                        All
                      </button>
                    </li>

                    <li>
                      <button
                        type="button"
                        className="dropdown-item"
                        onClick={() => setLanguage("en")}
                      >
                        English
                      </button>
                    </li>

                    <li>
                      <button
                        type="button"
                        className="dropdown-item"
                        onClick={() => setLanguage("de")}
                      >
                        German
                      </button>
                    </li>
                  </ul>
                </div> */}
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <Link to="/CreateProduct" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div></Link>
            </div>
          </div>

          <div className='pt-2'>

            {/* <DataTable
              columns={columns}
             data={filterdata}
             customStyles={customStyle}
              pagination
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            /> */}
            <DataTable
              columns={columns}
              data={filterdata}
              customStyles={customStyle}
              keyField={row => `${row.id}-${row.language}`}
              pagination
              fixedHeader
              className='productListDataTable'
            />
          </div>
        </div>
      </div>

      <Dialog header="Confirm Delete " visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmClosedelete()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmopendelete(selectedRowId)}>Yes </Button>
        </div>

      </Dialog>

      <Dialog header="Confirm product View" visible={viewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!viewconfirmmodal) return; setViewconfirmmodal(false); }}>
        {/* {viewProductEng && (
          <div className='row'>
            <div className='col'>
              <p><strong>Product Name  : </strong>   {viewProductEng?.translations?.en?.product_name}</p>
              <p>   <strong>Product Categories  :</strong> {viewProductEng.pro_category}</p>
              <p>   <strong>Additional Gender : </strong>{viewProductEng.addtional_gender}</p>
              <p>  <strong>Select Attribute :</strong> {viewProductEng?.translations?.en?.attribute_name}</p>
              <p>  <strong>Brand :</strong> {viewProductEng?.translations?.en?.brand}</p>
              <p>  <strong>Product Sub Categories :</strong> {viewProductEng.pro_sub_category}</p>
              <p>  <strong>Select Attribute Type : </strong>{viewProductEng?.translations?.en?.attribute_type_name}</p>

              <p> <strong>description :</strong>{" "}{viewProductEng?.translations?.en?.description?.replace(/<[^>]+>/g, "")}</p>

              <p>
                <strong>Additional Information :</strong>{" "}
                {viewProductEng?.translations?.en?.additional_info?.replace(/<[^>]+>/g, "")}
              </p>
              <p>  <strong>Tag No :</strong> {viewProductEng.tag_no}</p>
              <p>  <strong>Stock :</strong> {viewProductEng.stock}</p>
              <p>  <strong>Product SKU :</strong> {viewProductEng.pro_sku}</p>
              <p>  <strong>Tag :</strong> {viewProductEng.tag}</p>
            </div>
            <div className='col'>
              <p>  <strong>Low stock alert threshold :</strong> {viewProductEng.low_stk_alert}</p>
              <p>  <strong>Related Products :</strong> {viewProductEng.related_pro}</p>
              <p>  <strong>MRP :</strong> {viewProductEng.mrp}</p>
              <p>  <strong>Price :</strong> {viewProductEng.price}</p>
              <p>  <strong>Tax :</strong> {viewProductEng.tax}</p>
              <p>  <strong>Discount by :</strong> {viewProductEng.discount_type}</p>
              <p>  <strong>Maximum Purchase Qty : </strong>{viewProductEng.max_purchase_qty}</p>
              <p>   <strong>Discount : </strong>   {viewProductEng.discount}</p>
              <p>  <strong>Status : </strong>{viewProductEng.status}</p>
              <p>  <strong>Minimum Purchase Qty :</strong> {viewProductEng.max_purchase_qty}</p>
              <p>  <strong>Expired :  </strong>  {viewProductEng.expired}</p>
              <p>  <strong>Meta Title : </strong>   {viewProductEng?.translations?.en?.meta_title}</p>
              <p>  <strong>Product Subcategory Name Title : </strong>   {viewProductEng.subcategory_name}</p>


            </div>
            <div className="col-12 mt-3">
              <h6>Product Images:</h6>
              <div className="d-flex flex-wrap">
                {(() => {
                  let thumbnails = [];

                  if (viewProductEng.thumbnail) {
                    try {
                      thumbnails =
                        typeof viewProductEng.thumbnail === "string"
                          ? JSON.parse(viewProductEng.thumbnail)
                          : viewProductEng.thumbnail;
                    } catch (e) {
                      console.error("Invalid JSON for thumbnail:", viewProductEng.thumbnail);
                      thumbnails = [];
                    }
                  }

                  return thumbnails.length > 0 ? (
                    thumbnails.map((img, idx) => (
                      <img
                        key={idx}
                        src={`${img_path}/products/${img}`}
                        alt={viewProductEng.product_name}
                        style={{
                          width: "100px",
                          height: "80px",
                          objectFit: "cover",
                          borderRadius: "6px",
                          marginRight: "5px",
                        }}
                      />
                    ))
                  ) : (
                    <span className="text-muted">No image</span>
                  );
                })()}
              </div>
            </div>
          </div>
        )} */}



        {viewProductEng && (
          <div className='row'>
            <div className='col'>
              <p> <strong>Product Name  : </strong>   {viewProductEng?.product_name}</p>
              <p> <strong>description :</strong> {" "}{viewProductEng?.description?.replace(/<[^>]+>/g, "")}</p>
              <p> <strong>Brand :</strong> {viewProductEng?.brand}</p>
              {/* <p>  <strong>Attribute :</strong> {viewProductEng?.attribute_name}</p>
              <p>  <strong>Attribute Type :</strong> {viewProductEng?.attribute_type_name}</p> */}

            </div>


            <div className='col'>
              <p> <strong>description :</strong>{" "}{viewProductEng?.description?.replace(/<[^>]+>/g, "")}</p>
              <p>
                <strong>Additional Information :</strong>{" "}{viewProductEng?.additional_info?.replace(/<[^>]+>/g, "")}
              </p>

              <p>  <strong>Meta Title : </strong>{viewProductEng?.meta_title}</p>
              <p>  <strong>Meta Description : </strong>{viewProductEng?.meta_description}</p>
              <p>  <strong>Seller : </strong>{viewProductEng?.seller}</p>
            </div>



            <div className="col-md-3 pt-2">
              <div className="border p-2">
                <img
                  src={`${img_path}/products/${productImgE}`}
                  // alt={item.product_name}
                  className="img-fluid rounded d-block mx-auto"
                  style={{ width: "120px", height: "120px", objectFit: "contain" }}
                />
              </div>
            </div>









          </div>
        )}

      </Dialog>

      <Dialog header="Confirm product View" visible={viewconfirmmodalGerman} position="top" style={{ width: '80vw' }} onHide={() => { if (!viewconfirmmodalGerman) return; setViewconfirmmodalGerman(false); }}>

        {/* german view */}

        {/* {viewProductGer && (
          <div className='row'>
            <div className='col'>
              <p><strong>Product Name  : </strong>   {viewProductGer?.translation?.product_name}</p>
              <p>   <strong>Product Categories  :</strong> {viewProductGer?.pro_category}</p>
              <p>   <strong>Additional Gender : </strong>{viewProductGer?.addtional_gender}</p>
              <p>  <strong>Select Attribute :</strong> {viewProductGer?.translation?.attribute}</p>
              <p>  <strong>Brand :</strong> {viewProductGer?.translation?.brand}</p>
              <p>  <strong>Product Sub Categories :</strong> {viewProductGer.pro_sub_category}</p>
              <p>  <strong>Select Attribute Type : </strong>{viewProductGer?.translation?.attribute_type}</p>

              <p> <strong>description :</strong>{" "}{viewProductGer?.translation?.description?.replace(/<[^>]+>/g, "")}</p>

              <p>
                <strong>Additional Information :</strong>{" "}
                {viewProductEng?.translations?.de?.additional_info?.replace(/<[^>]+>/g, "")}
              </p>
              <p>  <strong>Tag No :</strong> {viewProductGer.tag_no}</p>
              <p>  <strong>Stock :</strong> {viewProductGer.stock}</p>
              <p>  <strong>Product SKU :</strong> {viewProductGer.pro_sku}</p>
              <p>  <strong>Tag :</strong> {viewProductGer.tag}</p>
            </div>
            <div className='col'>
              <p>  <strong>Low stock alert threshold :</strong> {viewProductGer.low_stk_alert}</p>
              <p>  <strong>Related Products :</strong> {viewProductGer.related_pro}</p>
              <p>  <strong>MRP :</strong> {viewProductGer.mrp}</p>
              <p>  <strong>Price :</strong> {viewProductGer.price}</p>
              <p>  <strong>Tax :</strong> {viewProductGer.tax}</p>
              <p>  <strong>Discount by :</strong> {viewProductGer.discount_type}</p>
              <p>  <strong>Maximum Purchase Qty : </strong>{viewProductGer.max_purchase_qty}</p>
              <p>   <strong>Discount : </strong>   {viewProductGer.discount}</p>
              <p>  <strong>Status : </strong>{viewProductGer.status}</p>
              <p>  <strong>Minimum Purchase Qty :</strong> {viewProductGer.max_purchase_qty}</p>
              <p>  <strong>Expired :  </strong>  {viewProductGer.expired}</p>
              <p>  <strong>Meta Title : </strong>   {viewProductGer.translation?.meta_title}</p>
              <p>  <strong>Product Subcategory Name Title : </strong>   {viewProductGer.subcategory_name}</p>


            </div>
            <div className="col-12 mt-3">
              <h6>Product Images:</h6>
              <div className="d-flex flex-wrap">
                {(() => {
                  let thumbnails = [];

                  if (viewProductGer.thumbnail) {
                    try {
                      thumbnails =
                        typeof viewProductGer.thumbnail === "string"
                          ? JSON.parse(viewProductGer.thumbnail)
                          : viewProductEng.thumbnail;
                    } catch (e) {
                      console.error("Invalid JSON for thumbnail:", viewProductGer.thumbnail);
                      thumbnails = [];
                    }
                  }

                  return thumbnails.length > 0 ? (
                    thumbnails.map((img, idx) => (
                      <img
                        key={idx}
                        src={`${img_path}/products/${img}`}
                        alt={viewProductGer?.translation?.product_name}
                        style={{
                          width: "100px",
                          height: "80px",
                          objectFit: "cover",
                          borderRadius: "6px",
                          marginRight: "5px",
                        }}
                      />
                    ))
                  ) : (
                    <span className="text-muted">No image</span>
                  );
                })()}
              </div>
            </div>
          </div>
        )} */}

        {viewProductGer && (
          <div className='row'>
            <div className='col'>
              <p> <strong>Product Name  : </strong>   {viewProductGer?.product_name}</p>
              <p> <strong>description :</strong> {" "}{viewProductGer?.description?.replace(/<[^>]+>/g, "")}</p>
              <p> <strong>Brand :</strong> {viewProductGer?.brand}</p>
              {/* <p>  <strong>Attribute :</strong> {viewProductGer?.attribute_name}</p>
              <p>  <strong>Attribute Type :</strong> {viewProductGer?.attribute_type_name}</p> */}

            </div>


            <div className='col'>
              <p> <strong>description :</strong>{" "}{viewProductGer?.description?.replace(/<[^>]+>/g, "")}</p>
              <p>
                <strong>Additional Information :</strong>{" "}{viewProductGer?.additional_info?.replace(/<[^>]+>/g, "")}
              </p>

              <p>  <strong>Meta Title : </strong>{viewProductGer?.meta_title}</p>
              <p>  <strong>Meta Description : </strong>{viewProductGer?.meta_description}</p>
              <p>  <strong>Seller : </strong>{viewProductGer?.seller}</p>
            </div>


            <div className="col-md-3 pt-2">
              <div className="border p-2">
                <img
                  src={`${img_path}/products/${productImgG}`}
                  // alt={item.product_name}
                  className="img-fluid rounded d-block mx-auto"
                  style={{ width: "120px", height: "120px", objectFit: "contain" }}
                />
              </div>
            </div>
            
          </div>
        )}
      </Dialog>

    </>
  )
}

export default ListProduct