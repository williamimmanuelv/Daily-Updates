import React, { useState, useEffect, useRef } from "react";
import Button from "@mui/material/Button";
// import { Html5QrcodeScanner } from "html5-qrcode";
import axiosInstance from "../../utils/axiosinstance";
import { img_path } from "../../Api/BaseUrl";
import { Dialog } from "primereact/dialog";
 import {
  Html5QrcodeScanner,
  Html5QrcodeSupportedFormats,
  Html5QrcodeScanType
 } from "html5-qrcode";

const QrScanner = () => {
  const [code, setCode] = useState("");
  const [result, setResult] = useState("");
  const [product, setProduct] = useState(null);
  const [scanning, setScanning] = useState(false);
  const scannerRef = useRef(null);
  const [viewconfirmmodal, setViewconfirmmodal] = useState(false);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (scannerRef.current) scannerRef.current.clear().catch(() => { });
    };
  }, []);

  const startScanner = () => {
    setScanning(true);
    setResult("");
    setProduct(null);

    setTimeout(() => {
      const scanner = new Html5QrcodeScanner(
        "reader",
        {
          fps: 10,
          qrbox: { width: 300, height: 150 },
          },
        false
      );

      // scanner.render(
      //   (decodedText) => {
      //     setCode(decodedText);
      //     setResult(decodedText);
      //     setScanning(false);
      //     scanner.clear();

      //     fetchProductScanner(decodedText);

      // new Audio("https://assets.mixkit.co/sfx/preview/mixkit-arcade-game-jump-coin-216.mp3").play();
      //     const beep = new Audio("https://raw.githubusercontent.com/johnsonsu/AudioSamples/main/beep.mp3");
      //     beep.play().catch(() => { });

      //   },
      //   () => { }
      // );
      scanner.render(
        (decodedText) => {
          const cleaned = decodedText.trim();

          // Allow alphabets, numbers, hyphen, slash, space
          if (!/^[A-Za-z0-9\-\/\s]+$/.test(cleaned)) {
            alert("Invalid barcode format!");
            return;
          }
          setCode(cleaned);
          setResult(cleaned);
          setScanning(false);
          scanner.clear();

          fetchProductScanner(cleaned);

          const beep = new Audio(
            "https://raw.githubusercontent.com/johnsonsu/AudioSamples/main/beep.mp3"
          );
          beep.play().catch(() => { });
        },
        () => { }
      );
      scannerRef.current = scanner;
    }, 150);
  };
 const stopScanner = () => {
    if (scannerRef.current) {
      scannerRef.current.clear().catch(() => { });
      scannerRef.current = null;
    }
    setScanning(false);
  };
 const [fetchScanner, setFetchScanner] = useState([])
  console.log("fetchScannerrrr", fetchScanner)

  const fetchProductScanner = async (barcode) => {
    try {
      const response = await axiosInstance.get(`/products/scanner/${barcode}`,);
      setFetchScanner(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
    setViewconfirmmodal(true)

  };

  //  Manual search also calls API
  const handleSearch = () => {
    if (code.trim() !== "") {
      fetchProductScanner(code.trim());
    }
  };

  return (
    <>
      <div className="container py-5">
        <h3 className="text-center mb-4">Product Barcode Scanner</h3>

        <div className="row justify-content-center">
          <div className="col-md-6">

            {/* Input */}
            <div className="mb-4">
              <label className="form-label">Enter Product Code</label>
              <input
                type="text"
                className="form-control form-control-lg"
                placeholder="Type or scan barcode..."
                value={code}
                // onChange={(e) => setCode(e.target.value)}
                onChange={(e) => {
                  const val = e.target.value;
                  if (/^[A-Za-z0-9]*$/.test(val)) {   // only alphanumeric allowed
                    setCode(val);
                  }
                }}
              />
            </div>

            <div className="text-center mb-4">
              <Button
                variant="contained"
                color="success"
                size="large"
                disabled={!code}
                onClick={handleSearch}
              >
                Search Product
              </Button>
            </div>

            {/* Scanner */}
            <div className="text-center w-75 ms-5">
              {!scanning ? (
                <Button variant="outlined" color="primary" size="large" onClick={startScanner}>
                  Open Barcode Scanner  
                </Button>
              ) : (
                <div className="position-relative  border rounded shadow overflow-hidden">
                  <div id="reader" style={{ width: "100%", maxWidth: "520px" }}></div>

                  {/* Animated Red Laser */}
                  <div
                    style={{
                      position: "absolute",
                      top: 0,
                      left: "50%",
                      transform: "translateX(-50%)",
                      width: "80%",
                      height: "4px",
                      background: "red",
                      boxShadow: "0 0 30px 8px red",
                      animation: "laser 3.8s infinite",
                      pointerEvents: "none",
                    }}
                  />
                   <Button variant="contained" color="error" className="mt-3" onClick={stopScanner}>
                    Close Scanner
                  </Button>
                </div>
              )}
            </div>

            {/* Success Message */}
            {result && (
              <div className="mt-4 p-4 bg-success text-white rounded text-center">
                <h4>Scanned Successfully!</h4>
                <h5 className="mb-0">{result}</h5>
              </div>
            )}

            {/* Display Product From API */}
            {product && (
              <div className="mt-4 p-3 border rounded bg-light">
                <h5>Product Details:</h5>
                <pre className="small">{JSON.stringify(product, null, 2)}</pre>
              </div>
            )}

          </div>
        </div>

        <style>{`
        @keyframes laser {
          0% { transform: translate(-50%, -300px); }
          50% { transform: translate(-50%, 300px); }
          100% { transform: translate(-50%, -300px); }
        }
      `}</style>


      </div>
      <Dialog header="Confirm product View" visible={viewconfirmmodal} position="top" style={{ width: '80vw' }} onHide={() => { if (!viewconfirmmodal) return; setViewconfirmmodal(false); }}>
        {fetchScanner && (
          <div className='row'>
            <div className='col'>
              <p><strong>Product_QRCODE: </strong>   {fetchScanner.product_lable_id}</p>

              <p><strong>Product Name  : </strong>   {fetchScanner.product_name}</p>
              <p>   <strong>Product Categories  :</strong> {fetchScanner.pro_category}</p>
              <p>   <strong>Additional Gender : </strong>{fetchScanner.addtional_gender}</p>
              <p>  <strong>Select Attribute :</strong> {fetchScanner.attribute}</p>
              <p>  <strong>Brand :</strong> {fetchScanner.brand}</p>
              <p>  <strong>Product Sub Categories :</strong> {fetchScanner.pro_sub_category}</p>
              <p>  <strong>Select Attribute Type : </strong>{fetchScanner.attribute_type}</p>
              {/* <p>  <strong>description :</strong> {fetchScanner.description}</p> */}
              <p>
                <strong>Additional Information :</strong>{" "}
                {fetchScanner.description?.replace(/<[^>]+>/g, "")}
              </p>
              {/* <p>  <strong>Additional Information :</strong> {fetchScanner.additional_info}</p> */}
              <p>
                <strong>Additional Information :</strong>{" "}
                {fetchScanner.additional_info?.replace(/<[^>]+>/g, "")}
              </p>
              <p>  <strong>Tag No :</strong> {fetchScanner.tag_no}</p>
              <p>  <strong>Stock :</strong> {fetchScanner.stock}</p>
              <p>  <strong>Product SKU :</strong> {fetchScanner.pro_sku}</p>
              <p>  <strong>Tag :</strong> {fetchScanner.tag}</p>
            </div>
            <div className='col'>
              <p>  <strong>Low stock alert threshold :</strong> {fetchScanner.low_stk_alert}</p>
              <p>  <strong>Related Products :</strong> {fetchScanner.related_pro}</p>
              <p>  <strong>MRP :</strong> {fetchScanner.mrp}</p>
              <p>  <strong>Price :</strong> {fetchScanner.price}</p>
              <p>  <strong>Tax :</strong> {fetchScanner.tax}</p>
              <p>  <strong>Discount by :</strong> {fetchScanner.discount_type}</p>
              <p>  <strong>Maximum Purchase Qty : </strong>{fetchScanner.max_purchase_qty}</p>
              <p>   <strong>Discount : </strong>   {fetchScanner.discount}</p>
              <p>  <strong>Status : </strong>{fetchScanner.status}</p>
              <p>  <strong>Minimum Purchase Qty :</strong> {fetchScanner.max_purchase_qty}</p>
              <p>  <strong>Expired :  </strong>  {fetchScanner.expired}</p>
              <p>  <strong>Meta Title : </strong>   {fetchScanner.meta_title}</p>

            </div>
            <div className="col-12 mt-3">
              <h6>Product Images:</h6>
              <div className="d-flex flex-wrap">
                {(() => {
                  let thumbnails = [];

                  if (fetchScanner.thumbnail) {
                    try {
                      thumbnails =
                        typeof fetchScanner.thumbnail === "string"
                          ? JSON.parse(fetchScanner.thumbnail)
                          : fetchScanner.thumbnail;
                    } catch (e) {
                      console.error("Invalid JSON for thumbnail:", fetchScanner.thumbnail);
                      thumbnails = [];
                    }
                  }

                  return thumbnails.length > 0 ? (
                    thumbnails.map((img, idx) => (
                      <img
                        key={idx}
                        src={`${img_path}/products/${img}`}
                        alt={fetchScanner.product_name}
                        style={{
                          width: "100px",
                          height: "80px",
                          objectFit: "cover",
                          borderRadius: "6px",
                          marginRight: "5px",
                        }}
                      />
                    ))
                  ) : (
                    <span className="text-muted">No image</span>
                  );
                })()}
              </div>
            </div>
          </div>
        )}

      </Dialog>
    </>
  );
};

export default QrScanner;
