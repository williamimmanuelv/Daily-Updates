import React from 'react'

const Dailysalesreport = () => {
  return (
 <>
 </>
  )
}

export default Dailysalesreport