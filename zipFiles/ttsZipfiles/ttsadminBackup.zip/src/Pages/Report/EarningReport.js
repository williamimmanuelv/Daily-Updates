import React, { useEffect, useState } from 'react'
import { IoMdThumbsUp } from "react-icons/io";
import './report.css'
import { Chart } from 'primereact/chart';
import DataTable from 'react-data-table-component';
import { useNavigate } from 'react-router-dom';
import { AiOutlineDelete } from "react-icons/ai";
import customStyle from '../../utils/Customstyle';

const EarningReport = () => {
  const navigate = useNavigate()

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [editmodalpolice, setEditmodalpolice] = useState(false)
  const [createmodalpolice, setCreatemodalpolice] = useState(false)

  const [selectedRows, setSelectedRows] = useState([]);

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const columns = [
    {
      name: "S.no",
      selector: (row) => row.SNo,
      wrap: true,
      sortable: true,
    },
    {
      name: "Month",
      selector: (row) => row.ProductName,

      // cell: (row) => (
      //   <div>
      //     <button className="btn btn-primary">{row.project_id}</button>
      //   </div>
      // ),
      wrap: true,
      sortable: true,
    },
    {
      name: "No.of wishes",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },
    {
      name: "No.of wishes",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },
    {
      name: "No.of wishes",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },
    {
      name: "No.of wishes",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },
    {
      name: "No.of wishes",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },
    {
      name: "Today Order",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },
    {
      name: "Today sales",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },



    //   {
    //     name: "Actions",
    //     cell: (row) => (

    //     <div className="d-flex gap-1 me-5">


    //   <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
    //     <AiOutlineDelete size={18} color="red"onClick={()=>setDeleteconfirmmodal(true)} />
    //   </div>
    // </div>

    //     ),
    //     wrap: true,
    //   },
  ];

  const products = [{
    SNo: "1",
    ProductName: "Rukmani ",
    Category: "$Dress",
    Createby: "27-09-2025",
    ID: "27-09-2026	",
    Stock: "10",
    Actions: ""
  }]

  const handleConfirmClose = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopen = () => {

    setDeleteconfirmmodal(false)

  }
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'date', 'category_name', 'subcat_name', 'file', 'tracking_status', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };

  const [chartData, setChartData] = useState({});
  const [chartOptions, setChartOptions] = useState({});

  useEffect(() => {
    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = documentStyle.getPropertyValue('--text-color');
    const textColorSecondary = documentStyle.getPropertyValue('--text-color-secondary');
    const surfaceBorder = documentStyle.getPropertyValue('--surface-border');
    const data = {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
      datasets: [
        {
          label: 'My First dataset',
          backgroundColor: documentStyle.getPropertyValue('--blue-500'),
          borderColor: documentStyle.getPropertyValue('--blue-500'),
          data: [65, 59, 80, 81, 56, 55, 40]
        },
        {
          label: 'My Second dataset',
          backgroundColor: documentStyle.getPropertyValue('--pink-500'),
          borderColor: documentStyle.getPropertyValue('--pink-500'),
          data: [28, 48, 40, 19, 86, 27, 90]
        }
      ]
    };
    const options = {
      maintainAspectRatio: false,
      aspectRatio: 0.8,
      plugins: {
        legend: {
          labels: {
            fontColor: textColor
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: textColorSecondary,
            font: {
              weight: 500
            }
          },
          grid: {
            display: false,
            drawBorder: false
          }
        },
        y: {
          ticks: {
            color: textColorSecondary
          },
          grid: {
            color: surfaceBorder,
            drawBorder: false
          }
        }
      }
    };

    setChartData(data);
    setChartOptions(options);
  }, []);
  return (
    <>
      <div>
        {/* <h3>Earning Report</h3> */}

      </div>
      <div className='row'>
        <div className='col-12 col-md-3'>
          <h5 className='my-3'>Total Sales</h5>
          <div className="accordion" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOneopen" aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    Today Sales(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapseOneopen" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

          <div className="accordion mt-3" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOneopentwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className='fw-semibold'>  <IoMdThumbsUp /> This week(50 orders)</p>
                  <p className=''>789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapseOneopentwo" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />

                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

          <div className="accordion mt-3" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOneopenthree " aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className='fw-semibold'><IoMdThumbsUp /> Today Month(50 orders)</p>
                  <p className=''>789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapseOneopenthree" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />

                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

        </div>
        <div className='col-12 col-md-3'>
          <h5 className='my-3'>Today Order</h5>

          <div className="accordion" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="false" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    Today Order(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapseOne" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

          <div className="accordion mt-3" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOnetwo" aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    This Week(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapseOnetwo" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

          <div className="accordion mt-3" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapseOnethree " aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    This Month(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapseOnethree" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>

                </div>
              </div>
            </div>
          </div>

        </div>

        <div className='col-12 col-md-3'>
          <h5 className='my-3'>Refund</h5>
          <div className="accordion" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapserefund1" aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    Today Refund(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapserefund1" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

          <div className="accordion mt-3" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapserefund2" aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    This Week(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapserefund2" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

          <div className="accordion mt-3" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapserefund3 " aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    This Month(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapserefund3" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>

                </div>
              </div>
            </div>
          </div>

        </div>

        <div className='col-12 col-md-3'>
          <h5 className='my-3'>Canceled</h5>
          <div className="accordion" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapsecancel1" aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    Today Cancel(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapsecancel1" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

          <div className="accordion mt-3" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapsecancel2" aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    This Week(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapsecancel2" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>
                </div>
              </div>
            </div>
          </div>

          <div className="accordion mt-3" id="accordionPanelsStayOpenExampleone">
            <div className="">
              <h2 className="accordion-header addshadow">
                <button className="accordion-button text-muted fqsadd" type="button" data-bs-toggle="collapse" data-bs-target="#panelsStayOpen-collapsecancel3 " aria-expanded="true" aria-controls="panelsStayOpen-collapseOneopen">
                  <p className="fw-semibold d-flex align-items-center">
                    <IoMdThumbsUp className="me-2 " />
                    This Month(50 orders)
                  </p>
                  <p className="ms-4">789631524852</p>
                </button>
              </h2>
              <div id="panelsStayOpen-collapsecancel3" className="accordion-collapse collapse show">
                <div className="accordion-body">
                  <span className='fw-semibold'> by App sales amount(Rm)</span><br />
                  <span>7,8456,255,454</span><br />
                  <hr />
                  <span className='fw-semibold'> by Portal sales amount(Rm)</span><br />
                  <span>321456987</span>

                </div>
              </div>
            </div>
          </div>

        </div>
      </div>

      <div className="mt-5 pt-5">
        <h3>Yearly Sales</h3>
        <Chart type="bar" data={chartData} options={chartOptions} />
      </div>

      <div className='pt-5 mt-5'>
        <div className='mt-5 box_shadow'>
          <div className='d-flex justify-content-between pt-3 px-3'>
            <div>
              <h5> Monthly Report Table</h5>
            </div>
            <div className='mb-3'>
              <button className='btn btn-danger bg_color p-0 px-2 py-1'>Print </button>
            </div>
          </div>
          <DataTable
            columns={columns}

            data={products}
            customStyles={customStyle}
            pagination
            // selectableRows
            className='earningReportDataTabel'
            onRowClicked={handleRowClick}
            fixedHeader
            persistTableHead={true}
          />
        </div>
      </div>
    </>
  )
}

export default EarningReport