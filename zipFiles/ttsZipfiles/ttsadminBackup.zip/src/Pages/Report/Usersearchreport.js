import React, { useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import customStyle from '../../utils/Customstyle';

const Usersearchreport = () => {
  const navigate = useNavigate()

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [editmodalpolice, setEditmodalpolice] = useState(false)
  const [createmodalpolice, setCreatemodalpolice] = useState(false)

  const [selectedRows, setSelectedRows] = useState([]);

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const columns = [
    {
      name: "S.no",
      selector: (row) => row.SNo,
      wrap: true,
      sortable: true,
    },
    {
      name: "Search by",
      selector: (row) => row.ProductName,

      // cell: (row) => (
      //   <div>
      //     <button className="btn btn-primary">{row.project_id}</button>
      //   </div>
      // ),
      wrap: true,
      sortable: true,
    },
    {
      name: "No.of wishes",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },

    {
      name: "Actions",
      cell: (row) => (

        <div className="d-flex gap-1 me-5">


          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
            <AiOutlineDelete size={18} color="red" onClick={() => setDeleteconfirmmodal(true)} />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  const products = [{
    SNo: "1",
    ProductName: "Women's Slim-Fit Layering Long Sleeve Knit Rib Crew Neck (Available in Plus Size), Pack of 2  ",
    Category: "$Dress",
    Createby: "27-09-2025",
    ID: "27-09-2026	",
    Stock: "10",
    Actions: ""
  }]

  const handleConfirmClose = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopen = () => {

    setDeleteconfirmmodal(false)

  }
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'date', 'category_name', 'subcat_name', 'file', 'tracking_status', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  return (
    <>
      <div>
        {/* <h4>UserSearch  Reports</h4> */}
      </div>

      <div className='d-flex'>

        <div className="mb-3 ps-3">
          <label htmlFor="categoryTitle" className="form-label text-muted">Sort by Category :</label>
          <input
            type="text"
            className="form-control opacity-75"
            id="categoryTitle"
            placeholder="Enter Sort by Category"
          />
        </div>

        <div className="mb-3 ps-3">
          <label htmlFor="createdBy" className="form-label text-muted">Select category</label>
          <select className="form-select opacity-75" id="createdBy" name="sellist1">
            <option>Select Category</option>
            <option>Admin</option>
            <option>Other</option>
            <option>Seller</option>
          </select>
        </div>
      </div>


      <div className='mt-5 box_shadow'>
        <div className='d-flex justify-content-between py-3 px-3'>
          <div>
            <h5> All UserSearch  Reports</h5>
          </div>
          <div className='text-end position-relative'>
            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
              size={18} />
            <input text="search" className='form-control opacity-75' id='' name='' placeholder='Search Filter.........' />
          </div>

        </div>


        <DataTable
          columns={columns}
         
          data={products}
          selectableRows
          customStyles={customStyle}
          pagination
          
          onRowClicked={handleRowClick}
          fixedHeader
          persistTableHead={true}
        />
      </div>


      <Dialog header="Confirm Delete Modal" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error"> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success">Yes </Button>
        </div>

      </Dialog>

    </>
  )
}

export default Usersearchreport