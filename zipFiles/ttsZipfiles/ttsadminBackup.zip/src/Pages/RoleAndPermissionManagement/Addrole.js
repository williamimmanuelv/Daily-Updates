import React, { useEffect, useState } from 'react'
import Button from '@mui/material/Button';
import { Editor } from "primereact/editor";
import { useFormik } from 'formik';
import * as yup from "yup";
import Toast from '../../utils/Toast';
import { useNavigate } from 'react-router-dom';
import axiosInstance from '../../utils/axiosinstance';

const Addrole = () => {

  const navigate = useNavigate();

  const [fetchRole, setFetchRole] = useState([])


  const fetchRoleList = async () => {
    try {
      const response = await axiosInstance.get(`/role`,);
      setFetchRole(response.data);

      console.log("response.data", response.data)
    } catch (error) {
      Toast({ message: "Error to get data", type: "error" });

      // console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchRoleList()
  }, [])

  const onSubmit = async (values) => {
    try {
      const response = await axiosInstance.post(`/permission`, values, {
        headers: { "Content-Type": "application/json" },
      });
      console.log("response", response);
      Toast({ message: "Successfully Created", type: "success" });

      formik.resetForm();
      navigate('/rolelist');
    } catch (error) {
      Toast({ message: "Error while creating role", type: "error" });
    }
  };

  const formik = useFormik({
    initialValues: {
      role_name: "",
      permission: [],      // array
      description: "",
      module_access: [],   // array
    },
    validationSchema: yup.object().shape({
      role_name: yup.string().required("Role name is required!"),
      permission: yup.array().min(1, "Select at least one permission"),
      module_access: yup.array().min(1, "Select at least one module"),
      description: yup.string().required("Description is required!"),
    }),
    onSubmit,
  });


  const handleCheckboxChange = (field, value, checked) => {
    if (checked) {
      formik.setFieldValue(field, [...formik.values[field], value]);
    } else {
      formik.setFieldValue(
        field,
        formik.values[field].filter((v) => v !== value)
      );
    }
  };

  const moduleOptions = [
    "Dashboard",
    "Customer Management",
    "Plan Management",
    "Ticket Management",
    "Staff/Agency Management",
    "Templates & Asset Library",
    "Payments Management",
    "Renewal Management",
    "Chatbot & Communication",
    "Offers & Promotions",
    "Reports & Analytics",
    "Role & Permission Management",
    "Support",
    "Settings",
  ];

  const permissionOptions = [
    "View",
    "Create/Add",
    "Edit",
    "Delete",
    "Export/Download",
  ];

  return (
    <>
      <div className="d-flex justify-content-start">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/rolelist')}
        >
          ← Back
        </button>
      </div>
      <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5 bg-white'>
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className='row py-4'>
            {/* Role Name */}


            {/* Module Access */}
            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <h6>Module Access :</h6>
                {moduleOptions.map((mod) => (
                  <div className="form-check" key={mod}>
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={mod}
                      value={mod}
                      checked={formik.values.module_access.includes(mod)}
                      onChange={(e) =>
                        handleCheckboxChange("module_access", mod, e.target.checked)
                      }
                    />
                    <label className="form-check-label" htmlFor={mod}>
                      {mod}
                    </label>
                  </div>
                ))}
                {formik.errors.module_access && formik.touched.module_access && (
                  <p style={{ color: "red", fontSize: "12px" }}>{formik.errors.module_access}</p>
                )}
              </div>
            </div>

            {/* Permissions */}
            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <h6>Action Permissions :</h6>
                {permissionOptions.map((perm) => (
                  <div className="form-check" key={perm}>
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={perm}
                      value={perm}
                      checked={formik.values.permission.includes(perm)}
                      onChange={(e) =>
                        handleCheckboxChange("permission", perm, e.target.checked)
                      }
                    />
                    <label className="form-check-label" htmlFor={perm}>
                      {perm}
                    </label>
                  </div>
                ))}
                {formik.errors.permission && formik.touched.permission && (
                  <p style={{ color: "red", fontSize: "12px" }}>{formik.errors.permission}</p>
                )}
              </div>
            </div>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <label htmlFor="role_name" className='form-label text-muted'>Role Name:</label>
                <select
                  className="form-select opacity-75"
                  id="role_name"
                  name="role_name"
                  value={formik.values.role_name}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                >
                  <option value="">Select Creator</option>
                  {fetchRole?.length > 0 ? (
                    fetchRole.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.role}
                      </option>
                    ))
                  ) : (
                    <option value="">No data</option>
                  )}
                  {/* <option value="Admin">Admin</option>
                <option value="User">User</option>
                <option value="Seller">Seller</option> */}
                </select>
                {formik.errors.role_name && formik.touched.role_name && (
                  <p style={{ color: "red", fontSize: "12px" }}>{formik.errors.role_name}</p>
                )}
              </div>
            </div>

            {/* Description */}
            <div className='col-12'>
              <div className='mb-3 pt-3'>
                <label htmlFor="role_name" className='form-label text-muted'>Description</label>

                <Editor
                  id="description"
                  name="description"
                  value={formik.values.description}
                  onTextChange={(e) =>
                    formik.setFieldValue("description", e.htmlValue)
                  }
                  onBlur={formik.handleBlur}
                  style={{ height: "320px" }}
                />
                {formik.errors.description && formik.touched.description && (
                  <p style={{ color: "red", fontSize: "12px" }}>{formik.errors.description}</p>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className='text-end'>
              <Button variant="outlined" color="error" onClick={() => formik.resetForm()}>
                Cancel
              </Button>
              <Button type="submit" variant="contained" className='mx-2' color="success">
                Save
              </Button>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default Addrole;
