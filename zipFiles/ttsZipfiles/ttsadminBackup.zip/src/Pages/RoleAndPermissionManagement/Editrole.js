import React, { useEffect, useState } from 'react'
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { Editor } from "primereact/editor";
import * as yup from "yup";
import Toast from '../../utils/Toast';
import axiosInstance from '../../utils/axiosinstance';
import { useLocation, useNavigate } from 'react-router-dom';
import { useFormik } from 'formik';


const Editrole = () => {

  const [text, setText] = useState('');
  const navigate = useNavigate();

  const [fetchRole, setFetchRole] = useState([])


  const fetchRoleList = async () => {
    try {
      const response = await axiosInstance.get(`/role`,);
      setFetchRole(response.data);

      console.log("response.data", response.data)
    } catch (error) {
      Toast({ message: "Error to get data", type: "error" });

      // console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchRoleList()
  }, [])

  const { state } = useLocation();
  const roleData = state;
  console.log("roleDataaaaaaaaa", roleData)

  useEffect(() => {

    if (!roleData) return;

    formik.setValues({
      role_name: roleData?.role_name || "",
      permission: roleData?.permission || "",
      description: roleData?.description || "",
      module_access: roleData?.module_access || "",
      id: roleData?.id || "",
    });


    // formik.setFieldValue('role_name', roleData?.role_name)
    // formik.setFieldValue('permission', roleData?.permission)
    // formik.setFieldValue('description', roleData?.description)
    // formik.setFieldValue('module_access', roleData?.module_access)


    // formik.setFieldValue('id', roleData?.id)
  }, [roleData])



  const formik = useFormik({
    initialValues: {
      role_name: "",
      permission: [],
      description: "",
      module_access: [],
    },
    // validationSchema: yup.object().shape({
    //   role_name: yup.string().required("Role name is required!"),
    //   permission: yup.array().min(1, "Select at least one permission"),
    //   module_access: yup.array().min(1, "Select at least one module"),
    //   description: yup.string().required("Description is required!"),
    // }),
    onSubmit: async (values) => {
      console.log("fghj")
      alert("rukku")
      try {
        const response = await axiosInstance.post(`/permission/${values.id}?_method=PUT`,
          values, {
          headers: { "Content-Type": "application/json" },
        });
        console.log("response", response);
        Toast({ message: "Successfully Updated", type: "success" });
        console.log("success")
        formik.resetForm();
        navigate('/rolelist');
      } catch (error) {
        Toast({ message: "Error while creating role", type: "error" });
        console.log("fsil")

      }
      console.log("run")

    }
  });


  const handleCheckboxChange = (field, value, checked) => {
    if (checked) {
      formik.setFieldValue(field, [...formik.values[field], value]);
    } else {
      formik.setFieldValue(
        field,
        formik.values[field].filter((v) => v !== value)
      );
    }
  };

  const moduleOptions = [
    "Dashboard",
    "Customer Management",
    "Plan Management",
    "Ticket Management",
    "Staff/Agency Management",
    "Templates & Asset Library",
    "Payments Management",
    "Renewal Management",
    "Chatbot & Communication",
    "Offers & Promotions",
    "Reports & Analytics",
    "Role & Permission Management",
    "Support",
    "Settings",
  ];

  const permissionOptions = [
    "View",
    "Create/Add",
    "Edit",
    "Delete",
    "Export/Download",
  ];


  return (
    <>
      <div className="d-flex justify-content-start">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/rolelist')}
        >
          ← Back
        </button>
      </div>
      <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5 bg-white'>
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className='row py-4'>
            {/* Role Name */}


            {/* Module Access */}
            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <h6>Module Access :</h6>
                {moduleOptions.map((mod) => (
                  <div className="form-check" key={mod}>
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={mod}
                      value={mod}
                      checked={formik.values.module_access.includes(mod)}
                      onChange={(e) =>
                        handleCheckboxChange("module_access", mod, e.target.checked)
                      }
                    />
                    <label className="form-check-label" htmlFor={mod}>
                      {mod}
                    </label>
                  </div>
                ))}
                {/* {formik.errors.module_access && formik.touched.module_access && (
                <p style={{ color: "red", fontSize: "12px" }}>{formik.errors.module_access}</p>
              )} */}
              </div>
            </div>

            {/* Permissions */}
            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <h6>Action Permissions :</h6>
                {permissionOptions.map((perm) => (
                  <div className="form-check" key={perm}>
                    <input
                      className="form-check-input"
                      type="checkbox"
                      id={perm}
                      value={perm}
                      checked={formik.values.permission.includes(perm)}
                      onChange={(e) =>
                        handleCheckboxChange("permission", perm, e.target.checked)
                      }
                    />
                    <label className="form-check-label" htmlFor={perm}>
                      {perm}
                    </label>
                  </div>
                ))}
                {formik.errors.permission && formik.touched.permission && (
                  <p style={{ color: "red", fontSize: "12px" }}>{formik.errors.permission}</p>
                )}
              </div>
            </div>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <label htmlFor="role_name" className='form-label text-muted'>Role Name:</label>
                <select
                  className="form-select opacity-75"
                  id="role_name"
                  name="role_name"
                  value={formik.values.role_name}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                >
                  <option value="">Select Creator</option>
                  {fetchRole?.length > 0 ? (
                    fetchRole.map((item) => (
                      <option key={item.id} value={item.id}>
                        {item.role}
                      </option>
                    ))
                  ) : (
                    <option value="">No data</option>
                  )}
                </select>
                {/* {formik.errors.role_name && formik.touched.role_name && (
                <p style={{ color: "red", fontSize: "12px" }}>{formik.errors.role_name}</p>
              )} */}
              </div>
            </div>

            {/* Description */}
            <div className='col-12'>
              <div className='mb-3 pt-3'>
                <label htmlFor="role_name" className='form-label text-muted'>Description</label>


                <Editor
                  // key={language}
                  value={formik.values.description}
                  style={{ height: "320px" }}
                  onTextChange={(e) => {
                    if (e.source !== "user") return;
                    formik.setFieldValue("description", e.htmlValue);
                  }}
                />

                {/* <Editor
                  id="description"
                  name="description"
                  value={formik.values.description}
                  onTextChange={(e) =>
                    formik.setFieldValue("description", e.htmlValue)
                  }
                  onBlur={formik.handleBlur}
                  style={{ height: "320px" }}
                /> */}


                {formik.errors.description && formik.touched.description && (
                  <p style={{ color: "red", fontSize: "12px" }}>{formik.errors.description}</p>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className='text-end'>
              <Button variant="outlined" color="error" onClick={() => formik.resetForm()}>
                Cancel
              </Button>
              <Button type="submit" variant="contained" className='mx-2' color="success" >
                Update
              </Button>
            </div>
          </div>
        </form>
      </div>
      {/* <div className='py-4'>
                <h4>Role Edit</h4>
            </div>
            <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5 bg-white'>
                <form>
                    <div className='row py-4'>

                        <div className='col-12 col-md-6'>
                            <div className='mb-3 pt-3'>
                                <label htmlFor="createdBy" className='form-label text-muted'>Role Name:</label>
                                <select className="form-select opacity-75" id="createdBy" name="sellist1">
                                    <option>Select Creator</option>
                                    <option>Admin</option>
                                    <option>user</option>
                                    <option>Seller</option>
                                </select>
                            </div>
                            
                        </div>

                       

                        <div>
                            <h5 className='text-center pt-4'>Assign Permissions:</h5>
                        </div>
                        <div className='col-12 col-md-6'>
                            <div className='mb-3 pt-3'>


                                <div class="form-check">
                                    <h6>Module Access :</h6>
                                    <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something" checked />
                                        <label class="form-check-label">Dashboard</label><br/>
                                          <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Customer Management</label><br/>
                                          <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Plan Management </label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Ticket Management </label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Staff/Agency Management </label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Templates & Asset Library</label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label"> Payments Management</label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label"> Renewal Management</label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label"> Chatbot & Communication</label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label"> Offers & Promotions</label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Reports & Analytics </label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Role & Permission Management </label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Support </label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Settings</label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Role & Permission Management</label><br/>
                                </div>
                            </div>
                        </div>
                          <div className='col-12 col-md-6'>
                            <div className='mb-3 pt-3'>


                                <div class="form-check">
                                    <h6>Action Permissions :</h6>
                                    <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something" checked />
                                        <label class="form-check-label">View</label><br/>
                                          <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Create/Add</label><br/>
                                          <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Edit </label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Delete </label><br/>
                                        <input class="form-check-input" type="checkbox" id="check1" name="option1" value="something"  />
                                        <label class="form-check-label">Export/Download </label><br/>
                                       </div>
                            </div>
                        </div>
                         <div className=''>
                            <div className='mb-3 pt-3'>
                                <div className="">
                          <Editor value={text} onTextChange={(e) => setText(e.htmlValue)} style={{ height: '320px' }} />
                         </div>
                            </div>
                        </div>

                           <div className='text-end'>
                            <Button variant="outlined" color="error"> Cancel</Button>

                            <Button variant="contained" className='mx-2' color="success">Update</Button>&nbsp;
                           </div>

                    </div>
                </form>
            </div> */}
    </>
  )
}

export default Editrole