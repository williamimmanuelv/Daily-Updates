import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
import Toast from '../../utils/Toast';
import customStyle from '../../utils/Customstyle';


const RoleList = () => {

  const navigate = useNavigate()

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [fetchRole, setFetchRole] = useState([])
  const [viewRole, setViewRole] = useState([])
  const [deleteRole, setdeleteRole] = useState(null)
  console.log("fetchRoleeeeeeeeee", fetchRole)

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [editmodalrole, seteditmodalrole] = useState(false)
  const [createmodalstaff, setCreatemodalstaff] = useState(false)

  const [selectedRows, setSelectedRows] = useState([]);

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };


  const fetchRoles = async () => {
    try {
      const response = await axiosInstance.get(`/permission`,);
      setFetchRole(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchRoles()
  }, [])


  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
    },
    {
      name: "Role Name",
      selector: (row) => row.role_name_val,

      // cell: (row) => (
      //   <div>
      //     <button className="btn btn-primary">{row.project_id}</button>
      //   </div>
      // ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Created On",
      selector: (row) => row.created_at,
      wrap: true,
      sortable: true,
    },

    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setViewRole(row); seteditmodalrole(true); }}>
            <GrFormView size={20} color="white" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => editRoles(row)}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setdeleteRole(row.id); setDeleteconfirmmodal(true) }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  //  const products =[{
  //   SNo:"1",
  // ProductName:"Rukmani ",
  // Category:"$Dress",
  //   Createby:"27-09-2025",
  //   ID:"27-09-2026	",
  //   Stock:"10",
  //   Actions:""
  // }]

  const editRoles = (row) => {
    navigate('/editrole', { state: row })
  }

  const handleConfirmCloseDltRole = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopenDltRole = async () => {
    try {
      await axiosInstance.delete(`/permission/${deleteRole}`)
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchRoles()

    } catch (error) {
      Toast({ message: "Error to Deleted", type: "error" });

    }


    setDeleteconfirmmodal(false)

  }
  const handleRowClick = (row) => {

  };
  const [filterText, setFilterText] = useState("");
  const searchColumns = ['role_name', 'created_at', 'category_name', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchRole, filterText, searchColumns);

  return (
    <>
      <div className='container'>


        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3'>
              <h5>All Roll List</h5>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <div className='mb-3 pt-1 text-end'><Link to="/addrole" className='text-decoration-none text-white'>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> + Add</button></Link>
              </div>
            </div>
          </div>

          <div className='pt-2'>


            <DataTable
              columns={columns}

              data={filterdata}
              customStyles={customStyle}
              pagination
              // selectableRows
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />
          </div>
        </div>
      </div>

      <Dialog header="View Role Details" visible={editmodalrole} position="top" style={{ width: '60vw' }} onHide={() => { if (!editmodalrole) return; seteditmodalrole(false); }}>
        {viewRole && (
          <div className='row'>
            <div className='col-12 col-md-6'>
              <p>Role Name :{viewRole?.role_name}</p>
              <p>Action Permissions :{viewRole?.permission}</p>

            </div>
            <div className='col-12 col-md-6'>
              <p>Module Access :{viewRole?.module_access}</p>
              <p>Created On :{viewRole?.created_at}</p>
            </div>
          </div>
        )}


      </Dialog>

      <Dialog header="Confirm Delete" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmCloseDltRole()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmopenDltRole(deleteRole)}>Yes </Button>
        </div>

      </Dialog>
    </>
  )
}

export default RoleList