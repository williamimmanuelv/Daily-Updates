import { Dialog } from 'primereact/dialog'
import React, { useEffect, useState } from 'react'
import { IoSearchOutline } from "react-icons/io5";
import { SearchData } from '../../utils/Search';
import { useFormik } from 'formik';
import * as yup from "yup"
import DataTable from 'react-data-table-component';
import { Button, Stack } from '@mui/material';
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import axiosInstance from '../../utils/axiosinstance';
import Toast from '../../utils/Toast';
import customStyle from '../../utils/Customstyle';
import { FiPlus } from "react-icons/fi";
import { RadioButton } from 'primereact/radiobutton';

const ListRoles = () => {

  const [editrole, seteditRole] = useState(false)
  const [createrole, setCreaterole] = useState(false)
  const [deleterolelist, setDeleterolelist] = useState(false)
  const [deleterow, setDeleterow] = useState(null)
  const [fetchRole, setFetchRole] = useState([])
  console.log("fetchRolellllllllll", fetchRole)



  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
    },
    {
      name: "Role",
      selector: (row) => row.role,


      wrap: true,
      sortable: true,
    },
    {
      name: "Status",
      selector: (row) => row.status,
      wrap: true,
      sortable: true,
    },

    {
      name: "Actions",
      cell: (row) => (

        <div className="d-flex gap-1 me-5">


          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => handleEdit(row)}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setDeleterow(row.id); setDeleterolelist(true) }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];


  const fetchRoleList = async () => {
    try {
      const response = await axiosInstance.get(`/role`,);
      setFetchRole(response.data);

      console.log("response.data", response.data)
    } catch (error) {
      Toast({ message: "Error to get data", type: "error" });

      // console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchRoleList()
  }, [])



  const handleEdit = (row) => {
    formik1.setValues({
      role: row.role,
      status: row.status,

      id: row.id,
    });
    seteditRole(true);
  };


  const handleConfirmClosedltrole = () => {
    setDeleterolelist(false)
  }
  const handleconfirmdltrole = async () => {
    try {
      await axiosInstance.delete(`/role/${deleterow}`)
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchRoleList()
    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });

    }
    setDeleterolelist(false)
  }




  const onSubmitEdit = async (values) => {
    try {
      const response = await axiosInstance.post(`/role/${values.id}?_method=PUT`, values, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log("response", response)
      Toast({ message: "Successfully Updated", type: "success" });

      formik1.resetForm()
      fetchRoleList()

      seteditRole(false)
    } catch (error) {
      // console.log("Suberror", error)
      Toast({ message: "Error to taken project", type: "error" });
    }

  }
  const formik1 = useFormik(
    {
      initialValues: {
        role: "",
        status: "",

      },
      validationSchema: yup.object().shape({
        role: yup.string().required("role is required!"),
        status: yup.string().required("status is required!"),


      }),
      onSubmit: onSubmitEdit,
    }
  )

  const onSubmit = async (values) => {
    try {
      const response = await axiosInstance.post(`/role`, values, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log("response", response)
      Toast({ message: "Successfully Created", type: "success" });

      formik.resetForm()
      fetchRoleList()

      setCreaterole(false)
    } catch (error) {
      // console.log("Suberror", error)
      Toast({ message: "Error to taken project", type: "error" });
    }

  }


  const formik = useFormik(
    {
      initialValues: {
        role: "",
        status: "",
      },
      validationSchema: yup.object().shape({
        role: yup.string().required("role is required!"),
        status: yup.string().required("status is required!"),

      }),
      onSubmit,
    }
  )


  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['name', 'email', 'phone', 'role', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchRole, filterText, searchColumns);
  return (
    <>

      <div className='container'>
        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3'>
              <h5>All Role List</h5>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <div className=' text-end pt-1' onClick={() => setCreaterole(true)}>
                <button className='btn btn-danger bg_color p-0 px-2 py-1' >Add <FiPlus  className='pb-1'/></button>
              </div>
            </div>
          </div>
          <div className='pt-2'>

            <DataTable
              columns={columns}
              data={filterdata}
              //  selectableRows
              pagination
              customStyles={customStyle}
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />
          </div>
        </div>
      </div>

      <Dialog header="Edit Role" visible={editrole} position="top" style={{ width: '50vw' }} onHide={() => { if (!editrole) return; seteditRole(false); }}>
         <form onSubmit={formik1.handleSubmit} autoComplete="off">
          <div className='row'>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <label htmlFor="role" className='form-label text-muted'>Role</label>
                <input
                  type="text"
                  class="form-control"
                  id="role"
                  name="role"
                  placeholder='Enter role'
                  value={formik1.values.role}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.role && formik1.touched.role && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.role}
                  </p>
                )}
              </div>
              <div className="mb-3 pt-4 ps-4">
                <label className="form-label text-muted">Status</label>
                <div className="d-flex  gap-2">
                  <div className="form-check">
                    {/* <input
                      className="form-check-input"
                      type="radio"
                      name="status"
                      id="status-active"
                      value="active"
                      checked={formik1.values.status === "active"}
                      onChange={formik1.handleChange}
                    /> */}
                      <RadioButton inputId="ingredient1"     name="status"      value="active"     id="status-active"
                                           checked={formik1.values.status === "active"}
                                           onChange={formik1.handleChange}
                                          />
                    <label className="form-check-label ms-2" htmlFor="status-active">
                      Active
                    </label>
                  </div>
                  <div className="form-check">
                    {/* <input
                      className="form-check-input"
                      type="radio"
                      name="status"
                      id="status-inactive"
                      value="inactive"
                      checked={formik1.values.status === "inactive"}
                      onChange={formik1.handleChange}
                    /> */}
                      <RadioButton inputId="ingredient2"   name="status"     value="inactive"   id="status-inactive" 
                                        checked={formik1.values.status === "inactive"}
                                           onChange={formik1.handleChange}
                                          />
                    <label className="form-check-label ms-2" htmlFor="status-inactive">
                      Inactive
                    </label>
                  </div>
                
                </div>
                {formik1.errors.status && formik1.touched.status && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.status}
                  </p>
                )}
              </div>
                </div>
             <div className='text-end'>
              <Button variant="outlined" color="error" onClick={() => seteditRole(false)}> Cancel</Button>

              <Button variant="contained" type='submit' className='mx-2' color="success">Update </Button>&nbsp;
            </div>

          </div>
        </form>
      </Dialog>
      <Dialog header="Create Role" visible={createrole} position="top" style={{ width: '60vw' }} onHide={() => { if (!createrole) return; setCreaterole(false); }}>

        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className='row py-4'>

            <div className='col-12 col-md-8'>
              <div className='mb-3  ps-4'>
                <label htmlFor="role" className='form-label text-muted'>Role</label>
                <input
                  type="text"
                  class="form-control"
                  id="role"
                  name="role"
                  placeholder='Enter role'
                  value={formik.values.role}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.role && formik.touched.role && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.role}
                  </p>
                )}
              </div>
              <div className="mb-3 pt-3 ps-4">
                <label className="form-label text-muted">Status</label>
                <div className="d-flex  gap-2">
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="radio"
                      name="status"
                      id="status"
                      value="active"
                      checked={formik.values.status === "active"}
                      onChange={formik.handleChange}
                    />
                    <label className="form-check-label ms-2" htmlFor="status">
                      Active
                    </label>
                  </div>
                  <div className="form-check">
                    <input
                      className="form-check-input"
                      type="radio"
                      name="status"
                      id="status"
                      value="inactive"
                      checked={formik.values.status === "inactive"}
                      onChange={formik.handleChange}
                    />
                    <label className="form-check-label ms-2" htmlFor="status">
                      Inactive
                    </label>
                  </div>
               
                </div>
                {formik.errors.status && formik.touched.status && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.status}
                  </p>
                )}
              </div>
                 </div>
               <div className='text-end'>
              <Button variant="outlined" color="error" onClick={() => setCreaterole(false)}> Cancel</Button>

              <Button variant="contained" type='submit' className='mx-2' color="success">Create </Button>&nbsp;
            </div>

          </div>
        </form>
      </Dialog>
      <Dialog header="Confirm Delete" visible={deleterolelist} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleterolelist) return; setDeleterolelist(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">

          <Stack direction="row" spacing={2}>

            <Button variant="outlined" color="error" onClick={() => handleConfirmClosedltrole()}> No  </Button>&nbsp;
          </Stack>


          <Button variant="contained" color="success" onClick={() => handleconfirmdltrole(deleterow)}>Yes </Button>
        </div>

      </Dialog>
    </>
  )
}

export default ListRoles