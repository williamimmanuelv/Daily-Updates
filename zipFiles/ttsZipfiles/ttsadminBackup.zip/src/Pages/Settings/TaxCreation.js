import React, { useEffect, useState } from 'react'
import { Editor } from "primereact/editor";
import { useFormik } from 'formik';
import * as yup from "yup"
import axiosInstance from '../../utils/axiosinstance';
import Toast from '../../utils/Toast';
import { useNavigate } from 'react-router-dom';

const TaxCreation = () => {
  const [text, setText] = useState('');
  const navigate = useNavigate()

 const [fetchcategory, setFetchcategory] = useState([])

  const fetch = async () => {
    try {
      const response = await axiosInstance.get(`/categories`,);
      setFetchcategory(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetch()
  }, [])

  const onSubmit = async (values) => {

    try {
      const response = await axiosInstance.post(`/tax`, values, {

        headers: {
          "Content-Type": "application-json"
        },
      });
      console.log("response", response)
      Toast({ message: "Successfully Created", type: "success" });
      formik.resetForm()
      navigate('/taxsetting')
    }
    catch (error) {
      console.log("error", error)
      Toast({ message: "Error to taken project", type: "error" });
    }
  }


  const formik = useFormik(
    {
      initialValues: {
        tax: "",
        category: "",
        select_percentage: "",
        description: "",

      },
      // validationSchema: yup.object().shape({
      //   tax: yup.string().required("tax is required!"),
      //   category: yup.string().required("category  is required"),
      //   select_percentage: yup.string().required("select_percentage is required!"),
      //   description: yup.string().required("description is required!"),
      // }),
      onSubmit,
    }
  )
  return (
    <>
     <div className="d-flex justify-content-start">
    <button
        type="button"
        className="btn btn-secondary"
        onClick={() => navigate('/taxsetting')}
    >
        ← Back
    </button>
    </div>
      <div className="container">
         <form onSubmit={formik.handleSubmit} autoComplete="off">
        <div className="row justify-content-center">
          <div className="col-12 col-md-10 col-lg-8">
            <div className="box_shadow p-5 rounded mt-4 bg-white">
              <h5 className="text-center">Create New Taxes</h5>
              <hr />

              <div className="row ">
                {/* Left Column */}
                <div className="col-12 col-md-6 mt-4">
                  <div className="mb-3">
                    <label htmlFor="tax" className="form-label text-muted">Tax</label>
                    <input
                      type="text"
                      className="form-control opacity-75"
                      id="tax"
                      name='tax'
                      placeholder="Enter Title"
                      value={formik.values.tax}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.tax && formik.touched.tax && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.tax}
                      </p>
                    )}
                  </div>

                  <div className="mb-3">
                    <label htmlFor="category" className="form-label text-muted">Category</label>
                    <select className="form-select opacity-75" id="category" name="category"
                      value={formik.values.category}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}>
                      <option value=''>Select Category</option>
                       {fetchcategory?.length > 0 ? (
                        fetchcategory.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.title}
                          </option>
                        ))
                      ) : (
                        <option value="">No data</option>
                      )}
                      {/* <option value="Admin">Admin</option>
                      <option value="Other">Other</option>
                      <option value="Seller">Seller</option> */}
                    </select>
                    {formik.errors.category && formik.touched.category && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.category}
                      </p>
                    )}
                  </div>

                 
                </div>

                <div  className="col-12 col-md-6 mt-4">
                   <div className="mb-3">
                    <label htmlFor="select_percentage" className="form-label text-muted">Select Percentage</label>
                    <input
                      type="text"
                      className="form-control opacity-75"
                      id="select_percentage"
                      name='select_percentage'
                      placeholder="Enter percentage"
                      value={formik.values.select_percentage}
                      onChange={formik.handleChange}
                      onBlur={formik.handleBlur}
                    />
                    {formik.errors.select_percentage && formik.touched.select_percentage && (
                      <p style={{ color: "red", fontSize: "12px" }}>
                        {formik.errors.select_percentage}
                      </p>
                    )}
                  </div>
                </div>

                {/* Description Field */}
                <div className="col-12 mt-3">
                  <div className="mb-3">
                    <div className="">
                      <Editor
                        id="description"
                        name="description"
                        value={formik.values.description}
                        onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                        onBlur={formik.handleBlur}
                        style={{ height: "320px" }}
                      />
                      {formik.errors.description && formik.touched.description && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.description}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Buttons */}
                <div className="col-12 d-flex justify-content-end gap-3">
                  <button className="btn btn-danger bg_color">Cancel</button>

                  <button type='submit' className="btn btn-outline-success">Create</button>
                </div>
              </div>
            </div>
          </div>
        </div>
        </form>
      </div>

    </>
  )
}

export default TaxCreation