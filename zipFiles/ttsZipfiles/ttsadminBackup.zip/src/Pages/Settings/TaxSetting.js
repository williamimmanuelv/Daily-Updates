import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import { SearchData } from '../../utils/Search';
import axiosInstance from '../../utils/axiosinstance';
import { InputSwitch } from 'primereact/inputswitch';
import Toast from '../../utils/Toast';
import customStyle from '../../utils/Customstyle';

const TaxSetting = () => {
  const navigate = useNavigate()

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [fetchTax, setFetchTax] = useState([])
  console.log("fetchTax",fetchTax)
      const [checkedRows, setCheckedRows] = useState({});
           

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [editmodalpolice, setEditmodalpolice] = useState(false)
  const[deletetax,setDeletetax]=useState(null)


  const [selectedRows, setSelectedRows] = useState([]);

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const fetchTaxs = async () => {
    try {
      const response = await axiosInstance.get(`/tax`,);
      setFetchTax(response.data);
      console.log("response.data", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchTaxs()
  }, [])

          const handleToggle = async (row) => {

    const newValue = !checkedRows[row.id];

    setCheckedRows((prev) => ({
      ...prev,
      [row.id]: newValue,
    }));

    const payload = {
      status: newValue ? "active" : "inactive",
    };

    console.log("payload", payload);

    try {
      const response = await axiosInstance.put(
        `/tax/${row.id}?_method=PUT`,
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
          fetchTaxs()
      console.log("Status updated:", response.data);
    } catch (error) {
      console.error("Upload error:", error);
    }
      };


  const columns = [
    {
      name: "S.no",
      cell: (row,index) => index + 1,
      wrap: true,
      sortable: true,
    },
    {
      name: "Category",
      selector: (row) => row.category_name,

      // cell: (row) => (
      //   <div>
      //     <button className="btn btn-primary">{row.project_id}</button>
      //   </div>
      // ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Percentage",
      selector: (row) => row.select_percentage,
      wrap: true,
      sortable: true,
    },
    {
      name: "Status ",
       cell: (row) => (
                      <div className=" flex justify-content-center">
                        <InputSwitch
                          checked={row.status === "active"}
                          onChange={() => handleToggle(row)}
                        />
                      </div>
                    ),
      wrap: true,
      sortable: true,
    },


    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() =>edittax(row) }>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() =>{setDeletetax(row.id); setDeleteconfirmmodal(true);}}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];

  const edittax=(row)=>{
navigate('/taxedit',{state:row})
console.log("kjkkkkkkkkkkk",{state:row})
  }

  const handleConfirmCloseDltTax = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopenDltTax =async () => {
      try {
      await axiosInstance.delete(`/tax/${deletetax}`)
           Toast({ message: "Successfully Deleted", type: "success" });

       fetchTaxs()
    } catch (error) {
   Toast({ message: "Error to taken project", type: "error" });

    }
       
      setDeleteconfirmmodal(false)

  }
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['category', 'select_percentage', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };

  const filterdata = SearchData(fetchTax, filterText, searchColumns);


  return (
    <>
    
      <div>
        {/* <h4>Tax Setting</h4> */}
      </div>
      <div className='mt-5 box_shadow'>
        <div className='d-flex justify-content-between py-3 px-3'>
          <div>
            <h5> All Tax Setting List</h5>
          </div>
          {/* <div className='mb-3'>
                        <button className='btn btn-danger bg_color p-0 px-2 py-1'> + Add All Police</button>
                    </div> */}
          <div className='text-end position-relative'>
            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
              size={18} />
            <input text="search" className='form-control opacity-75' id='' name=''onChange={handleFilter} placeholder='Search Filter.........' />
          </div>
        </div>


        <DataTable
          columns={columns}
          
          data={filterdata}
          
          customStyles={customStyle}
          pagination
          // selectableRows
          onRowClicked={handleRowClick}
          fixedHeader
          persistTableHead={true}
        />
      </div>




      <Dialog header="Confirm Deleted" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={()=>handleConfirmCloseDltTax()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={()=>handleconfirmopenDltTax(deletetax)}>Yes </Button>
        </div>

      </Dialog>

    </>
  )
}

export default TaxSetting