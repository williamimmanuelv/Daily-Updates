import React, { useEffect, useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import { useFormik } from 'formik';
import * as yup from "yup"
import axiosInstance from '../../utils/axiosinstance';
import Toast from '../../utils/Toast';
import 'react-toastify/dist/ReactToastify.css';
import { SearchData } from '../../utils/Search';
import customStyle from '../../utils/Customstyle';


const AllStaff = () => {

  const navigate = useNavigate()

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [fetchStaff, setFetchStaff] = useState([])
  console.log("fetchStafffffffffffffff", fetchStaff)
  const [deleteStaff, setDeleteStaff] = useState([])

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [editmodalstaff, setEditmodalstaff] = useState(false)
  const [createmodalstaff, setCreatemodalstaff] = useState(false)

  const [selectedRows, setSelectedRows] = useState([]);

  const handleEdit = (row) => {
    formik1.setValues({
      name: row.name,
      phone: row.phone,
      email: row.email,
      role: row.role,
      password: row.password,
      id: row.id,
    });
    setEditmodalstaff(true);
  };


  const onSubmitEdit = async (values) => {
    try {
      const response = await axiosInstance.post(`/staff/${values.id}?_method=PUT`, values, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log("response", response)
      Toast({ message: "Successfully Updated", type: "success" });

      formik1.resetForm()
      fetchStaffs()
      setEditmodalstaff(false)
    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });

      // console.log("Suberror", error)
    }
  }


  const formik1 = useFormik(
    {
      initialValues: {
        name: "",
        phone: "",
        email: "",
        role: "",
        password: "",

      },
      validateOnChange: true,
      validateOnBlur: true,
      validationSchema: yup.object().shape({
        name: yup.string().required("name is required!"),
        // phone: yup.string().required("phone By is required"),
        phone: yup
          .string()
          .matches(/^[0-9]*$/, "Only numbers allowed!")
          .length(15, "Phone number must be exactly 15 digits ")
          .required("Phone number is required!"),
        email: yup.string().required("email is required!"),
        role: yup.string().required("role is required!"),
        password: yup.string().required("password is required!"),

      }),
      onSubmit: onSubmitEdit,
    }
  )

  const onSubmit = async (values) => {
    try {
      const response = await axiosInstance.post(`/staff`, values, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log("response", response)
      Toast({ message: "Successfully Created", type: "success" });

      formik.resetForm()
      fetchStaffs()

      setCreatemodalstaff(false)
    } catch (error) {
      // console.log("Suberror", error)
      Toast({ message: "Error to taken project", type: "error" });
    }
  }

  const formik = useFormik({
    initialValues: {
      name: "",
      phone: "",
      email: "",
      role: "",
      password: "",
    },

    validationSchema: yup.object().shape({
      name: yup.string().required("Name is required!"),

      phone: yup
        .string()
        .matches(/^[0-9]*$/, "Only numbers allowed!")
        .length(15, "Phone number must be exactly 15 digits!")
        .required("Phone number is required!"),

      email: yup
        .string()
        .email("Enter a valid email address!")
        .required("Email is required!"),

      role: yup.string().required("Role is required!"),

      password: yup.string().required("Password is required!"),
    }),

    validateOnChange: true,
    validateOnBlur: true,

    onSubmit,
  });
  // const formik = useFormik(
  //   {
  //     initialValues: {
  //       name: "",
  //       phone: "",
  //       email: "",
  //       role: "",
  //       password: "",

  //     },
  //     validationSchema: yup.object().shape({
  //       name: yup.string().required("name is required!"),
  //       // phone: yup.string().required("phone By is required"),
  //       phone: yup
  //         .string()
  //         .matches(/^[0-9]*$/, "Only numbers allowed!")
  //         .length(10, "Phone number must be exactly 10 digits ")
  //         .required("Phone number is required!"),
  //       email: yup.string().required("email is required!"),
  //       role: yup.string().required("role is required!"),
  //       password: yup.string().required("password is required!"),

  //     }),
  //     validateOnChange: true,
  //     validateOnBlur: true,

  //     onSubmit,
  //   }
  // )



  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const columns = [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
    },
    {
      name: "Name",
      selector: (row) => row.name,

      // cell: (row) => (
      //   <div>
      //     <button className="btn btn-primary">{row.project_id}</button>
      //   </div>
      // ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Email",
      selector: (row) => row.email,
      wrap: true,
      sortable: true,
    },
    {
      name: "Phone ",
      selector: (row) => row.phone,
      wrap: true,
      sortable: true,
    },
    {
      name: "role",
      selector: (row) => row.role,
      wrap: true,
      sortable: true,
      // width: "170px",
    },

    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" />
            </div> */}

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => handleEdit(row)}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => { setDeleteStaff(row.id); setDeleteconfirmmodal(true) }}>
            <AiOutlineDelete size={18} color="red" />
          </div>
        </div>

      ),
      wrap: true,
    },
  ];


  const fetchStaffs = async () => {
    try {
      const response = await axiosInstance.get(`/staff`,);
      setFetchStaff(response.data);

      console.log("response.data", response.data)
    } catch (error) {
      Toast({ message: "Error to get data", type: "error" });

      // console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchStaffs()
  }, [])


  const handleConfirmClosedltstaff = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmdltstaff = async () => {
    try {
      await axiosInstance.delete(`/staff/${deleteStaff}`)
      Toast({ message: "Successfully Deleted", type: "success" });

      fetchStaffs()
    } catch (error) {
      Toast({ message: "Error to taken project", type: "error" });

      // console.log("error", error)
    }
    setDeleteconfirmmodal(false)
  }
  const handleRowClick = (row) => {

  };

  const [roleForAllStaff, setRoleForAllStaff] = useState(null);
  // const role = roleForAllStaff.map((value, index) => value.role && value.id);
  // console.log("dP", role);



  // for role
  const fetchRoleList = async () => {
    try {
      const response = await axiosInstance.get(`/role`,);
      setRoleForAllStaff(response.data);

      console.log("responsedataallStaff", response?.data)
    } catch (error) {
      Toast({ message: "Error to get data", type: "error" });

      // console.error("Error fetching data", error);
    }

  };
  useEffect(() => {
    fetchRoleList()
  }, [])

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['name', 'email', 'phone', 'role', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(fetchStaff, filterText, searchColumns);

  return (
    <>

      <div className='container'>


        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3'>
              <h5>All Staff List</h5>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              <div className='pt-1 text-end' onClick={() => setCreatemodalstaff(true)}>
                <button className='btn btn-danger bg_color p-0 px-2 py-1' > + Add</button>
              </div>
            </div>
          </div>

          <div className='pt-2'>

            <DataTable
              columns={columns}

              data={filterdata}

              customStyles={customStyle}
              pagination
              // selectableRows
              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            />
          </div>
        </div>
      </div>

      <Dialog header="Edit Staff" visible={editmodalstaff} position="top" style={{ width: '50vw' }} onHide={() => { if (!editmodalstaff) return; setEditmodalstaff(false); }}>

        {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
        <form onSubmit={formik1.handleSubmit} autoComplete="off">
          <div className='row py-4'>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <label htmlFor="name" className='form-label text-muted'>Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  name="name"
                  placeholder='Enter Name'
                  value={formik1.values.name}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.name && formik1.touched.name && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.name}
                  </p>
                )}
              </div>


              <div className='mb-3 ' >
                <label htmlFor="email" className='form-label text-muted'> Email </label>
                <input
                  type="Email"
                  className="form-control"
                  id="email"
                  name="email"
                  placeholder='Enter Email'
                  value={formik1.values.email}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.email && formik1.touched.email && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.email}
                  </p>
                )}
              </div>
              <div className='' >
                <label htmlFor="password" className='form-label text-muted'>  Password </label>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  placeholder='Enter Password'
                  value={formik1.values.password}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.password && formik1.touched.password && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.password}
                  </p>
                )}
              </div>

            </div>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3' >
                <label htmlFor="phone" className='form-label text-muted'>  Enter phone number </label>
                <input
                  type="text"
                  className="form-control opacite-75"
                  maxLength={15}
                  id="phone"
                  name="phone"
                  placeholder='Enter Phone Number'
                  value={formik1.values.phone}
                  // onChange={formik1.handleChange}
                  onChange={(e) => {
                    const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                    formik1.setFieldValue("phone", onlyNumbers);
                  }}
                  onBlur={formik1.handleBlur}
                />
                {formik1.errors.phone && formik1.touched.phone && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.phone}
                  </p>
                )}
              </div>
              <div className=''>
                <label htmlFor="role" className='form-label text-muted'>select role</label>
                <select className="form-select opacity-75" id="role" name="role"
                  value={formik1.values.role}
                  onChange={formik1.handleChange}
                  onBlur={formik1.handleBlur}>
                  <option value="">Select Creator</option>
                  {/* <option value="Admin">Admin</option>
                  <option value="Manager">{roleForAllStaff.role}</option>
                  <option value="Seller">Seller</option>
                  <option value="Staff">Staff</option>
                  <option value="User">User</option> */}


                  {roleForAllStaff?.length > 0 ? (
                    roleForAllStaff?.map((item) => (
                      <option key={item.id} value={item.role}>
                        {item.role}
                      </option>
                    ))
                  ) : (
                    <option value="" disabled>No data</option>
                  )}
                </select>
                {formik1.errors.role && formik1.touched.role && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik1.errors.role}
                  </p>
                )}
              </div>
            </div>
            <div className='text-end'>
              <Button variant="outlined" color="error" onClick={() => setEditmodalstaff(false)}> Cancel</Button>

              <Button variant="contained" type='submit' className='mx-2' color="success">Update </Button>&nbsp;
            </div>

          </div>
        </form>
      </Dialog>

      <Dialog header="Add staff " visible={createmodalstaff} position="top" style={{ width: '50vw' }} onHide={() => { if (!createmodalstaff) return; setCreatemodalstaff(false); }}>

        {/* <div className='box_shadow p-4 mt-5 px-lg-5 mx-lg-5'> */}
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className='row py-4'>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3'>
                <label htmlFor="name" className='form-label text-muted'>Name</label>
                <input
                  type="text"
                  className="form-control"
                  id="name"
                  name="name"
                  placeholder='Enter Name'
                  value={formik.values.name}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.name && formik.touched.name && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.name}
                  </p>
                )}
              </div>
              <div className='mb-3 ' >
                <label htmlFor="email" className='form-label text-muted'> Email </label>
                <input
                  type="Email"
                  className="form-control"
                  id="email"
                  name="email"
                  placeholder='Enter Email'
                  value={formik.values.email}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.email && formik.touched.email && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.email}
                  </p>
                )}
              </div>
              <div className='' >
                <label htmlFor="password" className='form-label text-muted'>  Password </label>
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  placeholder='Enter Password'
                  value={formik.values.password}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}
                />
                {formik.errors.password && formik.touched.password && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.password}
                  </p>
                )}
              </div>

            </div>

            <div className='col-12 col-md-6'>
              <div className='mb-3 pt-3' >
                <label htmlFor="phone" className='form-label text-muted'>  Enter phone number </label>
                <input
                  type="text"
                  className="form-control opacite-75"
                  maxLength={15}
                  id="phone"
                  name="phone"
                  placeholder='Enter Phone Number'
                  value={formik.values.phone}
                  // onChange={formik.handleChange} 
                  onChange={(e) => {
                    const onlyNumbers = e.target.value.replace(/[^0-9]/g, "");
                    formik.setFieldValue("phone", onlyNumbers);
                  }}
                  onBlur={formik.handleBlur}
                />
                {/* {formik.errors.phone && formik.touched.phone && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.phone}
                  </p>
                )} */}
                {formik.touched.phone && formik.errors.phone && (
                  <small style={{ color: "red" }}>
                    {formik.errors.phone}
                  </small>
                )}
              </div>
              <div className=''>
                <label htmlFor="role" className='form-label text-muted'>select role</label>
                <select className="form-select opacity-75" id="role" name="role"
                  value={formik.values.role}
                  onChange={formik.handleChange}
                  onBlur={formik.handleBlur}>
                  <option value="">Select Creator</option>
                  {/* <option value="Admin">Admin</option>
                  <option value="Manager">Manager</option>
                  <option value="Seller">Seller</option>
                  <option value="Staff">Staff</option>
                  <option value="User">User</option> */}
                  {roleForAllStaff?.length > 0 ? (
                    roleForAllStaff?.map((item) => (
                      <option key={item.id} value={item.role}>
                        {item.role}
                      </option>
                    ))
                  ) : (
                    <option value="" disabled>No data</option>
                  )}

                </select>
                {formik.errors.role && formik.touched.role && (
                  <p style={{ color: "red", fontSize: "12px" }}>
                    {formik.errors.role}
                  </p>
                )}
              </div>
            </div>
            <div className='text-end'>
              <Button variant="outlined" color="error" onClick={() => setCreatemodalstaff(false)}> Cancel</Button>

              <Button variant="contained" type='submit' className='mx-2' color="success">Save  </Button>&nbsp;
            </div>

          </div>
        </form>
      </Dialog>

      <Dialog header="Confirm Delete" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>

            <Button variant="outlined" color="error" onClick={() => handleConfirmClosedltstaff()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmdltstaff(deleteStaff)}>Yes </Button>
        </div>

      </Dialog>


    </>
  )
}

export default AllStaff