import React, { useEffect, useState } from 'react'
import { BiCloudUpload } from "react-icons/bi";
import tshirt from "../../Assets/t-shirt.png"
import './subcategory.css'
import { Editor } from "primereact/editor";
import { useFormik } from 'formik';
import * as yup from "yup"
import axiosInstance from '../../utils/axiosinstance';
import { base_url, img_path } from '../../Api/BaseUrl';
import { useNavigate } from 'react-router-dom';
import Toast from '../../utils/Toast';
import { RadioButton } from 'primereact/radiobutton';

const CreateSubcategory = () => {

  const navigate = useNavigate()
  const [text, setText] = useState('');
  const [imagePreview, setImagePreview] = useState(null);
  const [serverImage, setServerImage] = useState(null);
  const [fetchcategory, setFetchcategory] = useState('')
  console.log("fetchcategorysssssssss", fetchcategory)

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImagePreview(URL.createObjectURL(file));
      formik.setFieldValue("thumbnail", file);
    } else {
      setImagePreview(null);
      formik.setFieldValue("thumbnail", null);
    }
  };
  const handleLanguage = (e, lang) => {
    e.preventDefault();
    formik.setFieldValue("language_code", lang);
    setLanguage(lang)
  };

  const [language, setLanguage] = useState("en");

  const fetch = async () => {
    try {
      const response = await axiosInstance.get(`/categories`, {
        params: {
          lang: language,
        },
      });
      setFetchcategory(response.data.data);
      console.log("response.data", response.data.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetch()
  }, [language])

  // const onSubmit = async (values) => {
  //     try {
  //          const response = await axiosInstance.post(`/subcategories`, values, {
  //             headers: {
  //                 "Content-Type": "multipart/form-data",
  //                 Accept: "application/json",

  //             },
  //         });
  //         console.log("response", response)
  //         setImagePreview(null);
  //         setServerImage(response.data.thumbnail);
  //         formik.resetForm()
  //     } catch (error) {
  //         console.log("Suberror", error)
  //      }
  //     }

  const onSubmit = async (values) => {
    // alert("rukku")
    try {
      if (!values.thumbnail || !(values.thumbnail instanceof File)) {
        alert("Please select an image file");
        return;
      }
      const formData = new FormData();
      formData.append("title", values.title);
      formData.append("category_id", values.category_id);
      // formData.append("tag_id", values.tag_id);
      // formData.append("created_by", values.created_by);
      formData.append("status", values.status);
      formData.append("language_code", values.language_code);
      formData.append("description", values.description);
      formData.append("thumbnail", values.thumbnail);

      const response = await axiosInstance.post(`${base_url}/subcategories`, formData, {
        headers: {
          "Content-Type": "multipart/form-data",
          Accept: "application/json",
        },
      });
      Toast({ message: "Successfully Created", type: "success" });

      console.log("response", response);
      setImagePreview(null);
      setServerImage(response.data.thumbnail);
      formik.resetForm();
      navigate('/listsubcategory')
    } catch (error) {
      // console.error("Suberror", error);
      Toast({ message: error.response.data.message, type: "error" });
    }
  };
  const formik = useFormik(
    {
      initialValues: {
        title: "",
        category_id: "",
        // tag_id: "",
        // created_by: "",
        thumbnail: "null",
        description: "",
        status: "",
        language_code: language,
      },
      validationSchema: yup.object().shape({
        title: yup.string().required("title is required!"),
        category_id: yup.string().required("category_id By is required"),

        description: yup.string().required("description is required!"),
        status: yup.string().required("status is required!"),
        //   tag_id: yup.string().required("tag_id is required!"),
        //         created_by: yup.string().required("created_by is required!"),
      }),
      onSubmit,
    }
  )

  return (
    <>
      <div className="d-flex justify-content-start">
        <button
          type="button"
          className="btn btn-secondary"
          onClick={() => navigate('/listsubcategory')}
        >
          ← Back
        </button>
      </div>
      <div className=' py-4'>
        <form onSubmit={formik.handleSubmit} autoComplete="off">
          <div className='row'>

            <div className='col-12 col-md-12'>
              <div className='box_shadow p-4 rounded mt-4 bg-white'>
                <ul className="nav nav-tabs mb-3">
                  <li className="nav-item">
                    <button
                      type="button"
                      className='nav-link active text-primary'
                      // className={`nav-link ${language === "en" ? "active" : "black"}`}
                      // onClick={(e) => handleLanguage(e, "en")}
                    >
                      English
                    </button>
                  </li>
                  {/* <li className="nav-item">
                    <button
                      type="button"
                      className={`nav-link ${language === "de" ? "active text-primary" : "text-black"}`}
                      onClick={(e) => handleLanguage(e, "de")}
                    >
                      German
                    </button>
                  </li> */}
                </ul>
                <div className='d-flex'>
                  <h5>General Information</h5>
                  {/* <div className="dropdown ms-4">
                                        <button
                                            className="btn btn-outline-primary dropdown-toggle"
                                            data-bs-toggle="dropdown"
                                            type="button"
                                        >
                                            {formik.values.language_code === "en"
                                                ? "English"
                                                : formik.values.language_code === "de"
                                                    ? "German"
                                                    : "Select a language"}
                                        </button>

                                        <ul className="dropdown-menu">
                                            <li>
                                                <button
                                                    type="button"
                                                    className="dropdown-item"
                                                    onClick={() => {
                                                        formik.setFieldValue("language_code", "en")
                                                        setLanguage("en")
                                                    }}
                                                >
                                                    English
                                                </button>
                                            </li>

                                            <li>
                                                <button
                                                    type="button"
                                                    className="dropdown-item"
                                                    onClick={() => {
                                                        formik.setFieldValue("language_code", "de")
                                                        setLanguage("de")
                                                    }}
                                                >
                                                    German
                                                </button>
                                            </li>
                                        </ul>
                                        {formik.errors.language_code && formik.touched.language_code && (
                                            <p style={{ color: "red", fontSize: "12px" }}>
                                                {formik.errors.language_code}
                                            </p>
                                        )}
                                    </div> */}
                </div>
                <hr />
                <div className='row g-4'>
                  <div className='col-12 col-md-6'>
                    <div className='mb-3'>
                      <label htmlFor="category_id" className='form-label text-muted'>Select a Category</label>
                      <select
                        className="form-select opacity-75"
                        id="category_id"
                        name="category_id"
                        value={formik.values.category_id}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      >
                        <option value="">Select Creator</option>
                        {fetchcategory?.length > 0 ? (
                          fetchcategory?.map((item) => (
                            <option key={item.id} value={item.id} >{item.title} </option>
                          ))

                        ) : (<option value="" disabled>No data</option>)}
                      </select>
                      {formik.errors.category_id && formik.touched.category_id && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.category_id}
                        </p>
                      )}
                    </div>

                    {/* <div className='mb-3'>
                                            <label htmlFor="created_by" className='form-label text-muted'>Created By</label>
                                            <select className="form-select opacity-75" id="created_by" name="created_by"
                                                value={formik.values.created_by}
                                                onChange={formik.handleChange}
                                                onBlur={formik.handleBlur}>
                                                <option value=""> Select Creator</option>
                                               
                                                <option value="Admin">Admin</option>
                                                <option value="User">User</option>
                                                <option value="Seller">Seller</option>
                                            </select>
                                            {formik.errors.created_by && formik.touched.created_by && (
                                                <p style={{ color: "red", fontSize: "12px" }}>
                                                    {formik.errors.created_by}
                                                </p>
                                            )}  
                                        </div> */}

                    <div className="mb-3 ">
                      <label className="form-label text-muted">Status</label>
                      <div className="d-flex  gap-2">
                        <div className="form-check">

                          <RadioButton inputId="ingredient1" name="status" value="active" id="status-active"
                            checked={formik.values.status === "active"}
                            onChange={formik.handleChange}
                          />
                          <label className="form-check-label ms-2" htmlFor="status-active">
                            Active
                          </label>
                        </div>
                        <div className="form-check">

                          <RadioButton inputId="ingredient2" name="status" value="inactive" id="status-inactive"
                            checked={formik.values.status === "inactive"}
                            onChange={formik.handleChange}
                          />
                          <label className="form-check-label ms-2" htmlFor="status-inactive">
                            Inactive
                          </label>
                        </div>

                      </div>
                      {formik.errors.status && formik.touched.status && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.status}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className='col-12 col-md-6'>
                    <div className='mb-3'>
                      <label htmlFor="title" className='form-label text-muted '>Sub Category Title</label>
                      <input
                        type='text'
                        className='form-control opacity-75'
                        id="title"
                        name='title'
                        placeholder='Enter Title'
                        value={formik.values.title}
                        onChange={formik.handleChange}
                        onBlur={formik.handleBlur}
                      />
                      {formik.errors.title && formik.touched.title && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.title}
                        </p>
                      )}
                    </div>

                    {/* <div className='mb-3'>
                                            <label htmlFor="stockSelect" className='form-label text-muted'>Tag ID</label>
                                            <input
                                                type='text'
                                                name='tag_id'
                                                className='form-control opacity-75'
                                                id="tag_id"
                                                placeholder='Enter Title'
                                                value={formik.values.tag_id}
                                                onChange={formik.handleChange}
                                                onBlur={formik.handleBlur}
                                            />
                                            {formik.errors.tag_id && formik.touched.tag_id && (
                        <p style={{ color: "red", fontSize: "12px" }}>
                          {formik.errors.tag_id}
                        </p>
                      )} 
                                        </div> */}
                  </div>
                  <div className='col-12'>
                    <div className='mb-3'>
                      {/* <label htmlFor="description" className='form-label text-muted'>Description</label>
                                <textarea
                                    className="form-control "
                                    id="description"
                                    rows="5"
                                    placeholder="Type description"
                                ></textarea> */}
                      {/* <div className="">
                          <Editor value={text} onTextChange={(e) => setText(e.htmlValue)} style={{ height: '320px' }} />
                         </div> */}
                      <div className="">
                        <Editor
                          id="description"
                          name="description"
                          value={formik.values.description}
                          onTextChange={(e) => formik.setFieldValue("description", e.htmlValue)}
                          onBlur={formik.handleBlur}
                          style={{ height: "320px" }}
                        />
                        {formik.errors.description && formik.touched.description && (
                          <p style={{ color: "red", fontSize: "12px" }}>
                            {formik.errors.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>

          </div>
          <div className='row py-4'>
            <div className="col-12 col-md-12 ">
              <div className='box_shadow pb-4 bg-white'>

                <h5 className="mb-3 ms-4 pt-3">Add Thumbnail Photo</h5>
                <hr className='' />

                <div
                  className="border border-dotted  mx-auto text-center "
                  style={{ maxWidth: "800px", minHeight: "200px", display: "flex", alignItems: "center", justifyContent: "center" }}
                >
                  <input
                    type="file"
                    id="thumbnail-upload"
                    className="d-none"
                    name=''
                    accept="image/png, image/jpeg, image/gif"
                    onChange={handleImageChange}
                  />
                  {imagePreview || serverImage ? (
                    <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                      <img
                        src={
                          imagePreview
                            ? imagePreview
                            : `${img_path}/subcategories/${serverImage}`
                        }
                        alt="Preview"
                        className="img-fluid rounded"
                        style={{
                          maxHeight: "200px",
                          maxWidth: "100%",
                          objectFit: "contain",
                          border: "1px solid #ccc",
                          padding: "5px",
                        }}
                      />
                    </label>
                  ) : (
                    <label htmlFor="thumbnail-upload" style={{ cursor: "pointer" }}>
                      <BiCloudUpload size={50} className="color_icon mb-3" />
                      <h4>
                        Drop your images here, or{" "}
                        <span className="color_icon">click to browse</span>
                      </h4>
                      <p className="small text-muted">
                        1600 x 1200 (4:3) recommended. PNG, JPG and GIF files are allowed
                      </p>
                    </label>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className='col-12 d-flex justify-content-end gap-3 mt-3'>
            <button className='btn btn-danger bg_color' onClick={() => formik.resetForm()}>Cancel</button>

            <button className='btn btn-outline-success'>Create </button>
          </div>
        </form>
      </div>

    </>
  )
}

export default CreateSubcategory

