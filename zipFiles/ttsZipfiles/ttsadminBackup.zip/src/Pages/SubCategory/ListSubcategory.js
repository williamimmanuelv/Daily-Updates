import React, { useEffect, useMemo, useState } from 'react'
import imge1 from "../../Assets/Frame 21.png"
import imge2 from "../../Assets/Frame 17.png"
import image3 from "../../Assets/Frame 18.png"
import image4 from "../../Assets/Frame 19.png"
import image5 from "../../Assets/Frame 20.png"

import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dropdown } from 'primereact/dropdown';
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import axiosInstance from '../../utils/axiosinstance'
import { img_path } from '../../Api/BaseUrl'
import { SearchData } from '../../utils/Search'
import Toast from '../../utils/Toast'
import customStyle from '../../utils/Customstyle'
import { FiPlus } from "react-icons/fi";
import "./subcategory.css"

const ListSubcategory = () => {
  const navigate = useNavigate()

  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);
  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false);
  const [fetchsubcategory, setFetchsubcategory] = useState([])
  console.log("fetchsubcategorybbbbbb", fetchsubcategory)
  const [viewsubCategory, setViewsubCategory] = useState(null);
  const [viewsubcategoryconfirmmodal, setViewsubcategoryconfirmmodal] = useState(false)
  const [deleteRowId, setDeleteRowId] = useState(null);
  const [selectedRows, setSelectedRows] = useState([]);

  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  //  const columns = [
  const columns = useMemo(() => [
    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
      width: "120px"
    },

    {
      name: "Sub category",
      selector: (row) => row.title,
      sortable: true,
      cell: (row) => (
        <span className=" product-name-ellipsis  ">
          {row.title}
        </span>
      ),
    },
    {
      name: "Image",
      cell: (row) => (
        row.thumbnail ? (
          <img
            src={`${img_path}/subcategories/${row.thumbnail}`}
            alt={row.title}
            style={{ width: "40px", height: "40px", objectFit: "cover", borderRadius: "6px" }}
          />
        ) : (
          <span className="text-muted">No image</span>
        )
      ),
      wrap: true,
      sortable: false,
    },
    {
      name: "Category",
      selector: (row) => row.category_name,
      wrap: true,
      sortable: true,
    },
    {
      name: "language",
      selector: (row) => row.language,
      wrap: true,
      sortable: true,
    },
    {
      name: "Status",
      selector: (row) => row.status,
      wrap: true,
      sortable: true,
    },

    {
      name: "Actions",
      width: "200px",
      cell: (row) => (

        <div className="d-flex gap-3 me-5">
          <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => {
            setViewsubCategory(row)
            setViewsubcategoryconfirmmodal(true)
          }}>
            <GrFormView size={20} color="white" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => subcategoryEdit(row)}>
            <LuPencilLine size={16} color="red" />
          </div>

          <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} onClick={() => {
            setDeleteRowId(row);
            setDeleteconfirmmodal(true);
          }} >
            <AiOutlineDelete size={18} color="red" />


          </div>
        </div>

      ),
      wrap: true,
    },
    // ];
  ], [img_path]);


  const handleRowClick = (row) => {
  };
  const [language, setLanguage] = useState("all");

  const fetch = async () => {
    try {
      const response = await axiosInstance.get(`/subcategories`, {
        params: {
          lang: language,
        },
      });
      setFetchsubcategory(response.data.data);
      console.log("response.data", response.data);
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };
  useEffect(() => {
    fetch()
  }, [language])


  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const handleConfirmClose = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmdelete = async (row) => {
    try {
      const response = await axiosInstance.delete(`/subcategories/${row.id}`, {
        params: {
          lang: row.language,
        },
      });
      fetch()
      Toast({ message: response.data.message, type: "success" });

    } catch (error) {
      Toast({ message: error.response.data.message, type: "error" });
    } finally {
      setDeleteconfirmmodal(false);

    }
  }

  const subcategoryEdit = (row) => {
    navigate('/editsubcategory', { state: row })
  }

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['title', 'language', 'category_name', 'tag_id', 'status',];

  const uniqueData = useMemo(() => {
    const map = new Map();
    fetchsubcategory.forEach(item => {
      map.set(`${item.id}-${item.language}`, item);
    });
    return Array.from(map.values());
  }, [fetchsubcategory]);


  // const filterdata = SearchData(fetchsubcategory, filterText, searchColumns);
  const filterdata = useMemo(() => {
    return SearchData(uniqueData, filterText, searchColumns);
  }, [uniqueData, filterText]);

  console.log("fetchsubcategory", fetchsubcategory)
  console.log("filterdata", filterdata)

  return (
    <>
      <div className='container'>
        <div className='mt-3 box_shadow  bg-white rounded-2'>
          <div className='d-flex justify-content-between'>
            <div className='pt-3 px-3 d-flex'>
              <h5 className='pt-1'>All SubCategory List</h5>
              <div className="dropdown ms-2">
                <button
                  type="button"
                  className="btn btn-outline-primary dropdown-toggle"
                  data-bs-toggle="dropdown"
                >
                  {language === "all"
                    ? "All"
                    : language === "en"
                      ? "English"
                      : "German"}
                  {/* select language */}
                </button>

                <ul className="dropdown-menu">
                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("all")}
                    >
                      All
                    </button>
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("en")}
                    >
                      English
                    </button>
                  </li>

                  <li>
                    <button
                      type="button"
                      className="dropdown-item"
                      onClick={() => setLanguage("de")}
                    >
                      German
                    </button>
                  </li>
                </ul>
              </div>
            </div>
            <div className='d-flex  pt-2 pe-2'>
              <div className='text-end position-relative px-2 pt-1'>
                <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                  size={18} />
                <input text="search" className='form-control opacity-75' id='' onChange={handleFilter} name='' placeholder='Search Filter.........' />
              </div>
              {/* <Link to="/createsubcategory" className='text-decoration-none text-white'> <div className='mt-1  me-2'>
                <button className='btn btn-danger bg_color p-0 px-2 py-1'> Add <FiPlus className='pb-1' /></button>
              </div></Link> */}
            </div>
          </div>

          <div className='pt-2'>
            {/* <DataTable
              columns={columns}
              data={filterdata}
              customStyles={customStyle}
              pagination

              onRowClicked={handleRowClick}
              fixedHeader
              persistTableHead={true}
            /> */}

            <DataTable
              columns={columns}
              data={filterdata}
              customStyles={customStyle}
              keyField={row => `${row.id}-${row.language}`}
              pagination
              fixedHeader
              className='subCategoryListDataTable'
            />
          </div>
        </div>
      </div>

      <Dialog header="Confirm Delete Modal" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

        <div className=" form-group">
          <p>Do you want to delete this record?</p>
        </div>
        <div className="d-flex p-3 justify-content-end mt-3">
          {/* <button className="btn btn-danger" type="submit" onClick={() => handleConfirmClose()}>No </button>&nbsp; */}
          <Stack direction="row" spacing={2}>
            <Button variant="outlined" color="error" onClick={() => handleConfirmClose()}> No  </Button>&nbsp;
          </Stack>

          {/* <button className="btn btn-success" type="submit" onClick={() => handleconfirmopen()}>Yes </button> */}
          <Button variant="contained" color="success" onClick={() => handleconfirmdelete(deleteRowId)}>Yes </Button>
        </div>

      </Dialog>

      <Dialog header="Confirm View Modal" visible={viewsubcategoryconfirmmodal} position="top" style={{ width: '60vw' }} onHide={() => { if (!viewsubcategoryconfirmmodal) return; setViewsubcategoryconfirmmodal(false); }}>
        {viewsubcategoryconfirmmodal && (


          <div className='row'>
            <div className='col'>

              {/* <p>Sub category :{viewsubCategory.sub_title}</p> */}
              <p>Sub category :{viewsubCategory.title}</p>
              <p>Categories :{viewsubCategory.category_id}</p>
            </div>
            <div className='col'>

              {/* <p>ID :{viewsubCategory.tag_id}</p> */}
              {/* <p>ID :{viewsubCategory.id}</p> */}
              <p>Categories by :{viewsubCategory.category_name}</p>


              {/* <p>Categories by :{viewsubCategory.created_by}</p> */}
            </div>

            {/* <div className="col-md-3 pt-2">
              <div className="border p-2">
                <img
                  src={`${img_path}/subcategories/${viewsubCategory.thumbnail}`}
                  // alt={item.product_name}
                  className="img-fluid rounded"
                  style={{ width: "120px", height: "120px", objectFit: "contain" }}
                />
              </div>
            </div> */}

          </div>
        )}
      </Dialog>


    </>
  )
}

export default ListSubcategory