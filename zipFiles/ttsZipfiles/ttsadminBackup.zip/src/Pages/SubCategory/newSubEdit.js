import React, { useEffect, useRef, useState } from "react";
import { Editor } from "primereact/editor";
import { useLocation, useNavigate } from "react-router-dom";
import axiosInstance from "../../utils/axiosinstance";
import { useFormik } from "formik";
import { base_url } from "../../Api/BaseUrl";
import * as yup from "yup";
import Toast from "../../utils/Toast";
import { RadioButton } from "primereact/radiobutton";

const EditSubcategory = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem("tokenAdmin");

  const editorRef = useRef(null);
  const editorInitializedRef = useRef(false);

  const [fetchcategory, setFetchcategory] = useState([]);
  const [fetchsubcategory, setFetchsubcategory] = useState(null);
  const [language, setLanguage] = useState("en");
  const [imagePreview, setImagePreview] = useState(null);

  const { state } = useLocation();
  const subgetData = state;

  const pasteHtmlSafely = (html) => {
    const quill = editorRef.current?.getQuill?.();
    if (!quill) return false;

    quill.setContents([]);
    quill.clipboard.dangerouslyPasteHTML(html);
    return true;
  };


  useEffect(() => {
    if (!subgetData?.id) return;

    axiosInstance
      .get(`/subcategories/${subgetData.id}`, {
        params: {
          lang: language
        },
      })

      .then((res) => setFetchsubcategory(res.data))
      .catch(console.error);
  }, [language]);


  useEffect(() => {
    axiosInstance
      .get(`/categories`, { params: { lang: language } })
      .then((res) => setFetchcategory(res.data.data || []))
      .catch(console.error);
  }, [language]);


  const formik = useFormik({
    initialValues: {
      title: "",
      category_id: "",
      description: "",
      thumbnail: null,
      status: "",
      language_code: "",
      id: "",
    },
    validationSchema: yup.object({
      title: yup.string().required(),
      category_id: yup.string().required(),
      description: yup.string().required(),
      status: yup.string().required(),
    }),
    onSubmit: async (values) => {
      try {
        const formData = new FormData();
        Object.entries(values).forEach(([k, v]) => {
          if (v !== null) formData.append(k, v);
        });

        await axiosInstance.post(
          `${base_url}/subcategories/${values.id}?_method=PUT`,
          formData,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );

        Toast({ message: "Updated successfully", type: "success" });
        navigate("/listsubcategory");
      } catch {
        Toast({ message: "Update failed", type: "error" });
      }
    },
  });


  useEffect(() => {
    if (!fetchsubcategory) return;

    formik.setValues({
      title: fetchsubcategory?.translation?.title || "",
      category_id: fetchsubcategory?.category_id || "",
      description: fetchsubcategory?.translation?.description || "",
      status: fetchsubcategory?.status || "",
      thumbnail: null,
      language_code:
        fetchsubcategory?.translation?.language_code || language,
      id: fetchsubcategory?.id || "",
    });

    if (
      fetchsubcategory?.translation?.description &&
      !editorInitializedRef.current
    ) {
      const pasted = pasteHtmlSafely(
        fetchsubcategory.translation.description
      );

      if (pasted) {
        editorInitializedRef.current = true;
      }
    }
  }, [fetchsubcategory]);


  const handleLanguageChange = (lang) => {
    editorInitializedRef.current = false;
    setLanguage(lang);
  };


  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setImagePreview(URL.createObjectURL(file));
    formik.setFieldValue("thumbnail", file);
  };


  return (
    <form onSubmit={formik.handleSubmit}>
      <button type="button" onClick={() => navigate("/listsubcategory")}>
        ← Back
      </button>

      <div>
        <button type="button" onClick={() => handleLanguageChange("en")}>
          English
        </button>
        <button type="button" onClick={() => handleLanguageChange("de")}>
          German
        </button>
      </div>

      <input
        name="title"
        value={formik.values.title}
        onChange={formik.handleChange}
      />

      <select
        name="category_id"
        value={formik.values.category_id}
        onChange={formik.handleChange}
      >
        <option value="">Select</option>
        {fetchcategory.map((c) => (
          <option key={c.id} value={c.id}>
            {c.title}
          </option>
        ))}
      </select>

      <RadioButton
        name="status"
        value="active"
        checked={formik.values.status === "active"}
        onChange={formik.handleChange}
      />
      Active

      <RadioButton
        name="status"
        value="inactive"
        checked={formik.values.status === "inactive"}
        onChange={formik.handleChange}
      />
      Inactive

      <Editor
        ref={editorRef}
        style={{ height: "320px" }}
        onTextChange={(e) =>
          formik.setFieldValue("description", e.htmlValue)
        }
      />

      <input type="file" onChange={handleImageChange} />
      {imagePreview && <img src={imagePreview} width={200} />}

      <button type="submit">Update</button>
    </form>
  );
};

export default EditSubcategory;
