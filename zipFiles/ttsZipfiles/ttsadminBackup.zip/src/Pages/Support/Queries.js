import React, { useState } from 'react'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { IoSearchOutline } from "react-icons/io5";
import customStyle from '../../utils/Customstyle';

// 
import './queries.css'


const Queries = () => {
  const navigate = useNavigate()
  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [viewqueriesconfirmmodal, setViewqueriesconfirmmodal] = useState(false)

  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const columns = [
    {
      name: "S.no",
      selector: (row) => row.SNo,
      wrap: true,
      sortable: true,
    },
    {
      name: "User Name ",
      selector: (row) => row.ProductName,

      // cell: (row) => (
      //   <div>
      //     <button className="btn btn-primary">{row.project_id}</button>
      //   </div>
      // ),
      wrap: true,
      sortable: true,
    },
    {
      name: "Product Name",
      selector: (row) => row.Category,
      wrap: true,
      sortable: true,
    },
    {
      name: "Questions",
      selector: (row) => row.Createby,
      wrap: true,
      sortable: true,
    },
    {
      name: "Reply",
      selector: (row) => row.ProductName,
      wrap: true,
      sortable: true,
      // width: "170px",
    },
    {
      name: "Status ",
      selector: (row) => row.ID,
      wrap: true,
      sortable: true,
    },

    // {
    //   name: "Created At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    // {
    //   name: "Updated At",
    //   selector: (row) => row.stock,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Actions",
      cell: (row) => (
        // <button className="btn btn-danger btn-sm">Delete</button>
        <div className="d-flex gap-1 me-5">
          <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
            <GrFormView size={20} color="white" onClick={() => setViewqueriesconfirmmodal(true)} />
          </div>

          {/* <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <LuPencilLine size={16} color="red" onClick={()=>navigate('/couponEdit')} />
            </div>
          
            <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <AiOutlineDelete size={18} color="red"onClick={()=>setDeleteconfirmmodal(true)} />
            </div> */}
        </div>

      ),
      wrap: true,
    },
  ];

  const products = [{
    SNo: "1",
    ProductName: "New100 ",
    Category: "$Dress",
    Createby: "27-09-2025",
    ID: "27-09-2026	",
    Stock: "10",
    Actions: ""
  }]


  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'date', 'category_name', 'subcat_name', 'file', 'tracking_status', 'status'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  return (
    <>

      <div className='mt-5 box_shadow'>
        <div className='d-flex justify-content-between py-3 px-3'>
          <div>
            <h5> All Support Queries List</h5>
          </div>
          {/* <div className='mb-3'>
                        <button className='btn btn-danger bg_color p-0 px-2 py-1' onClick={()=>navigate('/couponCreate')}> + Add Coupon </button>
                    </div> */}
          <div className='text-end position-relative'>
            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
              size={18} />
            <input text="search" className='form-control opacity-75' id='' name='' placeholder='Search Filter.........' />
          </div>

        </div>


        <DataTable
          columns={columns}

          data={products}
          customStyles={customStyle}
          pagination
          // selectableRows
          className='queriesDataTable'
          onRowClicked={handleRowClick}
          fixedHeader
          persistTableHead={true}
        />
      </div>

      <Dialog header="Confirm View Modal" visible={viewqueriesconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!viewqueriesconfirmmodal) return; setViewqueriesconfirmmodal(false); }}>

        <div className='row'>
          <div className='col'>
            <p>User Name  :</p>
            <p>Product Name:</p>
            <p>Questions :</p>
          </div>
          <div className='col'>
            <p>Reply:</p>
            <p>Status :</p>
            <p>Stock :</p>
          </div>

        </div>

      </Dialog>
    </>
  )
}

export default Queries