import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

import DataTable from 'react-data-table-component';
import { Link } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { MdOutlineFileDownload } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5";
import { Editor } from "primereact/editor";
import customStyle from '../../utils/Customstyle';

// 
import './trackingorder.css'


const RefundandReplacement = () => {
    const [text, setText] = useState('');


    const navigate = useNavigate()
    const [selectedProducts, setSelectedProducts] = useState(null);
    const [rowClick, setRowClick] = useState(true);

    const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
    const [viewconfirmmodal, setViewconfirmmodal] = useState(false)

    const [selectedRows, setSelectedRows] = useState([]);
    const handleSelectedRowsChange = (state) => {
        setSelectedRows(state.selectedRows);
    };

    const columns = [
        {
            name: "S.no",
            selector: (row) => row.SNo,
            wrap: true,
            sortable: true,
        },
        {
            name: "Order ID",
            selector: (row) => row.ProductName,

            // cell: (row) => (
            //   <div>
            //     <button className="btn btn-primary">{row.project_id}</button>
            //   </div>
            // ),
            wrap: true,
            sortable: true,
        },
        {
            name: "Customer Name",
            selector: (row) => row.Category,

            wrap: true,
            sortable: true,
        },
        {
            name: "Date",
            selector: (row) => row.Createby,
            //                     cell: (row) => (
            //                 <div className="dropdown">
            //     <button
            //       className="btn btn-secondary dropdown-toggle"
            //       type="button"
            //       data-bs-toggle="dropdown"
            //       aria-expanded="false"
            //     >
            //       status
            //     </button>
            //     <ul className="dropdown-menu">
            //       <li><a className="dropdown-item" href="#">Action</a></li>
            //       <li><a className="dropdown-item" href="#">On process</a></li>
            //       <li><a className="dropdown-item" href="#">On process</a></li>
            //     </ul>
            //   </div>
            //             ),
            wrap: true,
            sortable: true,
        },
        {
            name: "PayStatus",
            selector: (row) => row.ProductName,
            wrap: true,
            sortable: true,
            // width: "170px",
        },
        {
            name: "Product",
            selector: (row) => row.ID,
            wrap: true,
            sortable: true,
        },
        {
            name: "Resolution",
            selector: (row) => row.ID,
            wrap: true,
            sortable: true,
        },
        {
            name: "Reson",
            selector: (row) => row.Stock,
            wrap: true,
            sortable: true,
        },

        {
            name: "Status",
            selector: (row) => row.ProductName,
            wrap: true,
            sortable: true,
        },

        {
            name: "Actions",
            cell: (row) => (
                // <button className="btn btn-danger btn-sm">Delete</button>
                <div className="d-flex gap-1 me-5">
                    {/* <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
              <GrFormView size={20} color="white" onClick={()=>setViewconfirmmodal(true)}/>
            </div>  */}

                    <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
                        <LuPencilLine size={16} color="red" onClick={() => setViewconfirmmodal(true)} />
                    </div>

                    {/* <div style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
                        <AiOutlineDelete size={18} color="red" onClick={() => setDeleteconfirmmodal(true)} />
                    </div>  */}
                </div>

            ),
            wrap: true,
        },
    ];

    const products = [{
        SNo: "1",
        ProductName: "New100 ",
        Category: "$Dress",
        Createby: "27-09-2025",
        ID: "27-09-2026	",
        Stock: "10",
        Actions: ""
    }]

    const handleConfirmClose = () => {
        setDeleteconfirmmodal(false)
    }
    const handleconfirmopen = () => {

        setDeleteconfirmmodal(false)

    }
    const handleRowClick = (row) => {

    };

    const [filterText, setFilterText] = useState("");
    const searchColumns = ['project_id', 'date', 'category_name', 'subcat_name', 'file', 'tracking_status', 'status'];
    const handleFilter = (event) => {
        setFilterText(event.target.value);
    };
    return (
        <>
            <div className='mt-3 box_shadow'>
                <div className='d-flex justify-content-between py-3 px-3'>
                    <div>
                        <h5> All Refund & Replacement</h5>
                    </div>
                    <div className='text-end position-relative'>
                        <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
                            size={18} />
                        <input text="search" className='form-control opacity-75' id='' name='' placeholder='Search Filter.........' />
                    </div>

                </div>


                <DataTable
                    columns={columns}

                    data={products}

                    customStyles={customStyle}
                    pagination
                    // selectableRows
                    className='refundAndReplaceDataTable'
                    onRowClicked={handleRowClick}
                    fixedHeader
                    persistTableHead={true}
                />
            </div>

            <Dialog header="Refund & REplacement" visible={viewconfirmmodal} position="top" style={{ width: '40vw' }} onHide={() => { if (!viewconfirmmodal) return; setViewconfirmmodal(false); }}>
                <form>
                    <div className='mb-3'>
                        <label htmlFor="createdBy" className='form-label text-muted'>Created By</label>
                        <select className="form-select opacity-75" id="createdBy" name="sellist1">
                            <option>Select Creator</option>
                            <option>Admin</option>
                            <option>Other</option>
                            <option>Seller</option>
                        </select>
                    </div>

                    <div className="">

                        {/* <Editor
                            key={language}
                            value={formik.values.description}
                            style={{ height: "320px" }}
                            onTextChange={(e) => { if (e.source !== "user") return; setText(e.htmlValue) }}
                        /> */}
                        
                        <Editor
                            value={text}
                            onTextChange={(e) => setText(e.htmlValue)}
                            style={{ height: '320px' }}
                        />
                    </div>
                    <div className='col-12 d-flex justify-content-end gap-3 mt-3'>
                        <button className='btn btn-danger bg_color'>Cancel</button>

                        <button className='btn btn-outline-success'>Save</button>
                    </div>
                </form>

            </Dialog>

        </>
    )
}

export default RefundandReplacement