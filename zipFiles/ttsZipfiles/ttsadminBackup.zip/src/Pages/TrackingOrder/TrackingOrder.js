import React, { useEffect, useRef, useState } from 'react'
import './trackingorder.css'
import DataTable from 'react-data-table-component';
import { Link, useNavigate } from 'react-router-dom'
import { GrFormView } from "react-icons/gr";
import { LuPencilLine } from "react-icons/lu";
import { AiOutlineDelete } from "react-icons/ai";
import { Dialog } from 'primereact/dialog';
import Button from '@mui/material/Button';
import Stack from '@mui/material/Stack';
import { MdOutlineFileDownload } from "react-icons/md";
import { IoSearchOutline } from "react-icons/io5";
import customStyle from '../../utils/Customstyle';
import { DatePicker, Dropdown, Space } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import { Calendar } from 'primereact/calendar';
import axiosInstance from '../../utils/axiosinstance';
import { SearchData } from '../../utils/Search';
import { InputText } from 'primereact/inputtext';
import { MdOutlineKeyboardArrowDown } from "react-icons/md";
import { Dropdown as PrimeDropdown } from 'primereact/dropdown';

import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import Invoice from '../../utils/Invoice';
import dayjs from 'dayjs';
// import { GenerateOrderSummaryPdf } from '../../Component/generateOrderSummaryPdf/GenerateOrderSummaryPdf';
// import { generateOrderSummaryPdf } from "./pdf/OrderSummaryPdf";

// 
import './trackingorder.css'



const TrackingOrder = () => {

  const navigate = useNavigate()

  // const orders = [...Array(1000)].map((_, i) => ({
  //     orderId: "ORD" + (i + 1),
  //     customerName: "Customer " + (i + 1),
  //     amount: Math.floor(Math.random() * 5000),
  //     status: i % 2 ? "Delivered" : "Pending",
  //     date: "2025-01-01",
  // }));

  //  const contentRef = useRef();
  //   const downloadPdf = () => {
  //     const input = contentRef.current;

  //     input.style.display = "block";

  //     html2canvas(input, { scale: 2 }).then((canvas) => {
  //       const imgData = canvas.toDataURL("image/png");
  //       const pdf = new jsPDF("p", "mm", "a4");
  //       const imgWidth = 210; 
  //       const imgHeight = (canvas.height * imgWidth) / canvas.width;

  //       pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
  //       pdf.save("invoice.pdf");
  //     });

  //     input.style.display = "none";
  //   };
  const contentRef = useRef();


  const downloadPdf = () => {
    const input = contentRef.current;

    html2canvas(input, { scale: 3 }).then((canvas) => {
      const imgData = canvas.toDataURL("image/png");

      const pdf = new jsPDF("p", "mm", "a4");

      const pageWidth = 210;
      const pageHeight = 297;

      const imgWidth = pageWidth;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;

      // PAGE 1
      pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      // MULTIPLE PAGES
      while (heightLeft > 0) {
        pdf.addPage();
        position = -(imgHeight - heightLeft);
        pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save("invoice.pdf");
    });
  };

  // const contentRef = useRef();

  // const downloadPdf = () => {
  //     console.log("hi")
  //     const input = contentRef.current;


  //     input.style.position = "absolute";
  //     input.style.left = "-9999px";
  //     input.style.visibility = "visible";

  //     html2canvas(input, { scale: 2 }).then((canvas) => {
  //         const imgData = canvas.toDataURL("image/png");
  //         const pdf = new jsPDF("p", "mm", "a4");

  //         const imgWidth = 210;
  //         const imgHeight = (canvas.height * imgWidth) / canvas.width;

  //         pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
  //         pdf.save("invoice.pdf");


  //         input.style.left = "0";
  //         input.style.position = "relative";
  //         input.style.visibility = "hidden";
  //     });
  // };


  const [selectedProducts, setSelectedProducts] = useState(null);
  const [rowClick, setRowClick] = useState(true);

  const [deleteconfirmmodal, setDeleteconfirmmodal] = useState(false)
  const [viewconfirmmodal, setViewconfirmmodal] = useState(false)

  const [selectedRows, setSelectedRows] = useState([]);
  const handleSelectedRowsChange = (state) => {
    setSelectedRows(state.selectedRows);
  };

  const [orderId, setOrderId] = useState("");
  const [paymentId, setPaymentId] = useState("");
  const [status, setStatus] = useState("");
  const [date, setDate] = useState(null);   // From Date
  const [todate, setTodate] = useState(null); // To Date


  const [filteredOrders, setFilteredOrders] = useState([]);
  console.log("filteredOrdersss", filteredOrders)

  const [ordertracking, setOrdertracking] = useState([])
  console.log("ordertrackingss", ordertracking)

  const fetchOrdertrac = async () => {
    try {
      const response = await axiosInstance.get(`/orders`,);
      setOrdertracking(response?.data.orders);
      console.log("response_count", response.data)
    } catch (error) {
      console.error("Error fetching data", error);
    }
  };

  useEffect(() => {
    fetchOrdertrac()
  }, [])

  const [rowId, setRowId] = useState();
  const [dataForInvoice, setDataForInvoice] = useState()
  console.log(rowId);

  const inData = async (rowId) => {
    try {

      const response = await axiosInstance.get(`invoice/${rowId}`);
      // const response = await axios.get(`https://rooptek.com/ttsbrothers/api/invoice/${rowId}`);
      console.log("cc", response.data);

      setDataForInvoice(response.data)
      console.log(rowId);

    } catch (error) {
      console.error("Error fetching data", error);
    }
  }


  useEffect(() => {
    inData(rowId);
  }, [rowId])

  useEffect(() => {
    if (dataForInvoice) {
      setTimeout(() => {
        downloadPdf();
      }, 500);
    }
  }, [dataForInvoice]);


  const [isChange, setIsChange] = useState(false);

  const [forRedErrors, setForRedErrors] = useState(false);

  const handleCancelFilter = async () => {
    setOrderId("");
    setPaymentId("");
    setStatus("");
    setDate(null);
    setTodate(null);
    setIsChange(true);
    setForRedErrors(!forRedErrors);

  }
  useEffect(() => {
    if (isChange) {

      handleFilterAll()
      setIsChange(false)

    }
  }, [orderId, paymentId, isChange, status, date, todate])



  const handleFilterAll = async () => {
    let filtered = ordertracking;

    // Filter by Order ID
    if (orderId.trim() !== "") {
      filtered = filtered.filter(order =>
        order.order_no.toLowerCase().includes(orderId.toLowerCase())
      );
    }

    // Filter by Payment ID
    if (paymentId.trim() !== "") {
      filtered = filtered.filter(order =>
        order.payment_ref?.toLowerCase().includes(paymentId.toLowerCase())
      );
    }

    // Filter Status
    if (status !== "") {
      filtered = filtered.filter(order =>
        order.status.toLowerCase() === status.toLowerCase()
      );
    }

    // Filter Date Range (created_at)
    if (date && todate) {
      const from = new Date(date);
      const to = new Date(todate);

      filtered = filtered.filter(order => {
        const created = new Date(order.created_at);
        return created >= from && created <= to;
      });
    }
    setFilteredOrders(filtered);



    // if (filteredOrders === "[]") {
    //   setForRedErrors(true)
    //   // console.log("length__", filteredTableForCancel.length);

    // }


    if (!filteredOrders || filteredOrders.length === 0) {
      setForRedErrors(true);
    }

    setShowFilterOrderId(false);
    setShowFilterPaymentId(false);


  };

  const columns = [

    {
      name: "S.no",
      cell: (row, index) => index + 1,
      wrap: true,
      sortable: true,
    },
    {
      name: "Order ID",
      selector: (row) => row.order_no,
      wrap: true,
      sortable: true,
    },
    {
      name: "Payment Ref",
      selector: (row) => row.payment_ref,
      wrap: true,
      sortable: true,
    },
    {
      name: "Pickup Date",
      selector: (row) => row.pickup_date,
      wrap: true,
      sortable: true,
    },
    {
      name: "Pickup Time",
      selector: (row) => row.pickup_time,
      wrap: true,
      sortable: true,
    },
    {
      name: "Transaction Id",
      selector: (row) => row.transaction_id,
      wrap: true,
      sortable: true,
    },

    {
      name: "Total Amount",
      selector: (row) => row.total_amount,
      wrap: true,
      sortable: true,

    },
    {
      name: "Payment Status",
      selector: (row) => row.payment_status,
      wrap: true,
      sortable: true,
    },
    {
      name: "Tax Amount",
      selector: (row) => row.tax_amount,
      wrap: true,
      sortable: true,
    },
    {
      name: "Delivery Type",
      selector: (row) => row.delivery_type,
      wrap: true,
      sortable: true,
    },
    {
      name: "Payment Type",
      selector: (row) => row.payment_type,
      wrap: true,
      sortable: true,
    },
    {
      name: "Status",
      selector: (row) => row.status,
      wrap: true,
      sortable: true,
    },
    {
      name: "User Name",
      selector: (row) => row.user_name,
      wrap: true,
      sortable: true,
    },
    {
      name: "User Mobile",
      selector: (row) => row.user_mobile,
      wrap: true,
      sortable: true,
    }, {
      name: "User Email",
      selector: (row) => row.user_email,
      wrap: true,
      sortable: true,
    }, {
      name: "Invoice No",
      selector: (row) => row.invoice_no,
      wrap: true,
      sortable: true,
    }, {
      name: "Discount Applied",
      selector: (row) => row.discount_applied,
      wrap: true,
      sortable: true,
    }, {
      name: "Delivery Type",
      selector: (row) => row.delivery_type,
      wrap: true,
      sortable: true,
    },
    {
      name: "Delivery Charge",
      selector: (row) => row.delivery_charge,
      wrap: true,
      sortable: true,
    },
    //  {
    //   name: "delivery_address_id",
    //   selector: (row) => row.delivery_address_id,
    //   wrap: true,
    //   sortable: true,
    // },
    //  {
    //   name: "coupon_id",
    //   selector: (row) => row.coupon_id,
    //   wrap: true,
    //   sortable: true,
    // },
    {
      name: "Created At",
      selector: (row) => row.created_at,
      wrap: true,
      sortable: true,
    },


    // {
    //     name: "Order status",
    //     cell: (row) => (
    //         <Dropdown menu={{ items }} trigger={["click"]}>
    //             <a
    //                 onClick={(e) => e.preventDefault()}
    //                 className="cursor-pointer"
    //                 style={{ color: "black", textDecoration: "none" }}
    //             >
    //                 <Space>
    //                     Status
    //                     <DownOutlined />
    //                 </Space>
    //             </a>
    //         </Dropdown>
    //     ),
    //     wrap: true,
    //     sortable: true, 
    // },
    {
      name: "Invoice",
      // selector: (row) => row.ID,
      cell: (row) => (

        //   <button onClick={() => generateOrderSummaryPdf(orders)}>
        //       Download 1000 Orders PDF
        //     </button>

        // 2secondedMethod..............................................
        // <button onClick={() => GenerateOrderSummaryPdf(orders)}
        //     style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
        //     <MdOutlineFileDownload size={22} />
        // </button>

        // <div
        //     onClick={downloadPdf}
        //     style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }}
        // >
        //     <MdOutlineFileDownload size={22} />
        // </div>
        <div
          onClick={async () => {
            await inData(row.id)

          }}
          // onClick={() => downloadPdf(row.id)}
          // onClick={() => setRowId(row.id)}
          style={{ backgroundColor: "#ffe6e6", padding: "6px", borderRadius: "6px", cursor: "pointer" }} >
          <MdOutlineFileDownload size={22} />

        </div>


      ),
      wrap: true,
      sortable: true,
    },
    // {
    //      name: "Actions",
    //     cell: (row) => (

    //         <div className="d-flex gap-1 me-5">
    //             <div style={{ backgroundColor: "black", padding: "6px", borderRadius: "6px", cursor: "pointer" }}>
    //                 <GrFormView size={20} color="white" onClick={() => setViewconfirmmodal(true)} />
    //             </div>
    //            </div>
    //             ),
    //     wrap: true,
    //   },

  ];

  // const products = [{
  //     SNo: "1",
  //     ProductName: "New100 ",
  //     Category: "$Dress",
  //     Createby: "27-09-2025",
  //     ID: "27-09-2026	",
  //     Stock: "10",
  //     Actions: ""
  // }]
  const invoicehandle = () => {

  }
  // const invoiceData = [{
  //     id:23,
  //     customerId: 1,
  //     customerName: "yara ",
  // }]

  const invoiceData = {
    customerId: 567,
    customerName: "Tricia McMillan",
    address1: "10a Watson Street",
    address2: "Islington",
    zipcode: "NSW 2296",

    invoiceNumber: 123,
    invoiceDate: "2025-12-09",
    cashier: "Mr. Cyrano Jones",

    items: [
      {
        code: "10001",
        name: "Our Best Product",
        qty: 4,
        price: "0,00 €",
        discount: "0,10 €",
        tax: 19,
      },
      {
        code: "10001",
        name: "Our Best Product",
        qty: 4,
        price: "0,00 €",
        discount: "0,10 €",
        tax: 19,
      },
      {
        code: "10001",
        name: "Our Best Product",
        qty: 4,
        price: "0,00 €",
        discount: "0,10 €",
        tax: 19,
      },
      {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      },
      {
        code: "1",
        name: "Super Savings",
        qty: 1,
        price: "0,00 €",
        discount: "0,00 €",
        tax: 19,
      },
      {
        code: "99999",
        name: "Zwischensumme",
        qty: "",
        price: "",
        discount: "",
        tax: "",
      },
      {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      },
      {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      }, {
        code: "50005",
        name: "High-End Device",
        qty: 1,
        price: "1.300 €",
        discount: "0,00 €",
        tax: 19,
      },
    ],

    subtotal: "1.300 €",
    total: "1.300 €",
  };

  const items = [
    {
      label: "Action",
      key: "1",
    },
    {
      label: "On process",
      key: "2",
    },
    {
      label: "On process",
      key: "3",
    }
  ];


  const handleConfirmClose = () => {
    setDeleteconfirmmodal(false)
  }
  const handleconfirmopen = () => {

    setDeleteconfirmmodal(false)

  }
  const handleRowClick = (row) => {

  };

  const [filterText, setFilterText] = useState("");
  const searchColumns = ['project_id', 'order_no', 'created_at', 'delivery_charge', 'delivery_type', 'discount_applied', 'invoice_no', 'user_email', 'user_mobile', 'user_name', 'status', 'payment_type', 'delivery_type', 'tax_amount', 'payment_status', 'total_amount', 'transaction_id', 'pickup_time', 'pickup_date', 'order_no'];
  const handleFilter = (event) => {
    setFilterText(event.target.value);
  };
  const filterdata = SearchData(ordertracking, filterText, searchColumns);
  const ordersToShow = filteredOrders.length > 0 ? filteredOrders : ordertracking;



  const filteredOrderId = ordertracking.filter((order) =>
    order.order_no.toLowerCase().includes(orderId.toLowerCase())
  );

  const filteredPaymentId = ordertracking.filter((order) =>
    order.payment_ref.toLowerCase().includes(paymentId.toLowerCase())
  );

  console.log("filtered_K", filteredOrderId);

  const [showFilterOrderId, setShowFilterOrderId] = useState(false);
  const [showFilterPaymentId, setShowFilterPaymentId] = useState(false);

  useEffect(() => {

    if (orderId.length === 0) {
      setShowFilterOrderId(false)
    }
    else if (orderId.length > 0) {
      setShowFilterOrderId(true)

    }

  }, [orderId])

  useEffect(() => {
    
    if (paymentId.length === 0) {
      setShowFilterPaymentId(false)
    }
    else if (paymentId.length > 0) {
      setShowFilterPaymentId(true)

    }
  },[paymentId])


  return (
    <>
      <div>
        {/* <h4>Tracking Order  List</h4> */}
      </div>

      <div>
        <div className='row py-3 px-lg- g-2 d-flex align-items-end'>
          <div className='col-12 col-md-2 position-relative'>
            <label htmlFor='' className='mb-2'>Order ID</label>
            {/* <input
                            type="text"
                            className="form-control opacity-75"
                            placeholder="Order ID..."
                            value={orderId}
                            onChange={(e) => setOrderId(e.target.value)}
                        /> */}
            <InputText
              className={`form-control opacity-75 ${forRedErrors && orderId === "" ? "border-danger" : ""}`}
              placeholder="Order ID..."
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
            />

            {showFilterOrderId && filteredOrderId.length > 0 && (
              <div className="overlay position-absolute rounded bg-white align-items-center"
                style={{ zIndex: "10" }}
              >
                {filteredOrderId.map((p) => (
                  <>
                    <p className='p-2' style={{ fontSize: "12px" }} onClick={() => setOrderId(p.order_no)}>{p.order_no}</p>
                    <hr className='mt-1 mb-1' />
                  </>

                ))}
              </div>
            )}

          </div>
          {/* <input
                            type="text"
                            className="form-control opacity-75"
                            placeholder="Payment ID"
                            value={paymentId}
                            onChange={(e) => setPaymentId(e.target.value)}
                        /> */}
          <div className='col-12 col-md-2 position-relative'>
            <label htmlFor='' className='mb-2'>Payment ID</label>
            
            <InputText
              className={`form-control opacity-75 mt-0 ${forRedErrors && paymentId === "" ? "border-danger" : ""}`}
              placeholder="Payment ID..."
              value={paymentId}
              onChange={(e) => setPaymentId(e.target.value)}
            />

            {showFilterPaymentId && filteredPaymentId.length > 0 && (
              <div className="overlay position-absolute rounded bg-white align-items-center"
                style={{ zIndex: "10" }}
              >
                {filteredPaymentId.map((p) => (
                  <>
                    <p className='p-2' style={{ fontSize: "12px" }} onClick={() => setPaymentId(p.payment_ref)}>{p.payment_ref}</p>
                    <hr className='mt-1 mb-1' />
                  </>

                ))}
              </div>
            )}
          </div>
          <div className='col-12 col-md-2'>
            {/* <label htmlFor=''  className='mb-2'>From Date</label>
                  <input text="date" className='form-control  opacity-75' id='date' name='date' placeholder='From Date' /> */}
            <div className="flex-auto ">
              <label htmlFor="buttondisplay" className="font-bold block mb-2">
                From Date
              </label>


              <DatePicker
                format="DD-MM-YYYY"
                value={date ? dayjs(date, "YYYY-MM-DD") : null}
                onChange={(date) => {
                  setDate(date ? date.format("YYYY-MM-DD") : null);
                }}
                style={{ width: "100%" }}
                className={`form-control opacity-75 mt-0 ${forRedErrors && date === null ? "border-danger" : ""}`}

              />

              {/* <Calendar className="small-calendar" value={date} onChange={(e) => (e.value)} showIcon /> */}
            </div>
          </div>
          <div className='col-12 col-md-2 '>
            {/* <label htmlFor=''  className='mb-2' >To Date</label>
                  <input text="date" className='form-control  opacity-75' id='date' name='date' placeholder='To Date' /> */}
            <div className="flex-auto">
              <label htmlFor="buttondisplay" className="font-bold block mb-2">
                To Date
              </label>
              {/* <Calendar id="buttondisplay" className="small-calendar" value={todate} onChange={(e) => setTodate(e.value)} showIcon /> */}
              <DatePicker
                format="DD-MM-YYYY"
                value={todate ? dayjs(todate, "YYYY-MM-DD") : null}
                onChange={(date) => {
                  setTodate(date ? date.format("YYYY-MM-DD") : null);
                }}
                className={`form-control opacity-75 mt-0 ${forRedErrors && todate === null ? "border-danger" : ""}`}

                style={{ width: "100%" }}
              />
            </div>
          </div>
          <div className='col-12 col-md-2'>
            <label className='mb-2'>Status</label>

            <PrimeDropdown
              value={status}
              onChange={(e) => setStatus(e.value)}
              options={[
                { label: "Pending", value: "Pending" },
                { label: "Order Placed", value: "Order Placed" },
                { label: "Processing", value: "Processing" },
                { label: "Packed", value: "Packed" },
                { label: "Ready for Pickup", value: "Ready for Pickup" },
                { label: "Shipped", value: "Shipped" },
                { label: "Picked Up", value: "Picked Up" },
                { label: "Delivered", value: "Delivered" },
                { label: "Cancelled", value: "Cancelled" },
                { label: "All", value: "all" }

              ]}
              optionLabel="label"
              placeholder="Select Status"
              // className="h-50 w-100 dropdownStatus_tracking"
              className={`h-50 w-100 dropdownStatus_tracking ${forRedErrors && status === "" ? "border-danger" : ""}`}

            // style={{height:"10px"}}
            />

          </div>

          <div className='d-flex gap-2 col-md-2'>
            <button type='button' className='btn btn-outline-secondary ' onClick={handleCancelFilter}
              style={{ height: "fit-content" }}
              disabled={orderId === "" && paymentId === "" && todate === null && date === null && status === "" ? true : false}

            >Clear</button>
            <button type='button' className='btn btn-outline-secondary ' onClick={handleFilterAll}
              style={{ height: "fit-content" }}
            >Filter</button>
          </div>
          {/* <div className='col-12 col-md-2 mt-4 ps-5'>
                        <button type='button' className='btn btn-outline-secondary mt-5 ms-3 ' onClick={handleFilterAll}>Filter</button>
                    </div> */}
        </div>
      </div>
      <div className='mt-5 box_shadow'>
        <div className='d-flex justify-content-between py-3 px-3'>
          <div>
            <h5> All Tracking Order  List</h5>
          </div>
          <div className='text-end position-relative'>
            <IoSearchOutline className="position-absolute top-50 end-0  translate-middle-y me-3 "
              size={18} />
            <input text="search" className='form-control opacity-75' id='' name='' placeholder='Search Filter.........' />
          </div>
        </div>
        <DataTable
          columns={columns}
          data={ordersToShow}
          customStyles={customStyle}
          pagination
          // selectableRows
          className='trackingOrderDataTable'
          onRowClicked={handleRowClick}
          fixedHeader
          persistTableHead={true}
        />
      </div>

      {/* <Dialog header="Confirm Delete Modal" visible={deleteconfirmmodal} position="top" style={{ width: '30vw' }} onHide={() => { if (!deleteconfirmmodal) return; setDeleteconfirmmodal(false); }}>

                <div className=" form-group">
                    <p>Do you want to delete this record?</p>
                </div>
                <div className="d-flex p-3 justify-content-end mt-3">
                  
                    <Stack direction="row" spacing={2}>
                        <Button variant="outlined" color="error"> No  </Button>&nbsp;
                    </Stack>

                  
                    <Button variant="contained" color="success">Yes </Button>
                </div>

            </Dialog> */}
      <Dialog header="Confirm view Modal" visible={viewconfirmmodal} position="top" style={{ width: '40vw' }} onHide={() => { if (!viewconfirmmodal) return; setViewconfirmmodal(false); }}>
        <div className='row'>
          <div className='col'>
            <p>Order ID  :</p>
            <p>Tracking status :</p>
            <p>Order status :</p>
            <p>Name :</p>
            <p>Phone :</p>
            <p>Invoice :</p>

          </div>
          <div className='col'>
            <p>Email :</p>
            <p>Details :</p>
            <p>Created at :</p>
            <p>Updated at :</p>
            <p>Amount :</p>
          </div>

        </div>

      </Dialog>


      {/* <div style={{ visibility: "hidden", position: "absolute" }}>
                    <Invoice ref={contentRef}  />
                </div>  */}

      <div style={{ position: "absolute", left: "-9999px", top: 0 }}>
        <Invoice ref={contentRef}
          data={dataForInvoice}
        // data={invoiceData}
        />
      </div>


    </>
  )
}

export default TrackingOrder