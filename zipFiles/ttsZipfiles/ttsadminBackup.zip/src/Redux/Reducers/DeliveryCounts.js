import { createSlice } from "@reduxjs/toolkit";

const initialState = 0;

const deliveybadge = createSlice({
  name: "deliverycount",
  initialState,
  reducers : {
    SetDeliveryCount: (state, action) => {
      return action.payload;
    }
  }
})
export const { SetDeliveryCount } = deliveybadge.actions;

export default deliveybadge.reducer;