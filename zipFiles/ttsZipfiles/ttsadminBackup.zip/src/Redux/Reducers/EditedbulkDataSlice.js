import { createSlice } from "@reduxjs/toolkit";

const initialState = null;

const EditedbulkDataSlice = createSlice({
  name: "editedbulkData",
  initialState,
  reducers: {
    SetEditedbulkData: (state, action) => {
      return action.payload;
    },
  },
});

export const { SetEditedbulkData } = EditedbulkDataSlice.actions;

export default EditedbulkDataSlice.reducer;
