import { createSlice } from "@reduxjs/toolkit";

const initialState = 0;

const pickedupbadge = createSlice({
  name: "pickupcount",
  initialState,
  reducers: {
    SetPickupCount: (state, action) => {
      return action.payload;
    },
  },
});

export const { SetPickupCount } = pickedupbadge.actions;

export default pickedupbadge.reducer;
