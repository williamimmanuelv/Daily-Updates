import { createSlice } from "@reduxjs/toolkit";

 const initialState = {
  adminlanguage: localStorage.getItem("adminlanguage")
    ? JSON.parse(localStorage.getItem("adminlanguage"))
    : "en",
 };
 const languageSlice = createSlice({
  name: "adminlanguage",
  initialState,
  reducers: {
    SetLanguage: (state, action) => {
      state.adminlanguage = action.payload;
      localStorage.setItem("adminlanguage", JSON.stringify(action.payload));
    },
  },
 });

export const { SetLanguage } = languageSlice.actions;
export default languageSlice.reducer;
