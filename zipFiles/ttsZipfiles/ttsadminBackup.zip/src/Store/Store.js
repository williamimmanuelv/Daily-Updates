import { configureStore } from "@reduxjs/toolkit";
import languageSlice from "../Redux/Reducers/languageSlice";
import pickedupbadge from "../Redux/Reducers/PickupCounts"
import deliverybadge from "../Redux/Reducers/DeliveryCounts"
import EditedbulkDataSlice from "../Redux/Reducers/EditedbulkDataSlice"


const Store = configureStore({
  reducer: {
    lng: languageSlice,
    pickupCount: pickedupbadge,
    diliveryCount: deliverybadge,
    editedBulkData: EditedbulkDataSlice 
  },
});



export default Store;