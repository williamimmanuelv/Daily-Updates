const customStyle = {
  
    headRow: {
      style: {
        backgroundColor: "lightgray",
        color: "black",
        
      },
    },
    headCells: {
      style: {
        fontSize: "15px",
        fontWeight: "600",
        textTransform: "capitalize",
        },
    },
    cells: {
      style: {
        fontSize: "14px",
        
      },
    },
  };

  export default customStyle;