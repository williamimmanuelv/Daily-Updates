

//   import invoicelogo from '../Assets/logo.png'
//   import React, { forwardRef } from "react";


//   const Invoice = forwardRef((props, ref) => {

//   const { data } = props;


//   const itemsPerPage = 37;

//   const pages = [];
//   for (let i = 0; i < data.items.length; i += itemsPerPage) {
//   pages.push(data.items.slice(i, i + itemsPerPage));
//   }
//    return (
//     <div ref={ref} style={{ padding: "40px", background: "#fff", width: "800px" }}>

//       {pages.map((items, pageIndex) => (
//         <div key={pageIndex} style={{ pageBreakAfter: "always" }}>


//           {pageIndex === 0 && (
//             <>

//               <div className="d-flex align-items-center" style={{ marginBottom: "30px" }}>
//                 <div className='w-25 h-25'>
//                 <img
//                   src={invoicelogo}
//                   style={{ width: "160px", height: "80px", objectFit: "contain" }}
//                   alt="logo"
//                 />
//                 </div>
//                 <div style={{ paddingLeft: "30px" }}>
//                   <h3 style={{ color: "red" ,border:"bottom"}}>TTS BROTHERS GmbH & Co.KG</h3>
//                 </div>
//               </div>


//               <div style={{ display: "flex", justifyContent: "space-between" }}>
//                 <div>
//                   <p style={{ fontWeight: "bold" }}>{data.customerName}</p>
//                   <p>{data.address1}</p>
//                   <p>{data.address2}</p>
//                   <p>{data.zipcode}</p>
//                 </div>

//                 <div>
//                   <p><b>Customer Number:</b> {data.customerId}</p>
//                   <p><b>Invoice Number:</b> {data.invoiceNumber}</p>
//                   <p><b>Invoice Date:</b> {data.invoiceDate}</p>
//                   <p><b>Cashier:</b> {data.cashier}</p>
//                 </div>
//               </div>

//               <h3 style={{ marginTop: "20px", fontWeight: "bold" }}>RECHNUNG</h3>
//             </>
//           )}


//           <table
//             width="100%"
//             cellPadding="8"
//             style={{ borderCollapse: "collapse", marginTop:`${pageIndex >0 ? "40px":"10px"} `, fontSize: "14px" }}
//           >
//            <thead>
//   <tr style={{ background: "#1a2126ff", fontWeight: "bold", color: "white" }}>
//     <th style={{ padding: "12px 8px" }}>Art.Nr.</th>
//     <th style={{ padding: "12px 8px" }}>Produkt</th>
//     <th style={{ padding: "12px 8px" }}>Menge</th>
//     <th style={{ padding: "12px 8px" }}>Preis</th>
//     <th style={{ padding: "12px 8px" }}>Rabatt</th>
//     <th style={{ padding: "12px 8px" }}>MwSt</th>
//   </tr>
// </thead>

//             <tbody>
//               {items.map((item, i) => (
//                 <tr key={i} style={{ background: i % 2 === 0 ? "#fafafa" : "#fff" }}>
//                   <td>{item.code}</td>
//                   <td>{item.name}</td>
//                   <td>{item.qty}</td>
//                   <td>{item.price}</td>
//                   <td>{item.discount}</td>
//                   <td>{item.tax}%</td>
//                 </tr>
//               ))}
//             </tbody>
//           </table>


//    {pageIndex === pages.length - 1 && (
//    <div style={{ marginTop: "40px", display: "flex", justifyContent: "space-between" }}>

//     <div style={{ textAlign: "left" }}>
//       <h3 style={{ margin: "5px 0" }}>
//         <b>Total:</b> {data.total}
//       </h3>

//       <div style={{ marginTop: "20px" }}>
//         <table style={{ width: "350px" }}>
//           <tbody>
//             <tr>
//               <td style={{ fontWeight: "bold" }}>Netto gesamt:</td>
//               <td style={{ fontWeight: "bold" }}>{data.subtotal}</td>
//             </tr>
//             <tr>
//               <td style={{ fontWeight: "bold" }}>Rabatt gesamt:</td>
//               <td style={{ fontWeight: "bold" }}>{data.discountTotal}</td>
//             </tr>
//             <tr>
//               <td style={{ fontWeight: "bold" }}>Brutto gesamt:</td>
//               <td style={{ fontWeight: "bold" }}>{data.total}</td>
//             </tr>
//           </tbody>
//         </table>
//       </div>
//     </div>


//     <table 
//       style={{ width: "320px", borderCollapse: "collapse" }} 
//       border="1" 
//       cellPadding="6"
//     >
//       <thead>
//         <tr>
//           <th>MwSt</th>
//           <th>Netto</th>
//           <th>MwSt</th>
//           <th>Brutto</th>
//         </tr>
//       </thead>

//       <tbody>
//         {data.taxTable?.map((row, idx) => (
//           <tr key={idx}>
//             <td>{row.taxRate}%</td>
//             <td>{row.net}</td>
//             <td>{row.taxAmount}</td>
//             <td>{row.gross}</td>
//           </tr>
//         ))}
//       </tbody>
//     </table>

//   </div>
//   )}
//   </div>
//       ))}

//     </div>
//   );
//  });

//  export default Invoice;

import invoicelogo from '../Assets/logo.png'
import React, { forwardRef } from "react";


const Invoice = forwardRef((props, ref) => {

  const { data } = props;
  console.log(props);

  console.log(data?.order?.delivery_charge.length);



  // Split items into chunks of 20 per page
  // const itemsPerPage = 39;
  // const pages = [];
  // for (let i = 0; i < data.items.length; i += itemsPerPage) {
  //   pages.push(data.items.slice(i, i + itemsPerPage));
  // }

  const itemsPerPage = 37;

  const pages = [];
  for (let i = 0; i < data?.items?.length; i += itemsPerPage) {
    pages.push(data?.items?.slice(i, i + itemsPerPage));
  }
  return (
    <div ref={ref} style={{ padding: "40px", background: "#fff", width: "800px" }}>

      {pages.map((items, pageIndex) => (
        <div key={pageIndex} style={{ pageBreakAfter: "always" }}>

          {/* ONLY FIRST PAGE SHOWS HEADER */}
          {pageIndex === 0 && (
            <>
              {/* HEADER + LOGO */}
              <div className="d-flex align-items-center" style={{ marginBottom: "30px" }}>
                <div className='w-25 h-25'>
                  <img
                    src={invoicelogo}
                    style={{ width: "160px", height: "80px", objectFit: "contain" }}
                    alt="logo"
                  />
                </div>
                <div style={{ paddingLeft: "30px" }}>
                  <h3 style={{ color: "red", border: "bottom" }}>TTS BROTHERS GmbH & Co.KG</h3>
                </div>
              </div>

              {/* CUSTOMER DETAILS */}
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <div>
                  {/* <p><b>Customer Number:</b> {data?.order?.id}</p> */}
                  <p><b>Invoice Number:</b> {data?.order?.invoice_no}</p>
                  <p><b>Invoice Date:</b> {data?.order?.created_at}</p>
                  <p><b>Order Number:</b>{data?.order?.order_no}</p>
                  <p><b>Address No.1:</b>{data.address1}</p>
                  <p><b>Address No.2:</b>{data.address2}</p>
                  <p><b>Zip code:</b>{data.zipcode}</p>
                  {/* <p><b>Billing Address :</b>{data?.order?.billing_address}</p> */}
                  {/* {data?.order?.cashier.length > 0  && <p><b>Cashier:</b> {data?.order?.cashier}</p>} */}
                </div>

                <div>
                  <p><b>Delivery Type:</b>{data?.order?.delivery_type}</p>
                  <p><b>Name:</b>{data?.order?.user_name}</p>
                  <p><b>Email:</b>{data?.order?.user_email}</p>
                  <p><b>Phone Number:</b>{data?.order?.user_mobile}</p>

                  {/* <p><b>Customer Number:</b> {data?.order?.user_mobile}</p>
                  <p><b>Invoice Number:</b> {data?.order?.user_id}</p>
                  <p><b>Invoice Date:</b> {data?.order?.created_at}</p>
                  <p><b>Cashier:</b> {data?.order?.cashier}</p> */}
                </div>
              </div>

              <h3 style={{ marginTop: "20px", fontWeight: "bold" }}>RECHNUNG</h3>
            </>
          )}

          {/* TABLE ALWAYS SHOWN */}
          <table
            width="100%"
            cellPadding="8"
            style={{ borderCollapse: "collapse", marginTop: `${pageIndex > 0 ? "40px" : "10px"} `, fontSize: "14px" }}
          >
            <thead>
              <tr style={{ background: "#1a2126ff", fontWeight: "bold", color: "white" }}>
                <th style={{ padding: "12px 8px" }}>Art.Nr.</th>
                <th style={{ padding: "12px 8px" }}>Produkt</th>
                <th style={{ padding: "12px 8px" }}>Menge</th>
                <th style={{ padding: "12px 8px" }}>Preis</th>
                <th style={{ padding: "12px 8px" }}>Total Preis</th>

                {/* <th style={{ padding: "12px 8px" }}>Rabatt</th>
                <th style={{ padding: "12px 8px" }}>MwSt</th> */}
              </tr>
            </thead>

            <tbody>
              {items?.map((item, i) => (
                <tr key={i} style={{ background: i % 2 === 0 ? "#fafafa" : "#fff" }}>
                  <td>{i + 1}</td>
                  <td>{item?.product_name}{item?.product_name}</td>
                  <td>{item?.qty}</td>
                  <td>{item?.item_price}</td>
                  <td>{item?.total_price}</td>
                  {/* <td>{item.discount}</td>
                  <td>{item.tax}%</td> */}
                </tr>
              ))}
            </tbody>
          </table>

          {/* ONLY LAST PAGE SHOWS TOTALS */}
          {pageIndex === pages.length - 1 && (
            <div style={{ marginTop: "40px", display: "flex", justifyContent: "space-between" }}>

              {/* LEFT SIDE TOTALS */}
              <div style={{ textAlign: "left" }}>
                <h3 style={{ margin: "5px 0" }}>
                  <b>Total:</b> {data?.order?.total_amount}
                </h3>

                <div style={{ marginTop: "20px" }}>
                  <table style={{ width: "350px" }}>
                    {/* <tbody>
                  <tr>
                    <td style={{ fontWeight: "bold" }}>Netto gesamt:</td>
                    <td style={{ fontWeight: "bold" }}>{data.subtotal}</td>
                  </tr>
                  <tr>
                    <td style={{ fontWeight: "bold" }}>Rabatt gesamt:</td>
                    <td style={{ fontWeight: "bold" }}>{data.discountTotal}</td>
                  </tr>
                  <tr>
                    <td style={{ fontWeight: "bold" }}>Brutto gesamt:</td>
                    <td style={{ fontWeight: "bold" }}>{data.total_amount}</td>
                  </tr>
                </tbody> */}
                    <tbody>
                      {data?.order?.delivery_charge.length > 0 &&
                        <tr>
                          <td style={{ fontWeight: "bold" }}>Deli gesamt:</td>
                          <td style={{ fontWeight: "bold" }}>{data?.order?.delivery_charge}</td>
                        </tr>}
                      {data?.order?.discount_applied !== "0.00" &&
                        <tr>
                          <td style={{ fontWeight: "bold" }}>Netto gesamt:</td>
                          <td style={{ fontWeight: "bold" }}>{data?.order?.discount_applied}</td>
                        </tr>
                      }
                      <tr>
                        <td style={{ fontWeight: "bold" }}>Rabatt gesamt:</td>
                        <td style={{ fontWeight: "bold" }}>{data?.order?.tax_amount}</td>
                      </tr>
                      <tr>
                        <td style={{ fontWeight: "bold" }}>Brutto gesamt:</td>
                        <td style={{ fontWeight: "bold" }}>{data?.order?.total_amount}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* RIGHT SIDE VAT TABLE */}
              {/* <table 
                    style={{ width: "320px", borderCollapse: "collapse" }} 
                    border="1" 
                    cellPadding="6"
                  >
                    <thead>
                  <tr>
                    <th>MwSt</th>
                    <th>Netto</th>
                    <th>MwSt</th>
                    <th>Brutto</th>
                  </tr>
                </thead>

                <tbody>
                  {data.taxTable?.map((row, idx) => (
                    <tr key={idx}>
                      <td>{row.taxRate}%</td>
                      <td>{row.net}</td>
                      <td>{row.taxAmount}</td>
                      <td>{row.gross}</td>
                    </tr>
                  ))}
                </tbody>
              </table> */}

            </div>
          )}
        </div>
      ))}

    </div>
  );
});

export default Invoice;







