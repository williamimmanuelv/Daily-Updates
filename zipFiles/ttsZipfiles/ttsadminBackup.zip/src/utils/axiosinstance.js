import axios from "axios";
import { base_url } from "../Api/BaseUrl";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
// import { base_url } from "./BaseUrl";

const axiosInstance = axios.create({
  baseURL: base_url,
  headers: {
    Accept: "application/json",
  
  },
});

// const navigate=useNavigate()
// useEffect(() => {
//   const token = localStorage.getItem("token");
  
//   if (!token) {
//     navigate("/login");
//   }
// }, [navigate]);

axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("tokenAdmin");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    if (config.data instanceof FormData) {
      delete config.headers["Content-Type"];
    } else {
      config.headers["Content-Type"] = "application/json";
    }

    return config;
  },
  (error) => Promise.reject(error)
);



export default axiosInstance;
